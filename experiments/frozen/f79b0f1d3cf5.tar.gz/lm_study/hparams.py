"""THE hyperparameter-knob registry -- single source of truth for every numeric knob that can be
swept from a YAML axis or overridden from the CLI.

One Knob row drives everything that previously kept hand-synced copies (adding `gate` meant editing
five lists across three files, and that drift already shipped one real bug -- an _emit_yaml that
dropped non-lr keys):
    run_sweep_lm.py   argparse flags (--lr / --kl-coef / ...), _OVERRIDE_KEYS, _HPARAM_KEYS
    run_yaml.py       _AXES (YAML key -> CLI flag -> tag abbrev -> caster)
    sweep_collect.py  per-cell hyperparameter columns + the axis summary

ORDER IS LOAD-BEARING: registry order is tag order (run_yaml appends `_{abbr}{value}` per set axis),
and tags name the CSVs that resume/skip logic keys on. Append new knobs at the END; never reorder or
rename an abbrev -- test_lm_helpers.py pins the (key, abbr) pairs for exactly this reason.
"""
from collections import namedtuple

Knob = namedtuple("Knob", "key cast abbr help")


def parse_bool(value):
    """Parse booleans consistently from YAML-native values and CLI strings."""

    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"expected a boolean, got {value!r}")


KNOBS = (
    Knob("lr", float, "lr", "override every method's default learning rate (for tuning/diagnostics)"),
    Knob("epochs", int, "e", "override update passes (GRPO PPO / RLOO / DPO / RAFT); ignored by AC-EM"),
    Knob("iters", int, "it", "override AC-EM M-step gradient iterations per round; ignored by methods without it"),
    Knob("beta", float, "b",
         "override beta where the method has one (EM advantage temp / DPO-APL); ignored by GRPO/RLOO/RAFT"),
    Knob("anchor", float, "anc",
         "override AC-EM base-prior anchor strength: w *= (p_base/p_theta)^anchor; ignored elsewhere"),
    Knob("causal", float, "c", "override AC-EM causal-tilt strength gamma (CVTO); ignored by methods without it"),
    Knob("pi_temp", float, "pt", "override AC-EM policy-factor temperature; ignored by methods without it"),
    Knob("sup", float, "sup",
         "AC-EM supervision fraction in [0,1] (M-step = (1-sup)*B_unsup + sup*B_sup; sup=1 = pure SFT, "
         "sup=0 = unsupervised); needs task.gold_solution; ignored elsewhere"),
    Knob("clip", float, "clip", "override GRPO PPO clip range; ignored elsewhere"),
    Knob("kl_coef", float, "kl",
         "low-level KL coefficient (GRPO/RLOO reward shaping; AC-EM/L2R in-loss penalty); "
         "new L2R YAMLs should use policy_kl_control"),
    Knob("top_frac", float, "tf", "override RAFT top-quantile fraction; ignored elsewhere"),
    Knob("pool_mult", int, "pm", "override APL acquisition pool multiplier; ignored elsewhere"),
    Knob("window", int, "w",
         "override the history window (AC-EM repair: fresh-only M-step at 1; legacy weighted-EM cap)"),
    Knob("gate", float, "g",
         "AC-EM per-question evidence gate: a question gets M-step mass only if its best sample's "
         "per-token answer prob clears this floor (SNIS validity; 0 = off); ignored elsewhere"),
    Knob("sup_warmup", int, "wu",
         "AC-EM curriculum: run the first N rounds at sup=1 (gold SFT) then drop to sup; ignored elsewhere"),
    Knob("reset_every", int, "rst",
         "AC-EM ReST: re-init the LoRA adapter+optimiser to base every N rounds (drift reset); ignored elsewhere"),
    Knob("buffer_limit", int, "buf",
         "AC-ALG1 per-question trace-buffer cap; 0 = unbounded; gold trace is preserved"),
    Knob("labelled_frac", float, "lf",
         "AC-ALG1 fraction of answer-known prompts and per-round question budget assigned to labelled L"),
    Knob("buffer_strategy", str, "bufs",
         "AC-ALG1 buffer pruning strategy: fifo or hybrid"),
    Knob("proposal_prompt", str, "prop",
         "candidate-generation prompt: AC-ALG1 supports question, derive_only, answer_hint, "
         "answer_derive, tagged_zero_shot, or tagged_gold_rationale; L2R supports question, "
         "answer_derive, or answer_derive_first"),
    Knob("proposal_filter", str, "pf",
         "AC-ALG1 candidate admission: all or answer_correct"),
    Knob("responsibility_score", str, "rs",
         "AC-ALG1 E-step logit: joint or token_mean"),
    Knob("responsibility_temperature", float, "rt",
         "AC-ALG1 positive E-step softmax temperature"),
    Knob("labelled_em_weight", float, "lem",
         "AC-ALG1 coefficient on the labelled latent-buffer term B'_unsup"),
    Knob("labelled_proposal_prompt", str, "lprop",
         "AC-ALG1 candidate-generation prompt override for labelled L' questions"),
    Knob("answer_only_proposal_prompt", str, "uprop",
         "AC-ALG1 candidate-generation prompt override for answer-only U' questions"),
    Knob("labelled_numeric_constraint", str, "lnc",
         "AC-ALG1 labelled E-step arithmetic potential: off, hard, soft, or graph_hard"),
    Knob("numeric_penalty", float, "npen",
         "AC-ALG1 per-invalid-equation log penalty for the soft labelled numeric constraint"),
    Knob("labelled_supervision", str, "lsup",
         "AC-ALG1 B_sup target: gold, gold_compact_mix, gold_compact_set, or gold_graph_factorized"),
    Knob("compact_gold_weight", float, "cgw",
         "AC-ALG1 compact-target weight in gold_compact_mix supervision"),
    Knob("numeric_contradiction_penalty", float, "ncp",
         "AC-ALG1 per-gold-contradiction log penalty for the soft labelled numeric constraint"),
    Knob("numeric_missing_penalty", float, "nmp",
         "AC-ALG1 per-missing calculation-graph item log penalty for the soft labelled numeric constraint"),
    Knob("digit_token_weight", float, "dtw",
         "AC-ALG1 scale-preserving relative B_sup weight on digit-bearing target tokens"),
    Knob("trace_representation", str, "trep",
         "AC-ALG1 trace representation: reasoning or calculation_graph"),
    Knob("answer_only_em_weight", float, "uem",
         "AC-ALG1 coefficient on the answer-only latent-buffer term B_unsup"),
    Knob("policy_kl_coef", float, "pkl",
         "low-level AC-ALG1 token-level KL-to-frozen-policy coefficient; new YAMLs should use "
         "policy_kl_control"),
    Knob("supervised_weight", float, "sw",
         "AC-ALG1 coefficient on the supervised gold-rationale term B_sup"),
    Knob("policy_anchor_mode", str, "pam",
         "resolved AC-ALG1/L2R policy-anchor mode; new YAMLs should use policy_kl_control"),
    Knob("policy_anchor_target_ratio", float, "rho",
         "AC-ALG1/L2R target ||beta*g_KL|| / ||g_objective|| for grad_ratio anchoring"),
    Knob("policy_anchor_beta_min", float, "pbmin",
         "AC-ALG1 lower clip for the adaptive policy-anchor coefficient"),
    Knob("policy_anchor_beta_max", float, "pbmax",
         "AC-ALG1 upper clip for the adaptive policy-anchor coefficient"),
    Knob("policy_anchor_ema", float, "pema",
         "AC-ALG1 EMA decay for adaptive policy-anchor gradient norms"),
    Knob("archive_limit", int, "arch",
         "L2R per-question trace archive cap; zero is unbounded"),
    Knob("replay_limit", int, "rep",
         "L2R per-question active replay cap after gold/elite/recent selection"),
    Knob("trace_segmentation", str, "tseg",
         "L2R latent-trace extraction: legacy or validated terminal-answer segmentation"),
    Knob("responsibility_projection", str, "rproj",
         "L2R posterior safe-set interpolation: none or safe_set"),
    Knob("responsibility_max_weight", float, "rmax",
         "L2R per-question maximum posterior trace weight under safe_set projection"),
    Knob("trust_kl_budget", float, "tkl",
         "L2R fresh-support token-level k3 ceiling for trust-region acceptance"),
    Knob("trust_safety_questions", int, "tsq",
         "L2R trailing training questions reserved from optimisation for safety checks"),
    Knob("trust_safety_tolerance", float, "tst",
         "L2R maximum accepted increase in safety-set rationale NLL"),
    Knob("trust_boundary_failure_ceiling", float, "tbfc",
         "L2R maximum invalid-segmentation fraction for an accepted trust-region step"),
    Knob("trust_max_backtracks", int, "tmb",
         "L2R reduced-size candidate updates attempted after trust-region rejection"),
    Knob("trust_backtrack_shrink", float, "tbs",
         "L2R learning-rate multiplier for each trust-region backtrack"),
    Knob("historical_replay_fraction", float, "hrep",
         "L2R update-question fraction replaced by uniformly sampled historical questions"),
    Knob("adaptive_max_g", int, "ag",
         "L2R maximum traces per question under adaptive sampling; zero uses fixed G"),
    Knob("adaptive_batch_g", int, "abg",
         "L2R traces added per unresolved question at each adaptive sampling pass"),
    Knob("adaptive_min_correct", int, "amc",
         "L2R correct proposals required before adaptive sampling stops for a question"),
    Knob("lora_r", int, "lorar",
         "LoRA rank loaded for a cell; structural L2R studies use rank two for surgical updates"),
    Knob("lora_alpha", int, "loraa",
         "LoRA alpha; set proportionally to rank when rank is an experimental factor"),
    Knob("lora_seed", int, "loras",
         "LoRA factor initialisation seed, decoupled from proposal and training randomness"),
    Knob("lora_trainable", str, "lorat",
         "L2R trainable adapter factors: all or b_only"),
    Knob("gradient_projection", str, "gproj",
         "L2R M-step gradient projection: none, basis, or a matched random subspace"),
    Knob("gradient_projection_rank", int, "gpr",
         "L2R empirical/random gradient-subspace rank; zero when projection is disabled"),
    Knob("buffer_replicates", int, "brep",
         "L2R parallel posterior buffers sharing the same total per-question proposal budget"),
    Knob("question_schedule", str, "qs",
         "L2R question schedule: uniform, cyclic, or failure/uncertainty/age priority"),
    Knob("schedule_exploration", float, "qse",
         "L2R priority-schedule fraction reserved for uniform exploration"),
    Knob("update_geometry", str, "ug",
         "AC-ALG1 M-step gradient combination: sum, mgda, normalized_mgda, or answer_primary"),
    Knob("step_acceptance", str, "sa",
         "AC-ALG1 post-Adam fixed-surrogate rule: none, total, componentwise, or answer_primary"),
    Knob("rollback_tolerance", float, "rbtol",
         "AC-ALG1 absolute no-harm tolerance used by safeguarded M-step acceptance"),
    Knob("rollback_max_backtracks", int, "rbn",
         "AC-ALG1 reduced-size candidate steps tried after a rollback"),
    Knob("rollback_shrink", float, "rbs",
         "AC-ALG1 learning-rate multiplier applied at each rollback backtrack"),
    Knob("optimizer_state_scope", str, "opts",
         "AC-ALG1 Adam state lifetime: persistent or outer_round"),
    Knob("proposal_policy", str, "ppol",
         "AC-ALG1 proposal sampler: current adapter or frozen_base"),
    Knob("responsibility_ess_floor", float, "ress",
         "AC-ALG1/L2R one-sided minimum responsibility ESS fraction; zero disables it"),
    Knob("responsibility_policy", str, "rpol",
         "AC-ALG1 E-step scorer: current adapter or frozen_base"),
    Knob("responsibility_answer_policy", str, "rapol",
         "AC-ALG1 answer-reader factor: current adapter or frozen_base"),
    Knob("responsibility_refresh", str, "rref",
         "AC-ALG1 E-step refresh: inner_step or outer_round"),
    Knob("responsibility_verifier_rollouts", int, "rvk",
         "AC-ALG1 free-decoding answer continuations per trace; zero disables rollout value"),
    Knob("responsibility_verifier_temperature", float, "rvt",
         "AC-ALG1 rollout-value continuation sampling temperature"),
    Knob("responsibility_verifier_max_new_tokens", int, "rvn",
         "AC-ALG1 rollout-value maximum answer-continuation tokens"),
    Knob("responsibility_verifier_batch_size", int, "rvb",
         "AC-ALG1 rollout-value continuation generation microbatch"),
    Knob("responsibility_verifier_smoothing_alpha", float, "rva",
         "AC-ALG1 symmetric Beta smoothing for finite rollout-value logits"),
    Knob("optimizer_step_scope", str, "ostep",
         "GRPO optimizer stepping: legacy per-microbatch or accumulated per rollout batch"),
    Knob("proposal_mixture", str, "pmix",
         "AC-ALG1 proposal support: single, question_answer, or question_answer_graph"),
    Knob("proposal_prior_fraction", float, "ppf",
         "L2R mixed-proposal probability assigned to the canonical question-only prior"),
    Knob("l2r_buffer_semantics", str, "l2rbuf",
         "L2R buffer estimator: set_archive preserves legacy deduplicated replay; "
         "fresh_multiset retains every current-round proposal draw"),
    Knob("mstep_objective", str, "mobj",
         "L2R M-step factor: generator updates log p(h|q); joint also updates "
         "the teacher-forced log p(a*|h,q) factor"),
    Knob("policy_anchor_scope", str, "pas",
         "L2R token-level base anchor scope: generator or generator_and_reader"),
    Knob("buffer_semantics", str, "bsem",
         "AC-ALG1 trace collection: multiset_legacy preserves historical replay; "
         "unique_set rejects token-identical traces per question"),
    Knob("responsibility_posterior", str, "rpost",
         "AC-ALG1 E-step posterior: softmax_entropy or hard_delta_no_entropy"),
    Knob("lora_target_set", str, "loratgt",
         "LoRA module coverage: attention uses q/k/v/o projections; attention_mlp also "
         "adapts gate/up/down MLP projections on supported model presets"),
    Knob("weight", str, "weight",
         "AC-EM/weighted-EM responsibility family: RW, AW, or AAW"),
    Knob("hindsight", parse_bool, "hs",
         "AC-EM answer-conditioned proposal toggle"),
    Knob("offline", parse_bool, "off",
         "DPO data mode: false is online iterative DPO; true is fixed offline DPO"),
    Knob("micro", int, "micro",
         "trainer microbatch size; recorded because legacy optimizer stepping can depend on it"),
    Knob("length_norm", parse_bool, "ln",
         "use token-mean rather than sequence-sum log probabilities in supported objectives"),
    Knob("acq", str, "acq",
         "APL acquisition rule"),
    Knob("train_span", str, "span",
         "AC-EM trained token span: both, h, or ans"),
    Knob("select", str, "sel",
         "AC-EM posterior selection: soft or top1"),
    Knob("centered", parse_bool, "ctr",
         "AC-EM centered-weight policy-gradient form"),
    Knob("dconsist", parse_bool, "dc",
         "AC-EM free-decoding consistency filter"),
    Knob("frozen_critic", parse_bool, "fc",
         "AC-EM frozen-base answer-reader toggle"),
    Knob("gold_in_buffer", parse_bool, "gold",
         "inject each available gold rationale into the per-question trace buffer"),
    Knob("policy_factor", parse_bool, "polf",
         "conditional-VRO policy-factor toggle"),
    Knob("reader_mode", str, "reader",
         "L2R answer-reader semantics: moving or frozen"),
    Knob("reader_decode_filter", parse_bool, "rdf",
         "L2R free-decoding reader-consistency gate"),
    Knob("algorithm_profile", str, "aprof",
         "AC-ALG1 compatibility profile: legacy, barber_source, "
         "l2r_common_factorial, barber_stability_ablation, barber_reader_ablation, "
         "barber_importance_ablation, barber_persistent_bridge, or "
         "barber_verifier"),
    Knob("variational_estimator", str, "vest",
         "AC-ALG1 finite-support estimator: delta_joint, uniform_mc, "
         "prior_importance, frozen_prior_importance, or "
         "fresh/persistent answer_conditioned_importance"),
    Knob("buffer_lifecycle", str, "blife",
         "AC-ALG1 support lifetime: persistent, fresh_round, or fixed_bank"),
    Knob("latent_mstep_objective", str, "lmobj",
         "AC-ALG1 latent M-step token span: joint, answer, or rationale"),
    Knob("reward_requires_eos", parse_bool, "reos",
         "online-RL/rejection-SFT reward requires a naturally emitted EOS after the terminal answer"),
)

# Kept as an extension point for non-overridable runtime metadata. Every
# scientific trainer parameter used by a registered method is now in KNOBS.
CONFIG_KEYS = ()


def flag(key):
    """CLI flag for a knob key ('kl_coef' -> '--kl-coef'); argparse maps it back to `key` as the dest."""
    return "--" + key.replace("_", "-")
