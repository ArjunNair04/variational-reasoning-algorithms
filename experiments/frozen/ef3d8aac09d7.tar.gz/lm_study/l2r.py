"""Scalable answer-conditioned Learning-to-Reason (L2R) trainer.

The latent-reasoning factorisation is

    p(a* | q) = sum_h p_reader(a* | q, h) p_generator(h | q).

This module isolates the two factors. The LoRA policy proposes and learns only
reasoning tokens. The answer reader can be frozen at the pretrained base model,
so optimisation cannot improve its own E-step reward by changing the answer
head. One official gold rationale may be retained in each per-question archive.

The implementation is intended for scaling studies:

* question breadth and traces per question are explicit through ``B`` and ``G``;
* optional adaptive sampling spends extra traces only on unresolved questions;
* bounded per-question archives avoid quadratic growth over long horizons;
* compact replay preserves gold, high-responsibility, and recent traces;
* every M-step uses the complete detached weighted replay support;
* rollout, generated-token, backward-token, buffer, and posterior diagnostics
  are emitted for matched-compute comparisons with GRPO.
"""
from __future__ import annotations

from contextlib import nullcontext
from dataclasses import dataclass
import math
import os
import re
from typing import Iterable

import numpy as np
import torch

from common import DEV, MODEL_NAME, format_rate, load_model, maybe_eval, sample_multi, seq_logprobs
from l2r_structural import (
    GRADIENT_PROJECTION_MODES,
    LORA_TRAINABLE_MODES,
    QUESTION_SCHEDULES,
    GradientProjector,
    QuestionScheduler,
    configure_lora_trainable,
    replicated_responsibilities,
)


RESPONSIBILITY_SCORES = {"joint", "token_mean"}
READER_MODES = {"moving", "frozen"}
PROPOSAL_PROMPTS = {"question", "answer_derive", "answer_derive_first"}


@dataclass
class L2RTrace:
    """One question-anchored latent rationale followed by a teacher-forced answer."""

    ids: torch.Tensor
    h_mask: torch.Tensor
    a_mask: torch.Tensor
    pid: int
    round_added: int
    completion_key: tuple[int, ...]
    text: str
    replica: int = 0
    is_gold: bool = False
    proposal_correct: bool | None = None
    generated_tokens: int = 0
    proposal_prompt: str = "question"
    target_mentioned_before_final: bool | None = None
    target_before_equation: bool | None = None
    has_equation: bool | None = None
    last_responsibility: float = 0.0

    @property
    def h_tokens(self) -> int:
        return int(self.h_mask.sum())


def l2r_responsibilities(
    policy_h_logps: torch.Tensor,
    reader_a_logps: torch.Tensor,
    h_lengths: torch.Tensor,
    a_lengths: torch.Tensor,
    pids: torch.Tensor,
    *,
    score: str = "joint",
    temperature: float = 1.0,
    active: torch.Tensor | None = None,
) -> torch.Tensor:
    """Normalise detached L2R responsibilities independently per question."""

    if score not in RESPONSIBILITY_SCORES:
        raise ValueError(f"unknown L2R responsibility score {score!r}")
    if not math.isfinite(temperature) or temperature <= 0:
        raise ValueError(f"temperature must be finite and positive, got {temperature}")
    shape = policy_h_logps.shape
    if any(values.shape != shape for values in (reader_a_logps, h_lengths, a_lengths, pids)):
        raise ValueError("all L2R responsibility inputs must have the same shape")
    if active is None:
        active = torch.ones_like(policy_h_logps, dtype=torch.bool)
    if active.shape != shape:
        raise ValueError("active mask must align with responsibility inputs")

    if score == "token_mean":
        logits = (
            policy_h_logps / h_lengths.clamp_min(1).to(policy_h_logps.dtype)
            + reader_a_logps / a_lengths.clamp_min(1).to(reader_a_logps.dtype)
        )
    else:
        logits = policy_h_logps + reader_a_logps

    weights = torch.zeros_like(logits)
    for pid in torch.unique(pids, sorted=True):
        local = (pids == pid) & active
        if bool(local.any()):
            weights[local] = torch.softmax(logits[local] / temperature, dim=0)
    return weights


def select_replay_indices(
    traces: list[L2RTrace],
    logits: torch.Tensor,
    replay_limit: int,
) -> list[int]:
    """Select gold, elite, and recent traces within one question archive."""

    if replay_limit <= 0 or len(traces) <= replay_limit:
        return list(range(len(traces)))
    gold = [index for index, trace in enumerate(traces) if trace.is_gold]
    if len(gold) >= replay_limit:
        return gold[:replay_limit]

    sampled = [index for index, trace in enumerate(traces) if not trace.is_gold]
    slots = replay_limit - len(gold)
    recent_slots = (slots + 1) // 2
    recent = sorted(
        sampled,
        key=lambda index: (traces[index].round_added, index),
        reverse=True,
    )[:recent_slots]
    recent_set = set(recent)
    elite = sorted(
        (index for index in sampled if index not in recent_set),
        key=lambda index: (float(logits[index]), traces[index].round_added, index),
        reverse=True,
    )[: slots - len(recent)]
    return sorted(gold + recent + elite)


def _reason_cut(text: str) -> int:
    cut = len(text)
    for marker in (
        "####",
        "</think>",
        "<answer>",
        "\nQuestion:",
        "\n\nQuestion:",
        "\nQ:",
        "\nUser:",
    ):
        index = text.find(marker)
        if index != -1:
            cut = min(cut, index)
    return cut


def _reasoning_token_prefix(tok, completion_ids: list[int], text: str) -> list[int]:
    if completion_ids and completion_ids[-1] == tok.eos_token_id:
        completion_ids = completion_ids[:-1]
    cut = _reason_cut(text)
    if cut >= len(text):
        return completion_ids
    lo, hi = 0, len(completion_ids)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if len(tok.decode(completion_ids[:mid])) <= cut:
            lo = mid
        else:
            hi = mid - 1
    return completion_ids[:lo]


def _proposal_prompt(base_prompt: str, answer, mode: str) -> str:
    """Build a proposal-only prompt while preserving the original q prompt for scoring.

    The answer-visible modes alter only the distribution used to discover finite
    buffer support. Every accepted trace is subsequently re-anchored under the
    unmodified question prompt before either factor in the L2R posterior is
    scored or trained.
    """

    if mode not in PROPOSAL_PROMPTS:
        raise ValueError(
            f"unknown L2R proposal prompt {mode!r}; expected one of "
            f"{sorted(PROPOSAL_PROMPTS)}"
        )
    if mode == "question":
        return base_prompt
    marker = "\nAnswer:"
    split = base_prompt.rfind(marker)
    if split < 0 or base_prompt[split + len(marker):].strip():
        raise ValueError(
            "answer-conditioned L2R proposals require a prompt ending in "
            "'\\nAnswer:'"
        )
    question_prefix = base_prompt[:split]
    target = str(answer)
    if mode == "answer_derive":
        instruction = (
            f"(Note: the correct final answer is {target}. Please create a "
            "complete step-by-step rationale for the question that leads to "
            f"this answer. End with #### {target}.)"
        )
    else:
        instruction = (
            f"(For verification only, the correct final answer is {target}. "
            "Solve the problem forward from the stated quantities. Do not "
            "reveal or cite the supplied answer until the final line. Show "
            f"every calculation, then end with #### {target}.)"
        )
    return f"{question_prefix}\n{instruction}{marker}"


_NUMBER_RE = re.compile(r"(?<![\d,])-?\d[\d,]*(?![\d,])")
_EQUATION_RE = re.compile(
    r"-?\d[\d,]*(?:\.\d+)?\s*(?:[+\-*/=×÷]|[xX](?=\s*\d))"
)


def _proposal_text_diagnostics(text: str, answer) -> dict[str, bool]:
    """Cheap leakage/support diagnostics that never affect training."""

    final_marker = text.find("####")
    reasoning = text if final_marker < 0 else text[:final_marker]
    target = int(answer) if answer is not None else None
    target_positions = []
    if target is not None:
        for match in _NUMBER_RE.finditer(reasoning):
            try:
                value = int(match.group(0).replace(",", ""))
            except ValueError:
                continue
            if value == target:
                target_positions.append(match.start())
    equation = _EQUATION_RE.search(reasoning)
    first_target = min(target_positions) if target_positions else None
    return {
        "target_mentioned_before_final": first_target is not None,
        "target_before_equation": (
            first_target is not None
            and (equation is None or first_target < equation.start())
        ),
        "has_equation": equation is not None,
    }


def _make_trace(
    tok,
    prompt_ids: torch.Tensor,
    h_ids: list[int],
    answer,
    *,
    pid: int,
    round_added: int,
    text: str,
    is_gold: bool,
    proposal_correct: bool | None,
    generated_tokens: int,
    replica: int = 0,
    proposal_prompt: str = "question",
    target_mentioned_before_final: bool | None = None,
    target_before_equation: bool | None = None,
    has_equation: bool | None = None,
) -> L2RTrace:
    a_ids = tok(f"\n#### {answer}", add_special_tokens=False).input_ids
    full = torch.tensor(
        prompt_ids.tolist() + h_ids + a_ids,
        dtype=torch.long,
    )
    h_mask = torch.zeros(len(full), dtype=torch.bool)
    h_mask[len(prompt_ids):len(prompt_ids) + len(h_ids)] = True
    a_mask = torch.zeros(len(full), dtype=torch.bool)
    a_mask[len(prompt_ids) + len(h_ids):] = True
    return L2RTrace(
        ids=full,
        h_mask=h_mask,
        a_mask=a_mask,
        pid=int(pid),
        round_added=int(round_added),
        completion_key=tuple(int(token) for token in h_ids),
        text=text,
        replica=int(replica),
        is_gold=bool(is_gold),
        proposal_correct=proposal_correct,
        generated_tokens=int(generated_tokens),
        proposal_prompt=proposal_prompt,
        target_mentioned_before_final=target_mentioned_before_final,
        target_before_equation=target_before_equation,
        has_equation=has_equation,
    )


def _gold_trace(tok, task, prompt_ids: torch.Tensor, pid: int, round_added: int) -> L2RTrace | None:
    if not hasattr(task, "gold_solution") or task.gold_answer[pid] is None:
        return None
    solution = task.gold_solution[pid]
    if not solution:
        return None
    reasoning = solution.split("####", 1)[0].rstrip()
    h_ids = tok(" " + reasoning, add_special_tokens=False).input_ids
    return _make_trace(
        tok,
        prompt_ids,
        h_ids,
        task.gold_answer[pid],
        pid=pid,
        round_added=round_added,
        text=reasoning,
        is_gold=True,
        proposal_correct=True,
        generated_tokens=0,
        replica=-1,
    )


def _append_unique(buffers: dict[int, list[L2RTrace]], trace: L2RTrace) -> bool:
    rows = buffers.setdefault(trace.pid, [])
    if any(row.completion_key == trace.completion_key for row in rows):
        return False
    rows.append(trace)
    return True


def _prune_archive(
    rows: list[L2RTrace],
    archive_limit: int,
    buffer_replicates: int = 1,
) -> int:
    """Bound one archive while preserving gold, prior elites, and recent traces."""

    if archive_limit <= 0 or len(rows) <= archive_limit:
        return 0
    gold = [row for row in rows if row.is_gold]
    sampled = [row for row in rows if not row.is_gold]
    slots = max(archive_limit - len(gold), 0)
    if buffer_replicates > 1:
        keep_rows = list(gold)
        base, remainder = divmod(slots, buffer_replicates)
        for replica in range(buffer_replicates):
            local = [row for row in sampled if row.replica == replica]
            local_slots = base + int(replica < remainder)
            recent_slots = (local_slots + 1) // 2
            recent = sorted(
                local,
                key=lambda row: row.round_added,
                reverse=True,
            )[:recent_slots]
            recent_ids = {id(row) for row in recent}
            elite = sorted(
                (row for row in local if id(row) not in recent_ids),
                key=lambda row: (row.last_responsibility, row.round_added),
                reverse=True,
            )[: local_slots - len(recent)]
            keep_rows.extend(recent + elite)
        keep = {id(row) for row in keep_rows}
        before = len(rows)
        rows[:] = [row for row in rows if id(row) in keep]
        return before - len(rows)
    recent_slots = (slots + 1) // 2
    recent = sorted(
        sampled,
        key=lambda row: row.round_added,
        reverse=True,
    )[:recent_slots]
    recent_ids = {id(row) for row in recent}
    elite = sorted(
        (row for row in sampled if id(row) not in recent_ids),
        key=lambda row: (row.last_responsibility, row.round_added),
        reverse=True,
    )[: slots - len(recent)]
    keep = {id(row) for row in gold + recent + elite}
    before = len(rows)
    rows[:] = [row for row in rows if id(row) in keep]
    return before - len(rows)


def _pad(
    rows: Iterable[L2RTrace],
    pad_token_id: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    rows = list(rows)
    pad = torch.nn.utils.rnn.pad_sequence
    ids = pad([row.ids for row in rows], batch_first=True, padding_value=pad_token_id)
    h_mask = pad([row.h_mask for row in rows], batch_first=True, padding_value=False)
    a_mask = pad([row.a_mask for row in rows], batch_first=True, padding_value=False)
    return ids.to(DEV), h_mask.to(DEV), a_mask.to(DEV)


def _generate_rows(
    model,
    tok,
    task,
    prompt_ids: list[torch.Tensor],
    pid_row: list[int],
    *,
    round_added: int,
    proposal_prompt: str,
    replica_row: list[int] | None = None,
) -> tuple[list[L2RTrace], list[str], int]:
    if not pid_row:
        return [], [], 0
    if replica_row is None:
        replica_row = [0] * len(pid_row)
    if len(replica_row) != len(pid_row):
        raise ValueError("replica_row must align with pid_row")
    prompts = [
        _proposal_prompt(task.prompts[pid], task.gold_answer[pid], proposal_prompt)
        for pid in pid_row
    ]
    ids, mask, texts = sample_multi(
        model,
        tok,
        prompts,
        max_new=getattr(task, "max_new", 40),
    )
    rewards = task.reward(texts, pids=pid_row)
    floor = float(getattr(task, "floor", 0.0))
    rows = []
    generated_tokens = 0
    for index, (pid, replica) in enumerate(zip(pid_row, replica_row)):
        token_count = int(mask[index].sum())
        generated_tokens += token_count
        completion = ids[index][mask[index]].detach().cpu().tolist()
        h_ids = _reasoning_token_prefix(tok, completion, texts[index])
        text_diagnostics = _proposal_text_diagnostics(
            texts[index],
            task.gold_answer[pid],
        )
        rows.append(
            _make_trace(
                tok,
                prompt_ids[pid],
                h_ids,
                task.gold_answer[pid],
                pid=pid,
                round_added=round_added,
                text=texts[index],
                is_gold=False,
                proposal_correct=bool(float(rewards[index]) > floor + 0.5),
                generated_tokens=token_count,
                replica=replica,
                proposal_prompt=proposal_prompt,
                **text_diagnostics,
            )
        )
    return rows, texts, generated_tokens


def _sample_round(
    model,
    tok,
    task,
    prompt_ids: list[torch.Tensor],
    *,
    B: int,
    G: int,
    rng: np.random.Generator,
    round_added: int,
    adaptive_max_g: int,
    adaptive_batch_g: int,
    adaptive_min_correct: int,
    proposal_prompt: str,
    buffer_replicates: int = 1,
    selected_pids: list[int] | None = None,
) -> tuple[list[int], list[L2RTrace], list[str], dict]:
    n_questions = B // G
    if n_questions > len(task.prompts):
        raise ValueError(
            f"B//G requests {n_questions} unique questions from a pool of {len(task.prompts)}"
        )
    if G % buffer_replicates:
        raise ValueError(
            f"G must be divisible by buffer_replicates, got G={G}, "
            f"buffer_replicates={buffer_replicates}"
        )
    if selected_pids is None:
        pids = [
            int(pid)
            for pid in rng.choice(
                len(task.prompts),
                size=n_questions,
                replace=False,
            )
        ]
    else:
        pids = [int(pid) for pid in selected_pids]
        if len(pids) != n_questions or len(set(pids)) != len(pids):
            raise ValueError("selected_pids must contain B//G unique question ids")
        if any(pid < 0 or pid >= len(task.prompts) for pid in pids):
            raise ValueError("selected_pids contains an out-of-range question id")
    per_replica = G // buffer_replicates
    initial_pid_row = []
    initial_replica_row = []
    for pid in pids:
        for replica in range(buffer_replicates):
            initial_pid_row.extend([pid] * per_replica)
            initial_replica_row.extend([replica] * per_replica)
    rows, texts, generated_tokens = _generate_rows(
        model,
        tok,
        task,
        prompt_ids,
        initial_pid_row,
        round_added=round_added,
        proposal_prompt=proposal_prompt,
        replica_row=initial_replica_row,
    )
    counts = {pid: G for pid in pids}
    correct = {pid: 0 for pid in pids}
    for row in rows:
        correct[row.pid] += int(row.proposal_correct is True)

    extra_rows = []
    extra_texts = []
    extra_tokens = 0
    if adaptive_max_g > G:
        while True:
            pid_row = []
            replica_row = []
            for pid in pids:
                if correct[pid] >= adaptive_min_correct or counts[pid] >= adaptive_max_g:
                    continue
                add = min(adaptive_batch_g, adaptive_max_g - counts[pid])
                for local_index in range(add):
                    pid_row.append(pid)
                    replica_row.append(
                        (counts[pid] + local_index) % buffer_replicates
                    )
                counts[pid] += add
            if not pid_row:
                break
            new_rows, new_texts, new_tokens = _generate_rows(
                model,
                tok,
                task,
                prompt_ids,
                pid_row,
                round_added=round_added,
                proposal_prompt=proposal_prompt,
                replica_row=replica_row,
            )
            extra_rows.extend(new_rows)
            extra_texts.extend(new_texts)
            extra_tokens += new_tokens
            for row in new_rows:
                correct[row.pid] += int(row.proposal_correct is True)

    all_rows = rows + extra_rows
    stats = {
        "questions": len(pids),
        "initial_generations": len(rows),
        "adaptive_generations": len(extra_rows),
        "generations": len(all_rows),
        "generated_tokens": generated_tokens + extra_tokens,
        "mean_g": float(np.mean(list(counts.values()))),
        "max_g": max(counts.values(), default=0),
        "resolved_initial": sum(
            any(row.pid == pid and row.proposal_correct for row in rows) for pid in pids
        ),
        "resolved_final": sum(correct[pid] >= adaptive_min_correct for pid in pids),
        "target_mentioned_before_final_fraction": float(np.mean([
            row.target_mentioned_before_final is True for row in all_rows
        ])),
        "target_before_equation_fraction": float(np.mean([
            row.target_before_equation is True for row in all_rows
        ])),
        "equation_fraction": float(np.mean([
            row.has_equation is True for row in all_rows
        ])),
    }
    return pids, all_rows, texts + extra_texts, stats


def _reader_decode_correct(
    model,
    tok,
    task,
    rows: list[L2RTrace],
    *,
    reader_mode: str,
    max_new: int = 12,
    batch_size: int = 16,
) -> tuple[list[bool], int]:
    """Greedily decode answers from q+h without teacher-forcing a*."""

    prefixes = []
    for row in rows:
        answer_positions = row.a_mask.nonzero()
        stop = int(answer_positions[0]) if len(answer_positions) else len(row.ids)
        prefixes.append(row.ids[:stop])
    outputs = []
    generated_tokens = 0
    context = model.disable_adapter() if reader_mode == "frozen" else nullcontext()
    model.eval()
    with context, torch.no_grad():
        for start in range(0, len(prefixes), batch_size):
            chunk = prefixes[start:start + batch_size]
            width = max(len(prefix) for prefix in chunk)
            batch_ids = torch.full(
                (len(chunk), width),
                tok.eos_token_id,
                dtype=torch.long,
                device=DEV,
            )
            attention = torch.zeros_like(batch_ids)
            for index, prefix in enumerate(chunk):
                batch_ids[index, -len(prefix):] = prefix.to(DEV)
                attention[index, -len(prefix):] = 1
            generated = model.generate(
                input_ids=batch_ids,
                attention_mask=attention,
                do_sample=False,
                max_new_tokens=max_new,
                pad_token_id=tok.eos_token_id,
            )
            outputs.extend(
                tok.batch_decode(generated[:, width:], skip_special_tokens=True)
            )
            continuation = generated[:, width:]
            for row in continuation:
                eos = (row == tok.eos_token_id).nonzero()
                generated_tokens += int(eos[0].item()) + 1 if len(eos) else len(row)
    rewards = task.reward(outputs, pids=[row.pid for row in rows])
    floor = float(getattr(task, "floor", 0.0))
    return (
        [bool(float(reward) > floor + 0.5) for reward in rewards],
        generated_tokens,
    )


def _within_question_mean(values: list[float]) -> float | None:
    finite = [value for value in values if math.isfinite(value)]
    return float(np.mean(finite)) if finite else None


def _posterior_diagnostics(
    rows: list[L2RTrace],
    weights: torch.Tensor,
    pids: torch.Tensor,
    policy_h: torch.Tensor,
    reader_a: torch.Tensor,
    *,
    top_k: int = 3,
) -> tuple[dict, list[dict]]:
    weights_np = weights.detach().double().cpu().numpy()
    pids_np = pids.detach().cpu().numpy()
    h_lengths = np.asarray([row.h_tokens for row in rows], dtype=np.float64)
    policy_np = policy_h.detach().double().cpu().numpy()
    reader_np = reader_a.detach().double().cpu().numpy()
    prompt_stats = []
    top = []
    for pid in sorted(set(int(value) for value in pids_np)):
        local = np.flatnonzero(pids_np == pid)
        active = local[weights_np[local] > 0]
        if not len(active):
            continue
        local_w = weights_np[active]
        local_w = local_w / local_w.sum()
        gold = np.asarray([rows[index].is_gold for index in active], dtype=bool)
        model_correct = np.asarray(
            [rows[index].proposal_correct is True and not rows[index].is_gold for index in active],
            dtype=bool,
        )
        ess = 1.0 / (len(active) * np.square(local_w).sum())
        entropy = -(local_w * np.log(np.clip(local_w, 1e-300, None))).sum()
        corr = None
        if len(active) > 1 and np.std(local_w) > 0 and np.std(h_lengths[active]) > 0:
            corr = float(np.corrcoef(local_w, h_lengths[active])[0, 1])
        prompt_stats.append({
            "pid": pid,
            "active": int(len(active)),
            "ess_fraction": float(ess),
            "entropy": float(entropy),
            "max_weight": float(local_w.max()),
            "gold_mass": float(local_w[gold].sum()),
            "model_correct_mass": float(local_w[model_correct].sum()),
            "weighted_h_tokens": float(np.dot(local_w, h_lengths[active])),
            "weight_length_corr": corr,
        })
        for index in active[np.argsort(-local_w)[:top_k]]:
            row = rows[int(index)]
            top.append({
                "pid": pid,
                "responsibility": float(weights_np[index]),
                "is_gold": row.is_gold,
                "proposal_correct": row.proposal_correct,
                "h_tokens": row.h_tokens,
                "round_added": row.round_added,
                "proposal_prompt": row.proposal_prompt,
                "target_mentioned_before_final": (
                    row.target_mentioned_before_final
                ),
                "target_before_equation": row.target_before_equation,
                "has_equation": row.has_equation,
                "policy_h_logp": float(policy_np[index]),
                "reader_a_logp": float(reader_np[index]),
                "text": row.text,
            })
    return {
        "question_count": len(prompt_stats),
        "active_rows": int((weights > 0).sum()),
        "ess_fraction": _within_question_mean(
            [row["ess_fraction"] for row in prompt_stats]
        ),
        "entropy": _within_question_mean([row["entropy"] for row in prompt_stats]),
        "max_weight": _within_question_mean([row["max_weight"] for row in prompt_stats]),
        "gold_mass": _within_question_mean([row["gold_mass"] for row in prompt_stats]),
        "model_correct_mass": _within_question_mean(
            [row["model_correct_mass"] for row in prompt_stats]
        ),
        "weighted_h_tokens": _within_question_mean(
            [row["weighted_h_tokens"] for row in prompt_stats]
        ),
        "weight_length_corr": _within_question_mean(
            [
                row["weight_length_corr"]
                for row in prompt_stats
                if row["weight_length_corr"] is not None
            ]
        ),
    }, top


def _mstep(
    model,
    tok,
    opt,
    rows: list[L2RTrace],
    weights: torch.Tensor,
    *,
    iters: int,
    micro: int,
    length_norm: bool,
    kl_coef: float,
    gradient_projector: GradientProjector | None = None,
) -> dict:
    active = torch.nonzero(weights > 0, as_tuple=False).flatten()
    if not len(active):
        return {
            "loss": float("nan"),
            "policy_loss": float("nan"),
            "kl_penalty": float("nan"),
            "gradient_steps": 0,
            "backward_tokens": 0,
            "gradient_norm_raw": float("nan"),
            "optimizer_update_norm_raw": float("nan"),
            "optimizer_update_norm_projected": float("nan"),
            "optimizer_update_norm_applied": float("nan"),
            "projection_retained_fraction": float("nan"),
        }
    selected_rows = [rows[int(index)] for index in active.cpu().tolist()]
    ids, h_mask, _ = _pad(selected_rows, tok.eos_token_id)
    local_weights = weights[active].to(DEV)
    question_count = len({row.pid for row in selected_rows})
    base_mean = None
    if kl_coef > 0:
        with torch.no_grad(), model.disable_adapter():
            base_mean = seq_logprobs(
                model,
                ids,
                h_mask,
                micro=micro,
                length_norm=True,
            )

    total_loss = total_policy = total_kl = 0.0
    total_gradient_norm = 0.0
    total_update_raw = total_update_projected = total_update_applied = 0.0
    total_retained = 0.0
    backward_tokens = 0
    for _ in range(iters):
        opt.zero_grad(set_to_none=True)
        step_loss = step_policy = step_kl = 0.0
        for start in range(0, len(selected_rows), micro):
            stop = min(start + micro, len(selected_rows))
            logp = seq_logprobs(
                model,
                ids[start:stop],
                h_mask[start:stop],
                micro=max(1, stop - start),
                grad=True,
                length_norm=length_norm,
            )
            policy_loss = -(
                local_weights[start:stop] * logp
            ).sum() / max(question_count, 1)
            loss = policy_loss
            kl_penalty = torch.zeros((), device=DEV)
            if base_mean is not None:
                current_mean = (
                    logp
                    if length_norm
                    else logp / h_mask[start:stop].sum(1).clamp_min(1)
                )
                log_ratio = (base_mean[start:stop] - current_mean).clamp(-5, 5)
                kl_rows = log_ratio.exp() - log_ratio - 1
                kl_penalty = (
                    local_weights[start:stop] * kl_rows
                ).sum() / max(question_count, 1)
                loss = loss + kl_coef * kl_penalty
            loss.backward()
            step_loss += float(loss.detach())
            step_policy += float(policy_loss.detach())
            step_kl += float(kl_penalty.detach())
            backward_tokens += int(h_mask[start:stop].sum())
        if gradient_projector is None:
            raise RuntimeError("L2R M-step requires an update projector")
        projection = gradient_projector.step(opt)
        total_loss += step_loss
        total_policy += step_policy
        total_kl += step_kl
        total_gradient_norm += projection["gradient_norm_raw"]
        total_update_raw += projection["optimizer_update_norm_raw"]
        total_update_projected += projection["optimizer_update_norm_projected"]
        total_update_applied += projection["optimizer_update_norm_applied"]
        total_retained += projection["projection_retained_fraction"]
    return {
        "loss": total_loss / iters,
        "policy_loss": total_policy / iters,
        "kl_penalty": total_kl / iters,
        "gradient_steps": iters,
        "backward_tokens": backward_tokens,
        "gradient_norm_raw": total_gradient_norm / iters,
        "optimizer_update_norm_raw": total_update_raw / iters,
        "optimizer_update_norm_projected": total_update_projected / iters,
        "optimizer_update_norm_applied": total_update_applied / iters,
        "projection_retained_fraction": total_retained / iters,
    }


def _empirical_h_kl(model, tok, rows: list[L2RTrace], micro: int) -> float:
    if not rows:
        return float("nan")
    ids, h_mask, _ = _pad(rows, tok.eos_token_id)
    current = seq_logprobs(model, ids, h_mask, micro=micro, length_norm=True)
    with model.disable_adapter():
        base = seq_logprobs(model, ids, h_mask, micro=micro, length_norm=True)
    return float((current - base).mean())


def run_l2r(
    task,
    rounds: int = 40,
    B: int = 64,
    G: int = 4,
    seed: int = 0,
    lr: float = 5e-5,
    iters: int = 4,
    model_name: str = MODEL_NAME,
    model_tok=None,
    micro: int = 4,
    reader_mode: str = "frozen",
    gold_in_buffer: bool = True,
    proposal_prompt: str = "question",
    responsibility_score: str = "joint",
    responsibility_temperature: float = 1.0,
    length_norm: bool = False,
    archive_limit: int = 64,
    replay_limit: int = 16,
    adaptive_max_g: int = 0,
    adaptive_batch_g: int = 2,
    adaptive_min_correct: int = 1,
    reader_decode_filter: bool = False,
    kl_coef: float = 0.0,
    lora_r: int = 16,
    lora_alpha: int = 32,
    lora_seed: int | None = None,
    lora_trainable: str = "all",
    gradient_projection: str = "none",
    gradient_projection_rank: int = 0,
    gradient_basis_path: str | None = None,
    gradient_projection_preserve_norm: bool = True,
    buffer_replicates: int = 1,
    question_schedule: str = "uniform",
    schedule_exploration: float = 0.1,
    eval_every: int = 0,
    eval_rounds: tuple[int, ...] | list[int] | None = None,
    eval_fn=None,
    diagnostics_fn=None,
    checkpoint_every: int = 0,
    checkpoint_fn=None,
    log=print,
) -> list[dict]:
    """Train an isolated latent-reasoning generator with answer-conditioned EM."""

    if rounds < 1:
        raise ValueError(f"rounds must be positive, got {rounds}")
    if B < 1 or G < 1 or B % G:
        raise ValueError(f"B must be positive and divisible by G, got B={B}, G={G}")
    if iters < 1 or micro < 1:
        raise ValueError("iters and micro must be positive")
    if reader_mode not in READER_MODES:
        raise ValueError(f"unknown L2R reader mode {reader_mode!r}")
    if proposal_prompt not in PROPOSAL_PROMPTS:
        raise ValueError(
            f"unknown L2R proposal prompt {proposal_prompt!r}; expected one of "
            f"{sorted(PROPOSAL_PROMPTS)}"
        )
    if responsibility_score not in RESPONSIBILITY_SCORES:
        raise ValueError(f"unknown L2R responsibility score {responsibility_score!r}")
    if not math.isfinite(responsibility_temperature) or responsibility_temperature <= 0:
        raise ValueError("responsibility_temperature must be finite and positive")
    if archive_limit < 0 or replay_limit < 0:
        raise ValueError("archive_limit and replay_limit must be nonnegative")
    if archive_limit > 0 and replay_limit > archive_limit:
        raise ValueError("replay_limit cannot exceed archive_limit")
    if adaptive_max_g == 0:
        adaptive_max_g = G
    if adaptive_max_g < G:
        raise ValueError("adaptive_max_g must be zero or at least G")
    if adaptive_batch_g < 1 or adaptive_min_correct < 1:
        raise ValueError("adaptive_batch_g and adaptive_min_correct must be positive")
    if not math.isfinite(kl_coef) or kl_coef < 0:
        raise ValueError("kl_coef must be finite and nonnegative")
    if lora_r < 1:
        raise ValueError("lora_r must be positive")
    if lora_alpha < 1:
        raise ValueError("lora_alpha must be positive")
    if lora_trainable not in LORA_TRAINABLE_MODES:
        raise ValueError(f"unknown LoRA trainable mode {lora_trainable!r}")
    if gradient_projection not in GRADIENT_PROJECTION_MODES:
        raise ValueError(f"unknown gradient projection mode {gradient_projection!r}")
    if gradient_projection == "none" and gradient_projection_rank != 0:
        raise ValueError("gradient_projection_rank must be zero when projection is disabled")
    if gradient_projection != "none" and gradient_projection_rank < 1:
        raise ValueError("projected gradients require a positive projection rank")
    if buffer_replicates < 1 or G % buffer_replicates:
        raise ValueError("buffer_replicates must be positive and divide G")
    if (
        buffer_replicates > 1
        and not gold_in_buffer
        and replay_limit > 0
        and replay_limit < buffer_replicates
    ):
        raise ValueError(
            "without a shared gold trace, replay_limit must retain at least "
            "one sampled trace per buffer replica"
        )
    if adaptive_max_g % buffer_replicates:
        raise ValueError("adaptive_max_g must be divisible by buffer_replicates")
    if question_schedule not in QUESTION_SCHEDULES:
        raise ValueError(f"unknown question schedule {question_schedule!r}")
    if not math.isfinite(schedule_exploration) or not 0 <= schedule_exploration <= 1:
        raise ValueError("schedule_exploration must be in [0, 1]")
    if eval_every and eval_rounds:
        raise ValueError("eval_every and eval_rounds are mutually exclusive")

    model, tok = (
        model_tok
        if model_tok is not None
        else load_model(
            seed=seed,
            model=model_name,
            lora_r=lora_r,
            lora_alpha=lora_alpha,
            lora_seed=lora_seed,
        )
    )
    named_trainable = configure_lora_trainable(model, lora_trainable)
    opt = torch.optim.Adam(
        [parameter for _, parameter in named_trainable],
        lr=lr,
    )
    gradient_projector = GradientProjector(
        named_trainable,
        mode=gradient_projection,
        rank=gradient_projection_rank,
        basis_path=(
            gradient_basis_path
            or os.environ.get("L2R_GRADIENT_BASIS_PATH")
        ),
        seed=(lora_seed if lora_seed is not None else seed) * 1009 + 17,
        preserve_norm=gradient_projection_preserve_norm,
    )
    rng = np.random.default_rng(seed)
    prompt_ids = [
        tok(prompt, return_tensors="pt").input_ids[0].detach().cpu()
        for prompt in task.prompts
    ]
    buffers: dict[int, list[L2RTrace]] = {}
    seen_questions: set[int] = set()
    records = []
    total_gen = total_generated_tokens = total_backward_tokens = total_steps = 0
    total_reader_decode_tokens = 0
    total_evictions = total_duplicates = total_reader_decode = 0
    question_exposures = 0
    scheduler = QuestionScheduler(
        len(task.prompts),
        seed=seed * 1013 + 23,
        mode=question_schedule,
        exploration=schedule_exploration,
    )

    for round_index in range(rounds):
        n_questions = B // G
        selected_pids = scheduler.select(n_questions, round_index)
        schedule_diagnostics = scheduler.diagnostics(selected_pids, round_index)
        pids, sampled_rows, sampled_texts, generation = _sample_round(
            model,
            tok,
            task,
            prompt_ids,
            B=B,
            G=G,
            rng=rng,
            round_added=round_index,
            adaptive_max_g=adaptive_max_g,
            adaptive_batch_g=adaptive_batch_g,
            adaptive_min_correct=adaptive_min_correct,
            proposal_prompt=proposal_prompt,
            buffer_replicates=buffer_replicates,
            selected_pids=selected_pids,
        )
        total_gen += generation["generations"]
        total_generated_tokens += generation["generated_tokens"]
        seen_questions.update(pids)
        question_exposures += len(pids)

        gold_added = sampled_added = duplicate_rows = evictions = 0
        if gold_in_buffer:
            for pid in pids:
                if any(row.is_gold for row in buffers.get(pid, [])):
                    continue
                row = _gold_trace(tok, task, prompt_ids[pid], pid, round_index)
                if row is not None and _append_unique(buffers, row):
                    gold_added += 1
        for row in sampled_rows:
            if _append_unique(buffers, row):
                sampled_added += 1
            else:
                duplicate_rows += 1
        for pid in pids:
            evictions += _prune_archive(
                buffers.get(pid, []),
                archive_limit,
                buffer_replicates,
            )
        total_duplicates += duplicate_rows
        total_evictions += evictions

        rows = [row for pid in pids for row in buffers.get(pid, [])]
        ids, h_mask, a_mask = _pad(rows, tok.eos_token_id)
        with torch.no_grad():
            policy_h = seq_logprobs(
                model,
                ids,
                h_mask,
                micro=micro,
                length_norm=False,
            )
            reader_context = (
                model.disable_adapter() if reader_mode == "frozen" else nullcontext()
            )
            with reader_context:
                reader_a = seq_logprobs(
                    model,
                    ids,
                    a_mask,
                    micro=micro,
                    length_norm=False,
                )
        h_lengths = h_mask.sum(1)
        a_lengths = a_mask.sum(1)
        trace_pids = torch.tensor([row.pid for row in rows], device=DEV, dtype=torch.long)
        raw_logits = (
            policy_h + reader_a
            if responsibility_score == "joint"
            else (
                policy_h / h_lengths.clamp_min(1)
                + reader_a / a_lengths.clamp_min(1)
            )
        )

        active = torch.zeros(len(rows), device=DEV, dtype=torch.bool)
        offset = 0
        for pid in pids:
            local_rows = buffers.get(pid, [])
            local_logits = raw_logits[offset:offset + len(local_rows)]
            if buffer_replicates == 1:
                selected = select_replay_indices(
                    local_rows,
                    local_logits,
                    replay_limit,
                )
            else:
                gold_indices = [
                    index for index, row in enumerate(local_rows) if row.is_gold
                ]
                selected_set = set(gold_indices)
                sampled_budget = max(replay_limit - len(gold_indices), 0)
                base_limit, remainder = (
                    (0, 0)
                    if replay_limit <= 0
                    else divmod(sampled_budget, buffer_replicates)
                )
                for replica in range(buffer_replicates):
                    replica_indices = gold_indices + [
                        index
                        for index, row in enumerate(local_rows)
                        if not row.is_gold and row.replica == replica
                    ]
                    replica_rows = [local_rows[index] for index in replica_indices]
                    replica_logits = local_logits[
                        torch.tensor(replica_indices, device=DEV)
                    ]
                    local_limit = (
                        0
                        if replay_limit <= 0
                        else (
                            len(gold_indices)
                            + base_limit
                            + int(replica < remainder)
                        )
                    )
                    selected_set.update(
                        replica_indices[index]
                        for index in select_replay_indices(
                            replica_rows,
                            replica_logits,
                            local_limit,
                        )
                    )
                selected = sorted(selected_set)
            active[offset + torch.tensor(selected, device=DEV)] = True
            offset += len(local_rows)

        decode_pass = None
        decode_fallback_questions = 0
        if reader_decode_filter:
            active_indices = torch.nonzero(active, as_tuple=False).flatten().cpu().tolist()
            decode_rows = [rows[index] for index in active_indices]
            decode_values, decode_tokens = _reader_decode_correct(
                model,
                tok,
                task,
                decode_rows,
                reader_mode=reader_mode,
            )
            total_reader_decode += len(decode_rows)
            total_reader_decode_tokens += decode_tokens
            decode_pass = torch.zeros(len(rows), device=DEV, dtype=torch.bool)
            for index, passed in zip(active_indices, decode_values):
                decode_pass[index] = passed
            for pid in pids:
                local = (trace_pids == pid) & active
                if bool(local.any()) and not bool((local & decode_pass).any()):
                    decode_pass[local] = True
                    decode_fallback_questions += 1
            active &= decode_pass

        if buffer_replicates == 1:
            weights = l2r_responsibilities(
                policy_h,
                reader_a,
                h_lengths,
                a_lengths,
                trace_pids,
                score=responsibility_score,
                temperature=responsibility_temperature,
                active=active,
            ).detach()
        else:
            replicas = torch.tensor(
                [row.replica for row in rows],
                device=DEV,
                dtype=torch.long,
            )
            is_gold = torch.tensor(
                [row.is_gold for row in rows],
                device=DEV,
                dtype=torch.bool,
            )
            weights = replicated_responsibilities(
                raw_logits,
                trace_pids,
                replicas,
                is_gold,
                active,
                replicate_count=buffer_replicates,
                temperature=responsibility_temperature,
            ).detach()
        for row, weight in zip(rows, weights.detach().cpu().tolist()):
            row.last_responsibility = float(weight)

        mstep = _mstep(
            model,
            tok,
            opt,
            rows,
            weights,
            iters=iters,
            micro=micro,
            length_norm=length_norm,
            kl_coef=kl_coef,
            gradient_projector=gradient_projector,
        )
        total_steps += mstep["gradient_steps"]
        total_backward_tokens += mstep["backward_tokens"]
        active_rows = [
            row for row, weight in zip(rows, weights.detach().cpu().tolist()) if weight > 0
        ]
        empirical_h_kl = _empirical_h_kl(model, tok, active_rows, micro)
        posterior, top_traces = _posterior_diagnostics(
            rows,
            weights,
            trace_pids,
            policy_h,
            reader_a,
        )
        for pid in pids:
            sampled_for_pid = [row for row in sampled_rows if row.pid == pid]
            correct_rate = (
                float(np.mean([row.proposal_correct is True for row in sampled_for_pid]))
                if sampled_for_pid
                else 0.0
            )
            local_weights = weights[trace_pids == pid]
            positive = local_weights[local_weights > 0]
            if len(positive) <= 1:
                uncertainty = 0.0
            else:
                local = positive / positive.sum()
                uncertainty = float(
                    -(local * local.clamp_min(1e-30).log()).sum()
                    / math.log(len(local))
                )
            scheduler.observe(
                pid,
                correct_rate=correct_rate,
                uncertainty=min(max(uncertainty, 0.0), 1.0),
                round_index=round_index,
            )
        schedule_after = scheduler.diagnostics(pids, round_index)
        test_acc = maybe_eval(
            model,
            round_index,
            rounds,
            eval_every,
            eval_fn,
            eval_rounds=eval_rounds,
        )

        proposal_correct = [row.proposal_correct is True for row in sampled_rows]
        archive_rows = sum(len(buffer) for buffer in buffers.values())
        record = {
            "round": round_index,
            "oracle": 0,
            "verifier_calls": (
                (total_gen if adaptive_max_g > G else 0) + total_reader_decode
            ),
            "diagnostic_verifier_calls": (
                0 if adaptive_max_g > G else total_gen
            ),
            "gen": total_gen,
            "llm_gen": total_gen + total_reader_decode,
            "rollout_generated_tokens": total_generated_tokens,
            "generated_tokens": total_generated_tokens + total_reader_decode_tokens,
            "reader_decode_generations": total_reader_decode,
            "reader_decode_tokens": total_reader_decode_tokens,
            "backward_tokens": total_backward_tokens,
            "gsteps": total_steps,
            "question_exposures": question_exposures,
            "unique_questions_seen": len(seen_questions),
            "questions_this_round": len(pids),
            "mean_g": generation["mean_g"],
            "adaptive_generations": generation["adaptive_generations"],
            "resolved_initial": generation["resolved_initial"],
            "resolved_final": generation["resolved_final"],
            "frac_correct": float(np.mean(proposal_correct)) if proposal_correct else float("nan"),
            "proposal_prompt": proposal_prompt,
            "target_mentioned_before_final": (
                generation["target_mentioned_before_final_fraction"]
            ),
            "target_before_equation": (
                generation["target_before_equation_fraction"]
            ),
            "equation_fraction": generation["equation_fraction"],
            "fmt": format_rate(sampled_texts),
            "gen_len": float(np.mean([row.generated_tokens for row in sampled_rows])),
            "archive_rows": archive_rows,
            "active_rows": posterior["active_rows"],
            "buffer_evictions": total_evictions,
            "duplicate_rows": total_duplicates,
            "gold_mass": posterior["gold_mass"],
            "model_correct_mass": posterior["model_correct_mass"],
            "ess": posterior["ess_fraction"],
            "responsibility_entropy": posterior["entropy"],
            "responsibility_max": posterior["max_weight"],
            "weight_length_corr": posterior["weight_length_corr"],
            "weighted_h_tokens": posterior["weighted_h_tokens"],
            "reader_mode": reader_mode,
            "responsibility_score": responsibility_score,
            "length_norm": length_norm,
            "archive_limit": archive_limit,
            "replay_limit": replay_limit,
            "buffer_replicates": buffer_replicates,
            "question_schedule": question_schedule,
            "schedule_priority_mean": schedule_diagnostics["selected_priority_mean"],
            "schedule_selected_unseen": schedule_diagnostics["selected_unseen"],
            "schedule_pool_unseen": schedule_diagnostics["pool_unseen"],
            "schedule_max_exposures": schedule_diagnostics["max_exposures"],
            "schedule_min_exposures": schedule_diagnostics["min_exposures"],
            "lora_r": lora_r,
            "lora_alpha": lora_alpha,
            "lora_seed": lora_seed,
            "lora_trainable": lora_trainable,
            "gradient_projection": gradient_projection,
            "gradient_projection_rank": gradient_projection_rank,
            "gradient_projection_preserve_norm": gradient_projection_preserve_norm,
            "reader_decode_filter": reader_decode_filter,
            "decode_fallback_questions": decode_fallback_questions,
            "loss": mstep["loss"],
            "policy_loss": mstep["policy_loss"],
            "kl_penalty": mstep["kl_penalty"],
            "gradient_norm_raw": mstep["gradient_norm_raw"],
            "optimizer_update_norm_raw": mstep["optimizer_update_norm_raw"],
            "optimizer_update_norm_projected": (
                mstep["optimizer_update_norm_projected"]
            ),
            "optimizer_update_norm_applied": (
                mstep["optimizer_update_norm_applied"]
            ),
            "projection_retained_fraction": mstep["projection_retained_fraction"],
            "kl": empirical_h_kl,
            "test_acc": test_acc,
        }
        records.append(record)

        if diagnostics_fn is not None:
            diagnostics_fn({
                "schema_version": 1,
                "method_family": "l2r",
                "round": round_index,
                "completed_rounds": round_index + 1,
                "configuration": {
                    "reader_mode": reader_mode,
                    "gold_in_buffer": gold_in_buffer,
                    "proposal_prompt": proposal_prompt,
                    "responsibility_score": responsibility_score,
                    "responsibility_temperature": responsibility_temperature,
                    "length_norm": length_norm,
                    "archive_limit": archive_limit,
                    "replay_limit": replay_limit,
                    "adaptive_max_g": adaptive_max_g,
                    "adaptive_batch_g": adaptive_batch_g,
                    "adaptive_min_correct": adaptive_min_correct,
                    "reader_decode_filter": reader_decode_filter,
                    "kl_coef": kl_coef,
                    "lora_r": lora_r,
                    "lora_alpha": lora_alpha,
                    "lora_seed": lora_seed,
                    "lora_trainable": lora_trainable,
                    "gradient_projection": gradient_projection,
                    "gradient_projection_rank": gradient_projection_rank,
                    "gradient_basis_path": gradient_basis_path,
                    "gradient_projection_preserve_norm": (
                        gradient_projection_preserve_norm
                    ),
                    "buffer_replicates": buffer_replicates,
                    "question_schedule": question_schedule,
                    "schedule_exploration": schedule_exploration,
                },
                "generation": {
                    **generation,
                    "cumulative_generations": total_gen,
                    "cumulative_generated_tokens": total_generated_tokens,
                    "proposal_correct_fraction": (
                        float(np.mean(proposal_correct)) if proposal_correct else None
                    ),
                    "format_fraction": (
                        format_rate(sampled_texts) if sampled_texts else None
                    ),
                },
                "sampled_traces": [
                    {
                        "pid": row.pid,
                        "replica": row.replica,
                        "proposal_prompt": row.proposal_prompt,
                        "proposal_correct": row.proposal_correct,
                        "generated_tokens": row.generated_tokens,
                        "h_tokens": row.h_tokens,
                        "target_mentioned_before_final": (
                            row.target_mentioned_before_final
                        ),
                        "target_before_equation": row.target_before_equation,
                        "has_equation": row.has_equation,
                        "text": row.text,
                    }
                    for row in sampled_rows
                ],
                "buffer": {
                    "gold_added": gold_added,
                    "sampled_added": sampled_added,
                    "duplicates": duplicate_rows,
                    "evictions": evictions,
                    "archive_rows": archive_rows,
                    "active_rows": posterior["active_rows"],
                },
                "posterior": posterior,
                "reader_decode": {
                    "enabled": reader_decode_filter,
                    "calls_cumulative": total_reader_decode,
                    "generated_tokens_cumulative": total_reader_decode_tokens,
                    "fallback_questions": decode_fallback_questions,
                },
                "optimizer": {
                    **mstep,
                    "gradient_steps_cumulative": total_steps,
                    "backward_tokens_cumulative": total_backward_tokens,
                    "empirical_h_kl": empirical_h_kl,
                },
                "scheduler": {
                    **schedule_diagnostics,
                    "pool_unseen_after": schedule_after["pool_unseen"],
                    "max_exposures_after": schedule_after["max_exposures"],
                    "min_exposures_after": schedule_after["min_exposures"],
                },
                "top_traces": top_traces,
                "test_acc": None if not math.isfinite(test_acc) else test_acc,
            })

        if (
            checkpoint_fn is not None
            and checkpoint_every > 0
            and (round_index + 1) % checkpoint_every == 0
            and (round_index + 1) < rounds
        ):
            checkpoint_fn(model, round_index + 1)

        log(
            f"  [L2R-{reader_mode} r{round_index:>3}] "
            f"gen={total_gen:>6} tok={total_generated_tokens:>8} "
            f"correct={record['frac_correct']:.3f} "
            f"gold={record['gold_mass']:.3f} ESS={record['ess']:.3f} "
            f"KLh={empirical_h_kl:+.3f} H={posterior['active_rows']}/{archive_rows}"
        )

    return records
