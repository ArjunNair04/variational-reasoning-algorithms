"""Faithful Barber Learning-to-Reason Algorithm 1 implementation.

This file implements the July 7, 2026 version of Learning to Reason. The
default ``proposal_prompt="question"`` follows Algorithm 1; answer-conditioned
proposal modes are isolated experimental extensions.

The objective is

    F = B_sup + B'_unsup + B_unsup

where:
    B_sup       is supervised learning on labelled triples (a, h, q),
    B'_unsup    is the EM/buffer contribution on labelled questions,
    B_unsup     is the EM/buffer contribution on answer-only questions.
"""

from __future__ import annotations

import ast
import copy
import math
import re
from collections import Counter, defaultdict
from contextlib import nullcontext
from dataclasses import dataclass
from fractions import Fraction

import numpy as np
import torch

from ac_alg1_update_geometry import (
    STEP_ACCEPTANCE_MODES,
    UPDATE_GEOMETRIES,
    assign_trainable_gradients,
    combine_component_gradients,
    component_gradients_from_cumulative,
    fixed_surrogate_acceptance,
)
from common import (
    DEV,
    MODEL_NAME,
    QuestionSampler,
    load_model,
    maybe_eval,
    sample_multi,
    seq_logprobs,
    token_logps,
)


PROPOSAL_PROMPTS = (
    "question",
    "derive_only",
    "answer_hint",
    "answer_derive",
    "tagged_zero_shot",
    "tagged_gold_rationale",
)
PROPOSAL_FILTERS = ("all", "answer_correct")
RESPONSIBILITY_SCORES = ("joint", "token_mean")
ADAPTER_POLICY_MODES = ("current", "frozen_base")
RESPONSIBILITY_REFRESH_MODES = ("inner_step", "outer_round")
OPTIMIZER_STATE_SCOPES = ("persistent", "outer_round")
POLICY_ANCHOR_MODES = ("fixed", "grad_ratio")
LABELLED_NUMERIC_CONSTRAINTS = ("off", "hard", "soft", "graph_hard")
LABELLED_SUPERVISION_MODES = (
    "gold",
    "gold_compact_mix",
    "gold_compact_set",
    "gold_graph_factorized",
)
TRACE_REPRESENTATIONS = ("reasoning", "calculation_graph")


@dataclass(frozen=True)
class NumericAudit:
    """Deterministic arithmetic audit for one labelled reasoning trace."""

    equation_mentions: int = 0
    parsed_equations: int = 0
    invalid_equations: int = 0
    gold_matches: int = 0
    gold_contradictions: int = 0
    gold_graph_available: bool = False
    gold_graph_nodes: int = 0
    gold_graph_edges: int = 0
    candidate_graph_nodes: int = 0
    candidate_graph_edges: int = 0
    graph_node_matches: int = 0
    graph_edge_matches: int = 0
    graph_node_coverage: float | None = None
    graph_edge_coverage: float | None = None
    graph_fully_covered: bool | None = None
    equations: tuple[str, ...] = ()
    invalid: tuple[str, ...] = ()
    contradictions: tuple[str, ...] = ()
    missing_graph_nodes: tuple[str, ...] = ()
    missing_graph_edges: tuple[str, ...] = ()


@dataclass(frozen=True)
class StructuredTraceAudit:
    """Format audit for the explicit calculation-graph trace representation."""

    has_calculation_block: bool = False
    has_reasoning_block: bool = False
    calculation_precedes_reasoning: bool = False
    well_formed: bool = False
    calculation_characters: int = 0
    reasoning_characters: int = 0


@dataclass
class TraceRow:
    """One candidate reasoning trace stored in a per-question buffer.

    Attributes:
        ids: Token ids for the full sequence q ++ h_s ++ a.
        span: Boolean mask for h_s ++ a, used to score log p(h_s, a | q).
        ans: Boolean mask for a only, used when we need log p(a | h_s, q).
        pid: Integer question id in task.prompts.
        round_added: Outer training round when this trace entered the buffer.
        source: Human-readable source label, e.g. "gold" or "labelled_sample".
        is_gold: True only for the official gold reasoning trace.
        elite_score: Most recently computed detached responsibility, also used by hybrid pruning.
        joint_logprob: Most recently computed log p_theta(h_s, a* | q).
        trace_logprob: Most recently computed trace-prior factor log p(h_s | q).
        answer_logprob: Most recently computed reader factor log p(a* | h_s, q).
        responsibility_logit: Logit used by the latest E-step before temperature scaling.
        trace_id: Stable identifier linking generation, buffer, and responsibility records.
        proposal_correct: Whether the sampled proposal decoded to the known answer.
        proposal_tokens: Number of tokens generated for the sampled proposal.
        numeric_audit: Arithmetic audit against labelled gold calculations. None
            for answer-only rows, which must not inspect gold_solution.
        numeric_log_potential: Fixed log compatibility potential most recently
            added to this row's labelled E-step logit.
        responsibility_before_potential: Responsibility under the same score and
            temperature before applying the fixed numerical potential.
        responsibility_temperature_used: Actual one-sided adaptive temperature
            used for the latest E-step. It equals the configured temperature
            unless an ESS floor required additional smoothing.
        trace_representation: ``reasoning`` or the explicit ``calculation_graph``
            serialization of z followed by h.
        structured_audit: Format audit for explicit calculation-graph traces.
    """

    ids: torch.Tensor
    span: torch.Tensor
    ans: torch.Tensor
    pid: int
    round_added: int
    source: str
    is_gold: bool = False
    elite_score: float = float("-inf")
    joint_logprob: float = float("-inf")
    trace_logprob: float = float("-inf")
    answer_logprob: float = float("-inf")
    responsibility_logit: float = float("-inf")
    trace_id: str | None = None
    proposal_correct: bool | None = None
    proposal_tokens: int | None = None
    numeric_audit: NumericAudit | None = None
    numeric_log_potential: float = 0.0
    responsibility_before_potential: float | None = None
    responsibility_temperature_used: float | None = None
    trace_representation: str = "reasoning"
    structured_audit: StructuredTraceAudit | None = None


def _adapter_policy_context(model, mode: str):
    """Select the current adapter policy or the frozen pretrained base."""

    if mode not in ADAPTER_POLICY_MODES:
        raise ValueError(f"unknown AC-ALG1 adapter policy mode {mode!r}")
    if mode == "current":
        return nullcontext()
    disable_adapter = getattr(model, "disable_adapter", None)
    if disable_adapter is None:
        raise ValueError(
            "frozen_base policy mode requires a model with disable_adapter()"
        )
    return disable_adapter()


def _responsibility_effective_sample_size(weights: torch.Tensor) -> float:
    """Return inverse-squared-mass ESS for a detached weight vector."""

    return 1.0 / float(torch.sum(weights.detach().float().square()).item())


def _one_sided_ess_temperature(
    logits: torch.Tensor,
    base_temperature: float,
    ess_floor_fraction: float,
) -> float:
    """Raise temperature only when needed to prevent posterior concentration.

    Unlike a two-sided ESS target, this rule leaves flat or already diffuse
    evidence unchanged. The floor is measured relative to the number of
    finite, admissible logits, so hard constraints are never softened.
    """

    if not math.isfinite(base_temperature) or base_temperature <= 0:
        raise ValueError("base temperature must be finite and positive")
    if (
        not math.isfinite(ess_floor_fraction)
        or not 0.0 <= ess_floor_fraction <= 1.0
    ):
        raise ValueError("ESS floor fraction must be finite and in [0, 1]")

    # ``-inf`` is the deliberate representation of a hard-excluded trace, but
    # NaN and ``+inf`` do not define a categorical posterior.  Validate before
    # the disabled-floor fast path: even with no adaptive smoothing, an
    # all-excluded support would otherwise become a vector of NaNs in softmax.
    if bool(torch.isnan(logits).any()) or bool(torch.isposinf(logits).any()):
        raise FloatingPointError(
            "responsibility logits must be finite or -inf hard exclusions"
        )
    finite_count = int(torch.isfinite(logits).sum().item())
    if finite_count == 0:
        raise ValueError(
            "responsibility posterior has no finite admissible logits"
        )
    if ess_floor_fraction == 0.0 or finite_count == 1:
        return float(base_temperature)
    target = max(1.0, ess_floor_fraction * finite_count)

    def ess_at(temperature: float) -> float:
        weights = torch.softmax(logits / temperature, dim=0)
        return _responsibility_effective_sample_size(weights)

    if ess_at(base_temperature) >= target:
        return float(base_temperature)

    low = float(base_temperature)
    high = low
    for _ in range(32):
        high *= 2.0
        if ess_at(high) >= target:
            break
    else:
        return high

    for _ in range(40):
        middle = 0.5 * (low + high)
        if ess_at(middle) >= target:
            high = middle
        else:
            low = middle
    return high


def _answer_known_pids(task) -> list[int]:
    """Return question ids with a parsed gold answer.

    Args:
        task: GSM8K-style task with prompts and gold_answer.

    Returns:
        List of integer prompt ids that can supply answer-known pairs (a, q).
    """

    if not hasattr(task, "gold_answer"):
        return []

    return [
        i
        for i in range(len(task.prompts))
        if task.gold_answer[i] is not None
    ]


def _labelled_answer_only_pools(task, labelled_frac: float = 0.5) -> tuple[list[int], list[int]]:
    """Partition the task into Algorithm-1 L and U pools.

    GSM8K ships gold solutions for every prompt. To represent Barber's distinct
    labelled L={(a,h,q)} and answer-only U={(a,q)} sets in this single dataset,
    prompts with gold_solution are split deterministically according to
    labelled_frac. The rest enter U with their gold_solution deliberately ignored.
    """

    if not 0.0 <= labelled_frac <= 1.0:
        raise ValueError(f"labelled_frac must be in [0,1], got {labelled_frac}")

    answer_known = _answer_known_pids(task)
    if not hasattr(task, "gold_solution"):
        return [], answer_known

    labelled_candidates = [pid for pid in answer_known if task.gold_solution[pid]]
    n_labelled = min(len(labelled_candidates), max(0, int(len(labelled_candidates) * labelled_frac + 0.5)))
    if n_labelled == 0:
        labelled_set = set()
    elif n_labelled == len(labelled_candidates):
        labelled_set = set(labelled_candidates)
    else:
        step = len(labelled_candidates) / n_labelled
        labelled_set = {labelled_candidates[int(i * step)] for i in range(n_labelled)}

    labelled = [pid for pid in answer_known if pid in labelled_set]
    answer_only = [pid for pid in answer_known if pid not in labelled_set]
    return labelled, answer_only


def _sample_minibatch(pool: list[int], rng, batch_size: int) -> list[int]:
    """Uniformly sample prompt ids from a fixed pool."""

    if not pool or batch_size <= 0:
        return []

    replace = batch_size > len(pool)
    return [int(pid) for pid in rng.choice(pool, size=batch_size, replace=replace)]


def _labelled_pids(task, labelled_frac: float = 0.5) -> list[int]:
    """Return question ids in the labelled L={(a,h,q)} split."""

    labelled, _answer_only = _labelled_answer_only_pools(task, labelled_frac=labelled_frac)
    return labelled


def _sample_labelled_minibatch(task, rng, L_batch: int) -> list[int]:
    """Uniformly sample labelled question ids.

    Args:
        task: GSM8K-style task.
        rng: NumPy random generator.
        L_batch: Number of labelled questions to sample.

    Returns:
        List of sampled integer prompt ids. Empty if no labelled data is available.
    """

    return _sample_minibatch(_labelled_pids(task), rng, L_batch)


def _answer_only_pids(task, labelled_frac: float = 0.5) -> list[int]:
    """Return question ids in the answer-only U={(a,q)} split."""

    _labelled, answer_only = _labelled_answer_only_pools(task, labelled_frac=labelled_frac)
    return answer_only


def _sample_answer_only_minibatch(task, rng, U_batch: int) -> list[int]:
    """Uniformly sample question ids for the answer-only objective.

    Args:
        task: GSM8K-style task.
        rng: NumPy random generator.
        U_batch: Number of answer-only questions to sample.

    Returns:
        List of sampled integer prompt ids. Empty if no answer-only data is available.
    """

    return _sample_minibatch(_answer_only_pids(task), rng, U_batch)


def _build_supervised_batch(
    tok,
    task,
    pids: list[int],
    solutions: list[str] | None = None,
) -> tuple[torch.Tensor, torch.Tensor] | None:
    """Tokenise labelled triples for the supervised objective B_sup.

    Args:
        tok: Tokenizer.
        task: GSM8K-style task with prompts and gold_solution.
        pids: Question ids for the labelled minibatch.
        solutions: Optional target solution aligned one-to-one with pids.

    Returns:
        None if pids is empty. Otherwise:
            ids: Padded token ids for q ++ gold_solution.
            span: Boolean mask selecting only gold_solution tokens.
    """

    if solutions is not None and len(solutions) != len(pids):
        raise ValueError("supervised solutions must align one-to-one with pids")

    rows, spans = [], []

    for row_index, pid in enumerate(pids):
        prompt_ids = tok(task.prompts[int(pid)], return_tensors="pt").input_ids[0].tolist()

        # gold_solution is the full GSM8K target string: gold_reasoning followed by
        # the "#### gold_answer" marker. For B_sup we score the whole continuation:
        # log p_theta(gold_reasoning, gold_answer | q).
        solution = (
            solutions[row_index]
            if solutions is not None
            else task.gold_solution[int(pid)]
        )
        solution_ids = tok(" " + solution, add_special_tokens=False).input_ids

        ids = torch.tensor(prompt_ids + solution_ids, dtype=torch.long)
        span = torch.zeros(len(ids), dtype=torch.bool)
        span[len(prompt_ids):] = True

        rows.append(ids)
        spans.append(span)

    if not rows:
        return None

    pad = torch.nn.utils.rnn.pad_sequence
    ids = pad(rows, batch_first=True, padding_value=tok.eos_token_id).to(DEV)
    span = pad(spans, batch_first=True, padding_value=False).to(DEV)
    return ids, span


def _digit_weighted_span(
    tok,
    ids: torch.Tensor,
    span: torch.Tensor,
    digit_token_weight: float,
) -> torch.Tensor:
    """Upweight digit-bearing target tokens without changing total row weight."""

    if not math.isfinite(digit_token_weight) or digit_token_weight < 1.0:
        raise ValueError(
            "digit_token_weight must be finite and at least 1, "
            f"got {digit_token_weight}"
        )
    if digit_token_weight == 1.0:
        return span

    weighted = span.to(dtype=torch.float32).clone()
    ids_cpu = ids.detach().cpu()
    span_cpu = span.detach().cpu()
    for row_index in range(ids_cpu.shape[0]):
        for token_index in span_cpu[row_index].nonzero(as_tuple=False).flatten().tolist():
            piece = tok.decode([int(ids_cpu[row_index, token_index])])
            if any(character.isdigit() for character in piece):
                weighted[row_index, token_index] = digit_token_weight

    target_counts = span.sum(dim=1).to(weighted.dtype)
    weighted_mass = weighted.sum(dim=1).clamp_min(1.0)
    weighted *= (target_counts / weighted_mass).unsqueeze(1)
    return weighted


def _B_sup(
    model,
    tok,
    task,
    labelled_pids: list[int],
    labelled_supervision: str = "gold",
    compact_gold_weight: float = 0.5,
    digit_token_weight: float = 1.0,
    grad: bool = True,
) -> torch.Tensor:
    """Supervised log-likelihood of gold solutions given questions.

    Args:
        model: Trainable language model.
        tok: Tokenizer.
        task: GSM8K-style task.
        labelled_pids: Labelled question ids.
        labelled_supervision: ``gold`` uses only the official solution;
            ``gold_compact_mix`` uses a fixed mixture with a compact target;
            ``gold_compact_set`` maximises set-valued evidence; and
            ``gold_graph_factorized`` supervises an explicit z, h, a sequence.
        compact_gold_weight: Mixture weight on the compact target.
        digit_token_weight: Relative weight on digit-bearing target tokens.
            Per-row weights are renormalised to preserve total objective scale.
        grad: Whether the returned score must retain an autograd graph.
    Returns:
        Scalar tensor containing B_sup. Returns zero if labelled_pids is empty.
    """

    if labelled_supervision not in LABELLED_SUPERVISION_MODES:
        raise ValueError(f"unknown AC-ALG1 labelled_supervision {labelled_supervision!r}")
    if not math.isfinite(compact_gold_weight) or not 0.0 <= compact_gold_weight <= 1.0:
        raise ValueError(
            "compact_gold_weight must be finite and in [0,1], "
            f"got {compact_gold_weight}"
        )
    if not math.isfinite(digit_token_weight) or digit_token_weight < 1.0:
        raise ValueError(
            "digit_token_weight must be finite and at least 1, "
            f"got {digit_token_weight}"
        )

    gold_solutions = [task.gold_solution[int(pid)] for pid in labelled_pids]
    if labelled_supervision == "gold_graph_factorized":
        gold_solutions = [
            _structured_gold_solution(solution, task.gold_answer[int(pid)])
            for pid, solution in zip(labelled_pids, gold_solutions)
        ]

    gold_batch = _build_supervised_batch(
        tok,
        task,
        labelled_pids,
        solutions=(
            gold_solutions
            if labelled_supervision == "gold_graph_factorized"
            else None
        ),
    )
    if gold_batch is None:
        return torch.zeros((), device=DEV)

    gold_ids, gold_span = gold_batch
    gold_score_span = _digit_weighted_span(
        tok,
        gold_ids,
        gold_span,
        digit_token_weight,
    )
    gold_logp = seq_logprobs(
        model, gold_ids, gold_score_span, grad=grad, length_norm=False
    )
    if labelled_supervision in ("gold", "gold_graph_factorized"):
        return gold_logp.mean()

    compact_solutions = [
        _compact_gold_solution(task.gold_solution[int(pid)], task.gold_answer[int(pid)])
        for pid in labelled_pids
    ]
    compact_ids, compact_span = _build_supervised_batch(
        tok,
        task,
        labelled_pids,
        solutions=compact_solutions,
    )
    compact_score_span = _digit_weighted_span(
        tok,
        compact_ids,
        compact_span,
        digit_token_weight,
    )
    compact_logp = seq_logprobs(
        model, compact_ids, compact_score_span, grad=grad, length_norm=False
    )
    if labelled_supervision == "gold_compact_set":
        set_logp = torch.logaddexp(gold_logp, compact_logp)
        duplicate_target = torch.tensor(
            [gold == compact for gold, compact in zip(gold_solutions, compact_solutions)],
            dtype=torch.bool,
            device=set_logp.device,
        )
        return torch.where(duplicate_target, gold_logp, set_logp).mean()

    if compact_gold_weight == 0.0:
        return gold_logp.mean()
    return (
        (1.0 - compact_gold_weight) * gold_logp
        + compact_gold_weight * compact_logp
    ).mean()


def _gold_reasoning_from_solution(gold_solution: str) -> str:
    """Extract gold reasoning h from a full GSM8K gold solution.

    Args:
        gold_solution: Full GSM8K answer string, usually "reasoning ... #### answer".

    Returns:
        The text before the first "####" marker, stripped on the right.
    """

    return gold_solution.split("####", 1)[0].rstrip()


_GOLD_CALCULATION_RE = re.compile(r"<<([^<>]+)>>")
_UNSIGNED_NUMBER_RE = r"(?:\d[\d,]*(?:\.\d+)?|\.\d+)"
_NUMBER_RE = rf"[-+]?\s*\$?\s*{_UNSIGNED_NUMBER_RE}"
_ARITHMETIC_TERM_RE = (
    rf"(?:\s*(?:\+|-|\*|/|×|÷)\s*{_NUMBER_RE}"
    rf"|\s*[xX]\s*\$?\s*{_UNSIGNED_NUMBER_RE})"
)
_ARITHMETIC_EXPRESSION_RE = rf"{_NUMBER_RE}(?:{_ARITHMETIC_TERM_RE})*"
_SINGLE_EQUALS_RE = r"(?<![=])=(?!=)"
_EXPLICIT_EQUATION_CHAIN_RE = re.compile(
    rf"(?P<chain>{_ARITHMETIC_EXPRESSION_RE}"
    rf"(?:\s*{_SINGLE_EQUALS_RE}\s*{_ARITHMETIC_EXPRESSION_RE})+)"
)
_SINGLE_EQUALS_SPLIT_RE = re.compile(_SINGLE_EQUALS_RE)


@dataclass(frozen=True)
class _ParsedEquation:
    text: str
    lhs_key: str
    lhs_value: Fraction
    rhs_value: Fraction
    lhs_node: ast.AST


@dataclass(frozen=True)
class _CalculationNode:
    """One canonical equation node in an ordered calculation DAG."""

    index: int
    text: str
    result: Fraction
    signature: tuple
    dependencies: tuple[int, ...]


@dataclass(frozen=True)
class _CalculationGraph:
    """Canonical calculation nodes plus dependency edges."""

    nodes: tuple[_CalculationNode, ...] = ()

    @property
    def edges(self) -> tuple[tuple[int, int], ...]:
        return tuple(
            (parent, node.index)
            for node in self.nodes
            for parent in node.dependencies
        )


def _normalise_arithmetic(expression: str) -> str:
    """Normalise display variants before parsing a numeric expression."""

    expression = expression.replace(",", "").replace("$", "")
    expression = expression.replace("×", "*").replace("÷", "/")
    expression = expression.replace("−", "-").replace("–", "-")
    expression = re.sub(r"(?<=\d)\s*[xX]\s*(?=[-+]?\s*\d)", "*", expression)
    return expression.strip()


def _eval_arithmetic_node(node) -> Fraction:
    """Evaluate a whitelisted arithmetic AST exactly as a Fraction."""

    if isinstance(node, ast.Constant) and not isinstance(node.value, bool):
        if isinstance(node.value, int):
            return Fraction(node.value)
        if isinstance(node.value, float):
            return Fraction(str(node.value))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        value = _eval_arithmetic_node(node.operand)
        return value if isinstance(node.op, ast.UAdd) else -value
    if isinstance(node, ast.BinOp):
        left = _eval_arithmetic_node(node.left)
        right = _eval_arithmetic_node(node.right)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if right == 0:
                raise ValueError("division by zero")
            return left / right
    raise ValueError("unsupported arithmetic expression")


def _parse_arithmetic_tree(expression: str) -> tuple[Fraction, str, ast.AST] | None:
    """Parse a basic arithmetic expression without executing arbitrary code."""

    normalised = _normalise_arithmetic(expression)
    try:
        tree = ast.parse(normalised, mode="eval")
        value = _eval_arithmetic_node(tree.body)
    except (SyntaxError, TypeError, ValueError, ZeroDivisionError):
        return None
    return (
        value,
        ast.dump(tree.body, annotate_fields=False, include_attributes=False),
        tree.body,
    )


def _parse_arithmetic(expression: str) -> tuple[Fraction, str] | None:
    """Return the exact value and stable AST key for a basic expression."""

    parsed = _parse_arithmetic_tree(expression)
    if parsed is None:
        return None
    value, key, _node = parsed
    return value, key


def _parse_equation(lhs: str, rhs: str, text: str) -> _ParsedEquation | None:
    lhs_parsed = _parse_arithmetic_tree(lhs)
    rhs_parsed = _parse_arithmetic(rhs)
    if lhs_parsed is None or rhs_parsed is None:
        return None
    lhs_value, lhs_key, lhs_node = lhs_parsed
    rhs_value, _rhs_key = rhs_parsed
    return _ParsedEquation(text.strip(), lhs_key, lhs_value, rhs_value, lhs_node)


def _gold_calculations(gold_solution: str) -> list[_ParsedEquation]:
    """Extract ordered GSM8K ``<<expression=result>>`` calculations."""

    calculations = []
    for annotation in _GOLD_CALCULATION_RE.findall(gold_solution or ""):
        if "=" not in annotation:
            continue
        lhs, rhs = annotation.rsplit("=", 1)
        parsed = _parse_equation(lhs, rhs, annotation)
        if parsed is not None:
            calculations.append(parsed)
    return calculations


def _explicit_calculations(reasoning: str) -> tuple[int, list[_ParsedEquation]]:
    """Extract explicit arithmetic equalities, including equality chains.

    Each adjacent link in ``a=b=c`` is audited independently. A match beginning
    with a sign is ignored when it is the trailing numeric fragment of a
    symbolic equation such as ``5x + 1 = 31``; standalone ``x``/``X`` remains a
    multiplication marker only when followed directly by a numeric literal.
    """

    reasoning = reasoning or ""
    mentions = 0
    parsed = []
    for match in _EXPLICIT_EQUATION_CHAIN_RE.finditer(reasoning):
        chain = match.group("chain")
        prefix = reasoning[:match.start()].rstrip()
        starts_with_sign = chain.lstrip().startswith(("+", "-"))
        follows_symbol = bool(
            re.search(r"(?:^|[^A-Za-z])[A-Za-z]$", prefix)
        )
        if starts_with_sign and follows_symbol:
            continue

        expressions = [
            expression.strip()
            for expression in _SINGLE_EQUALS_SPLIT_RE.split(chain)
        ]
        mentions += len(expressions) - 1
        for index, (lhs, rhs) in enumerate(zip(expressions, expressions[1:])):
            text = (
                chain.strip()
                if len(expressions) == 2
                else f"{lhs}={rhs}"
            )
            equation = _parse_equation(lhs, rhs, text)
            if equation is not None:
                parsed.append(equation)
    return mentions, parsed


def _fraction_signature(value: Fraction) -> tuple[str, int, int]:
    """Return a stable, hashable representation of an exact number."""

    return ("number", value.numerator, value.denominator)


def _literal_fraction(node: ast.AST) -> Fraction | None:
    """Evaluate a numeric literal, including unary signs, but not an operation."""

    if isinstance(node, ast.Constant) and not isinstance(node.value, bool):
        if isinstance(node.value, int):
            return Fraction(node.value)
        if isinstance(node.value, float):
            return Fraction(str(node.value))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        value = _literal_fraction(node.operand)
        if value is not None:
            return value if isinstance(node.op, ast.UAdd) else -value
    return None


def _graph_expression_signature(
    node: ast.AST,
    prior_by_value: dict[Fraction, _CalculationNode],
    dependencies: set[int],
) -> tuple:
    """Canonicalise an expression while resolving earlier results as DAG edges."""

    literal = _literal_fraction(node)
    if literal is not None:
        parent = prior_by_value.get(literal)
        if parent is not None:
            dependencies.add(parent.index)
        return _fraction_signature(literal)

    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        operand = _graph_expression_signature(node.operand, prior_by_value, dependencies)
        return operand if isinstance(node.op, ast.UAdd) else ("negate", operand)

    if isinstance(node, ast.BinOp):
        if isinstance(node.op, (ast.Add, ast.Mult)):
            operator = "add" if isinstance(node.op, ast.Add) else "multiply"
            operator_type = type(node.op)
            operands = []

            def collect(current: ast.AST) -> None:
                if isinstance(current, ast.BinOp) and isinstance(current.op, operator_type):
                    collect(current.left)
                    collect(current.right)
                else:
                    operands.append(
                        _graph_expression_signature(
                            current,
                            prior_by_value,
                            dependencies,
                        )
                    )

            collect(node)
            return (operator, tuple(sorted(operands, key=repr)))

        operator = "subtract" if isinstance(node.op, ast.Sub) else "divide"
        return (
            operator,
            _graph_expression_signature(node.left, prior_by_value, dependencies),
            _graph_expression_signature(node.right, prior_by_value, dependencies),
        )

    raise ValueError("unsupported arithmetic graph node")


def _calculation_graph(equations: list[_ParsedEquation]) -> _CalculationGraph:
    """Build a canonical DAG from ordered, explicit arithmetic equations.

    A numeric literal is treated as a dependency when it equals the most recent
    earlier equation result. Independent equations may therefore be reordered,
    while dependent equations must expose the same calculation path.
    """

    nodes = []
    prior_by_value: dict[Fraction, _CalculationNode] = {}
    for index, equation in enumerate(equations):
        dependencies: set[int] = set()
        expression = _graph_expression_signature(
            equation.lhs_node,
            prior_by_value,
            dependencies,
        )
        signature = (
            "equation",
            expression,
            _fraction_signature(equation.rhs_value),
        )
        node = _CalculationNode(
            index=index,
            text=equation.text,
            result=equation.rhs_value,
            signature=signature,
            dependencies=tuple(sorted(dependencies)),
        )
        nodes.append(node)
        prior_by_value[equation.rhs_value] = node
    return _CalculationGraph(tuple(nodes))


def _graph_overlap(
    gold: _CalculationGraph,
    candidate: _CalculationGraph,
) -> tuple[int, int, tuple[str, ...], tuple[str, ...]]:
    """Count covered gold nodes and edges as multisets of canonical signatures."""

    candidate_nodes = Counter(node.signature for node in candidate.nodes)
    node_matches = 0
    missing_nodes = []
    for node in gold.nodes:
        if candidate_nodes[node.signature] > 0:
            candidate_nodes[node.signature] -= 1
            node_matches += 1
        else:
            missing_nodes.append(node.text)

    def edge_signatures(graph: _CalculationGraph):
        return [
            (
                graph.nodes[parent].signature,
                graph.nodes[child].signature,
            )
            for parent, child in graph.edges
        ]

    candidate_edges = Counter(edge_signatures(candidate))
    edge_matches = 0
    missing_edges = []
    for parent, child in gold.edges:
        signature = (
            gold.nodes[parent].signature,
            gold.nodes[child].signature,
        )
        if candidate_edges[signature] > 0:
            candidate_edges[signature] -= 1
            edge_matches += 1
        else:
            missing_edges.append(
                f"{gold.nodes[parent].text} -> {gold.nodes[child].text}"
            )

    return node_matches, edge_matches, tuple(missing_nodes), tuple(missing_edges)


def _numeric_audit(reasoning: str, gold_solution: str) -> NumericAudit:
    """Audit explicit candidate equations against arithmetic and gold checkpoints.

    The local audit permits alternative valid calculations. The graph audit is
    stricter: it asks whether the candidate contains the complete canonical DAG
    encoded by GSM8K's ordered ``<<expression=result>>`` annotations. Independent
    steps may be reordered and commutative operands may swap, but every gold node
    and dependency edge must be present. A graph is unavailable when any annotated
    gold calculation cannot be parsed safely.
    """

    gold_annotations = [
        annotation
        for annotation in _GOLD_CALCULATION_RE.findall(gold_solution or "")
        if "=" in annotation
    ]
    gold_equations = _gold_calculations(gold_solution)
    gold_by_lhs = {equation.lhs_key: equation.rhs_value for equation in gold_equations}
    mentions, equations = _explicit_calculations(reasoning)
    invalid = [equation.text for equation in equations
               if equation.lhs_value != equation.rhs_value]
    matches = []
    contradictions = []
    for equation in equations:
        expected = gold_by_lhs.get(equation.lhs_key)
        if expected is None:
            continue
        if equation.rhs_value == expected:
            matches.append(equation.text)
        else:
            contradictions.append(equation.text)

    gold_graph = _calculation_graph(gold_equations)
    candidate_graph = _calculation_graph(equations)
    graph_available = bool(gold_annotations) and (
        len(gold_equations) == len(gold_annotations)
        and all(equation.lhs_value == equation.rhs_value for equation in gold_equations)
    )
    if graph_available:
        node_matches, edge_matches, missing_nodes, missing_edges = _graph_overlap(
            gold_graph,
            candidate_graph,
        )
        node_coverage = node_matches / len(gold_graph.nodes)
        edge_coverage = (
            edge_matches / len(gold_graph.edges)
            if gold_graph.edges
            else 1.0
        )
        graph_fully_covered = (
            node_matches == len(gold_graph.nodes)
            and edge_matches == len(gold_graph.edges)
        )
    else:
        node_matches = edge_matches = 0
        node_coverage = edge_coverage = graph_fully_covered = None
        missing_nodes = missing_edges = ()

    return NumericAudit(
        equation_mentions=mentions,
        parsed_equations=len(equations),
        invalid_equations=len(invalid),
        gold_matches=len(matches),
        gold_contradictions=len(contradictions),
        gold_graph_available=graph_available,
        gold_graph_nodes=len(gold_graph.nodes),
        gold_graph_edges=len(gold_graph.edges),
        candidate_graph_nodes=len(candidate_graph.nodes),
        candidate_graph_edges=len(candidate_graph.edges),
        graph_node_matches=node_matches,
        graph_edge_matches=edge_matches,
        graph_node_coverage=node_coverage,
        graph_edge_coverage=edge_coverage,
        graph_fully_covered=graph_fully_covered,
        equations=tuple(equation.text for equation in equations),
        invalid=tuple(invalid),
        contradictions=tuple(contradictions),
        missing_graph_nodes=missing_nodes,
        missing_graph_edges=missing_edges,
    )


def _compact_gold_solution(gold_solution: str, gold_answer) -> str:
    """Render GSM8K's annotated calculations as a concise supervised target."""

    calculations = _gold_calculations(gold_solution)
    if not calculations:
        return gold_solution
    steps = [f"{equation.text.replace('=', ' = ', 1)}." for equation in calculations]
    return "\n".join(steps + [f"#### {gold_answer}"])


_CALCULATION_BLOCK_RE = re.compile(
    r"<calculations>\s*(.*?)\s*</calculations>",
    re.IGNORECASE | re.DOTALL,
)
_REASONING_BLOCK_RE = re.compile(
    r"<reasoning>\s*(.*?)\s*</reasoning>",
    re.IGNORECASE | re.DOTALL,
)


def _structured_trace_sections(text: str) -> tuple[str | None, str | None]:
    """Extract the explicit z and h fields from a structured completion."""

    calculations = _CALCULATION_BLOCK_RE.search(text or "")
    reasoning = _REASONING_BLOCK_RE.search(text or "")
    return (
        calculations.group(1).strip() if calculations else None,
        reasoning.group(1).strip() if reasoning else None,
    )


def _structured_trace_audit(text: str) -> StructuredTraceAudit:
    """Check whether a generated trace cleanly separates z before h."""

    calculation_match = _CALCULATION_BLOCK_RE.search(text or "")
    reasoning_match = _REASONING_BLOCK_RE.search(text or "")
    precedes = bool(
        calculation_match
        and reasoning_match
        and calculation_match.end() <= reasoning_match.start()
    )
    calculations = calculation_match.group(1).strip() if calculation_match else ""
    reasoning = reasoning_match.group(1).strip() if reasoning_match else ""
    return StructuredTraceAudit(
        has_calculation_block=calculation_match is not None,
        has_reasoning_block=reasoning_match is not None,
        calculation_precedes_reasoning=precedes,
        well_formed=bool(calculation_match and reasoning_match and precedes),
        calculation_characters=len(calculations),
        reasoning_characters=len(reasoning),
    )


def _structured_gold_reasoning(gold_solution: str) -> str:
    """Serialize observed z* before a verbal h* without duplicating annotations."""

    calculations = _gold_calculations(gold_solution)
    calculation_lines = [
        f"{index}. {equation.text.replace('=', ' = ', 1)}"
        for index, equation in enumerate(calculations, start=1)
    ]
    reasoning = _GOLD_CALCULATION_RE.sub("", _gold_reasoning_from_solution(gold_solution))
    reasoning = re.sub(r"[ \t]+", " ", reasoning).strip()
    return (
        "<calculations>\n"
        + "\n".join(calculation_lines)
        + "\n</calculations>\n<reasoning>\n"
        + reasoning
        + "\n</reasoning>"
    )


def _structured_gold_solution(gold_solution: str, gold_answer) -> str:
    """Return the supervised z* ++ h* ++ a* target for Option III."""

    return f"{_structured_gold_reasoning(gold_solution)}\n#### {gold_answer}"


def _trace_row_from_h_ids(
    tok,
    task,
    pid: int,
    h_ids: list[int],
    round_added: int,
    source: str,
    *,
    is_gold: bool = False,
    trace_id: str | None = None,
    proposal_correct: bool | None = None,
    proposal_tokens: int | None = None,
    numeric_reference_solution: str | None = None,
    trace_representation: str = "reasoning",
) -> TraceRow | None:
    """Build a q ++ h_s ++ gold_answer row and its training/scoring masks."""

    gold_answer = task.gold_answer[pid]
    if gold_answer is None:
        return None

    prompt_ids = tok(task.prompts[pid], return_tensors="pt").input_ids[0].tolist()
    answer_ids = tok(f"\n#### {gold_answer}", add_special_tokens=False).input_ids
    full = torch.tensor(prompt_ids + list(h_ids) + answer_ids, dtype=torch.long)

    span = torch.zeros(len(full), dtype=torch.bool)
    span[len(prompt_ids):] = True

    ans = torch.zeros(len(full), dtype=torch.bool)
    ans[len(prompt_ids) + len(h_ids):] = True
    if trace_representation not in TRACE_REPRESENTATIONS:
        raise ValueError(f"unknown AC-ALG1 trace_representation {trace_representation!r}")
    reasoning_text = tok.decode(list(h_ids))
    structured_audit = None
    audit_text = reasoning_text
    if trace_representation == "calculation_graph":
        structured_audit = _structured_trace_audit(reasoning_text)
        calculations, _reasoning = _structured_trace_sections(reasoning_text)
        audit_text = calculations or ""
    numeric_audit = (
        _numeric_audit(audit_text, numeric_reference_solution)
        if numeric_reference_solution is not None
        else None
    )

    return TraceRow(
        ids=full,
        span=span,
        ans=ans,
        pid=pid,
        round_added=round_added,
        source=source,
        is_gold=is_gold,
        trace_id=trace_id,
        proposal_correct=proposal_correct,
        proposal_tokens=proposal_tokens,
        numeric_audit=numeric_audit,
        trace_representation=trace_representation,
        structured_audit=structured_audit,
    )


def _gold_trace_row(
    tok,
    task,
    pid: int,
    round_added: int,
    trace_representation: str = "reasoning",
) -> TraceRow | None:
    """Build the official gold trace row for a question buffer.

    Args:
        tok: Tokenizer.
        task: GSM8K-style task.
        pid: Question id.
        round_added: Current outer training round.

    Returns:
        TraceRow for q ++ gold_reasoning ++ gold_answer, or None if the answer
        or solution is unavailable.
    """

    gold_solution = task.gold_solution[pid]
    if task.gold_answer[pid] is None or not gold_solution:
        return None

    if trace_representation not in TRACE_REPRESENTATIONS:
        raise ValueError(f"unknown AC-ALG1 trace_representation {trace_representation!r}")
    gold_reasoning = (
        _structured_gold_reasoning(gold_solution)
        if trace_representation == "calculation_graph"
        else _gold_reasoning_from_solution(gold_solution)
    )
    h_ids = tok(" " + gold_reasoning, add_special_tokens=False).input_ids
    return _trace_row_from_h_ids(
        tok,
        task,
        pid,
        h_ids,
        round_added,
        "gold",
        is_gold=True,
        trace_id=f"gold:{pid}",
        proposal_correct=True,
        numeric_reference_solution=gold_solution,
        trace_representation=trace_representation,
    )


def _enforce_buffer_limit(rows: list[TraceRow], buffer_limit: int, buffer_strategy: str = "fifo") -> int:
    """Apply a per-question buffer cap while preserving the official gold trace.

    Args:
        rows: Mutable per-question buffer.
        buffer_limit: Maximum rows to keep. Values <= 0 mean unbounded.
        buffer_strategy: "fifo" keeps the newest rows. "hybrid" keeps gold,
            recent sampled rows, and high-weight sampled rows.

    Returns:
        Number of rows evicted. Mutates rows in place.
    """

    if buffer_limit <= 0 or len(rows) <= buffer_limit:
        return 0
    if buffer_strategy not in ("fifo", "hybrid"):
        raise ValueError(f"unknown AC-ALG1 buffer_strategy {buffer_strategy!r}")

    gold_rows = [row for row in rows if row.is_gold]
    sampled_rows = [row for row in rows if not row.is_gold]
    sampled_keep = max(buffer_limit - len(gold_rows), 0)

    if buffer_strategy == "fifo":
        keep_sampled_ids = {id(row) for row in sampled_rows[-sampled_keep:]} if sampled_keep else set()
    else:
        recent_keep = (sampled_keep + 1) // 2
        elite_keep = sampled_keep - recent_keep
        recent_rows = sampled_rows[-recent_keep:] if recent_keep else []
        recent_ids = {id(row) for row in recent_rows}
        elite_pool = [row for row in sampled_rows if id(row) not in recent_ids]
        elite_rows = sorted(elite_pool, key=lambda row: (row.elite_score, row.round_added), reverse=True)[:elite_keep]
        keep_sampled_ids = recent_ids | {id(row) for row in elite_rows}

    before = len(rows)
    rows[:] = [row for row in rows if row.is_gold or id(row) in keep_sampled_ids]
    return before - len(rows)


def _add_gold_traces_to_buffer(
    tok,
    task,
    buffers: dict[int, list[TraceRow]],
    labelled_pids: list[int],
    round_added: int,
    buffer_limit: int,
    buffer_strategy: str,
    trace_representation: str = "reasoning",
) -> tuple[int, int]:
    """Insert gold reasoning traces into per-question buffers.

    Args:
        tok: Tokenizer.
        task: GSM8K-style task.
        buffers: Dictionary mapping question id to list of TraceRow objects.
        labelled_pids: Labelled question ids.
        round_added: Current outer training round.
        buffer_limit: Per-question buffer cap. Values <= 0 mean unbounded.
        buffer_strategy: Buffer pruning strategy.

    Returns:
        Pair ``(rows_added, rows_evicted)``. Mutates buffers in place.
    """

    rows_added = 0
    rows_evicted = 0
    for pid in labelled_pids:
        # Keep one copy of the official trace per question. Repeated copies would
        # artificially increase its buffer mass just because the question recurred.
        if any(row.is_gold for row in buffers[pid]):
            continue

        row = _gold_trace_row(
            tok,
            task,
            int(pid),
            round_added,
            trace_representation=trace_representation,
        )
        if row is not None:
            buffers[int(pid)].append(row)
            rows_added += 1
            rows_evicted += _enforce_buffer_limit(buffers[int(pid)], buffer_limit, buffer_strategy)
    return rows_added, rows_evicted


def _reason_cut(text: str) -> int:
    """Find where sampled reasoning should stop before appending the gold answer.

    Args:
        text: Decoded model completion.

    Returns:
        Character index where h_s ends.
    """

    cut = len(text)
    for marker in (
        "####",
        "</think>",
        "<answer>",
        "\nQuestion:",
        "\n\nQuestion:",
        "\nQ:",
        "\nUser:",
    ):
        idx = text.find(marker)
        if idx != -1:
            cut = min(cut, idx)
    return cut


def _tagged_reasoning_prompt(
    question: str,
    gold_solution: str | None = None,
) -> str:
    """Build the zero-shot User/Assistant proposal format."""

    instruction = (
        "A conversation between User and Assistant. The user asks a question, "
        "and the Assistant solves it. The Assistant first thinks about the "
        "reasoning process in the mind and then provides the user with the "
        "answer. The reasoning process and answer are enclosed within "
        "<think>...</think> and <answer>...</answer> tags, respectively, i.e., "
        "<think> reasoning process here </think> "
        "<answer> answer here </answer>."
    )
    user_prompt = question.strip()
    if gold_solution:
        rationale = _gold_reasoning_from_solution(gold_solution).strip()
        user_prompt += (
            "\nReference rationale for this labelled question: "
            f"<rationale>{rationale}</rationale>"
        )
    return f"{instruction}\nUser: {user_prompt}\nAssistant: <think>"


def _build_proposal_prompt(
    prompt: str,
    gold_answer,
    proposal_prompt: str = "question",
    *,
    question: str | None = None,
    gold_solution: str | None = None,
    trace_representation: str = "reasoning",
) -> str:
    """Build the prompt used only to propose a candidate reasoning trace.

    The returned prompt may expose the known answer, but sampled reasoning is
    subsequently reanchored under the original question-only prompt before it
    enters the buffer. Thus this changes candidate discovery, not the sequence
    scored by the E-step or trained by the M-step.
    """

    if proposal_prompt not in PROPOSAL_PROMPTS:
        raise ValueError(f"unknown AC-ALG1 proposal_prompt {proposal_prompt!r}")
    if trace_representation not in TRACE_REPRESENTATIONS:
        raise ValueError(f"unknown AC-ALG1 trace_representation {trace_representation!r}")
    if trace_representation == "calculation_graph" and proposal_prompt.startswith("tagged_"):
        raise ValueError(
            "calculation_graph traces cannot be combined with tagged proposal prompts"
        )

    if proposal_prompt in ("tagged_zero_shot", "tagged_gold_rationale"):
        if question is None:
            raise ValueError(
                f"proposal_prompt={proposal_prompt!r} requires the raw question text"
            )
        if proposal_prompt == "tagged_gold_rationale" and not gold_solution:
            raise ValueError(
                "proposal_prompt='tagged_gold_rationale' requires a labelled gold solution"
            )
        return _tagged_reasoning_prompt(
            question,
            gold_solution if proposal_prompt == "tagged_gold_rationale" else None,
        )

    if proposal_prompt == "question":
        insertion = ""
    elif proposal_prompt == "derive_only":
        insertion = (
            "\nDerive a step-by-step solution to the question and finish with "
            "#### followed by the final numeric answer."
        )
    elif gold_answer is None:
        return prompt
    elif proposal_prompt == "answer_hint":
        insertion = f" (the final answer is {gold_answer})"
    else:
        insertion = (
            f"\nThe correct final answer is {gold_answer}. "
            "Derive a step-by-step solution and finish with "
            f"#### {gold_answer}."
        )

    if trace_representation == "calculation_graph":
        insertion = (
            "\nRepresent the calculation graph and its verbal explanation separately. "
            "Use exactly this output structure:\n"
            "<calculations>\n"
            "one explicit arithmetic equality per line\n"
            "</calculations>\n"
            "<reasoning>\n"
            "a concise explanation that uses those calculations\n"
            "</reasoning>\n"
            "#### final numeric answer"
            + insertion
        )

    if not insertion:
        return prompt

    answer_marker = "\nAnswer:"
    marker_index = prompt.rfind(answer_marker)
    if marker_index == -1:
        return prompt + insertion
    return prompt[:marker_index] + insertion + prompt[marker_index:]


def _proposal_source(
    source: str,
    proposal_prompt: str,
    proposal_filter: str,
    trace_representation: str = "reasoning",
) -> str:
    """Build a trace-source label that preserves proposal provenance."""

    labels = [source]
    if proposal_prompt != "question":
        labels.append(proposal_prompt)
    if proposal_filter != "all":
        labels.append(proposal_filter)
    if trace_representation != "reasoning":
        labels.append(trace_representation)
    return ":".join(labels)


def _sampled_trace_row(
    tok,
    task,
    pid: int,
    ids: torch.Tensor,
    comp_mask: torch.Tensor,
    text: str,
    round_added: int,
    source: str,
    trace_id: str | None = None,
    proposal_correct: bool | None = None,
    proposal_tokens: int | None = None,
    numeric_reference_solution: str | None = None,
    trace_representation: str = "reasoning",
) -> TraceRow | None:
    """Convert one sampled completion into a trace-buffer row.

    Args:
        tok: Tokenizer.
        task: GSM8K-style task.
        pid: Question id for this completion.
        ids: Full generated token ids returned by sample_multi for this row.
        comp_mask: Boolean mask selecting completion tokens inside ids.
        text: Decoded completion text.
        round_added: Current outer training round.
        source: Source label for diagnostics.

    Returns:
        TraceRow for q ++ sampled_h ++ gold_answer, or None if no gold answer exists.
    """

    comp = ids[comp_mask].tolist()
    if comp and comp[-1] == tok.eos_token_id:
        comp = comp[:-1]

    cut = _reason_cut(text)

    if cut >= len(text):
        h_ids = comp
    else:
        # We cut in character space first, then find the longest token prefix whose
        # decoded text stays within that character cut. This avoids re-tokenising
        # decoded text and drifting from the original sampled tokens.
        lo, hi = 0, len(comp)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if len(tok.decode(comp[:mid])) <= cut:
                lo = mid
            else:
                hi = mid - 1
        h_ids = comp[:lo]

    return _trace_row_from_h_ids(
        tok,
        task,
        pid,
        h_ids,
        round_added,
        source,
        trace_id=trace_id,
        proposal_correct=proposal_correct,
        proposal_tokens=proposal_tokens,
        numeric_reference_solution=numeric_reference_solution,
        trace_representation=trace_representation,
    )


def _add_model_traces_to_buffer(
    model,
    tok,
    task,
    buffers: dict[int, list[TraceRow]],
    pids: list[int],
    traces_per_question: int,
    round_added: int,
    source: str,
    buffer_limit: int,
    buffer_strategy: str,
    proposal_prompt: str = "question",
    proposal_filter: str = "all",
    proposal_policy: str = "current",
    trace_representation: str = "reasoning",
    collect_token_counts: bool = False,
    collect_proposal_outcomes: bool = False,
) -> tuple[list[int], list[str], list[int], int, int, dict]:
    """Sample model traces and append them to per-question buffers.

    Args:
        model: Language model used to sample h_s.
        tok: Tokenizer.
        task: GSM8K-style task.
        buffers: Dictionary mapping question id to list of TraceRow objects.
        pids: Question ids to sample from.
        traces_per_question: Number of sampled traces per question.
        round_added: Current outer training round.
        source: Source label, e.g. "labelled_sample" or "answer_only_sample".
        buffer_limit: Per-question buffer cap. Values <= 0 mean unbounded.
        buffer_strategy: Buffer pruning strategy.
        proposal_prompt: Candidate-generation prompt mode. Proposal-only
            instructions are stripped before the candidate enters the trace buffer.
        proposal_filter: Candidate-admission rule. ``answer_correct`` retains
            only completions whose decoded final answer matches the known answer.
        proposal_policy: ``current`` samples with the trained adapter;
            ``frozen_base`` temporarily disables it, yielding a fixed sampler.
        collect_token_counts: Return exact generated-token counts for diagnostics.
        collect_proposal_outcomes: Attach verifier outcomes and stable trace ids
            for observational diagnostics.

    Returns:
        Tuple containing question ids, decoded completions, generated token
        counts, rows added, rows evicted, and proposal-filter counts.
    """

    if proposal_filter not in PROPOSAL_FILTERS:
        raise ValueError(f"unknown AC-ALG1 proposal_filter {proposal_filter!r}")
    if proposal_policy not in ADAPTER_POLICY_MODES:
        raise ValueError(f"unknown AC-ALG1 proposal_policy {proposal_policy!r}")
    if trace_representation not in TRACE_REPRESENTATIONS:
        raise ValueError(f"unknown AC-ALG1 trace_representation {trace_representation!r}")
    if proposal_prompt == "tagged_gold_rationale" and source != "labelled_sample":
        raise ValueError(
            "tagged_gold_rationale proposals are restricted to labelled L' samples"
        )
    if not pids or traces_per_question <= 0:
        return [], [], [], 0, 0, {
            "mode": proposal_filter,
            "policy": proposal_policy,
            "attempted": 0,
            "accepted": 0,
            "rejected": 0,
            "verifier_calls": 0,
            "diagnostic_verifier_calls": 0,
            "trace_ids": [],
            "rewards": [],
            "correct": [],
            "admitted": [],
            "retained_after_insertion": [],
        }

    pid_row = [int(pid) for pid in pids for _ in range(traces_per_question)]
    prompts = [
        _build_proposal_prompt(
            task.prompts[pid],
            task.gold_answer[pid],
            proposal_prompt,
            question=(task.questions[pid] if hasattr(task, "questions") else None),
            gold_solution=(
                task.gold_solution[pid]
                if proposal_prompt == "tagged_gold_rationale"
                and hasattr(task, "gold_solution")
                else None
            ),
            trace_representation=trace_representation,
        )
        for pid in pid_row
    ]
    row_source = _proposal_source(
        source,
        proposal_prompt,
        proposal_filter,
        trace_representation,
    )
    if proposal_policy != "current":
        row_source = f"{row_source}:{proposal_policy}"

    with _adapter_policy_context(model, proposal_policy):
        ids, comp_mask, texts = sample_multi(
            model,
            tok,
            prompts,
            max_new=getattr(task, "max_new", 40),
        )

    measured_token_counts = (
        [int(value) for value in comp_mask.sum(dim=1).detach().cpu().tolist()]
        if collect_token_counts or collect_proposal_outcomes
        else []
    )
    token_counts = measured_token_counts if collect_token_counts else []
    trace_ids = [
        f"r{round_added}:{source}:{row_idx}:p{pid}"
        for row_idx, pid in enumerate(pid_row)
    ]
    rewards = None
    if proposal_filter == "answer_correct" or collect_proposal_outcomes:
        rewards = [float(value) for value in task.reward(texts, pids=pid_row)]
    correct = (
        [bool(reward > 0.5) for reward in rewards]
        if rewards is not None
        else [None] * len(texts)
    )
    accepted = [True] * len(texts)
    filter_verifier_calls = 0
    if proposal_filter == "answer_correct":
        accepted = list(correct)
        filter_verifier_calls = len(texts)

    filter_stats = {
        "mode": proposal_filter,
        "policy": proposal_policy,
        "attempted": len(texts),
        "accepted": int(sum(accepted)),
        "rejected": int(len(accepted) - sum(accepted)),
        "verifier_calls": filter_verifier_calls,
        "diagnostic_verifier_calls": (
            len(texts) if collect_proposal_outcomes and proposal_filter == "all" else 0
        ),
        "trace_ids": trace_ids,
        "rewards": rewards if rewards is not None else [None] * len(texts),
        "correct": correct,
        "admitted": accepted,
    }
    rows_added = 0
    rows_evicted = 0
    for row_idx, pid in enumerate(pid_row):
        if not accepted[row_idx]:
            continue
        row = _sampled_trace_row(
            tok,
            task,
            pid,
            ids[row_idx].cpu(),
            comp_mask[row_idx].cpu(),
            texts[row_idx],
            round_added,
            row_source,
            trace_id=trace_ids[row_idx],
            proposal_correct=correct[row_idx],
            proposal_tokens=(
                measured_token_counts[row_idx] if measured_token_counts else None
            ),
            numeric_reference_solution=(
                task.gold_solution[pid]
                if source == "labelled_sample" and hasattr(task, "gold_solution")
                else None
            ),
            trace_representation=trace_representation,
        )
        if row is not None:
            buffers[pid].append(row)
            rows_added += 1
            rows_evicted += _enforce_buffer_limit(buffers[pid], buffer_limit, buffer_strategy)

    retained_ids = {
        row.trace_id
        for pid in set(pid_row)
        for row in buffers[pid]
        if row.trace_id is not None
    }
    filter_stats["retained_after_insertion"] = [
        bool(admitted and trace_id in retained_ids)
        for admitted, trace_id in zip(accepted, trace_ids)
    ]
    return pid_row, texts, token_counts, rows_added, rows_evicted, filter_stats


def _pad_trace_rows(tok, rows: list[TraceRow]) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Pad trace-buffer rows into a model batch.

    Args:
        tok: Tokenizer.
        rows: TraceRow objects from one question buffer.

    Returns:
        ids: Padded q ++ h_s ++ a token ids.
        span: Padded mask for h_s ++ a.
        ans: Padded mask for a only.
    """

    pad = torch.nn.utils.rnn.pad_sequence
    ids = pad([row.ids for row in rows], batch_first=True, padding_value=tok.eos_token_id).to(DEV)
    span = pad([row.span for row in rows], batch_first=True, padding_value=False).to(DEV)
    ans = pad([row.ans for row in rows], batch_first=True, padding_value=False).to(DEV)
    return ids, span, ans


def _numeric_log_potential(
    row: TraceRow,
    labelled_numeric_constraint: str,
    numeric_penalty: float,
    numeric_contradiction_penalty: float = 0.0,
    numeric_missing_penalty: float = 0.0,
) -> float:
    """Return the fixed log compatibility potential for one labelled row."""

    if labelled_numeric_constraint == "off" or row.is_gold or row.numeric_audit is None:
        return 0.0
    errors = row.numeric_audit.invalid_equations
    if labelled_numeric_constraint == "graph_hard":
        if errors > 0 or row.numeric_audit.gold_contradictions > 0:
            return float("-inf")
        if (row.numeric_audit.gold_graph_available
                and row.numeric_audit.graph_fully_covered is not True):
            return float("-inf")
        return 0.0
    if errors == 0:
        if labelled_numeric_constraint == "hard":
            return 0.0
    if labelled_numeric_constraint == "hard":
        return float("-inf")
    missing_graph_items = (
        len(row.numeric_audit.missing_graph_nodes)
        + len(row.numeric_audit.missing_graph_edges)
        if row.numeric_audit.gold_graph_available
        else 0
    )
    return -(
        numeric_penalty * errors
        + numeric_contradiction_penalty * row.numeric_audit.gold_contradictions
        + numeric_missing_penalty * missing_graph_items
    )


def _buffer_weights_for_questions(
    model,
    tok,
    buffers: dict[int, list[TraceRow]],
    pids: list[int],
    responsibility_score: str = "joint",
    responsibility_temperature: float = 1.0,
    responsibility_ess_floor: float = 0.0,
    responsibility_policy: str = "current",
    responsibility_answer_policy: str = "current",
    labelled_numeric_constraint: str = "off",
    numeric_penalty: float = 2.0,
    numeric_contradiction_penalty: float = 0.0,
    numeric_missing_penalty: float = 0.0,
    record_joint_logprobs: bool = False,
) -> dict[int, torch.Tensor]:
    """Compute detached posterior responsibilities inside each question buffer.

    Args:
        model: Language model used for the E-step scoring pass.
        tok: Tokenizer.
        buffers: Dictionary mapping question id to list of TraceRow objects.
        pids: Question ids whose buffers should be weighted.
        responsibility_score: ``joint`` uses log p(h_s, a* | q), while
            ``token_mean`` divides that value by the scored token count.
        responsibility_temperature: Positive softmax temperature for E-step logits.
        responsibility_ess_floor: Minimum ESS as a fraction of the finite
            support. Zero disables the one-sided adaptive temperature.
        responsibility_policy: ``current`` scores with the trained adapter;
            ``frozen_base`` disables it for a stationary E-step scorer.
        responsibility_answer_policy: Policy used only for the answer-reader
            factor p(a* | h_s, q). ``current`` preserves the joint-policy
            E-step; ``frozen_base`` combines the configured trace prior with a
            frozen pretrained answer reader.
        labelled_numeric_constraint: ``off``, ``hard``, ``soft``, or
            ``graph_hard`` arithmetic compatibility potential. ``graph_hard``
            requires full gold calculation-DAG coverage when the gold graph is
            safely parseable. Callers must leave this off for U'.
        numeric_penalty: Per-invalid-equation log penalty in ``soft`` mode.
        numeric_contradiction_penalty: Per-gold-contradiction log penalty.
        numeric_missing_penalty: Per-missing gold graph node or edge log penalty.
        record_joint_logprobs: Copy logits to TraceRow objects for diagnostics.

    Returns:
        Dictionary mapping each question id to a detached weight vector over B(q).
    """

    if responsibility_score not in RESPONSIBILITY_SCORES:
        raise ValueError(f"unknown AC-ALG1 responsibility_score {responsibility_score!r}")
    if labelled_numeric_constraint not in LABELLED_NUMERIC_CONSTRAINTS:
        raise ValueError(
            "unknown AC-ALG1 labelled_numeric_constraint "
            f"{labelled_numeric_constraint!r}"
        )
    if not math.isfinite(responsibility_temperature) or responsibility_temperature <= 0:
        raise ValueError(
            "responsibility_temperature must be finite and positive, "
            f"got {responsibility_temperature}"
        )
    if (
        not math.isfinite(responsibility_ess_floor)
        or not 0.0 <= responsibility_ess_floor <= 1.0
    ):
        raise ValueError(
            "responsibility_ess_floor must be finite and in [0, 1], "
            f"got {responsibility_ess_floor}"
        )
    if responsibility_policy not in ADAPTER_POLICY_MODES:
        raise ValueError(
            f"unknown AC-ALG1 responsibility_policy {responsibility_policy!r}"
        )
    if responsibility_answer_policy not in ADAPTER_POLICY_MODES:
        raise ValueError(
            "unknown AC-ALG1 responsibility_answer_policy "
            f"{responsibility_answer_policy!r}"
        )
    if not math.isfinite(numeric_penalty) or numeric_penalty < 0:
        raise ValueError(f"numeric_penalty must be finite and nonnegative, got {numeric_penalty}")
    for name, value in (
        ("numeric_contradiction_penalty", numeric_contradiction_penalty),
        ("numeric_missing_penalty", numeric_missing_penalty),
    ):
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative, got {value}")

    weights = {}

    with torch.no_grad():
        for pid in pids:
            rows = list(buffers[int(pid)])
            if not rows:
                continue

            ids, span, ans = _pad_trace_rows(tok, rows)
            # The finite-buffer logit factorizes into a trace prior and answer
            # reader. Matched policies recover the joint sequence score; the
            # frozen-reader arm changes only the answer factor.
            trace_logprobs = answer_logprobs = None
            if responsibility_answer_policy == responsibility_policy:
                with _adapter_policy_context(model, responsibility_policy):
                    joint_logprobs = seq_logprobs(
                        model, ids, span, micro=16, length_norm=False
                    )
                    if record_joint_logprobs:
                        answer_logprobs = seq_logprobs(
                            model, ids, ans, micro=16, length_norm=False
                        )
                        trace_logprobs = joint_logprobs - answer_logprobs
            else:
                trace_span = span & ~ans
                with _adapter_policy_context(model, responsibility_policy):
                    trace_logprobs = seq_logprobs(
                        model, ids, trace_span, micro=16, length_norm=False
                    )
                with _adapter_policy_context(model, responsibility_answer_policy):
                    answer_logprobs = seq_logprobs(
                        model, ids, ans, micro=16, length_norm=False
                    )
                joint_logprobs = trace_logprobs + answer_logprobs
            if responsibility_score == "token_mean":
                scored_tokens = span.sum(dim=1).clamp_min(1).to(joint_logprobs.dtype)
                base_logits = joint_logprobs / scored_tokens
            else:
                base_logits = joint_logprobs

            log_potentials = torch.tensor(
                [
                    _numeric_log_potential(
                        row,
                        labelled_numeric_constraint,
                        numeric_penalty,
                        numeric_contradiction_penalty,
                        numeric_missing_penalty,
                    )
                    for row in rows
                ],
                dtype=base_logits.dtype,
                device=base_logits.device,
            )
            logits = base_logits + log_potentials

            effective_temperature = _one_sided_ess_temperature(
                logits,
                base_temperature=responsibility_temperature,
                ess_floor_fraction=responsibility_ess_floor,
            )
            before = torch.softmax(
                base_logits / effective_temperature, dim=0
            ).detach()
            w = torch.softmax(logits / effective_temperature, dim=0).detach()
            joint_values = joint_logprobs.cpu().tolist() if record_joint_logprobs else None
            trace_values = (
                trace_logprobs.cpu().tolist()
                if record_joint_logprobs and trace_logprobs is not None
                else None
            )
            answer_values = (
                answer_logprobs.cpu().tolist()
                if record_joint_logprobs and answer_logprobs is not None
                else None
            )
            logit_values = logits.cpu().tolist() if record_joint_logprobs else None
            for index, (row, score) in enumerate(zip(rows, w.cpu().tolist())):
                row.numeric_log_potential = float(log_potentials[index].item())
                row.responsibility_before_potential = float(before[index].item())
                row.responsibility_temperature_used = effective_temperature
                if joint_values is not None:
                    row.joint_logprob = float(joint_values[index])
                    row.trace_logprob = float(trace_values[index])
                    row.answer_logprob = float(answer_values[index])
                    row.responsibility_logit = float(logit_values[index])
                row.elite_score = float(score)
            weights[int(pid)] = w

    return weights


def _B_unsup_for_questions(
    model,
    tok,
    buffers: dict[int, list[TraceRow]],
    pids: list[int],
    weights: dict[int, torch.Tensor],
    grad: bool = True,
) -> torch.Tensor:
    """Weighted latent-trace objective over selected per-question buffers.

    Args:
        model: Trainable language model.
        tok: Tokenizer.
        buffers: Dictionary mapping question id to list of TraceRow objects.
        pids: Question ids selected for this objective term.
        weights: Detached posterior responsibilities for each selected B(q).
        grad: Whether the returned score must retain an autograd graph.

    Returns:
        Scalar tensor containing the weighted EM objective over the selected buffers.
    """

    terms = []

    for pid in pids:
        rows = list(buffers[int(pid)])
        w = weights.get(int(pid))

        if not rows or w is None:
            continue

        ids, span, _ans = _pad_trace_rows(tok, rows)
        logp = seq_logprobs(model, ids, span, grad=grad, length_norm=False)

        terms.append((w.to(DEV) * logp).sum())

    if not terms:
        return torch.zeros((), device=DEV)

    return torch.stack(terms).mean()


def _reference_policy_row_kl(
    model,
    ids: torch.Tensor,
    span: torch.Tensor,
    micro: int = 4,
    grad: bool = True,
) -> torch.Tensor:
    """Return a per-row token-mean KL estimate to the frozen base policy.

    The non-negative ``k3`` estimator matches the GRPO implementation:
    ``exp(log p_ref - log p_theta) - (log p_ref - log p_theta) - 1``.
    It is evaluated only on the supplied target span, so policy anchoring does
    not introduce a new prompt or trace distribution.
    """

    if ids.shape[0] == 0:
        return torch.empty(0, device=DEV)

    rows = []
    for start in range(0, ids.shape[0], micro):
        chunk_ids = ids[start:start + micro]
        chunk_span = span[start:start + micro]
        with torch.no_grad(), model.disable_adapter():
            reference_logps = token_logps(model, chunk_ids, grad=False)
        current_logps = token_logps(model, chunk_ids, grad=grad)
        log_reference_ratio = (reference_logps - current_logps).clamp(-5, 5)
        token_kl = torch.exp(log_reference_ratio) - log_reference_ratio - 1
        target_mask = chunk_span[:, 1:].to(dtype=token_kl.dtype)
        rows.append(
            (token_kl * target_mask).sum(dim=1)
            / target_mask.sum(dim=1).clamp_min(1.0)
        )
    return torch.cat(rows)


def _supervised_reference_policy_kl(
    model,
    tok,
    task,
    labelled_pids: list[int],
    labelled_supervision: str = "gold",
    micro: int = 4,
    grad: bool = True,
) -> torch.Tensor:
    """Measure the frozen-policy KL on the supervised M-step targets."""

    solutions = None
    if labelled_supervision == "gold_graph_factorized":
        solutions = [
            _structured_gold_solution(
                task.gold_solution[int(pid)], task.gold_answer[int(pid)]
            )
            for pid in labelled_pids
        ]
    batch = _build_supervised_batch(tok, task, labelled_pids, solutions=solutions)
    if batch is None:
        return torch.zeros((), device=DEV)
    ids, span = batch
    return _reference_policy_row_kl(
        model, ids, span, micro=micro, grad=grad
    ).mean()


def _backward_reference_policy_kl_for_questions(
    model,
    tok,
    buffers: dict[int, list[TraceRow]],
    pids: list[int],
    weights: dict[int, torch.Tensor],
    micro: int = 4,
    backward_scale: float = 0.0,
) -> tuple[float, bool]:
    """Measure a responsibility-weighted buffer KL and optionally backpropagate it."""

    valid = [
        int(pid)
        for pid in pids
        if buffers[int(pid)] and weights.get(int(pid)) is not None
    ]
    if not valid:
        return 0.0, False

    raw_kl = 0.0
    took_grad = False
    denominator = len(valid)
    for pid in valid:
        rows = list(buffers[pid])
        row_weights = weights[pid].to(DEV)
        for start in range(0, len(rows), micro):
            chunk = rows[start:start + micro]
            ids, span, _ans = _pad_trace_rows(tok, chunk)
            row_kl = _reference_policy_row_kl(
                model,
                ids,
                span,
                micro=micro,
                grad=backward_scale > 0,
            )
            contribution = (
                row_weights[start:start + len(chunk)] * row_kl
            ).sum() / denominator
            raw_kl += float(contribution.detach())
            if backward_scale > 0 and contribution.requires_grad:
                (backward_scale * contribution).backward()
                took_grad = True
    return raw_kl, took_grad


def _backward_B_unsup_for_questions(
    model,
    tok,
    buffers: dict[int, list[TraceRow]],
    pids: list[int],
    weights: dict[int, torch.Tensor],
    micro: int = 4,
    coefficient: float = 1.0,
) -> tuple[float, bool]:
    """Accumulate ascent gradients without retaining every buffer row's graph."""
    valid = [
        int(pid)
        for pid in pids
        if buffers[int(pid)] and weights.get(int(pid)) is not None
    ]
    if not valid:
        return 0.0, False

    objective = 0.0
    denominator = len(valid)
    took_grad = False
    for pid in valid:
        rows = list(buffers[pid])
        w = weights[pid].to(DEV)
        for start in range(0, len(rows), micro):
            chunk = rows[start:start + micro]
            ids, span, _ans = _pad_trace_rows(tok, chunk)
            logp = seq_logprobs(model, ids, span, grad=True, micro=micro, length_norm=False)
            contribution = coefficient * (w[start:start + len(chunk)] * logp).sum() / denominator
            objective += float(contribution.detach())
            if contribution.requires_grad:
                (-contribution).backward()
                took_grad = True
    return objective, took_grad


def _total_objective(
    B_sup: torch.Tensor,
    B_prime_unsup: torch.Tensor,
    B_unsup: torch.Tensor,
) -> torch.Tensor:
    """Add the supervised and latent-trace objective contributions.

    Args:
        B_sup: Supervised gold-solution objective.
        B_prime_unsup: Weighted buffer objective on labelled questions, B'_unsup.
        B_unsup: Weighted buffer objective on answer-only questions.

    Returns:
        Scalar tensor F = B_sup + B'_unsup + B_unsup.
    """

    return B_sup + B_prime_unsup + B_unsup


def _gradient_ascent_step(opt, F: torch.Tensor) -> bool:
    """Take one optimizer step that ascends the objective F.

    Args:
        opt: PyTorch optimizer for the trainable model parameters.
        F: Scalar objective tensor to maximise.

    Returns:
        True if a gradient step was taken, False if F has no gradient path.
    """

    if not F.requires_grad:
        return False

    opt.zero_grad()
    (-F).backward()
    opt.step()
    return True


def _snapshot_trainable_gradients(model) -> list[torch.Tensor]:
    """Clone current trainable gradients for diagnostic decomposition."""

    snapshots = []
    with torch.no_grad():
        for parameter in model.parameters():
            if not parameter.requires_grad:
                continue
            if parameter.grad is None:
                snapshots.append(torch.zeros_like(parameter, dtype=torch.float32))
            else:
                snapshots.append(parameter.grad.detach().float().clone())
    return snapshots


def _snapshot_native_trainable_gradients(
    model,
) -> list[torch.Tensor | None]:
    """Clone trainable gradients without changing their optimizer dtype."""

    return [
        None if parameter.grad is None else parameter.grad.detach().clone()
        for parameter in model.parameters()
        if parameter.requires_grad
    ]


def _gradient_norm(gradients: list[torch.Tensor | None]) -> float:
    """Return a stable float32 L2 norm for a trainable-gradient snapshot."""

    squared = sum(
        float(torch.sum(gradient.detach().float().square()))
        for gradient in gradients
        if gradient is not None
    )
    if not math.isfinite(squared):
        raise FloatingPointError("non-finite policy-anchor gradient norm")
    return math.sqrt(max(squared, 0.0))


def _apply_gradient_ratio_policy_anchor(
    model,
    objective_gradients: list[torch.Tensor | None],
    state: dict[str, float],
    target_ratio: float,
    beta_min: float,
    beta_max: float,
    ema: float,
    epsilon: float = 1e-12,
) -> dict[str, float]:
    """Scale the unit KL gradient to a target fraction of the objective gradient.

    ``parameter.grad`` must contain ``g_F + g_KL`` on entry, where ``g_F`` is
    the minimization gradient of ``-F`` captured in ``objective_gradients`` and
    ``g_KL`` is the unit-coefficient reference-policy gradient. The function
    replaces it with ``g_F + beta * g_KL`` using a detached, EMA-smoothed beta.
    """

    parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    if len(parameters) != len(objective_gradients):
        raise ValueError("adaptive policy-anchor snapshots must contain the same parameters")

    raw_anchor_gradients: list[torch.Tensor | None] = []
    for parameter, objective in zip(parameters, objective_gradients):
        combined = parameter.grad
        if combined is None:
            raw_anchor_gradients.append(None)
        elif objective is None:
            raw_anchor_gradients.append(combined.detach().clone())
        else:
            raw_anchor_gradients.append(combined.detach() - objective)

    objective_norm = _gradient_norm(objective_gradients)
    raw_anchor_norm = _gradient_norm(raw_anchor_gradients)

    previous_objective = state.get("ema_objective_grad_norm")
    previous_anchor = state.get("ema_raw_anchor_grad_norm")
    ema_objective = (
        objective_norm
        if previous_objective is None
        else ema * previous_objective + (1.0 - ema) * objective_norm
    )
    ema_anchor = (
        raw_anchor_norm
        if previous_anchor is None
        else ema * previous_anchor + (1.0 - ema) * raw_anchor_norm
    )
    state["ema_objective_grad_norm"] = ema_objective
    state["ema_raw_anchor_grad_norm"] = ema_anchor

    if target_ratio == 0.0 or ema_objective <= epsilon or ema_anchor <= epsilon:
        beta_unclipped = 0.0
        beta = 0.0
    else:
        beta_unclipped = target_ratio * ema_objective / max(ema_anchor, epsilon)
        beta = min(max(beta_unclipped, beta_min), beta_max)

    with torch.no_grad():
        for parameter, objective, raw_anchor in zip(
            parameters, objective_gradients, raw_anchor_gradients
        ):
            if objective is None and (raw_anchor is None or beta == 0.0):
                parameter.grad = None
                continue
            if objective is None:
                optimized = beta * raw_anchor
            elif raw_anchor is None:
                optimized = objective
            else:
                optimized = objective + beta * raw_anchor
            if parameter.grad is None:
                parameter.grad = optimized.clone()
            else:
                parameter.grad.copy_(optimized)

    applied_anchor_norm = beta * raw_anchor_norm
    achieved_ratio = (
        applied_anchor_norm / objective_norm if objective_norm > epsilon else 0.0
    )
    return {
        "beta": beta,
        "beta_unclipped": beta_unclipped,
        "beta_clipped": float(beta != beta_unclipped),
        "objective_grad_norm": objective_norm,
        "raw_anchor_grad_norm": raw_anchor_norm,
        "applied_anchor_grad_norm": applied_anchor_norm,
        "achieved_ratio": achieved_ratio,
        "ema_objective_grad_norm": ema_objective,
        "ema_raw_anchor_grad_norm": ema_anchor,
    }


def _gradient_geometry_from_snapshots(
    supervised: list[torch.Tensor],
    after_labelled_em: list[torch.Tensor],
    total: list[torch.Tensor],
) -> dict:
    """Recover objective-component gradient norms and pairwise cosines."""

    if not (len(supervised) == len(after_labelled_em) == len(total)):
        raise ValueError("gradient snapshots must contain the same parameters")
    components = {
        "B_sup": supervised,
        "B_prime_unsup": [
            labelled - sup for labelled, sup in zip(after_labelled_em, supervised)
        ],
        "B_unsup": [
            combined - labelled for combined, labelled in zip(total, after_labelled_em)
        ],
        "total": total,
    }

    norms = {}
    for name, tensors in components.items():
        squared = sum(float(torch.sum(tensor * tensor)) for tensor in tensors)
        norms[name] = (
            math.sqrt(max(squared, 0.0)) if math.isfinite(squared) else None
        )

    cosines = {}
    for left, right in (
        ("B_sup", "B_prime_unsup"),
        ("B_sup", "B_unsup"),
        ("B_prime_unsup", "B_unsup"),
    ):
        if norms[left] is None or norms[right] is None:
            cosine = None
        else:
            denominator = norms[left] * norms[right]
            dot = sum(
                float(torch.sum(a * b))
                for a, b in zip(components[left], components[right])
            )
            cosine = (
                min(max(dot / denominator, -1.0), 1.0)
                if denominator > 0 and math.isfinite(dot)
                else None
            )
        cosines[f"{left}__{right}"] = cosine

    return {"norms": norms, "cosines": cosines}


def _add_policy_anchor_gradient_geometry(
    geometry: dict,
    objective_total: list[torch.Tensor],
    optimized_total: list[torch.Tensor],
) -> dict:
    """Add the KL-anchor norm and its cosine with the unanchored loss gradient."""

    if len(objective_total) != len(optimized_total):
        raise ValueError("policy-anchor gradient snapshots must contain the same parameters")
    anchor = [
        optimized - objective
        for optimized, objective in zip(optimized_total, objective_total)
    ]

    def norm(tensors):
        squared = sum(float(torch.sum(tensor * tensor)) for tensor in tensors)
        return math.sqrt(max(squared, 0.0)) if math.isfinite(squared) else None

    objective_norm = geometry["norms"].get("total")
    anchor_norm = norm(anchor)
    optimized_norm = norm(optimized_total)
    geometry["norms"]["policy_anchor"] = anchor_norm
    geometry["norms"]["optimized_total"] = optimized_norm

    denominator = (
        objective_norm * anchor_norm
        if objective_norm is not None and anchor_norm is not None
        else 0.0
    )
    dot = sum(
        float(torch.sum(objective * policy))
        for objective, policy in zip(objective_total, anchor)
    )
    geometry["cosines"]["total__policy_anchor"] = (
        min(max(dot / denominator, -1.0), 1.0)
        if denominator > 0 and math.isfinite(dot)
        else None
    )
    return geometry


def _refresh_minibatch_weights(
    model,
    tok,
    buffers: dict[int, list[TraceRow]],
    labelled_pids: list[int],
    answer_only_pids: list[int],
    responsibility_score: str = "joint",
    responsibility_temperature: float = 1.0,
    responsibility_ess_floor: float = 0.0,
    responsibility_policy: str = "current",
    responsibility_answer_policy: str = "current",
    labelled_numeric_constraint: str = "off",
    numeric_penalty: float = 2.0,
    numeric_contradiction_penalty: float = 0.0,
    numeric_missing_penalty: float = 0.0,
    record_joint_logprobs: bool = False,
) -> tuple[dict[int, torch.Tensor], dict[int, torch.Tensor]]:
    """Recompute detached trace responsibilities for the current minibatches.

    Args:
        model: Language model after the latest gradient step.
        tok: Tokenizer.
        buffers: Dictionary mapping question id to list of TraceRow objects.
        labelled_pids: Labelled question ids currently in L'.
        answer_only_pids: Answer-only question ids currently in U'.
        responsibility_score: E-step logit definition.
        responsibility_temperature: Positive E-step softmax temperature.
        responsibility_ess_floor: One-sided minimum ESS fraction.
        responsibility_policy: Current adapter or frozen-base E-step scorer.
        responsibility_answer_policy: Current or frozen-base answer-reader factor.
        labelled_numeric_constraint: Local or calculation-graph arithmetic
            potential applied only to L'.
        numeric_penalty: Per-invalid-equation log penalty in soft mode.
        numeric_contradiction_penalty: Per-gold-contradiction soft penalty.
        numeric_missing_penalty: Per-missing graph item soft penalty.
        record_joint_logprobs: Persist the scoring logits for diagnostics.

    Returns:
        labelled_weights: Responsibilities over B(q) for q in labelled_pids.
        answer_only_weights: Responsibilities over B(q) for q in answer_only_pids.
    """

    labelled_weights = _buffer_weights_for_questions(
        model,
        tok,
        buffers,
        labelled_pids,
        responsibility_score=responsibility_score,
        responsibility_temperature=responsibility_temperature,
        responsibility_ess_floor=responsibility_ess_floor,
        responsibility_policy=responsibility_policy,
        responsibility_answer_policy=responsibility_answer_policy,
        labelled_numeric_constraint=labelled_numeric_constraint,
        numeric_penalty=numeric_penalty,
        numeric_contradiction_penalty=numeric_contradiction_penalty,
        numeric_missing_penalty=numeric_missing_penalty,
        record_joint_logprobs=record_joint_logprobs,
    )
    answer_only_weights = _buffer_weights_for_questions(
        model,
        tok,
        buffers,
        answer_only_pids,
        responsibility_score=responsibility_score,
        responsibility_temperature=responsibility_temperature,
        responsibility_ess_floor=responsibility_ess_floor,
        responsibility_policy=responsibility_policy,
        responsibility_answer_policy=responsibility_answer_policy,
        record_joint_logprobs=record_joint_logprobs,
    )
    return labelled_weights, answer_only_weights


def _responsibility_refresh_total_variations(
    before: dict[int, torch.Tensor],
    after: dict[int, torch.Tensor],
) -> list[float]:
    """Return per-question total variation across one E-step refresh.

    Support is fixed inside an AC-ALG1 inner loop, so a changed question key or
    vector width is a bookkeeping error rather than a quantity to average away.
    Empty partitions return an empty list.
    """

    if set(before) != set(after):
        raise RuntimeError(
            "responsibility refresh changed the question support"
        )
    variations = []
    for pid in sorted(before):
        left = before[pid].detach().float().cpu()
        right = after[pid].detach().float().cpu()
        if left.shape != right.shape:
            raise RuntimeError(
                f"responsibility refresh changed support width for pid {pid}"
            )
        variation = 0.5 * float(torch.sum(torch.abs(left - right)).item())
        if not math.isfinite(variation):
            raise FloatingPointError(
                f"non-finite responsibility refresh variation for pid {pid}"
            )
        variations.append(min(max(variation, 0.0), 1.0))
    return variations


def _fixed_surrogate_objective_values(
    model,
    tok,
    task,
    buffers: dict[int, list[TraceRow]],
    labelled_pids: list[int],
    answer_only_pids: list[int],
    labelled_weights: dict[int, torch.Tensor],
    answer_only_weights: dict[int, torch.Tensor],
    supervised_weight: float,
    labelled_em_weight: float,
    answer_only_em_weight: float,
    labelled_supervision: str,
    compact_gold_weight: float,
    digit_token_weight: float,
) -> dict[str, float]:
    """Evaluate the three M-step terms without refreshing responsibilities.

    These values define the generalized-EM rollback test.  Holding the E-step
    responsibilities fixed is essential: refreshing them before the comparison
    would compare two different surrogate functions and invalidate the
    monotonicity claim.
    """

    was_training = model.training
    model.eval()
    try:
        B_sup = (
            supervised_weight * _B_sup(
                model,
                tok,
                task,
                labelled_pids,
                labelled_supervision=labelled_supervision,
                compact_gold_weight=compact_gold_weight,
                digit_token_weight=digit_token_weight,
                grad=False,
            )
            if supervised_weight > 0 else torch.zeros((), device=DEV)
        )
        B_prime_unsup = (
            labelled_em_weight * _B_unsup_for_questions(
                model,
                tok,
                buffers,
                labelled_pids,
                labelled_weights,
                grad=False,
            )
            if labelled_em_weight > 0 else torch.zeros((), device=DEV)
        )
        B_unsup = (
            answer_only_em_weight * _B_unsup_for_questions(
                model,
                tok,
                buffers,
                answer_only_pids,
                answer_only_weights,
                grad=False,
            )
            if answer_only_em_weight > 0 else torch.zeros((), device=DEV)
        )
        return {
            "B_sup": float(B_sup.detach()),
            "B_prime_unsup": float(B_prime_unsup.detach()),
            "B_unsup": float(B_unsup.detach()),
        }
    finally:
        model.train(was_training)


def _snapshot_trainable_parameters(model) -> list[torch.Tensor]:
    """Clone trainable parameters before a candidate optimizer step."""

    with torch.no_grad():
        return [
            parameter.detach().clone()
            for parameter in model.parameters()
            if parameter.requires_grad
        ]


def _restore_trainable_parameters(model, snapshots: list[torch.Tensor]) -> None:
    """Restore a trainable-parameter snapshot after a rejected candidate step."""

    parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    if len(parameters) != len(snapshots):
        raise ValueError("parameter rollback snapshot has the wrong length")
    with torch.no_grad():
        for parameter, snapshot in zip(parameters, snapshots):
            parameter.copy_(snapshot)


def _inner_weighted_em_steps(
    model,
    tok,
    opt,
    task,
    buffers: dict[int, list[TraceRow]],
    labelled_pids: list[int],
    answer_only_pids: list[int],
    labelled_weights: dict[int, torch.Tensor],
    answer_only_weights: dict[int, torch.Tensor],
    inner_steps: int,
    responsibility_score: str = "joint",
    responsibility_temperature: float = 1.0,
    responsibility_ess_floor: float = 0.0,
    responsibility_policy: str = "current",
    responsibility_answer_policy: str = "current",
    responsibility_refresh: str = "inner_step",
    labelled_em_weight: float = 1.0,
    answer_only_em_weight: float = 1.0,
    policy_kl_coef: float | None = None,
    supervised_weight: float = 1.0,
    policy_anchor_mode: str = "fixed",
    policy_anchor_target_ratio: float | None = None,
    policy_anchor_beta_min: float = 0.0,
    policy_anchor_beta_max: float = 10.0,
    policy_anchor_ema: float = 0.9,
    policy_anchor_state: dict[str, float] | None = None,
    labelled_numeric_constraint: str = "off",
    numeric_penalty: float = 2.0,
    numeric_contradiction_penalty: float = 0.0,
    numeric_missing_penalty: float = 0.0,
    labelled_supervision: str = "gold",
    compact_gold_weight: float = 0.5,
    digit_token_weight: float = 1.0,
    update_geometry: str = "sum",
    step_acceptance: str = "none",
    rollback_tolerance: float = 1e-6,
    rollback_max_backtracks: int = 0,
    rollback_shrink: float = 0.5,
    record_joint_logprobs: bool = False,
    record_gradient_geometry: bool = False,
) -> tuple[dict[int, torch.Tensor], dict[int, torch.Tensor], dict[str, object]]:
    """Run repeated objective ascent and responsibility refreshes on one minibatch.

    Args:
        model: Trainable language model.
        tok: Tokenizer.
        opt: Optimizer for trainable model parameters.
        task: GSM8K-style task.
        buffers: Dictionary mapping question id to trace rows.
        labelled_pids: Labelled question ids in L'.
        answer_only_pids: Answer-only question ids in U'.
        labelled_weights: Initial detached responsibilities for labelled buffers.
        answer_only_weights: Initial detached responsibilities for answer-only buffers.
        inner_steps: Number of gradient/refresh iterations.
        responsibility_score: E-step logit definition.
        responsibility_temperature: Positive E-step softmax temperature.
        responsibility_ess_floor: One-sided minimum ESS fraction.
        responsibility_policy: Current adapter or frozen-base E-step scorer.
        responsibility_answer_policy: Current or frozen-base answer-reader factor.
        responsibility_refresh: Refresh after every gradient step or hold the
            outer-round E-step fixed throughout the approximate M-step.
        labelled_em_weight: Coefficient on B'_unsup; zero removes that term.
        answer_only_em_weight: Coefficient on B_unsup; zero removes that term.
        policy_kl_coef: KL-to-frozen-base coefficient. ``None`` disables both
            measurement and anchoring; zero measures the matched control.
        supervised_weight: Coefficient on B_sup; zero removes the direct
            gold-rationale supervision term.
        policy_anchor_mode: ``fixed`` uses policy_kl_coef; ``grad_ratio``
            adapts beta so the applied KL-gradient norm tracks a target
            fraction of the unanchored objective-gradient norm.
        policy_anchor_target_ratio: Target applied-anchor/objective gradient
            norm ratio in grad_ratio mode.
        policy_anchor_beta_min: Lower clip for adaptive beta.
        policy_anchor_beta_max: Upper clip for adaptive beta.
        policy_anchor_ema: EMA decay for the two gradient norms.
        policy_anchor_state: Mutable EMA state shared across outer rounds.
        labelled_numeric_constraint: Local or calculation-graph arithmetic
            potential applied only to L'.
        numeric_penalty: Per-invalid-equation log penalty in soft mode.
        numeric_contradiction_penalty: Per-gold-contradiction soft penalty.
        numeric_missing_penalty: Per-missing graph item soft penalty.
        labelled_supervision: Full gold or full/compact mixed B_sup target.
        compact_gold_weight: Compact-target mixture weight.
        digit_token_weight: Scale-preserving relative weight on digit tokens.
        update_geometry: ``sum`` for the original gradient, ``mgda`` for a
            raw common-descent direction, ``normalized_mgda`` for its
            scale-invariant counterpart, or ``answer_primary`` for a
            B_unsup-dominant direction with non-conflicting auxiliaries.
        step_acceptance: Post-Adam fixed-surrogate acceptance rule.
        rollback_tolerance: Absolute no-harm tolerance for the fixed surrogate.
        rollback_max_backtracks: Smaller candidate steps tried after rejection.
        rollback_shrink: Multiplicative learning-rate shrink per backtrack.
        record_joint_logprobs: Persist logits from the final refresh for diagnostics.
        record_gradient_geometry: Decompose existing final-inner-step gradients
            without another forward or backward pass.

    Returns:
        labelled_weights: Final labelled responsibilities under the configured
            refresh policy.
        answer_only_weights: Final answer-only responsibilities under the
            configured refresh policy.
        stats: Mean objective values and number of optimizer steps taken.
    """

    if responsibility_refresh not in RESPONSIBILITY_REFRESH_MODES:
        raise ValueError(
            "unknown AC-ALG1 responsibility_refresh "
            f"{responsibility_refresh!r}"
        )

    totals = {
        "B_sup": 0.0,
        "B_prime_unsup": 0.0,
        "B_unsup": 0.0,
        "F": 0.0,
        "policy_kl": 0.0,
        "policy_kl_penalty": 0.0,
        "F_anchored": 0.0,
        "steps": 0.0,
    }
    gradient_geometry = None
    update_geometry_diagnostics = None
    update_metric_sums = {
        "direction_norm": 0.0,
        "B_sup_coefficient": 0.0,
        "B_prime_unsup_coefficient": 0.0,
        "B_unsup_coefficient": 0.0,
        "count": 0.0,
    }
    safeguard_totals = {
        "candidate_steps": 0.0,
        "rolled_back_candidates": 0.0,
        "backtracks": 0.0,
        "accepted_scale": 0.0,
        "accepted_surrogate_total_delta": 0.0,
        "accepted_B_sup_delta": 0.0,
        "accepted_B_prime_unsup_delta": 0.0,
        "accepted_B_unsup_delta": 0.0,
        "accepted_steps": 0.0,
    }
    responsibility_refresh_variations: list[float] = []
    policy_anchor_state = policy_anchor_state if policy_anchor_state is not None else {}
    policy_anchor_measured = (
        policy_kl_coef is not None or policy_anchor_mode == "grad_ratio"
    )
    anchor_metric_sums = {
        "beta": 0.0,
        "beta_unclipped": 0.0,
        "beta_clipped": 0.0,
        "objective_grad_norm": 0.0,
        "raw_anchor_grad_norm": 0.0,
        "applied_anchor_grad_norm": 0.0,
        "achieved_ratio": 0.0,
        "ema_objective_grad_norm": 0.0,
        "ema_raw_anchor_grad_norm": 0.0,
    }

    for inner_index in range(inner_steps):
        collect_gradient_geometry = (
            record_gradient_geometry and inner_index == inner_steps - 1
        )
        model.train()
        opt.zero_grad()

        B_sup_took_grad = False
        if supervised_weight == 0:
            B_sup_value = 0.0
        else:
            B_sup = supervised_weight * _B_sup(
                model,
                tok,
                task,
                labelled_pids,
                labelled_supervision=labelled_supervision,
                compact_gold_weight=compact_gold_weight,
                digit_token_weight=digit_token_weight,
            )
            B_sup_value = float(B_sup.detach())
            if B_sup.requires_grad:
                (-B_sup).backward()
                B_sup_took_grad = True
        supervised_gradients = (
            _snapshot_trainable_gradients(model) if collect_gradient_geometry else None
        )
        supervised_native_gradients = (
            _snapshot_native_trainable_gradients(model)
            if update_geometry != "sum" else None
        )

        if labelled_em_weight == 0:
            B_prime_unsup_value, B_prime_took_grad = 0.0, False
        else:
            B_prime_unsup_value, B_prime_took_grad = _backward_B_unsup_for_questions(
                model,
                tok,
                buffers,
                labelled_pids,
                labelled_weights,
                coefficient=labelled_em_weight,
            )
        after_labelled_gradients = (
            _snapshot_trainable_gradients(model) if collect_gradient_geometry else None
        )
        after_labelled_native_gradients = (
            _snapshot_native_trainable_gradients(model)
            if update_geometry != "sum" else None
        )
        if answer_only_em_weight == 0:
            B_unsup_value, B_unsup_took_grad = 0.0, False
        else:
            B_unsup_value, B_unsup_took_grad = _backward_B_unsup_for_questions(
                model,
                tok,
                buffers,
                answer_only_pids,
                answer_only_weights,
                coefficient=answer_only_em_weight,
            )
        objective_gradients = (
            _snapshot_trainable_gradients(model) if collect_gradient_geometry else None
        )
        summed_native_gradients = (
            _snapshot_native_trainable_gradients(model)
            if update_geometry == "sum" and hasattr(model, "parameters") else []
        )
        update_geometry_diagnostics = {
            "mode": "sum",
            "active_components": [
                name for name, active in (
                    ("B_sup", B_sup_took_grad),
                    ("B_prime_unsup", B_prime_took_grad),
                    ("B_unsup", B_unsup_took_grad),
                )
                if active
            ],
            "coefficients": {
                name: 1.0 for name, active in (
                    ("B_sup", B_sup_took_grad),
                    ("B_prime_unsup", B_prime_took_grad),
                    ("B_unsup", B_unsup_took_grad),
                )
                if active
            },
            "direction_norm": _gradient_norm(summed_native_gradients),
        }
        objective_took_grad = (
            B_sup_took_grad or B_prime_took_grad or B_unsup_took_grad
        )
        if update_geometry != "sum":
            objective_native_gradients = _snapshot_native_trainable_gradients(model)
            component_gradients = component_gradients_from_cumulative(
                supervised_native_gradients,
                after_labelled_native_gradients,
                objective_native_gradients,
            )
            optimized_gradients, update_geometry_diagnostics = (
                combine_component_gradients(
                    component_gradients,
                    mode=update_geometry,
                )
            )
            assign_trainable_gradients(model, optimized_gradients)
            objective_took_grad = (
                float(update_geometry_diagnostics["direction_norm"]) > 0.0
            )
        update_metric_sums["direction_norm"] += float(
            update_geometry_diagnostics.get("direction_norm", 0.0)
        )
        for component_name in ("B_sup", "B_prime_unsup", "B_unsup"):
            update_metric_sums[f"{component_name}_coefficient"] += float(
                update_geometry_diagnostics["coefficients"].get(component_name, 0.0)
            )
        update_metric_sums["count"] += 1.0

        adaptive_objective_gradients = (
            _snapshot_native_trainable_gradients(model)
            if policy_anchor_mode == "grad_ratio" else None
        )

        policy_kl_value = 0.0
        policy_kl_took_grad = False
        effective_beta = 0.0
        anchor_metrics = None
        if policy_anchor_measured:
            beta = (
                1.0 if policy_anchor_mode == "grad_ratio"
                else float(policy_kl_coef)
            )
            labelled_buffer_available = any(
                buffers[int(pid)] and labelled_weights.get(int(pid)) is not None
                for pid in labelled_pids
            )
            answer_only_buffer_available = any(
                buffers[int(pid)] and answer_only_weights.get(int(pid)) is not None
                for pid in answer_only_pids
            )
            component_weight = (
                (supervised_weight if labelled_pids else 0.0)
                + (labelled_em_weight if labelled_buffer_available else 0.0)
                + (answer_only_em_weight if answer_only_buffer_available else 0.0)
            )
            if component_weight > 0:
                supervised_kl_value = 0.0
                if supervised_weight > 0 and labelled_pids:
                    supervised_kl = _supervised_reference_policy_kl(
                        model,
                        tok,
                        task,
                        labelled_pids,
                        labelled_supervision=labelled_supervision,
                        grad=beta > 0,
                    )
                    supervised_kl_value = float(supervised_kl.detach())
                    if beta > 0 and supervised_kl.requires_grad:
                        (
                            beta * supervised_weight * supervised_kl
                            / component_weight
                        ).backward()
                        policy_kl_took_grad = True

                labelled_kl_value, labelled_kl_took_grad = (
                    _backward_reference_policy_kl_for_questions(
                        model,
                        tok,
                        buffers,
                        labelled_pids,
                        labelled_weights,
                        backward_scale=(
                            beta * labelled_em_weight / component_weight
                            if labelled_buffer_available else 0.0
                        ),
                    )
                )
                answer_only_kl_value, answer_only_kl_took_grad = (
                    _backward_reference_policy_kl_for_questions(
                        model,
                        tok,
                        buffers,
                        answer_only_pids,
                        answer_only_weights,
                        backward_scale=(
                            beta * answer_only_em_weight / component_weight
                            if answer_only_buffer_available else 0.0
                        ),
                    )
                )
                policy_kl_took_grad = (
                    policy_kl_took_grad
                    or labelled_kl_took_grad
                    or answer_only_kl_took_grad
                )
                policy_kl_value = (
                    supervised_weight * supervised_kl_value
                    + labelled_em_weight * labelled_kl_value
                    + answer_only_em_weight * answer_only_kl_value
                ) / component_weight

            if policy_anchor_mode == "grad_ratio":
                anchor_metrics = _apply_gradient_ratio_policy_anchor(
                    model,
                    adaptive_objective_gradients,
                    policy_anchor_state,
                    target_ratio=float(policy_anchor_target_ratio),
                    beta_min=policy_anchor_beta_min,
                    beta_max=policy_anchor_beta_max,
                    ema=policy_anchor_ema,
                )
                effective_beta = anchor_metrics["beta"]
                policy_kl_took_grad = policy_kl_took_grad and effective_beta > 0
            else:
                effective_beta = beta

        if collect_gradient_geometry:
            gradient_geometry = _gradient_geometry_from_snapshots(
                supervised_gradients,
                after_labelled_gradients,
                objective_gradients,
            )
            if policy_anchor_measured:
                gradient_geometry = _add_policy_anchor_gradient_geometry(
                    gradient_geometry,
                    objective_gradients,
                    _snapshot_trainable_gradients(model),
                )
        took_grad = objective_took_grad or policy_kl_took_grad
        if took_grad:
            if step_acceptance == "none":
                opt.step()
            else:
                before_values = _fixed_surrogate_objective_values(
                    model,
                    tok,
                    task,
                    buffers,
                    labelled_pids,
                    answer_only_pids,
                    labelled_weights,
                    answer_only_weights,
                    supervised_weight=supervised_weight,
                    labelled_em_weight=labelled_em_weight,
                    answer_only_em_weight=answer_only_em_weight,
                    labelled_supervision=labelled_supervision,
                    compact_gold_weight=compact_gold_weight,
                    digit_token_weight=digit_token_weight,
                )
                parameter_snapshot = _snapshot_trainable_parameters(model)
                optimizer_snapshot = copy.deepcopy(opt.state_dict())
                base_learning_rates = [
                    float(group["lr"]) for group in opt.param_groups
                ]
                accepted = False
                for backtrack_index in range(rollback_max_backtracks + 1):
                    step_scale = rollback_shrink ** backtrack_index
                    for group, base_learning_rate in zip(
                        opt.param_groups, base_learning_rates
                    ):
                        group["lr"] = base_learning_rate * step_scale
                    opt.step()
                    after_values = _fixed_surrogate_objective_values(
                        model,
                        tok,
                        task,
                        buffers,
                        labelled_pids,
                        answer_only_pids,
                        labelled_weights,
                        answer_only_weights,
                        supervised_weight=supervised_weight,
                        labelled_em_weight=labelled_em_weight,
                        answer_only_em_weight=answer_only_em_weight,
                        labelled_supervision=labelled_supervision,
                        compact_gold_weight=compact_gold_weight,
                        digit_token_weight=digit_token_weight,
                    )
                    accepted, safeguard_diagnostics = fixed_surrogate_acceptance(
                        before_values,
                        after_values,
                        mode=step_acceptance,
                        active_components=update_geometry_diagnostics[
                            "active_components"
                        ],
                        tolerance=rollback_tolerance,
                    )
                    safeguard_totals["candidate_steps"] += 1.0
                    safeguard_totals["backtracks"] += float(backtrack_index > 0)
                    if accepted:
                        safeguard_totals["accepted_steps"] += 1.0
                        safeguard_totals["accepted_scale"] += step_scale
                        safeguard_totals["accepted_surrogate_total_delta"] += float(
                            safeguard_diagnostics["total_delta"]
                        )
                        for component_name in (
                            "B_sup",
                            "B_prime_unsup",
                            "B_unsup",
                        ):
                            safeguard_totals[
                                f"accepted_{component_name}_delta"
                            ] += float(
                                safeguard_diagnostics["deltas"][component_name]
                            )
                        break

                    safeguard_totals["rolled_back_candidates"] += 1.0
                    _restore_trainable_parameters(model, parameter_snapshot)
                    opt.load_state_dict(optimizer_snapshot)

                for group, base_learning_rate in zip(
                    opt.param_groups, base_learning_rates
                ):
                    group["lr"] = base_learning_rate
                took_grad = accepted

        F_value = B_sup_value + B_prime_unsup_value + B_unsup_value
        policy_kl_penalty = effective_beta * policy_kl_value
        F_anchored_value = F_value - policy_kl_penalty
        totals["B_sup"] += B_sup_value
        totals["B_prime_unsup"] += B_prime_unsup_value
        totals["B_unsup"] += B_unsup_value
        totals["F"] += F_value
        totals["policy_kl"] += policy_kl_value
        totals["policy_kl_penalty"] += policy_kl_penalty
        totals["F_anchored"] += F_anchored_value
        totals["steps"] += float(took_grad)
        anchor_metric_sums["beta"] += effective_beta
        anchor_metric_sums["beta_unclipped"] += (
            anchor_metrics["beta_unclipped"]
            if anchor_metrics is not None else effective_beta
        )
        if anchor_metrics is not None:
            for key in (
                "beta_clipped",
                "objective_grad_norm",
                "raw_anchor_grad_norm",
                "applied_anchor_grad_norm",
                "achieved_ratio",
                "ema_objective_grad_norm",
                "ema_raw_anchor_grad_norm",
            ):
                anchor_metric_sums[key] += anchor_metrics[key]

        if responsibility_refresh == "inner_step":
            refreshed_labelled, refreshed_answer_only = _refresh_minibatch_weights(
                model,
                tok,
                buffers,
                labelled_pids,
                answer_only_pids,
                responsibility_score=responsibility_score,
                responsibility_temperature=responsibility_temperature,
                responsibility_ess_floor=responsibility_ess_floor,
                responsibility_policy=responsibility_policy,
                responsibility_answer_policy=responsibility_answer_policy,
                labelled_numeric_constraint=labelled_numeric_constraint,
                numeric_penalty=numeric_penalty,
                numeric_contradiction_penalty=numeric_contradiction_penalty,
                numeric_missing_penalty=numeric_missing_penalty,
                record_joint_logprobs=(
                    record_joint_logprobs and inner_index == inner_steps - 1
                ),
            )
            responsibility_refresh_variations.extend(
                _responsibility_refresh_total_variations(
                    labelled_weights,
                    refreshed_labelled,
                )
            )
            responsibility_refresh_variations.extend(
                _responsibility_refresh_total_variations(
                    answer_only_weights,
                    refreshed_answer_only,
                )
            )
            labelled_weights = refreshed_labelled
            answer_only_weights = refreshed_answer_only

    denom = max(inner_steps, 1)
    stats = {
        key: value / denom
        for key, value in totals.items()
        if key != "steps"
    }
    stats["B_unsup_label"] = stats["B_prime_unsup"]
    stats["B_unsup_answer_only"] = stats["B_unsup"]
    stats["steps"] = totals["steps"]
    stats["gradient_geometry"] = gradient_geometry
    stats["update_geometry_diagnostics"] = update_geometry_diagnostics
    stats["update_geometry"] = update_geometry
    stats["step_acceptance"] = step_acceptance
    stats["responsibility_refresh"] = responsibility_refresh
    stats["responsibility_refresh_total_variation_mean"] = _mean_or_none(
        responsibility_refresh_variations
    )
    stats["responsibility_refresh_total_variation_max"] = (
        max(responsibility_refresh_variations)
        if responsibility_refresh_variations else None
    )
    update_count = max(update_metric_sums["count"], 1.0)
    stats["update_direction_norm"] = (
        update_metric_sums["direction_norm"] / update_count
    )
    for component_name in ("B_sup", "B_prime_unsup", "B_unsup"):
        stats[f"update_{component_name}_coefficient"] = (
            update_metric_sums[f"{component_name}_coefficient"] / update_count
        )
    stats["candidate_steps"] = safeguard_totals["candidate_steps"]
    stats["rolled_back_candidates"] = safeguard_totals["rolled_back_candidates"]
    stats["rollback_backtracks"] = safeguard_totals["backtracks"]
    accepted_safeguarded_steps = safeguard_totals["accepted_steps"]
    stats["safeguard_acceptance_fraction"] = (
        accepted_safeguarded_steps / safeguard_totals["candidate_steps"]
        if safeguard_totals["candidate_steps"] else None
    )
    stats["accepted_step_scale"] = (
        safeguard_totals["accepted_scale"] / accepted_safeguarded_steps
        if accepted_safeguarded_steps else None
    )
    stats["accepted_surrogate_total_delta"] = (
        safeguard_totals["accepted_surrogate_total_delta"]
        / accepted_safeguarded_steps
        if accepted_safeguarded_steps else None
    )
    for component_name in ("B_sup", "B_prime_unsup", "B_unsup"):
        stats[f"accepted_{component_name}_delta"] = (
            safeguard_totals[f"accepted_{component_name}_delta"]
            / accepted_safeguarded_steps
            if accepted_safeguarded_steps else None
        )
    stats["policy_anchor_mode"] = policy_anchor_mode
    stats["policy_anchor_target_ratio"] = policy_anchor_target_ratio
    stats["policy_anchor_beta"] = (
        anchor_metric_sums["beta"] / denom if policy_anchor_measured else None
    )
    stats["policy_anchor_beta_unclipped"] = (
        anchor_metric_sums["beta_unclipped"] / denom
        if policy_anchor_measured else None
    )
    for key in (
        "beta_clipped",
        "objective_grad_norm",
        "raw_anchor_grad_norm",
        "applied_anchor_grad_norm",
        "achieved_ratio",
        "ema_objective_grad_norm",
        "ema_raw_anchor_grad_norm",
    ):
        stats[f"policy_anchor_{key}"] = (
            anchor_metric_sums[key] / denom
            if policy_anchor_mode == "grad_ratio" else None
        )

    return labelled_weights, answer_only_weights, stats


def _finite_or_none(value):
    """Return a JSON-safe finite float, or None for NaN/Inf/missing values."""

    if value is None:
        return None
    value = float(value)
    return value if math.isfinite(value) else None


def _mean_or_none(values) -> float | None:
    """Mean of a non-empty numeric iterable, otherwise None."""

    values = [float(value) for value in values
              if value is not None and math.isfinite(float(value))]
    return float(np.mean(values)) if values else None


def _numeric_responsibility_metrics(weighted_rows) -> dict:
    """Summarise arithmetic and graph status under supplied responsibilities."""

    weighted_rows = list(weighted_rows)
    graph_available = [
        (row, float(weight))
        for row, weight in weighted_rows
        if row.numeric_audit.graph_fully_covered is not None
    ]
    graph_available_mass = sum(weight for _row, weight in graph_available)
    return {
        "numeric_valid_mass": sum(
            weight
            for row, weight in weighted_rows
            if row.numeric_audit.parsed_equations > 0
            and row.numeric_audit.invalid_equations == 0
            and row.numeric_audit.gold_contradictions == 0
        ),
        "numeric_invalid_mass": sum(
            weight
            for row, weight in weighted_rows
            if row.numeric_audit.invalid_equations > 0
            or row.numeric_audit.gold_contradictions > 0
        ),
        "numeric_unparsed_mass": sum(
            weight
            for row, weight in weighted_rows
            if row.numeric_audit.parsed_equations == 0
        ),
        "numeric_graph_available_mass": graph_available_mass,
        "numeric_graph_compatible_mass": sum(
            weight
            for row, weight in graph_available
            if row.numeric_audit.graph_fully_covered is True
        ),
        "numeric_graph_incomplete_mass": sum(
            weight
            for row, weight in graph_available
            if row.numeric_audit.graph_fully_covered is False
        ),
        "numeric_graph_unavailable_mass": sum(
            weight
            for row, weight in weighted_rows
            if row.numeric_audit.graph_fully_covered is None
        ),
        "numeric_graph_node_coverage": (
            sum(
                weight * float(row.numeric_audit.graph_node_coverage)
                for row, weight in graph_available
            ) / graph_available_mass
            if graph_available_mass > 0
            else None
        ),
        "numeric_graph_edge_coverage": (
            sum(
                weight * float(row.numeric_audit.graph_edge_coverage)
                for row, weight in graph_available
            ) / graph_available_mass
            if graph_available_mass > 0
            else None
        ),
    }


def _sample_diagnostics(
    task,
    pid_rows: list[int],
    texts: list[str],
    token_counts: list[int],
    sources: list[str],
    *,
    trace_ids: list[str] | None = None,
    rewards: list[float] | None = None,
    admitted: list[bool] | None = None,
    retained_after_insertion: list[bool] | None = None,
    verifier_calls: int | None = None,
) -> dict:
    """Summarise already-generated completions without another model call."""

    optional = (trace_ids, rewards, admitted, retained_after_insertion)
    if not (len(pid_rows) == len(texts) == len(token_counts) == len(sources)):
        raise ValueError("sample diagnostic inputs must have equal lengths")
    if any(values is not None and len(values) != len(texts) for values in optional):
        raise ValueError("optional sample diagnostic inputs must match text count")

    if not texts:
        return {
            "count": 0,
            "verifier_calls": 0,
            "correct_fraction": None,
            "format_fraction": None,
            "mean_tokens": None,
            "mean_characters": None,
            "mean_words": None,
            "unique_fraction_within_question": None,
            "duplicate_fraction_within_question": None,
            "question_outcomes": {"all_wrong": 0, "mixed": 0, "all_correct": 0},
            "samples": [],
        }

    trace_ids = trace_ids if trace_ids is not None else [None] * len(texts)
    admitted = admitted if admitted is not None else [True] * len(texts)
    retained_after_insertion = (
        retained_after_insertion
        if retained_after_insertion is not None
        else list(admitted)
    )
    if rewards is None:
        rewards = [float(value) for value in task.reward(texts, pids=pid_rows)]
        verifier_calls = len(texts)
    else:
        rewards = [float(value) for value in rewards]
        verifier_calls = 0 if verifier_calls is None else int(verifier_calls)
    correct = [bool(float(reward) > 0.5) for reward in rewards]
    formatted = [
        "####" in text or ("<answer>" in text and "</answer>" in text)
        for text in texts
    ]
    by_pid: dict[int, list[bool]] = defaultdict(list)
    for pid, is_correct in zip(pid_rows, correct):
        by_pid[int(pid)].append(is_correct)

    outcomes = Counter()
    for values in by_pid.values():
        if all(values):
            outcomes["all_correct"] += 1
        elif any(values):
            outcomes["mixed"] += 1
        else:
            outcomes["all_wrong"] += 1

    unique = len({(int(pid), text) for pid, text in zip(pid_rows, texts)})
    samples = [
        {
            "pid": int(pid),
            "trace_id": trace_id,
            "source": source,
            "text": text,
            "reward": _finite_or_none(reward),
            "correct": is_correct,
            "admitted": bool(was_admitted),
            "retained_after_insertion": bool(was_retained),
            "has_answer_marker": has_marker,
            "tokens": int(n_tokens),
            "characters": len(text),
            "words": len(text.split()),
        }
        for (pid, trace_id, source, text, reward, is_correct, was_admitted,
             was_retained, has_marker, n_tokens) in zip(
            pid_rows, trace_ids, sources, texts, rewards, correct, admitted,
            retained_after_insertion, formatted, token_counts
        )
    ]
    return {
        "count": len(texts),
        "verifier_calls": verifier_calls,
        "correct_fraction": float(np.mean(correct)),
        "format_fraction": float(np.mean(formatted)),
        "mean_tokens": float(np.mean(token_counts)),
        "mean_characters": float(np.mean([len(text) for text in texts])),
        "mean_words": float(np.mean([len(text.split()) for text in texts])),
        "unique_fraction_within_question": unique / len(texts),
        "duplicate_fraction_within_question": 1.0 - unique / len(texts),
        "question_outcomes": {
            "all_wrong": int(outcomes["all_wrong"]),
            "mixed": int(outcomes["mixed"]),
            "all_correct": int(outcomes["all_correct"]),
        },
        "samples": samples,
    }


def _buffer_diagnostics(
    buffers: dict[int, list[TraceRow]],
    buffer_limit: int,
    buffer_strategy: str,
    rows_added: int,
    rows_evicted: int,
) -> dict:
    """Describe retained trace composition after this round's pruning."""

    active = {int(pid): rows for pid, rows in buffers.items() if rows}
    all_rows = [row for rows in active.values() for row in rows]
    source_counts = Counter(row.source for row in all_rows)
    unique_rows = len({(row.pid, tuple(row.ids.tolist())) for row in all_rows})
    n_rows = len(all_rows)
    saturated = (
        sum(len(rows) >= buffer_limit for rows in active.values()) / len(active)
        if buffer_limit > 0 and active
        else None
    )
    return {
        "strategy": buffer_strategy,
        "limit_per_question": int(buffer_limit),
        "rows": n_rows,
        "gold_rows": sum(row.is_gold for row in all_rows),
        "model_rows": sum(not row.is_gold for row in all_rows),
        "active_questions": len(active),
        "mean_rows_per_active_question": _mean_or_none(len(rows) for rows in active.values()),
        "max_rows_per_question": max((len(rows) for rows in active.values()), default=0),
        "saturated_question_fraction": saturated,
        "exact_duplicate_fraction": (1.0 - unique_rows / n_rows) if n_rows else None,
        "source_counts": dict(sorted(source_counts.items())),
        "rows_added_this_round": int(rows_added),
        "rows_evicted_this_round": int(rows_evicted),
    }


def _counterfactual_responsibility_diagnostics(rows: list[TraceRow]) -> dict:
    """Replay score/temperature combinations from already-computed joint logits."""

    schemes = (
        ("joint_tau1", "joint", 1.0),
        ("joint_tau2", "joint", 2.0),
        ("token_mean_tau1", "token_mean", 1.0),
        ("token_mean_tau2", "token_mean", 2.0),
    )
    joint = [float(row.joint_logprob) for row in rows]
    if not rows or any(not math.isfinite(value) for value in joint):
        return {
            name: {"available": False}
            for name, _score, _temperature in schemes
        }

    results = {}
    for name, score, temperature in schemes:
        logits = [
            value / max(int(row.span.sum()), 1) if score == "token_mean" else value
            for row, value in zip(rows, joint)
        ]
        scaled = [value / temperature for value in logits]
        maximum = max(scaled)
        unnormalized = [math.exp(value - maximum) for value in scaled]
        denominator = sum(unnormalized)
        weights = [value / denominator for value in unnormalized]
        order = sorted(range(len(weights)), key=weights.__getitem__, reverse=True)
        gold_indices = [index for index, row in enumerate(rows) if row.is_gold]
        gold_ranks = [order.index(index) + 1 for index in gold_indices]
        entropy = -sum(value * math.log(max(value, 1e-300)) for value in weights)
        top1_index = order[0]
        audited_model_rows = [
            (row, weight)
            for row, weight in zip(rows, weights)
            if not row.is_gold and row.numeric_audit is not None
        ]
        results[name] = {
            "available": True,
            "score": score,
            "temperature": temperature,
            "weights": weights,
            "gold_mass": sum(weights[index] for index in gold_indices),
            "gold_rank": min(gold_ranks) if gold_ranks else None,
            "gold_is_top1": bool(rows[top1_index].is_gold),
            "top1_index": top1_index,
            "top1_trace_id": rows[top1_index].trace_id,
            "top1_source": rows[top1_index].source,
            "max_responsibility": weights[top1_index],
            "normalized_entropy": entropy / math.log(len(rows)) if len(rows) > 1 else 0.0,
            "effective_sample_size_fraction": (
                1.0 / sum(value * value for value in weights) / len(rows)
            ),
            **_numeric_responsibility_metrics(audited_model_rows),
        }

    faithful_top1 = results["joint_tau1"]["top1_index"]
    for result in results.values():
        result["top1_changed_from_joint_tau1"] = result["top1_index"] != faithful_top1
    return results


def _responsibility_diagnostics(
    buffers: dict[int, list[TraceRow]],
    labelled_weights: dict[int, torch.Tensor],
    answer_only_weights: dict[int, torch.Tensor],
    round_index: int,
) -> dict:
    """Record final E-step responsibilities already computed for this minibatch."""

    traces = []
    questions = []
    partition_summaries = {}
    for partition, weights_by_pid in (
        ("labelled", labelled_weights),
        ("answer_only", answer_only_weights),
    ):
        partition_questions = []
        for pid, weights in weights_by_pid.items():
            rows = list(buffers[int(pid)])
            values = [float(value) for value in weights.detach().cpu().tolist()]
            if len(rows) != len(values):
                raise RuntimeError(
                    f"responsibility length mismatch for pid {pid}: {len(rows)} rows vs {len(values)} weights"
                )

            nonfinite = sum(not math.isfinite(value) for value in values)
            order = sorted(
                range(len(values)),
                key=lambda index: values[index] if math.isfinite(values[index]) else float("-inf"),
                reverse=True,
            )
            ranks = {index: rank + 1 for rank, index in enumerate(order)}
            if nonfinite:
                gold_mass = max_responsibility = entropy = normalized_entropy = None
                ess = ess_fraction = weighted_age = None
                gold_is_top1 = None
            else:
                gold_mass = min(max(
                    sum(value for row, value in zip(rows, values) if row.is_gold), 0.0
                ), 1.0)
                max_responsibility = min(max(max(values, default=0.0), 0.0), 1.0)
                entropy = max(
                    -sum(value * math.log(max(value, 1e-300)) for value in values), 0.0
                )
                normalized_entropy = (
                    min(max(entropy / math.log(len(values)), 0.0), 1.0)
                    if len(values) > 1 else 0.0
                )
                ess = 1.0 / sum(value * value for value in values)
                ess_fraction = min(max(ess / len(values), 0.0), 1.0)
                weighted_age = sum(value * max(round_index - row.round_added, 0)
                                   for row, value in zip(rows, values))
                gold_is_top1 = bool(rows[order[0]].is_gold) if rows else False

            audited_model_rows = [
                (row, value)
                for row, value in zip(rows, values)
                if not row.is_gold and row.numeric_audit is not None
            ]
            numeric_metrics = _numeric_responsibility_metrics(audited_model_rows)
            before_values = [row.responsibility_before_potential for row in rows]
            before_available = bool(before_values) and all(
                value is not None and math.isfinite(value) for value in before_values
            )
            if before_available and not nonfinite:
                gold_mass_before_potential = min(max(
                    sum(
                        float(value)
                        for row, value in zip(rows, before_values)
                        if row.is_gold
                    ),
                    0.0,
                ), 1.0)
                gold_mass_change_from_potential = gold_mass - gold_mass_before_potential
                responsibility_total_variation_from_potential = 0.5 * sum(
                    abs(value - float(before_value))
                    for value, before_value in zip(values, before_values)
                )
            else:
                gold_mass_before_potential = None
                gold_mass_change_from_potential = None
                responsibility_total_variation_from_potential = None

            structured_rows = [
                (row, value)
                for row, value in zip(rows, values)
                if row.structured_audit is not None
            ]
            question = {
                "pid": int(pid),
                "partition": partition,
                "trace_count": len(rows),
                "gold_mass": gold_mass,
                "gold_mass_before_potential": gold_mass_before_potential,
                "gold_mass_change_from_potential": gold_mass_change_from_potential,
                "responsibility_total_variation_from_potential": (
                    responsibility_total_variation_from_potential
                ),
                "gold_is_top1": gold_is_top1,
                "max_responsibility": max_responsibility,
                "entropy": entropy,
                "normalized_entropy": normalized_entropy,
                "effective_sample_size": ess,
                "effective_sample_size_fraction": ess_fraction,
                "responsibility_temperature_used": _mean_or_none(
                    row.responsibility_temperature_used for row in rows
                ),
                "responsibility_weighted_age": weighted_age,
                "nonfinite_responsibilities": nonfinite,
                "numeric_audited_model_traces": len(audited_model_rows),
                "structured_traces": len(structured_rows),
                "structured_well_formed_fraction": _mean_or_none(
                    row.structured_audit.well_formed for row, _value in structured_rows
                ),
                "structured_well_formed_mass": (
                    sum(
                        value
                        for row, value in structured_rows
                        if row.structured_audit.well_formed
                    )
                    if structured_rows and not nonfinite else None
                ),
                **numeric_metrics,
                "numeric_hard_rejected_traces": sum(
                    math.isinf(row.numeric_log_potential)
                    and row.numeric_log_potential < 0
                    for row, _value in audited_model_rows
                ),
                "numeric_graph_rejected_traces": sum(
                    math.isinf(row.numeric_log_potential)
                    and row.numeric_log_potential < 0
                    and row.numeric_audit.graph_fully_covered is False
                    for row, _value in audited_model_rows
                ),
                "counterfactuals": _counterfactual_responsibility_diagnostics(rows),
            }
            questions.append(question)
            partition_questions.append(question)

            for index, (row, value) in enumerate(zip(rows, values)):
                audit = row.numeric_audit
                structured_audit = row.structured_audit
                traces.append({
                    "pid": int(pid),
                    "partition": partition,
                    "buffer_index": index,
                    "trace_id": row.trace_id,
                    "source": row.source,
                    "is_gold": bool(row.is_gold),
                    "proposal_correct": row.proposal_correct,
                    "proposal_tokens": row.proposal_tokens,
                    "round_added": int(row.round_added),
                    "age": max(round_index - row.round_added, 0),
                    "joint_logprob": _finite_or_none(row.joint_logprob),
                    "trace_logprob": _finite_or_none(row.trace_logprob),
                    "answer_logprob": _finite_or_none(row.answer_logprob),
                    "responsibility_logit": _finite_or_none(row.responsibility_logit),
                    "responsibility_before_potential": _finite_or_none(
                        row.responsibility_before_potential
                    ),
                    "responsibility_temperature_used": _finite_or_none(
                        row.responsibility_temperature_used
                    ),
                    "responsibility": _finite_or_none(value),
                    "rank": ranks[index],
                    "total_tokens": int(row.ids.numel()),
                    "objective_tokens": int(row.span.sum()),
                    "answer_tokens": int(row.ans.sum()),
                    "trace_representation": row.trace_representation,
                    "structured_audit": (
                        None if structured_audit is None else {
                            "has_calculation_block": structured_audit.has_calculation_block,
                            "has_reasoning_block": structured_audit.has_reasoning_block,
                            "calculation_precedes_reasoning": (
                                structured_audit.calculation_precedes_reasoning
                            ),
                            "well_formed": structured_audit.well_formed,
                            "calculation_characters": (
                                structured_audit.calculation_characters
                            ),
                            "reasoning_characters": structured_audit.reasoning_characters,
                        }
                    ),
                    "numeric_audit": None if audit is None else {
                        "equation_mentions": int(audit.equation_mentions),
                        "parsed_equations": int(audit.parsed_equations),
                        "parse_failures": int(
                            audit.equation_mentions - audit.parsed_equations
                        ),
                        "invalid_equations": int(audit.invalid_equations),
                        "gold_matches": int(audit.gold_matches),
                        "gold_contradictions": int(audit.gold_contradictions),
                        "gold_graph_available": bool(audit.gold_graph_available),
                        "gold_graph_nodes": int(audit.gold_graph_nodes),
                        "gold_graph_edges": int(audit.gold_graph_edges),
                        "candidate_graph_nodes": int(audit.candidate_graph_nodes),
                        "candidate_graph_edges": int(audit.candidate_graph_edges),
                        "graph_node_matches": int(audit.graph_node_matches),
                        "graph_edge_matches": int(audit.graph_edge_matches),
                        "graph_node_coverage": audit.graph_node_coverage,
                        "graph_edge_coverage": audit.graph_edge_coverage,
                        "graph_fully_covered": audit.graph_fully_covered,
                        "equations": list(audit.equations),
                        "invalid": list(audit.invalid),
                        "contradictions": list(audit.contradictions),
                        "missing_graph_nodes": list(audit.missing_graph_nodes),
                        "missing_graph_edges": list(audit.missing_graph_edges),
                        "log_potential": _finite_or_none(row.numeric_log_potential),
                        "hard_rejected": bool(
                            math.isinf(row.numeric_log_potential)
                            and row.numeric_log_potential < 0
                        ),
                    },
                })

        counterfactual_summaries = {}
        for scheme in ("joint_tau1", "joint_tau2", "token_mean_tau1", "token_mean_tau2"):
            available = [
                question["counterfactuals"][scheme]
                for question in partition_questions
                if question["counterfactuals"][scheme].get("available")
            ]
            counterfactual_summaries[scheme] = {
                "question_count": len(available),
                "mean_gold_mass": _mean_or_none(item["gold_mass"] for item in available),
                "gold_top1_fraction": _mean_or_none(item["gold_is_top1"] for item in available),
                "mean_gold_rank": _mean_or_none(item["gold_rank"] for item in available),
                "mean_effective_sample_size_fraction": _mean_or_none(
                    item["effective_sample_size_fraction"] for item in available
                ),
                "top1_change_fraction_from_joint_tau1": _mean_or_none(
                    item["top1_changed_from_joint_tau1"] for item in available
                ),
                "mean_numeric_valid_mass": _mean_or_none(
                    item["numeric_valid_mass"] for item in available
                ),
                "mean_numeric_invalid_mass": _mean_or_none(
                    item["numeric_invalid_mass"] for item in available
                ),
                "mean_numeric_unparsed_mass": _mean_or_none(
                    item["numeric_unparsed_mass"] for item in available
                ),
                "mean_numeric_graph_available_mass": _mean_or_none(
                    item["numeric_graph_available_mass"] for item in available
                ),
                "mean_numeric_graph_compatible_mass": _mean_or_none(
                    item["numeric_graph_compatible_mass"] for item in available
                ),
                "mean_numeric_graph_incomplete_mass": _mean_or_none(
                    item["numeric_graph_incomplete_mass"] for item in available
                ),
                "mean_numeric_graph_unavailable_mass": _mean_or_none(
                    item["numeric_graph_unavailable_mass"] for item in available
                ),
                "mean_numeric_graph_node_coverage": _mean_or_none(
                    item["numeric_graph_node_coverage"] for item in available
                ),
                "mean_numeric_graph_edge_coverage": _mean_or_none(
                    item["numeric_graph_edge_coverage"] for item in available
                ),
            }

        partition_summaries[partition] = {
            "question_count": len(partition_questions),
            "mean_trace_count": _mean_or_none(q["trace_count"] for q in partition_questions),
            "mean_gold_mass": _mean_or_none(q["gold_mass"] for q in partition_questions),
            "mean_gold_mass_before_potential": _mean_or_none(
                q["gold_mass_before_potential"] for q in partition_questions
            ),
            "mean_gold_mass_change_from_potential": _mean_or_none(
                q["gold_mass_change_from_potential"] for q in partition_questions
            ),
            "mean_responsibility_total_variation_from_potential": _mean_or_none(
                q["responsibility_total_variation_from_potential"]
                for q in partition_questions
            ),
            "gold_top1_fraction": _mean_or_none(q["gold_is_top1"] for q in partition_questions),
            "mean_max_responsibility": _mean_or_none(
                q["max_responsibility"] for q in partition_questions
            ),
            "mean_effective_sample_size_fraction": _mean_or_none(
                q["effective_sample_size_fraction"] for q in partition_questions
            ),
            "mean_normalized_entropy": _mean_or_none(
                q["normalized_entropy"] for q in partition_questions
            ),
            "mean_responsibility_weighted_age": _mean_or_none(
                q["responsibility_weighted_age"] for q in partition_questions
            ),
            "nonfinite_responsibilities": sum(
                q["nonfinite_responsibilities"] for q in partition_questions
            ),
            "mean_numeric_valid_mass": _mean_or_none(
                q["numeric_valid_mass"] for q in partition_questions
            ),
            "mean_numeric_invalid_mass": _mean_or_none(
                q["numeric_invalid_mass"] for q in partition_questions
            ),
            "mean_numeric_unparsed_mass": _mean_or_none(
                q["numeric_unparsed_mass"] for q in partition_questions
            ),
            "mean_numeric_graph_available_mass": _mean_or_none(
                q["numeric_graph_available_mass"] for q in partition_questions
            ),
            "mean_numeric_graph_compatible_mass": _mean_or_none(
                q["numeric_graph_compatible_mass"] for q in partition_questions
            ),
            "mean_numeric_graph_incomplete_mass": _mean_or_none(
                q["numeric_graph_incomplete_mass"] for q in partition_questions
            ),
            "mean_numeric_graph_unavailable_mass": _mean_or_none(
                q["numeric_graph_unavailable_mass"] for q in partition_questions
            ),
            "mean_numeric_graph_node_coverage": _mean_or_none(
                q["numeric_graph_node_coverage"] for q in partition_questions
            ),
            "mean_numeric_graph_edge_coverage": _mean_or_none(
                q["numeric_graph_edge_coverage"] for q in partition_questions
            ),
            "numeric_hard_rejected_traces": sum(
                q["numeric_hard_rejected_traces"] for q in partition_questions
            ),
            "numeric_graph_rejected_traces": sum(
                q["numeric_graph_rejected_traces"] for q in partition_questions
            ),
            "structured_traces": sum(q["structured_traces"] for q in partition_questions),
            "mean_structured_well_formed_fraction": _mean_or_none(
                q["structured_well_formed_fraction"] for q in partition_questions
            ),
            "mean_structured_well_formed_mass": _mean_or_none(
                q["structured_well_formed_mass"] for q in partition_questions
            ),
            "counterfactuals": counterfactual_summaries,
        }

    return {
        "partitions": partition_summaries,
        "questions": questions,
        "traces": traces,
    }


def _optimizer_diagnostics(
    model,
    initial_parameters: list[torch.Tensor] | None = None,
) -> dict:
    """Measure trainable parameter, displacement, and gradient health."""

    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    if initial_parameters is not None and len(initial_parameters) != len(trainable):
        raise ValueError("initial parameter snapshot has the wrong length")
    parameter_sq = 0.0
    parameter_drift_sq = 0.0
    gradient_sq = 0.0
    parameter_nonfinite = 0
    gradient_nonfinite = 0
    gradient_tensors = 0
    with torch.no_grad():
        for parameter_index, parameter in enumerate(trainable):
            values = parameter.detach()
            parameter_sq += float(torch.sum(values.float() ** 2))
            if initial_parameters is not None:
                reference = initial_parameters[parameter_index]
                if reference.shape != values.shape:
                    raise ValueError(
                        "initial parameter snapshot has a mismatched shape"
                    )
                parameter_drift_sq += float(torch.sum(
                    (values.float() - reference.to(values.device).float()) ** 2
                ))
            parameter_nonfinite += int((~torch.isfinite(values)).sum())
            if parameter.grad is None:
                continue
            gradients = parameter.grad.detach()
            gradient_tensors += 1
            gradient_sq += float(torch.sum(gradients.float() ** 2))
            gradient_nonfinite += int((~torch.isfinite(gradients)).sum())
    return {
        "trainable_parameter_tensors": len(trainable),
        "trainable_parameters": sum(parameter.numel() for parameter in trainable),
        "parameter_l2_norm": _finite_or_none(math.sqrt(parameter_sq)),
        "parameter_l2_drift_from_initial": (
            _finite_or_none(math.sqrt(parameter_drift_sq))
            if initial_parameters is not None else None
        ),
        "gradient_tensors": gradient_tensors,
        "gradient_l2_norm": _finite_or_none(math.sqrt(gradient_sq)),
        "nonfinite_parameter_values": parameter_nonfinite,
        "nonfinite_gradient_values": gradient_nonfinite,
    }


def run_ac_alg1(
    task,
    rounds: int = 40,
    L_batch: int = 32,
    U_batch: int = 32,
    G_label: int = 1,
    G_answer_only: int = 1,
    inner_steps: int = 8,
    seed: int = 0,
    lr: float = 1e-4,
    model_name: str = MODEL_NAME,
    model_tok=None,
    length_norm: bool = False,
    buffer_limit: int = 0,
    labelled_frac: float = 0.5,
    buffer_strategy: str = "fifo",
    proposal_prompt: str = "question",
    labelled_proposal_prompt: str | None = None,
    answer_only_proposal_prompt: str | None = None,
    proposal_filter: str = "all",
    proposal_policy: str = "current",
    responsibility_score: str = "joint",
    responsibility_temperature: float = 1.0,
    responsibility_ess_floor: float = 0.0,
    responsibility_policy: str = "current",
    responsibility_answer_policy: str = "current",
    responsibility_refresh: str = "inner_step",
    labelled_em_weight: float = 1.0,
    answer_only_em_weight: float = 1.0,
    policy_kl_coef: float | None = None,
    supervised_weight: float = 1.0,
    policy_anchor_mode: str = "fixed",
    policy_anchor_target_ratio: float | None = None,
    policy_anchor_beta_min: float = 0.0,
    policy_anchor_beta_max: float = 10.0,
    policy_anchor_ema: float = 0.9,
    labelled_numeric_constraint: str = "off",
    numeric_penalty: float = 2.0,
    numeric_contradiction_penalty: float = 0.0,
    numeric_missing_penalty: float = 0.0,
    labelled_supervision: str = "gold",
    compact_gold_weight: float = 0.5,
    digit_token_weight: float = 1.0,
    trace_representation: str = "reasoning",
    update_geometry: str = "sum",
    step_acceptance: str = "none",
    rollback_tolerance: float = 1e-6,
    rollback_max_backtracks: int = 0,
    rollback_shrink: float = 0.5,
    optimizer_state_scope: str = "persistent",
    question_sampling: str = "random",
    eval_every: int = 0,
    eval_rounds=None,
    eval_fn=None,
    diagnostics_fn=None,
    checkpoint_every: int = 0,
    checkpoint_fn=None,
    log=print,
) -> list[dict]:
    """Train with the faithful three-term buffer objective.

    Args:
        task: GSM8K-style task with prompts, gold_answer, and gold_solution.
        rounds: Number of outer rounds.
        L_batch: Number of labelled questions in each labelled minibatch.
        U_batch: Number of answer-only questions in each answer-only minibatch.
        G_label: Number of model traces sampled per labelled question.
        G_answer_only: Number of model traces sampled per answer-only question.
        inner_steps: Number of objective/weight-refresh steps per outer minibatch.
        seed: Random seed for minibatch sampling.
        lr: Optimizer learning rate.
        model_name: Model name passed to load_model if model_tok is not supplied.
        model_tok: Optional preloaded (model, tokenizer) pair.
        length_norm: Must be False; AC-ALG1 keeps Barber's unnormalised joint log-prob objective.
        buffer_limit: Per-question trace-buffer cap. Values <= 0 mean unbounded.
        labelled_frac: Fraction of answer-known prompts assigned to labelled L rather than answer-only U.
        buffer_strategy: "fifo" or "hybrid".
        proposal_prompt: Candidate-generation prompt mode: "question",
            "derive_only", "answer_hint", "answer_derive",
            "tagged_zero_shot", or "tagged_gold_rationale". Proposal-only
            instructions are not retained in the buffered sequence used for
            scoring or training. This is the fallback for both data pools.
        labelled_proposal_prompt: Optional candidate-generation override for
            labelled L' questions.
        answer_only_proposal_prompt: Optional candidate-generation override for
            answer-only U' questions. Gold-rationale prompting is forbidden.
        proposal_filter: ``all`` retains every proposal; ``answer_correct``
            retains only proposals that decode to the known final answer.
        proposal_policy: ``current`` samples with the trained adapter;
            ``frozen_base`` disables it during proposal generation.
        responsibility_score: ``joint`` uses the faithful unnormalised E-step
            logit; ``token_mean`` divides it by the scored sequence length.
        responsibility_temperature: Positive softmax temperature applied to
            the E-step logits. Values above one smooth responsibilities.
        responsibility_ess_floor: One-sided minimum effective-sample-size
            fraction over finite support. Zero disables adaptive smoothing.
        responsibility_policy: ``current`` scores responsibilities with the
            trained adapter; ``frozen_base`` uses the pretrained base.
        responsibility_answer_policy: Policy used for p(a* | h_s, q).
            ``frozen_base`` freezes only the answer reader while leaving the
            trace-prior factor under responsibility_policy.
        responsibility_refresh: ``inner_step`` recomputes the E-step after
            every optimizer step; ``outer_round`` holds it fixed for the
            complete generalized-EM M-step.
        labelled_em_weight: Coefficient on B'_unsup. Zero removes the labelled
            latent-buffer term while retaining B_sup and B_unsup.
        answer_only_em_weight: Coefficient on B_unsup. Zero removes the
            answer-only latent-buffer term while retaining B_sup and B'_unsup.
        policy_kl_coef: Coefficient on the empirical token-level KL penalty to
            the frozen pretrained policy. ``None`` preserves the original
            implementation without extra scoring; zero measures policy drift
            without changing gradients.
        supervised_weight: Coefficient on B_sup. Zero removes direct
            gold-rationale supervision while retaining both latent-buffer terms.
        policy_anchor_mode: ``fixed`` uses policy_kl_coef; ``grad_ratio``
            chooses a detached per-step beta from gradient norms.
        policy_anchor_target_ratio: Target norm ratio between the applied KL
            gradient and the unanchored objective gradient in grad_ratio mode.
        policy_anchor_beta_min: Lower clip for adaptive beta.
        policy_anchor_beta_max: Upper clip for adaptive beta.
        policy_anchor_ema: EMA decay applied to objective and unit-KL norms.
        labelled_numeric_constraint: ``off``, ``hard``, ``soft``, or
            ``graph_hard`` fixed arithmetic potential applied to labelled
            E-step logits only.
        numeric_penalty: Lambda_false, the per-invalid-equation soft penalty.
        numeric_contradiction_penalty: Lambda_contra, the per-gold-contradiction
            soft penalty.
        numeric_missing_penalty: Lambda_miss, the per-missing graph node or edge
            soft penalty.
        labelled_supervision: Gold, fixed compact mixture, set-valued compact
            evidence, or explicit graph-factorized B_sup target.
        compact_gold_weight: Weight on the compact target in the mixed B_sup.
        digit_token_weight: Scale-preserving relative B_sup weight on digit tokens.
        trace_representation: Plain reasoning or explicit z then h serialization.
        update_geometry: Geometry used to combine the three M-step gradients.
        step_acceptance: Fixed-responsibility post-Adam no-harm rule.
        rollback_tolerance: Absolute tolerance in the no-harm comparison.
        rollback_max_backtracks: Number of reduced-size retries after rollback.
        rollback_shrink: Learning-rate multiplier for each retry.
        optimizer_state_scope: ``persistent`` keeps Adam moments across outer
            rounds; ``outer_round`` resets them before each round's M-step.
        question_sampling: Independent random minibatches or reproducible
            shuffled epochs over each labelled/answer-only pool.
        eval_every: Run eval_fn every N rounds and on the final round; zero disables it.
        eval_rounds: Optional explicit completed-round evaluation schedule.
        eval_fn: Optional function mapping the current model to a held-out metric.
        diagnostics_fn: Optional callback receiving one observational diagnostics record per round.
            Enabling it reuses sampled texts and E-step weights; it does not generate or score again.
        checkpoint_every: Save an intermediate adapter every N rounds through checkpoint_fn. The
            final round is omitted because the sweep runner saves the final adapter separately.
        checkpoint_fn: Optional callback accepting ``(model, completed_rounds)``.
        log: Logging function.

    Returns:
        List of per-round metric dictionaries.
    """

    if length_norm:
        raise ValueError("AC-ALG1 is faithful only with length_norm=False")
    if buffer_strategy not in ("fifo", "hybrid"):
        raise ValueError(f"unknown AC-ALG1 buffer_strategy {buffer_strategy!r}")
    if proposal_prompt not in PROPOSAL_PROMPTS:
        raise ValueError(f"unknown AC-ALG1 proposal_prompt {proposal_prompt!r}")
    labelled_proposal_prompt = labelled_proposal_prompt or proposal_prompt
    answer_only_proposal_prompt = answer_only_proposal_prompt or proposal_prompt
    if labelled_proposal_prompt not in PROPOSAL_PROMPTS:
        raise ValueError(
            "unknown AC-ALG1 labelled_proposal_prompt "
            f"{labelled_proposal_prompt!r}"
        )
    if answer_only_proposal_prompt not in PROPOSAL_PROMPTS:
        raise ValueError(
            "unknown AC-ALG1 answer_only_proposal_prompt "
            f"{answer_only_proposal_prompt!r}"
        )
    if answer_only_proposal_prompt == "tagged_gold_rationale":
        raise ValueError(
            "answer_only_proposal_prompt cannot expose a gold rationale to U'"
        )
    if proposal_filter not in PROPOSAL_FILTERS:
        raise ValueError(f"unknown AC-ALG1 proposal_filter {proposal_filter!r}")
    if proposal_policy not in ADAPTER_POLICY_MODES:
        raise ValueError(f"unknown AC-ALG1 proposal_policy {proposal_policy!r}")
    if responsibility_score not in RESPONSIBILITY_SCORES:
        raise ValueError(f"unknown AC-ALG1 responsibility_score {responsibility_score!r}")
    if not math.isfinite(responsibility_temperature) or responsibility_temperature <= 0:
        raise ValueError(
            "responsibility_temperature must be finite and positive, "
            f"got {responsibility_temperature}"
        )
    if (
        not math.isfinite(responsibility_ess_floor)
        or not 0.0 <= responsibility_ess_floor <= 1.0
    ):
        raise ValueError(
            "responsibility_ess_floor must be finite and in [0, 1], "
            f"got {responsibility_ess_floor}"
        )
    if responsibility_policy not in ADAPTER_POLICY_MODES:
        raise ValueError(
            f"unknown AC-ALG1 responsibility_policy {responsibility_policy!r}"
        )
    if responsibility_answer_policy not in ADAPTER_POLICY_MODES:
        raise ValueError(
            "unknown AC-ALG1 responsibility_answer_policy "
            f"{responsibility_answer_policy!r}"
        )
    if responsibility_refresh not in RESPONSIBILITY_REFRESH_MODES:
        raise ValueError(
            "unknown AC-ALG1 responsibility_refresh "
            f"{responsibility_refresh!r}"
        )
    if not math.isfinite(labelled_em_weight) or labelled_em_weight < 0:
        raise ValueError(
            f"labelled_em_weight must be finite and nonnegative, got {labelled_em_weight}"
        )
    if not math.isfinite(answer_only_em_weight) or answer_only_em_weight < 0:
        raise ValueError(
            "answer_only_em_weight must be finite and nonnegative, "
            f"got {answer_only_em_weight}"
        )
    if not math.isfinite(supervised_weight) or supervised_weight < 0:
        raise ValueError(
            f"supervised_weight must be finite and nonnegative, got {supervised_weight}"
        )
    if policy_kl_coef is not None and (
        not math.isfinite(policy_kl_coef) or policy_kl_coef < 0
    ):
        raise ValueError(
            "policy_kl_coef must be finite and nonnegative when supplied, "
            f"got {policy_kl_coef}"
        )
    if policy_anchor_mode not in POLICY_ANCHOR_MODES:
        raise ValueError(f"unknown AC-ALG1 policy_anchor_mode {policy_anchor_mode!r}")
    if policy_anchor_mode == "fixed":
        if policy_anchor_target_ratio is not None:
            raise ValueError(
                "policy_anchor_target_ratio is only valid when "
                "policy_anchor_mode='grad_ratio'"
            )
    else:
        if policy_kl_coef is not None:
            raise ValueError(
                "policy_kl_coef and policy_anchor_mode='grad_ratio' are mutually exclusive"
            )
        if policy_anchor_target_ratio is None or (
            not math.isfinite(policy_anchor_target_ratio)
            or policy_anchor_target_ratio < 0
        ):
            raise ValueError(
                "policy_anchor_target_ratio must be finite and nonnegative in "
                "grad_ratio mode"
            )
    for name, value in (
        ("policy_anchor_beta_min", policy_anchor_beta_min),
        ("policy_anchor_beta_max", policy_anchor_beta_max),
    ):
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative, got {value}")
    if policy_anchor_beta_min > policy_anchor_beta_max:
        raise ValueError("policy_anchor_beta_min cannot exceed policy_anchor_beta_max")
    if not math.isfinite(policy_anchor_ema) or not 0 <= policy_anchor_ema < 1:
        raise ValueError(
            f"policy_anchor_ema must be finite and in [0,1), got {policy_anchor_ema}"
        )
    if labelled_numeric_constraint not in LABELLED_NUMERIC_CONSTRAINTS:
        raise ValueError(
            "unknown AC-ALG1 labelled_numeric_constraint "
            f"{labelled_numeric_constraint!r}"
        )
    if not math.isfinite(numeric_penalty) or numeric_penalty < 0:
        raise ValueError(f"numeric_penalty must be finite and nonnegative, got {numeric_penalty}")
    for name, value in (
        ("numeric_contradiction_penalty", numeric_contradiction_penalty),
        ("numeric_missing_penalty", numeric_missing_penalty),
    ):
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative, got {value}")
    if labelled_supervision not in LABELLED_SUPERVISION_MODES:
        raise ValueError(f"unknown AC-ALG1 labelled_supervision {labelled_supervision!r}")
    policy_anchor_measured = (
        policy_kl_coef is not None or policy_anchor_mode == "grad_ratio"
    )
    if update_geometry not in UPDATE_GEOMETRIES:
        raise ValueError(f"unknown AC-ALG1 update_geometry {update_geometry!r}")
    if step_acceptance not in STEP_ACCEPTANCE_MODES:
        raise ValueError(f"unknown AC-ALG1 step_acceptance {step_acceptance!r}")
    if not math.isfinite(rollback_tolerance) or rollback_tolerance < 0:
        raise ValueError(
            "rollback_tolerance must be finite and nonnegative, "
            f"got {rollback_tolerance}"
        )
    if rollback_max_backtracks < 0:
        raise ValueError(
            "rollback_max_backtracks must be nonnegative, "
            f"got {rollback_max_backtracks}"
        )
    if not math.isfinite(rollback_shrink) or not 0 < rollback_shrink < 1:
        raise ValueError(
            "rollback_shrink must be finite and strictly between zero and one, "
            f"got {rollback_shrink}"
        )
    if step_acceptance == "none" and rollback_max_backtracks:
        raise ValueError(
            "rollback_max_backtracks requires an active step_acceptance rule"
        )
    if optimizer_state_scope not in OPTIMIZER_STATE_SCOPES:
        raise ValueError(
            "unknown AC-ALG1 optimizer_state_scope "
            f"{optimizer_state_scope!r}"
        )
    if (
        update_geometry != "sum" or step_acceptance != "none"
    ) and policy_anchor_measured:
        raise ValueError(
            "safeguarded update geometry and policy anchoring are isolated "
            "experimental factors and cannot be enabled in the same cell"
        )
    if (
        update_geometry == "answer_primary"
        or step_acceptance == "answer_primary"
    ) and (answer_only_em_weight <= 0 or U_batch <= 0):
        raise ValueError(
            "answer-primary updates require a nonzero B_unsup term and "
            "at least one answer-only question per round"
        )
    if policy_anchor_measured and labelled_supervision not in (
        "gold",
        "gold_graph_factorized",
    ):
        raise ValueError(
            "policy anchoring currently requires gold or gold_graph_factorized "
            "labelled supervision so its target distribution is unambiguous"
        )
    if not math.isfinite(compact_gold_weight) or not 0.0 <= compact_gold_weight <= 1.0:
        raise ValueError(
            "compact_gold_weight must be finite and in [0,1], "
            f"got {compact_gold_weight}"
        )
    if not math.isfinite(digit_token_weight) or digit_token_weight < 1.0:
        raise ValueError(
            "digit_token_weight must be finite and at least 1, "
            f"got {digit_token_weight}"
        )
    if trace_representation not in TRACE_REPRESENTATIONS:
        raise ValueError(f"unknown AC-ALG1 trace_representation {trace_representation!r}")
    graph_supervision = labelled_supervision == "gold_graph_factorized"
    graph_representation = trace_representation == "calculation_graph"
    if graph_supervision != graph_representation:
        raise ValueError(
            "gold_graph_factorized supervision and calculation_graph trace_representation "
            "must be enabled together"
        )
    if graph_representation and (
        labelled_proposal_prompt.startswith("tagged_")
        or answer_only_proposal_prompt.startswith("tagged_")
    ):
        raise ValueError(
            "calculation_graph traces cannot be combined with tagged proposal prompts"
        )
    if checkpoint_every < 0:
        raise ValueError(f"checkpoint_every must be nonnegative, got {checkpoint_every}")

    model, tok = model_tok if model_tok is not None else load_model(seed=seed, model=model_name)
    opt = None
    rng = np.random.default_rng(seed)

    labelled_pool, answer_only_pool = _labelled_answer_only_pools(task, labelled_frac=labelled_frac)
    labelled_sampler = QuestionSampler(labelled_pool, rng, mode=question_sampling)
    answer_only_sampler = QuestionSampler(answer_only_pool, rng, mode=question_sampling)
    buffers: dict[int, list[TraceRow]] = {pid: [] for pid in range(len(task.prompts))}
    records = []
    total_generated = 0
    total_steps = 0
    total_buffer_evictions = 0
    total_filter_verifier_calls = 0
    total_diagnostic_verifier_calls = 0
    policy_anchor_state: dict[str, float] = {}
    initial_trainable_parameters = (
        _snapshot_trainable_parameters(model)
        if diagnostics_fn is not None else None
    )

    for t in range(rounds):
        if opt is None or optimizer_state_scope == "outer_round":
            opt = torch.optim.Adam(
                [p for p in model.parameters() if p.requires_grad],
                lr=lr,
            )
        labelled_pids = labelled_sampler.sample(L_batch).tolist()
        answer_only_pids = answer_only_sampler.sample(U_batch).tolist()

        gold_added, gold_evicted = _add_gold_traces_to_buffer(
            tok, task, buffers, labelled_pids, round_added=t,
            buffer_limit=buffer_limit, buffer_strategy=buffer_strategy,
            trace_representation=trace_representation,
        )

        (labelled_sample_pid_row, labelled_sample_texts, labelled_sample_tokens,
         labelled_added, labelled_evicted, labelled_filter_stats) = _add_model_traces_to_buffer(
            model,
            tok,
            task,
            buffers,
            labelled_pids,
            traces_per_question=G_label,
            round_added=t,
            source="labelled_sample",
            buffer_limit=buffer_limit,
            buffer_strategy=buffer_strategy,
            proposal_prompt=labelled_proposal_prompt,
            proposal_filter=proposal_filter,
            proposal_policy=proposal_policy,
            trace_representation=trace_representation,
            collect_token_counts=diagnostics_fn is not None,
            collect_proposal_outcomes=diagnostics_fn is not None,
        )
        (answer_only_sample_pid_row, answer_only_sample_texts, answer_only_sample_tokens,
         answer_only_added, answer_only_evicted,
         answer_only_filter_stats) = _add_model_traces_to_buffer(
            model,
            tok,
            task,
            buffers,
            answer_only_pids,
            traces_per_question=G_answer_only,
            round_added=t,
            source="answer_only_sample",
            buffer_limit=buffer_limit,
            buffer_strategy=buffer_strategy,
            proposal_prompt=answer_only_proposal_prompt,
            proposal_filter=proposal_filter,
            proposal_policy=proposal_policy,
            trace_representation=trace_representation,
            collect_token_counts=diagnostics_fn is not None,
            collect_proposal_outcomes=diagnostics_fn is not None,
        )

        total_generated += len(labelled_sample_pid_row) + len(answer_only_sample_pid_row)
        round_rows_added = gold_added + labelled_added + answer_only_added
        round_evictions = gold_evicted + labelled_evicted + answer_only_evicted
        round_filter_attempted = int(
            labelled_filter_stats["attempted"] + answer_only_filter_stats["attempted"]
        )
        round_filter_accepted = int(
            labelled_filter_stats["accepted"] + answer_only_filter_stats["accepted"]
        )
        round_filter_rejected = int(
            labelled_filter_stats["rejected"] + answer_only_filter_stats["rejected"]
        )
        round_filter_verifier_calls = int(
            labelled_filter_stats["verifier_calls"]
            + answer_only_filter_stats["verifier_calls"]
        )
        total_filter_verifier_calls += round_filter_verifier_calls

        labelled_weights, answer_only_weights = _refresh_minibatch_weights(
            model,
            tok,
            buffers,
            labelled_pids,
            answer_only_pids,
            responsibility_score=responsibility_score,
            responsibility_temperature=responsibility_temperature,
            responsibility_ess_floor=responsibility_ess_floor,
            responsibility_policy=responsibility_policy,
            responsibility_answer_policy=responsibility_answer_policy,
            labelled_numeric_constraint=labelled_numeric_constraint,
            numeric_penalty=numeric_penalty,
            numeric_contradiction_penalty=numeric_contradiction_penalty,
            numeric_missing_penalty=numeric_missing_penalty,
            record_joint_logprobs=diagnostics_fn is not None,
        )

        labelled_weights, answer_only_weights, stats = _inner_weighted_em_steps(
            model,
            tok,
            opt,
            task,
            buffers,
            labelled_pids,
            answer_only_pids,
            labelled_weights,
            answer_only_weights,
            inner_steps,
            responsibility_score=responsibility_score,
            responsibility_temperature=responsibility_temperature,
            responsibility_ess_floor=responsibility_ess_floor,
            responsibility_policy=responsibility_policy,
            responsibility_answer_policy=responsibility_answer_policy,
            responsibility_refresh=responsibility_refresh,
            labelled_em_weight=labelled_em_weight,
            answer_only_em_weight=answer_only_em_weight,
            policy_kl_coef=policy_kl_coef,
            supervised_weight=supervised_weight,
            policy_anchor_mode=policy_anchor_mode,
            policy_anchor_target_ratio=policy_anchor_target_ratio,
            policy_anchor_beta_min=policy_anchor_beta_min,
            policy_anchor_beta_max=policy_anchor_beta_max,
            policy_anchor_ema=policy_anchor_ema,
            policy_anchor_state=policy_anchor_state,
            labelled_numeric_constraint=labelled_numeric_constraint,
            numeric_penalty=numeric_penalty,
            numeric_contradiction_penalty=numeric_contradiction_penalty,
            numeric_missing_penalty=numeric_missing_penalty,
            labelled_supervision=labelled_supervision,
            compact_gold_weight=compact_gold_weight,
            digit_token_weight=digit_token_weight,
            update_geometry=update_geometry,
            step_acceptance=step_acceptance,
            rollback_tolerance=rollback_tolerance,
            rollback_max_backtracks=rollback_max_backtracks,
            rollback_shrink=rollback_shrink,
            record_joint_logprobs=diagnostics_fn is not None,
            record_gradient_geometry=diagnostics_fn is not None,
        )
        gradient_geometry = stats.pop("gradient_geometry", None)
        update_geometry_diagnostics = stats.pop(
            "update_geometry_diagnostics", None
        )

        total_steps += int(stats["steps"])
        for pid in set(labelled_pids) | set(answer_only_pids):
            round_evictions += _enforce_buffer_limit(
                buffers[int(pid)], buffer_limit, buffer_strategy
            )
        total_buffer_evictions += round_evictions
        test_acc = maybe_eval(
            model,
            t,
            rounds,
            eval_every,
            eval_fn,
            eval_rounds=eval_rounds,
        )

        sample_diagnostics = None
        if diagnostics_fn is not None:
            labelled_source = _proposal_source(
                "labelled_sample",
                labelled_proposal_prompt,
                proposal_filter,
                trace_representation,
            )
            answer_only_source = _proposal_source(
                "answer_only_sample",
                answer_only_proposal_prompt,
                proposal_filter,
                trace_representation,
            )
            if proposal_policy != "current":
                labelled_source = f"{labelled_source}:{proposal_policy}"
                answer_only_source = f"{answer_only_source}:{proposal_policy}"
            sample_diagnostics = _sample_diagnostics(
                task,
                labelled_sample_pid_row + answer_only_sample_pid_row,
                labelled_sample_texts + answer_only_sample_texts,
                labelled_sample_tokens + answer_only_sample_tokens,
                ([labelled_source] * len(labelled_sample_pid_row)
                 + [answer_only_source] * len(answer_only_sample_pid_row)),
                trace_ids=(
                    labelled_filter_stats["trace_ids"]
                    + answer_only_filter_stats["trace_ids"]
                ),
                rewards=(
                    labelled_filter_stats["rewards"]
                    + answer_only_filter_stats["rewards"]
                ),
                admitted=(
                    labelled_filter_stats["admitted"]
                    + answer_only_filter_stats["admitted"]
                ),
                retained_after_insertion=(
                    labelled_filter_stats["retained_after_insertion"]
                    + answer_only_filter_stats["retained_after_insertion"]
                ),
                verifier_calls=int(
                    labelled_filter_stats["diagnostic_verifier_calls"]
                    + answer_only_filter_stats["diagnostic_verifier_calls"]
                ),
            )
            total_diagnostic_verifier_calls += sample_diagnostics["verifier_calls"]

        record = {
            "round": t,
            "oracle": 0,
            "gen": total_generated,
            "llm_gen": total_generated,
            "gsteps": total_steps,
            "buffer_limit": buffer_limit,
            "buffer_strategy": buffer_strategy,
            "proposal_prompt": proposal_prompt,
            "labelled_proposal_prompt": labelled_proposal_prompt,
            "answer_only_proposal_prompt": answer_only_proposal_prompt,
            "proposal_filter": proposal_filter,
            "proposal_policy": proposal_policy,
            "responsibility_score": responsibility_score,
            "responsibility_temperature": responsibility_temperature,
            "responsibility_ess_floor": responsibility_ess_floor,
            "responsibility_policy": responsibility_policy,
            "responsibility_answer_policy": responsibility_answer_policy,
            "responsibility_refresh": responsibility_refresh,
            "labelled_em_weight": labelled_em_weight,
            "answer_only_em_weight": answer_only_em_weight,
            "supervised_weight": supervised_weight,
            "policy_kl_coef": policy_kl_coef,
            "policy_kl_measured": policy_anchor_measured,
            "policy_anchor_mode": policy_anchor_mode,
            "policy_anchor_target_ratio": policy_anchor_target_ratio,
            "policy_anchor_beta_min": policy_anchor_beta_min,
            "policy_anchor_beta_max": policy_anchor_beta_max,
            "policy_anchor_ema": policy_anchor_ema,
            "labelled_numeric_constraint": labelled_numeric_constraint,
            "numeric_penalty": numeric_penalty,
            "numeric_contradiction_penalty": numeric_contradiction_penalty,
            "numeric_missing_penalty": numeric_missing_penalty,
            "labelled_supervision": labelled_supervision,
            "compact_gold_weight": compact_gold_weight,
            "digit_token_weight": digit_token_weight,
            "trace_representation": trace_representation,
            "update_geometry": update_geometry,
            "step_acceptance": step_acceptance,
            "rollback_tolerance": rollback_tolerance,
            "rollback_max_backtracks": rollback_max_backtracks,
            "rollback_shrink": rollback_shrink,
            "optimizer_state_scope": optimizer_state_scope,
            "question_sampling": question_sampling,
            "labelled_frac": labelled_frac,
            "buffer_rows": sum(len(rows) for rows in buffers.values()),
            "buffer_evictions": total_buffer_evictions,
            "proposal_filter_verifier_calls": total_filter_verifier_calls,
            "proposal_filter_accepted": round_filter_accepted,
            "proposal_filter_rejected": round_filter_rejected,
            "diagnostic_verifier_calls": total_diagnostic_verifier_calls,
            "labelled_pool": len(labelled_pool),
            "answer_only_pool": len(answer_only_pool),
            "labelled_questions": len(labelled_pids),
            "answer_only_questions": len(answer_only_pids),
            "test_acc": test_acc,
            **stats,
        }
        if sample_diagnostics is not None:
            record.update(
                frac_correct=sample_diagnostics["correct_fraction"],
                fmt=sample_diagnostics["format_fraction"],
                gen_len=sample_diagnostics["mean_tokens"],
            )
        records.append(record)

        if diagnostics_fn is not None:
            diagnostics_fn({
                "schema_version": 6,
                "round": t,
                "completed_rounds": t + 1,
                "minibatch": {
                    "labelled_pids": [int(pid) for pid in labelled_pids],
                    "answer_only_pids": [int(pid) for pid in answer_only_pids],
                },
                "generation": {
                    "proposal_prompt": proposal_prompt,
                    "labelled_proposal_prompt": labelled_proposal_prompt,
                    "answer_only_proposal_prompt": answer_only_proposal_prompt,
                    "proposal_filter": proposal_filter,
                    "proposal_policy": proposal_policy,
                    "trace_representation": trace_representation,
                    "this_round": len(labelled_sample_pid_row) + len(answer_only_sample_pid_row),
                    "cumulative": total_generated,
                    "filter": {
                        "attempted": round_filter_attempted,
                        "accepted": round_filter_accepted,
                        "rejected": round_filter_rejected,
                        "acceptance_fraction": (
                            round_filter_accepted / round_filter_attempted
                            if round_filter_attempted else None
                        ),
                        "verifier_calls_this_round": round_filter_verifier_calls,
                        "verifier_calls_cumulative": total_filter_verifier_calls,
                    },
                    "samples": sample_diagnostics,
                    "diagnostic_verifier_calls_cumulative": total_diagnostic_verifier_calls,
                },
                "buffer": _buffer_diagnostics(
                    buffers,
                    buffer_limit,
                    buffer_strategy,
                    round_rows_added,
                    round_evictions,
                ),
                "buffer_evictions_cumulative": total_buffer_evictions,
                "responsibilities": {
                    "score": responsibility_score,
                    "temperature": responsibility_temperature,
                    "ess_floor_fraction": responsibility_ess_floor,
                    "policy": responsibility_policy,
                    "answer_policy": responsibility_answer_policy,
                    "refresh": responsibility_refresh,
                    "inter_refresh_total_variation_mean": _finite_or_none(
                        stats["responsibility_refresh_total_variation_mean"]
                    ),
                    "inter_refresh_total_variation_max": _finite_or_none(
                        stats["responsibility_refresh_total_variation_max"]
                    ),
                    "labelled_numeric_constraint": labelled_numeric_constraint,
                    "numeric_penalty": numeric_penalty,
                    "numeric_contradiction_penalty": numeric_contradiction_penalty,
                    "numeric_missing_penalty": numeric_missing_penalty,
                    **_responsibility_diagnostics(
                        buffers,
                        labelled_weights,
                        answer_only_weights,
                        t,
                    ),
                },
                "optimizer": _optimizer_diagnostics(
                    model,
                    initial_parameters=initial_trainable_parameters,
                ),
                "gradient_geometry": gradient_geometry,
                "update_geometry": update_geometry_diagnostics,
                "objective": {
                    "B_sup": _finite_or_none(stats["B_sup"]),
                    "B_prime_unsup": _finite_or_none(stats["B_prime_unsup"]),
                    "B_unsup": _finite_or_none(stats["B_unsup"]),
                    "F": _finite_or_none(stats["F"]),
                    "policy_kl": _finite_or_none(stats["policy_kl"]),
                    "policy_kl_penalty": _finite_or_none(stats["policy_kl_penalty"]),
                    "F_anchored": _finite_or_none(stats["F_anchored"]),
                    "policy_kl_coef": policy_kl_coef,
                    "policy_kl_measured": policy_anchor_measured,
                    "policy_anchor_mode": policy_anchor_mode,
                    "policy_anchor_target_ratio": policy_anchor_target_ratio,
                    "policy_anchor_beta": _finite_or_none(
                        stats["policy_anchor_beta"]
                    ),
                    "policy_anchor_beta_unclipped": _finite_or_none(
                        stats["policy_anchor_beta_unclipped"]
                    ),
                    "policy_anchor_beta_clip_fraction": _finite_or_none(
                        stats["policy_anchor_beta_clipped"]
                    ),
                    "policy_anchor_objective_grad_norm": _finite_or_none(
                        stats["policy_anchor_objective_grad_norm"]
                    ),
                    "policy_anchor_raw_grad_norm": _finite_or_none(
                        stats["policy_anchor_raw_anchor_grad_norm"]
                    ),
                    "policy_anchor_applied_grad_norm": _finite_or_none(
                        stats["policy_anchor_applied_anchor_grad_norm"]
                    ),
                    "policy_anchor_achieved_ratio": _finite_or_none(
                        stats["policy_anchor_achieved_ratio"]
                    ),
                    "policy_anchor_ema_objective_grad_norm": _finite_or_none(
                        stats["policy_anchor_ema_objective_grad_norm"]
                    ),
                    "policy_anchor_ema_raw_grad_norm": _finite_or_none(
                        stats["policy_anchor_ema_raw_anchor_grad_norm"]
                    ),
                    "policy_anchor_beta_min": policy_anchor_beta_min,
                    "policy_anchor_beta_max": policy_anchor_beta_max,
                    "policy_anchor_ema": policy_anchor_ema,
                    "optimizer_state_scope": optimizer_state_scope,
                    "labelled_em_weight": labelled_em_weight,
                    "answer_only_em_weight": answer_only_em_weight,
                    "supervised_weight": supervised_weight,
                    "labelled_supervision": labelled_supervision,
                    "compact_gold_weight": compact_gold_weight,
                    "digit_token_weight": digit_token_weight,
                    "trace_representation": trace_representation,
                    "update_geometry": update_geometry,
                    "step_acceptance": step_acceptance,
                    "rollback_tolerance": rollback_tolerance,
                    "rollback_max_backtracks": rollback_max_backtracks,
                    "rollback_shrink": rollback_shrink,
                    "update_direction_norm": _finite_or_none(
                        stats["update_direction_norm"]
                    ),
                    "update_B_sup_coefficient": _finite_or_none(
                        stats["update_B_sup_coefficient"]
                    ),
                    "update_B_prime_unsup_coefficient": _finite_or_none(
                        stats["update_B_prime_unsup_coefficient"]
                    ),
                    "update_B_unsup_coefficient": _finite_or_none(
                        stats["update_B_unsup_coefficient"]
                    ),
                    "candidate_steps": int(stats["candidate_steps"]),
                    "rolled_back_candidates": int(
                        stats["rolled_back_candidates"]
                    ),
                    "rollback_backtracks": int(stats["rollback_backtracks"]),
                    "safeguard_acceptance_fraction": _finite_or_none(
                        stats["safeguard_acceptance_fraction"]
                    ),
                    "accepted_step_scale": _finite_or_none(
                        stats["accepted_step_scale"]
                    ),
                    "accepted_surrogate_total_delta": _finite_or_none(
                        stats["accepted_surrogate_total_delta"]
                    ),
                    "accepted_B_sup_delta": _finite_or_none(
                        stats["accepted_B_sup_delta"]
                    ),
                    "accepted_B_prime_unsup_delta": _finite_or_none(
                        stats["accepted_B_prime_unsup_delta"]
                    ),
                    "accepted_B_unsup_delta": _finite_or_none(
                        stats["accepted_B_unsup_delta"]
                    ),
                    "gradient_steps_this_round": int(stats["steps"]),
                    "gradient_steps_cumulative": total_steps,
                    "test_acc": _finite_or_none(test_acc),
                },
            })

        if (checkpoint_fn is not None and checkpoint_every > 0
                and (t + 1) % checkpoint_every == 0 and (t + 1) < rounds):
            checkpoint_fn(model, t + 1)

        policy_suffix = (
            f" KL={record['policy_kl']:.4f} "
            f"beta={record['policy_anchor_beta']:.4g}"
            + (
                f" rho={record['policy_anchor_achieved_ratio']:.3f}"
                if policy_anchor_mode == "grad_ratio" else ""
            )
            if policy_anchor_measured else ""
        )
        log(
            f"  [AC-ALG1 r{t:>3}] "
            f"gen={total_generated:>6} "
            f"F={record['F']:.3f} "
            f"Bsup={record['B_sup']:.3f} "
            f"B'unsup={record['B_prime_unsup']:.3f} "
            f"Bunsup={record['B_unsup']:.3f} "
            f"accept={round_filter_accepted}/{round_filter_attempted} "
            f"H={record['buffer_rows']}"
            f"{policy_suffix}"
        )

    return records
