"""PO-vs-RL-vs-EM sweep driver (docs/experiments/po_vs_rl/po_vs_rl_vs_em_study_design.md) — the nested experiment loop:

    for seed: for base model: for fine-tuning method: train -> BENCHMARK on held-out.

Multi-prompt tasks (gsm8k, imdb). The driver OWNS the model (creates it, passes via model_tok),
so after training it can run the held-out benchmark on that exact model. Outputs go to --out
(point this at HOME on the cluster -- /scratch0 is wiped at session end). CSV is checkpointed after
every (seed, model, method) cell.

    python run_sweep_lm.py --task gsm8k --models qwen2.5-1.5b-instruct \
        --methods AC-EM GRPO --seeds 3 --rounds 60 --G 8 --prompts 64 \
        --out ~/po_vs_rl_results --tag run1

Conditional VRO + weighted-EM family (AW/AAW/RW-EM) + AC-EM (eq-8) + RL/PO comparators
(GRPO, RLOO, RAFT, DPO, APL).
"""
from __future__ import annotations
import argparse
import functools
import gzip
import inspect
import json
import os
import time

import pandas as pd
import torch

from tasks import GSM8KTask, IMDBSentimentTask
from methods import (
    run_ac_alg1,
    run_ac_dpo,
    run_ac_em,
    run_apl,
    run_conditional_vro,
    run_dpo,
    run_grpo,
    run_l2r,
    run_raft,
    run_rloo,
    run_weighted_em,
)
from methods_lm import load_model, MODELS, MODEL_NAME
from hparams import KNOBS, CONFIG_KEYS, flag
import benchmark as B

try:                                                      # per-round logging coexists with the tqdm bar
    from tqdm import tqdm
    def _log(s): tqdm.write(str(s))
except Exception:
    def _log(s): print(s, flush=True)

# The exact algorithm parameters are recorded ONCE per CSV (a single `params` cell on row 0), not
# repeated on every result row -- algos have been retuned across commits, so two CSVs with the same
# `method` names can be different algorithms, and this makes each file self-describing.
# Both lists derive from the ONE knob registry (hparams.py); CLI flags are generated from it too.
_HPARAM_KEYS = tuple(k.key for k in KNOBS) + CONFIG_KEYS

# Sweep hyperparameters overridable from the CLI / YAML; each is applied ONLY where the trainer
# accepts it (via _accepts), so e.g. --clip hits GRPO and is silently ignored by AC-EM. Remaining
# categorical / boolean knobs (hparams.CONFIG_KEYS) are varied via named method variants in the
# registry instead; `micro` stays a memory-only knob.
_OVERRIDE_KEYS = tuple(k.key for k in KNOBS)


def _method_hparams(fn):
    """Resolve a trainer's EFFECTIVE kwargs: signature defaults overlaid with functools.partial bindings."""
    bound = {}
    while isinstance(fn, functools.partial):
        bound.update(fn.keywords or {})
        fn = fn.func
    sig = inspect.signature(fn)
    hp = {n: p.default for n, p in sig.parameters.items() if p.default is not inspect.Parameter.empty}
    hp.update(bound)
    return {k: hp[k] for k in _HPARAM_KEYS if k in hp}


def _accepts(fn, name):
    """Does the trainer accept this kwarg? (--beta is valid for EM/DPO/APL but not GRPO/RLOO/RAFT.)"""
    while isinstance(fn, functools.partial):
        fn = fn.func
    return name in inspect.signature(fn).parameters


def _env_meta():
    """Code + environment provenance, stamped into every CSV's params blob. Two mid-project refactors
    have already made "same method name, different algorithm" a real hazard: the commit hash pins the
    exact code that produced each number (papers need this in the repro statement anyway)."""
    import platform
    import subprocess
    env = {"python": platform.python_version(), "host": platform.node()}
    try:
        env["commit"] = subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                                       cwd=os.path.dirname(os.path.abspath(__file__)),
                                       capture_output=True, text=True, timeout=5).stdout.strip() or "unknown"
    except Exception:
        env["commit"] = "unknown"
    for mod in ("torch", "transformers", "peft"):
        try:
            env[mod] = __import__(mod).__version__
        except Exception:
            pass
    try:
        if torch.cuda.is_available():
            env["gpu"] = torch.cuda.get_device_name(0)
    except Exception:
        pass
    return env


def _params_blob(args):
    """One-cell JSON snapshot of the whole run: sweep config + every method's resolved hyperparameters.
    Written to the `params` column of row 0 only; every other row leaves that cell blank."""
    methods = {m: _method_hparams(METHODS[m]) for m in args.methods if m in METHODS}
    for k in _OVERRIDE_KEYS:                              # reflect each CLI override wherever the method exposes it
        v = getattr(args, k)
        if v is not None:
            for hp in methods.values():
                if k in hp:
                    hp[k] = v
    return json.dumps({"run_id": args.run_id,
                       "sweep": {"rounds": args.rounds, "B": args.batch, "G": args.G,
                                 "seeds": args.seeds, "seed0": args.seed0,
                                 "prompts": args.prompts, "shots": args.shots,
                                 "shot_bank_size": args.shot_bank_size,
                                 "task_seed_from_run_seed": args.task_seed_from_run_seed,
                                 "question_sampling": args.question_sampling,
                                 "n_test": args.n_test,
                                 "train_partition": args.train_partition,
                                 "eval_partition": args.eval_partition,
                                 "eval_batch": args.eval_batch,
                                 "gradient_checkpointing": args.grad_checkpoint,
                                 "eval_every": args.eval_every,
                                 "eval_rounds": args.eval_rounds,
                                 "dump_completions": args.dump_completions,
                                 "save_adapter": args.save_adapter,
                                 "save_training_diagnostics": args.save_training_diagnostics,
                                 "checkpoint_every": args.checkpoint_every,
                                 "passk": args.passk,
                                 "passk_n": args.passk_n},
                       "env": _env_meta(),
                       "methods": methods}, default=str)

# Adapter for the faithful Barber Algorithm 1 implementation. Keep --batch as the same total LLM
# generation budget used by the other methods: B//G questions per round, split across L' and U'.
def _run_ac_alg1_sweep(task, rounds=40, B=64, G=4, seed=0, lr=1e-4, iters=8,
                       model_name=MODEL_NAME, model_tok=None, length_norm=False, buffer_limit=0,
                       labelled_frac=0.5, buffer_strategy="fifo", proposal_prompt="question",
                       labelled_proposal_prompt=None, answer_only_proposal_prompt=None,
                       proposal_filter="all", proposal_policy="current",
                       responsibility_score="joint",
                       responsibility_temperature=1.0,
                       responsibility_ess_floor=0.0,
                       responsibility_policy="current",
                       responsibility_answer_policy="current",
                       responsibility_refresh="inner_step",
                       labelled_em_weight=1.0,
                       answer_only_em_weight=1.0, policy_kl_coef=None,
                       supervised_weight=1.0,
                       policy_anchor_mode="fixed", policy_anchor_target_ratio=None,
                       policy_anchor_beta_min=0.0, policy_anchor_beta_max=10.0,
                       policy_anchor_ema=0.9,
                       labelled_numeric_constraint="off", numeric_penalty=2.0,
                       labelled_supervision="gold", compact_gold_weight=0.5,
                       numeric_contradiction_penalty=0.0, numeric_missing_penalty=0.0,
                       digit_token_weight=1.0, trace_representation="reasoning",
                       update_geometry="sum", step_acceptance="none",
                       rollback_tolerance=1e-6, rollback_max_backtracks=0,
                       rollback_shrink=0.5, optimizer_state_scope="persistent",
                       question_sampling="random",
                       eval_every=0, eval_rounds=None, eval_fn=None,
                       diagnostics_fn=None, checkpoint_every=0,
                       checkpoint_fn=None, log=print):
    if not 0.0 <= labelled_frac <= 1.0:
        raise ValueError(f"labelled_frac must be in [0,1], got {labelled_frac}")
    n_questions = max(B // G, 1)
    L_batch = min(n_questions, max(0, int(n_questions * labelled_frac + 0.5)))
    if 0.0 < labelled_frac < 1.0 and n_questions > 1:
        L_batch = min(n_questions - 1, max(1, L_batch))
    U_batch = n_questions - L_batch
    recs = run_ac_alg1(task, rounds=rounds, L_batch=L_batch, U_batch=U_batch, G_label=G, G_answer_only=G,
                       inner_steps=iters, seed=seed, lr=lr, model_name=model_name, model_tok=model_tok,
                       length_norm=length_norm, buffer_limit=buffer_limit, labelled_frac=labelled_frac,
                       buffer_strategy=buffer_strategy, proposal_prompt=proposal_prompt,
                       labelled_proposal_prompt=labelled_proposal_prompt,
                       answer_only_proposal_prompt=answer_only_proposal_prompt,
                       proposal_filter=proposal_filter, proposal_policy=proposal_policy,
                       responsibility_score=responsibility_score,
                       responsibility_temperature=responsibility_temperature,
                       responsibility_ess_floor=responsibility_ess_floor,
                       responsibility_policy=responsibility_policy,
                       responsibility_answer_policy=responsibility_answer_policy,
                       responsibility_refresh=responsibility_refresh,
                       labelled_em_weight=labelled_em_weight,
                       answer_only_em_weight=answer_only_em_weight,
                       policy_kl_coef=policy_kl_coef,
                       supervised_weight=supervised_weight,
                       policy_anchor_mode=policy_anchor_mode,
                       policy_anchor_target_ratio=policy_anchor_target_ratio,
                       policy_anchor_beta_min=policy_anchor_beta_min,
                       policy_anchor_beta_max=policy_anchor_beta_max,
                       policy_anchor_ema=policy_anchor_ema,
                       labelled_numeric_constraint=labelled_numeric_constraint,
                       numeric_penalty=numeric_penalty,
                       numeric_contradiction_penalty=numeric_contradiction_penalty,
                       numeric_missing_penalty=numeric_missing_penalty,
                       labelled_supervision=labelled_supervision,
                       compact_gold_weight=compact_gold_weight,
                       digit_token_weight=digit_token_weight,
                       trace_representation=trace_representation,
                       update_geometry=update_geometry,
                       step_acceptance=step_acceptance,
                       rollback_tolerance=rollback_tolerance,
                       rollback_max_backtracks=rollback_max_backtracks,
                       rollback_shrink=rollback_shrink,
                       optimizer_state_scope=optimizer_state_scope,
                       question_sampling=question_sampling,
                       eval_every=eval_every, eval_rounds=eval_rounds,
                       eval_fn=eval_fn, diagnostics_fn=diagnostics_fn,
                       checkpoint_every=checkpoint_every, checkpoint_fn=checkpoint_fn, log=log)
    for r in recs:
        r.setdefault("oracle", 0)
        r.setdefault("llm_gen", r.get("gen"))
    return recs


# Multi-prompt method registry. Conditional VRO is the verifier-reward implementation of Barber
# equations 58--62; GRPO/RLOO = RL; DPO/APL = PO. The old global weighted-EM implementation remains
# reproducible below but is not the conditional VRO experiment.
METHODS = {
    # ---- CONDITIONAL VRO: one independently normalised completion history per question ----
    "VRO-Full": run_conditional_vro,  # eq 61 policy x reward responsibilities; full unique history
    "VRO-Current": functools.partial(run_conditional_vro, window=1),  # current-round support only
    "VRO-RewardOnly": functools.partial(run_conditional_vro, policy_factor=False),  # document eq 63
    "VRO-TokenMean": functools.partial(  # LM length-bias control; not the sequence-probability bound
        run_conditional_vro, responsibility_score="token_mean"
    ),
    # ---- AC-EM family (ACTIVE): answer-conditioned, "reward" = p(a*|h); weight = RW (eq8) / AW / AAW ----
    # M-step = (1-sup)·B_unsup + sup·B_sup; default sup=0.5 (equal mix, B_sup = SFT on gold reasoning,
    # eq 11-14). --sup 0 = unsupervised-only ablation; AC-SFT below is the sup-only (pure SFT) endpoint.
    "AC-EM":      run_ac_em,                                       # B_unsup(w ∝ p(a*|h)·p(h), eq8) + B_sup
    "AC-ALG1":    _run_ac_alg1_sweep,                              # faithful Barber Algorithm 1:
                                                                   # F = B_sup + B'_unsup + B_unsup
    # ---- SCALABLE L2R: isolate the reasoning generator from the answer reader ----
    "L2R-Moving": functools.partial(                                # endogenous-reader control
        run_l2r, reader_mode="moving", gold_in_buffer=True
    ),
    "L2R-Frozen": functools.partial(                                # exogenous base reader; h-only M-step
        run_l2r, reader_mode="frozen", gold_in_buffer=True
    ),
    "L2R-Frozen-LN": functools.partial(                             # factor-wise token means + h-token mean M-step
        run_l2r, reader_mode="frozen", gold_in_buffer=True,
        responsibility_score="token_mean", length_norm=True
    ),
    "L2R-Frozen-Decode": functools.partial(                         # free-decoding consistency gate
        run_l2r, reader_mode="frozen", gold_in_buffer=True,
        reader_decode_filter=True
    ),
    "L2R-Frozen-NoGold": functools.partial(                         # gold-buffer attribution control
        run_l2r, reader_mode="frozen", gold_in_buffer=False
    ),
    "AC-EM-anchor":  functools.partial(run_ac_em, anchor=1.0),        # eq 8 + variational prior (w *= p_base/p_θ)
    "AC-AW":      functools.partial(run_ac_em, weight="AW"),       # w ∝ e^{βA}, A = adv of log p(a*|h)
    "AC-AW-anchor":  functools.partial(run_ac_em, weight="AW", anchor=1.0),
    "AC-AAW":     functools.partial(run_ac_em, weight="AAW"),      # w ∝ p(h)·e^{βA}  (advantage × policy)
    "AC-AAW-anchor": functools.partial(run_ac_em, weight="AAW", anchor=1.0),
    "AC-SFT":     functools.partial(run_ac_em, sup=1.0),          # pure-SFT baseline (sup=1 -> unsup=0; EM term off)
    "AC-CW":      functools.partial(run_ac_em, weight="RW", causal=1.0),          # causal-tilted (CVTO): w *= exp(γ·ablation lift), γ=1
    "AC-CW-anchor": functools.partial(run_ac_em, weight="RW", causal=1.0, anchor=1.0),  # CVTO + base-prior anchor
    "AC-EM-hs":   functools.partial(run_ac_em, hindsight=True),                   # answer-conditioned proposal (Extension 1, ρ=0)
    "AC-CW-hs":   functools.partial(run_ac_em, weight="RW", causal=1.0, hindsight=True),  # Ext-1 discovery × CVTO credit (synergy)
    # ---- M-STEP REPAIR ARMS (experiments_repair.yaml; each reinstates ONE property eq-9 lacks vs
    #      RL/RAFT/DPO -- on-policyness, a trust region, or negative gradients; pin sup: 0 to isolate) ----
    "AC-EM-kl":   run_ac_em,                                       # alias: sweep kl_coef (in-loss trust region) on its own line
    "AC-EM-ln":   functools.partial(run_ac_em, length_norm=True),  # length-normalised lps (the un-faithful knob, unrun till now)
    "AC-EM-fresh": functools.partial(run_ac_em, window=1),         # fresh-only M-step (drop eq-5's stale history)
    "AC-EM-hspan": functools.partial(run_ac_em, train_span="h"),   # imitate reasoning only (no conditional sharpening)
    "AC-EM-aspan": functools.partial(run_ac_em, train_span="ans"), # answer head only (no reinforcement of sampled h)
    "AC-EM-top1": functools.partial(run_ac_em, select="top1"),     # hard/Viterbi EM (per-question argmax only)
    "AC-PG":      functools.partial(run_ac_em, centered=True),     # PG-form centred weights -> negative gradients
    "AC-EM-dc":   functools.partial(run_ac_em, dconsist=True),     # decode-consistency filter (teacher-forcing gap)
    "AC-DPO":     run_ac_dpo,                                      # contrastive M-step: DPO loss on p(a*|h) pairs, oracle=0
    # ---- repair-screen CONTROLS + combos (close the screen's attribution gaps) ----
    "AC-EM-lr":   run_ac_em,                                       # alias: the LR CONTROL line (plain eq-9 at GRPO-scale lr:
                                                                   #   if this recovers, step size -- not structure -- was the disease)
    "AC-EM-gate": run_ac_em,                                       # alias: sweep the evidence gate (SNIS validity floor) on its own line
    "AC-EM-kl-fresh": functools.partial(run_ac_em, window=1, kl_coef=0.02),  # combo: trust region x fresh-only (both diseases at once)
    "AC-EM-hs-dc": functools.partial(run_ac_em, hindsight=True, dconsist=True),  # DIRECT leakage fix: hindsight discovery, but the
                                                                   #   dconsist probe decodes HINT-FREE from [q++h] -> must stand alone
    # ---- PROPOSAL-SIDE arms (make the E-step's INPUT good, not the M-step update; sweep sup_warmup /
    #      reset_every / gate in the YAML). Motivated by the M-step line closing as a negative. ----
    "AC-EM-curr": functools.partial(run_ac_em, sup=0.0),          # curriculum: sup_warmup rounds of gold-SFT, THEN pure EM
    "AC-EM-rest": functools.partial(run_ac_em, sup=0.0, dconsist=True),  # verifier-free ReST: reset_every from-base improve
                                                                   #   + dconsist/gate filter (isolate reset vs the known filter-only arms)
    "AC-EM-fc":  functools.partial(run_ac_em, sup=0.0, frozen_critic=True),  # EXOGENOUS reward: score p(a*|h) under the
                                                                   #   frozen base (VRO eq-17, ungameable); faithful eq-9 M-step otherwise
    "AC-EM-fch": functools.partial(run_ac_em, sup=0.0, frozen_critic=True, train_span="h"),  # + train the GENERATOR only
                                                                   #   (never the answer head): the full exogenous-reward form
    "AC-EM-alg1": functools.partial(run_ac_em, gold_in_buffer=True),  # L2R v5 Algorithm 1: inject the GOLD trace into
                                                                   #   each question's buffer (step 3); sweep sup in the YAML
    "AC-EM-alg1fc": functools.partial(run_ac_em, gold_in_buffer=True, frozen_critic=True),  # the combined attack:
                                                                   #   gold anchor in the buffer + ungameable frozen-base scorer
    # ---- LEGACY verifier-reward weighted-EM (run_weighted_em); reproducible, not run going forward ----
    "AW-EM":      functools.partial(run_weighted_em, weight="AW"),                 # w ∝ e^{βA}           (Advantage-Weighted)
    "AW-EM-anchor":  functools.partial(run_weighted_em, weight="AW", anchor=1.0),     # w ∝ e^{βA}·(p_base/p_θ)
    "AAW-EM":     functools.partial(run_weighted_em, weight="AAW"),                # w ∝ p_θ·e^{βA}       (Anchored Advantage-Weighted)
    "AAW-EM-anchor": functools.partial(run_weighted_em, weight="AAW", anchor=1.0),    # w ∝ p_base·e^{βA}
    "RW-EM":      functools.partial(run_weighted_em, weight="RW"),                 # w ∝ p_θ·r            (Reward-Weighted = Barber VRO)
    "RW-EM-anchor":  functools.partial(run_weighted_em, weight="RW", anchor=1.0),     # w ∝ p_base·r
    "RFT":       run_raft,                                  # answer-correct rejection SFT
    "RAFT":      run_raft,                                  # historical alias for old configs/results
    "RLOO":      run_rloo,                                  # REINFORCE + leave-one-out (RL)
    "GRPO":      run_grpo,                                  # clipped PG + KL (RL)
    "DPO":       functools.partial(run_dpo, offline=False), # online iterative DPO (PO)
    "DPO-offline":  functools.partial(run_dpo, offline=True),  # offline DPO (PO)  -- RQ3 vs APL
    "APL":       run_apl,                                   # active DPO (Barber, PO)
}


def build_task(
    name,
    prompts,
    shots,
    seed,
    train_partition="all",
    shot_bank_size=0,
    task_seed_from_run_seed=False,
):
    if name == "gsm8k":
        task_seed = seed if task_seed_from_run_seed else 0
        return GSM8KTask(
            n_prompts=prompts,
            n_shots=shots,
            seed=task_seed,
            train_partition=train_partition,
            shot_bank_size=(shot_bank_size or None),
        )
    if name == "imdb":
        return IMDBSentimentTask(n_prompts=prompts, seed=0)
    raise ValueError(name)


def benchmark(
    task_name,
    model,
    tok,
    n_test,
    shots,
    seed,
    eval_partition="all",
    eval_batch=16,
    shot_bank_size=0,
):
    """Returns (metrics_dict, per_question_records). The records are EVERY held-out example
    (idx/question/completion/gold/pred/correct) from the SAME pass that scored the model -- the caller
    writes a compact per-question file (stratify by difficulty) and, optionally, the first N in full."""
    if task_name == "gsm8k":
        acc, recs = B.benchmark_gsm8k(model, tok, n_test=n_test, n_shots=shots, seed=seed,
                                      batch=eval_batch, return_records=True,
                                      eval_partition=eval_partition,
                                      shot_bank_size=(shot_bank_size or None))
        return {"test_acc": acc}, recs
    if task_name == "imdb":
        from datasets import load_dataset
        ds = load_dataset("imdb", split="test")
        import numpy as np
        idx = np.random.default_rng(seed).permutation(len(ds))[:n_test]
        prompts = [" ".join(ds[int(i)]["text"].split()[:8]) for i in idx]
        win, pos = B.benchmark_imdb(model, tok, prompts, batch=eval_batch)
        return {"win_rate": win, "mean_pos": pos}, []
    raise ValueError(task_name)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--task", default="gsm8k", choices=["gsm8k", "imdb"])
    p.add_argument("--models", nargs="+", default=["qwen2.5-1.5b-instruct"])
    p.add_argument("--methods", nargs="+", default=list(METHODS), choices=list(METHODS) + ["base"])
    p.add_argument("--seeds", type=int, default=3)
    p.add_argument("--seed0", type=int, default=0)
    p.add_argument("--rounds", type=int, default=60)
    p.add_argument("--batch", type=int, default=64)
    p.add_argument("--eval-batch", type=int, default=16,
                   help="generation batch size for held-out and pass@k evaluation")
    p.add_argument("--G", type=int, default=8)
    p.add_argument("--prompts", type=int, default=64)
    p.add_argument("--shots", type=int, default=4)
    p.add_argument(
        "--shot-bank-size",
        type=int,
        default=0,
        help=(
            "reserve this many leading task examples for a nested few-shot bank; "
            "training questions then remain fixed when --shots changes"
        ),
    )
    p.add_argument(
        "--task-seed-from-run-seed",
        action="store_true",
        help=(
            "use each run seed for GSM8K demonstrations and training-question "
            "selection; default keeps the historical seed-0 task across runs"
        ),
    )
    p.add_argument(
        "--question-sampling",
        choices=["random", "epoch_shuffle"],
        default="random",
        help=(
            "sample training questions independently each round or consume "
            "reproducible shuffled epochs before repeating a question"
        ),
    )
    p.add_argument("--grad-checkpoint", action="store_true",
                   help="gradient checkpointing: saves VRAM, needed for 1.5B backward on the 16 GB box")
    for k in KNOBS:                                       # one flag per sweepable knob (hparams.py, the registry)
        p.add_argument(flag(k.key), type=k.cast, default=None, help=k.help)
    p.add_argument("--n-test", type=int, default=200, help="held-out benchmark size")
    p.add_argument("--train-partition", choices=["all", "train"], default="all",
                   help="GSM8K training pool: full official train split, or the fixed subset left "
                        "after reserving a training-derived validation set")
    p.add_argument("--eval-partition", choices=["all", "tune", "final", "validation", "test"],
                   default="all", help="GSM8K evaluation pool; validation is held out from train, "
                                        "test is the untouched official test split")
    p.add_argument("--dump-completions", type=int, default=0,
                   help="if >0, write the first N held-out completions per method to dump_*.json "
                        "(reuses the benchmark pass; eyeball real degradation vs a parse miss)")
    p.add_argument("--eval-every", type=int, default=0,
                   help="if >0, run the held-out benchmark every K rounds DURING training and log test_acc "
                        "into the trajectory (all trainers; extra generation cost, off by default)")
    p.add_argument("--eval-rounds", default="",
                   help="comma-separated completed rounds for sparse held-out checks; mutually exclusive "
                        "with --eval-every and always includes the final round")
    p.add_argument("--passk", type=int, default=0,
                   help="if >0, run pass@K on held-out GSM8K at the end of each cell (K sampled completions "
                        "at T=0.7 per question) -> passk_*.json + pass1/passK columns. The RLVR sharpening "
                        "check (pass@1 up while pass@k down = narrowed distribution); finalists only")
    p.add_argument("--passk-n", type=int, default=100,
                   help="held-out questions for the pass@K estimate (default 100; cost = K x this in generations)")
    p.add_argument("--save-adapter", action="store_true",
                   help="save each trained cell's LoRA adapter to adapter_<task>__<tag>__<method>_s<seed>/ "
                        "(~20-40MB each): any post-hoc analysis without re-training the cell")
    p.add_argument("--save-training-diagnostics", action="store_true",
                   help="write method-specific per-round samples, responsibilities, buffer composition, "
                        "and optimisation health to a gzip JSONL artifact (no extra model calls)")
    p.add_argument("--checkpoint-every", type=int, default=0,
                   help="save intermediate adapters every N completed rounds where supported; zero disables it")
    p.add_argument("--out", default="results", help="point at HOME on the cluster (scratch is wiped)")
    p.add_argument("--tag", default="run")
    p.add_argument("--run-id", default=None, help="run id linking these CSVs to the YAML that launched them")
    args = p.parse_args()
    try:
        args.eval_rounds = tuple(
            sorted({int(value) for value in args.eval_rounds.split(",") if value.strip()})
        )
    except ValueError as exc:
        p.error(f"--eval-rounds must be comma-separated positive integers: {exc}")
    if any(value < 1 for value in args.eval_rounds):
        p.error("--eval-rounds values must be positive")
    if args.eval_every and args.eval_rounds:
        p.error("--eval-every and --eval-rounds are mutually exclusive")
    blob = _params_blob(args)                             # one-cell snapshot of all algo params (row 0)
    qi_stamped = False                                    # train-question ids added to the blob once (below)

    out = os.path.expanduser(args.out)
    os.makedirs(out, exist_ok=True)
    path = os.path.join(out, f"sweep_{args.task}__{args.tag}.csv")
    rows, t0 = [], time.time()
    failures = []
    done = set()                                          # RESUMABILITY: skip cells already in the CSV
    if os.path.exists(path):                              # survives crashes + the 3-day session cutoff
        rows = pd.read_csv(path).to_dict("records")
        done = {(r["model"], r["method"], int(r["seed"])) for r in rows}
        print(f"resuming: {len(done)} cells already complete in {path}", flush=True)
    for model_name in args.models:
        # per-model artifact tag: traj/eval/dump/passk/adapter filenames carry no model of their own, so a
        # direct multi-model invocation would overwrite model A's JSONs with model B's (CSV rows are safe --
        # they carry a model column). Single-model runs (the run_yaml path) keep their unchanged names.
        mtag = args.tag if len(args.models) == 1 else f"{args.tag}_{model_name.replace('/', '-')}"
        for method in args.methods:
            for seed in range(args.seed0, args.seed0 + args.seeds):
                tag = f"{model_name} | {args.task} | {method} | seed {seed}"
                if (model_name, method, seed) in done:
                    print(f"== SKIP (done): {tag} ==", flush=True); continue
                print(f"== {tag} | {time.time()-t0:.0f}s ==", flush=True)
                cell_t0 = time.time()                               # wall-clock cost axis (per cell)
                if torch.cuda.is_available():
                    torch.cuda.reset_peak_memory_stats()            # per-cell peak VRAM (vram_gb column)
                model = tok = None
                diagnostics_fh = None
                checkpoint_eval_fh = None
                eval_usage = {"calls": 0, "generations": 0}
                try:                                                # one bad cell must not kill the grid
                    task = build_task(
                        args.task,
                        args.prompts,
                        args.shots,
                        seed,
                        args.train_partition,
                        shot_bank_size=args.shot_bank_size,
                        task_seed_from_run_seed=args.task_seed_from_run_seed,
                    )
                    if (
                        not args.task_seed_from_run_seed
                        and not qi_stamped
                        and hasattr(task, "train_qi")
                    ):
                        blob = json.dumps({**json.loads(blob), "train_qi": task.train_qi,
                                           "shot_qi": task.shot_qi})  # contamination/leakage audit;
                        qi_stamped = True
                    model, tok = load_model(seed=seed, model=model_name,
                                            lora_r=(
                                                args.lora_r
                                                if args.lora_r is not None
                                                else 16
                                            ),
                                            lora_alpha=(
                                                args.lora_alpha
                                                if args.lora_alpha is not None
                                                else 32
                                            ),
                                            lora_seed=args.lora_seed,
                                            gradient_checkpointing=args.grad_checkpoint)
                    over = {k: getattr(args, k) for k in _OVERRIDE_KEYS      # CLI hyperparameter overrides
                            if getattr(args, k) is not None}                # (filtered per-method by _accepts below)
                    if method == "base":                            # no-train baseline -> benchmark base model
                        recs = []
                    else:
                        kw = {k: v for k, v in over.items() if _accepts(METHODS[method], k)}
                        if _accepts(METHODS[method], "question_sampling"):
                            kw["question_sampling"] = args.question_sampling
                        eval_enabled = bool(args.eval_every or args.eval_rounds)
                        if eval_enabled and _accepts(METHODS[method], "eval_every"):
                            kw["eval_every"] = args.eval_every
                            if args.eval_rounds:
                                if not _accepts(METHODS[method], "eval_rounds"):
                                    raise ValueError(
                                        f"{method} does not support sparse --eval-rounds"
                                    )
                                kw["eval_rounds"] = args.eval_rounds
                            if args.save_training_diagnostics:
                                checkpoint_eval_path = os.path.join(
                                    out,
                                    f"checkpoint_eval_{args.task}__{mtag}__{method}_s{seed}.jsonl.gz",
                                )
                                checkpoint_eval_fh = gzip.open(
                                    checkpoint_eval_path, "wt", encoding="utf-8"
                                )

                            def eval_current(m, s=seed):
                                metrics, eval_records = benchmark(
                                    args.task, m, tok, args.n_test, args.shots, s,
                                    args.eval_partition, args.eval_batch,
                                    args.shot_bank_size)
                                eval_usage["calls"] += 1
                                eval_usage["generations"] += len(eval_records) if eval_records else args.n_test
                                if checkpoint_eval_fh is not None:
                                    compact = [
                                        {
                                            "idx": record.get("idx"),
                                            "correct": record.get("correct"),
                                            "pred": record.get("pred"),
                                            "gold": record.get("gold"),
                                            "len": record.get("len"),
                                            "rep4": record.get("rep4"),
                                        }
                                        for record in (eval_records or [])
                                    ]
                                    if args.eval_rounds:
                                        schedule = sorted({
                                            *(
                                                value
                                                for value in args.eval_rounds
                                                if value <= args.rounds
                                            ),
                                            args.rounds,
                                        })
                                        completed_rounds = schedule[eval_usage["calls"] - 1]
                                    else:
                                        completed_rounds = min(
                                            eval_usage["calls"] * args.eval_every,
                                            args.rounds,
                                        )
                                    json.dump({
                                        "run_id": args.run_id,
                                        "model": model_name,
                                        "task": args.task,
                                        "method": method,
                                        "seed": seed,
                                        "tag": mtag,
                                        "completed_rounds": completed_rounds,
                                        "metrics": metrics,
                                        "records": compact,
                                    }, checkpoint_eval_fh, separators=(",", ":"), default=str)
                                    checkpoint_eval_fh.write("\n")
                                    checkpoint_eval_fh.flush()
                                return metrics.get("test_acc", metrics.get("win_rate"))
                            kw["eval_fn"] = eval_current
                        if (args.save_training_diagnostics
                                and _accepts(METHODS[method], "diagnostics_fn")):
                            diagnostics_path = os.path.join(
                                out,
                                f"training_diagnostics_{args.task}__{mtag}__{method}_s{seed}.jsonl.gz",
                            )
                            diagnostics_fh = gzip.open(diagnostics_path, "wt", encoding="utf-8")

                            def write_diagnostics(payload, fh=diagnostics_fh):
                                artifact_record = {
                                    "run_id": args.run_id,
                                    "model": model_name,
                                    "task": args.task,
                                    "method": method,
                                    "seed": seed,
                                    "tag": mtag,
                                    **payload,
                                }
                                json.dump(artifact_record, fh, separators=(",", ":"), allow_nan=False)
                                fh.write("\n")
                                fh.flush()

                            kw["diagnostics_fn"] = write_diagnostics
                        if (args.checkpoint_every > 0
                                and _accepts(METHODS[method], "checkpoint_every")):
                            kw["checkpoint_every"] = args.checkpoint_every

                            def save_checkpoint(current_model, completed_rounds):
                                checkpoint_path = os.path.join(
                                    out,
                                    f"adapter_checkpoint_{args.task}__{mtag}__{method}_s{seed}"
                                    f"_r{completed_rounds:04d}",
                                )
                                try:
                                    current_model.save_pretrained(checkpoint_path)
                                except Exception as exc:
                                    print(
                                        f"   !! intermediate adapter save failed (training continues): {exc}",
                                        flush=True,
                                    )

                            kw["checkpoint_fn"] = save_checkpoint
                        recs = METHODS[method](task, rounds=args.rounds, B=args.batch, G=args.G, seed=seed,
                                               model_tok=(model, tok), log=_log, **kw)
                    for r in recs:
                        if "gen" in r:
                            r.setdefault("llm_gen", r["gen"])
                    bench, samples = benchmark(args.task, model, tok, args.n_test, args.shots, seed,
                                               args.eval_partition, args.eval_batch,
                                               args.shot_bank_size)
                    final_eval_gen = len(samples) if samples else args.n_test
                    passk_gen = 0
                    if args.passk > 0 and args.task == "gsm8k":      # end-of-cell pass@K (incl. base = the reference
                        pk, pk_recs = B.passk_gsm8k(model, tok, n_test=args.passk_n,   # distribution): sharpening check
                                                    k=args.passk, n_shots=args.shots, seed=seed,
                                                    batch=args.eval_batch,
                                                    eval_partition=args.eval_partition,
                                                    shot_bank_size=(args.shot_bank_size or None))
                        bench = {**bench, **pk}                      # pass1 / passK -> CSV columns
                        passk_gen = len(pk_recs) * args.passk
                        with open(os.path.join(out, f"passk_{args.task}__{mtag}__{method}_s{seed}.json"),
                                  "w") as fh:
                            json.dump(dict(run_id=args.run_id, model=model_name, method=method, seed=seed,
                                           **pk, records=pk_recs), fh, default=str)
                    if args.save_adapter and method != "base":      # ~20-40MB LoRA adapter per cell: enables ANY
                        try:                                        # post-hoc metric without re-training
                            model.save_pretrained(os.path.join(
                                out, f"adapter_{args.task}__{mtag}__{method}_s{seed}"))
                        except Exception as e:                      # never fail a finished cell over a save
                            print(f"   !! adapter save failed (cell kept): {e}", flush=True)
                    final = recs[-1] if recs else {}
                    train_llm_gen = int(final.get("llm_gen", final.get("gen", 0)) or 0)
                    eval_llm_gen = int(eval_usage["generations"] + final_eval_gen + passk_gen)
                    total_llm_gen = train_llm_gen + eval_llm_gen
                    verifier_calls = int(final.get("verifier_calls", final.get("oracle", 0)) or 0)
                    oracle_gen = int(final.get("oracle_gen", 0) or 0)
                    if recs:                                        # per-round trajectory (ess/kl/div/...) for diagnosis
                        with open(os.path.join(out, f"traj_{args.task}__{mtag}__{method}_s{seed}.json"),
                                  "w") as fh:
                            json.dump(recs, fh, default=float)
                    if samples:                                     # per-QUESTION held-out results (EVERY item) ->
                        compact = [dict(idx=s.get("idx"), correct=s.get("correct"),   # stratify by difficulty, align
                                        pred=s.get("pred"), gold=s.get("gold"),       # methods by (idx,seed)
                                        len=s.get("len"), rep4=s.get("rep4")) for s in samples]  # length/degeneration
                                                                                      # at full n_test scale
                        with open(os.path.join(out, f"eval_{args.task}__{mtag}__{method}_s{seed}.json"),
                                  "w") as fh:
                            json.dump(dict(run_id=args.run_id, model=model_name, method=method, seed=seed,
                                           **bench, records=compact), fh, default=str)
                    if samples and args.dump_completions > 0:        # first N held-out generations IN FULL to eyeball
                        with open(os.path.join(out, f"dump_{args.task}__{mtag}__{method}_s{seed}.json"),
                                  "w") as fh:
                            json.dump(dict(run_id=args.run_id, method=method, seed=seed, **bench,
                                           samples=samples[:args.dump_completions]), fh, indent=2, default=str)
                    rows.append(dict(run_id=args.run_id, model=model_name, task=args.task,
                                     train_partition=args.train_partition,
                                     eval_partition=args.eval_partition,
                                     task_seed=(
                                         seed if args.task_seed_from_run_seed else 0
                                     ),
                                     shot_qi=(
                                         json.dumps(task.shot_qi)
                                         if hasattr(task, "shot_qi")
                                         else None
                                     ),
                                     train_qi=(
                                         json.dumps(task.train_qi)
                                         if hasattr(task, "train_qi")
                                         else None
                                     ),
                                     method=method, seed=seed,
                                     train_reward=final.get("mean_reward"),
                                     frac_correct=final.get("frac_correct"),  # base rate / signal at last round
                                     kl=final.get("kl"),              # final drift from base (degrade vs inert)
                                     oracle=final.get("oracle"),      # reward-oracle calls (AC-EM=0; the cost axis)
                                     verifier_calls=verifier_calls,
                                     diagnostic_verifier_calls=final.get("diagnostic_verifier_calls"),
                                     oracle_gen=oracle_gen,
                                     gen=final.get("gen"),            # completions generated (compute proxy)
                                     generated_tokens=final.get("generated_tokens"),
                                     backward_tokens=final.get("backward_tokens"),
                                     question_exposures=final.get("question_exposures"),
                                     unique_questions_seen=final.get("unique_questions_seen"),
                                     train_llm_gen=train_llm_gen,
                                     eval_llm_gen=eval_llm_gen,
                                     llm_gen=total_llm_gen,
                                     gsteps=final.get("gsteps"),      # gradient steps taken
                                     buffer_evictions=final.get("buffer_evictions"),
                                     cost=final.get("oracle"),        # back-compat alias = oracle calls
                                     gen_len=final.get("gen_len"),    # mean completion length (degeneration)
                                     ess=final.get("ess"),            # EM weight ESS (collapse); NaN for non-EM
                                     fmt=final.get("fmt"),            # last-round '####' format rate (train-time)
                                     samp_lp=final.get("samp_lp"),    # policy-entropy proxy at the last round
                                     gold_lp=final.get("gold_lp"),    # gold-CoT likelihood at the last round
                                     loss=final.get("loss"),
                                     secs=round(time.time() - cell_t0, 1),  # wall-clock compute (gen+train+bench)
                                     vram_gb=(round(torch.cuda.max_memory_allocated() / 2**30, 2)
                                              if torch.cuda.is_available() else None),  # peak VRAM this cell
                                     **bench))
                    rows[0]["params"] = blob                        # all algo params live in ONE cell (row 0)
                    pd.DataFrame(rows).to_csv(path, index=False)    # checkpoint after every cell
                    print(f"   -> {bench} | {tag}", flush=True)
                except Exception:                                   # log + skip; resume retries it later
                    import traceback
                    print(f"!! FAILED (skipping; will retry on resume): {tag}", flush=True)
                    traceback.print_exc()
                    failures.append(tag)
                finally:
                    if diagnostics_fh is not None:
                        diagnostics_fh.close()
                    if checkpoint_eval_fh is not None:
                        checkpoint_eval_fh.close()
                    del model, tok
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
    print(f"done in {time.time()-t0:.0f}s -> {path}")
    if failures:
        print(f"FAILED: {len(failures)} cell(s): {', '.join(failures)}", flush=True)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
