"""Held-out benchmarks (the 'benchmark it' step of the experiment loop).

Method-agnostic: given a fine-tuned (model, tok), score it on a HELD-OUT set, separate from the
prompts any method trained on. This is the number we report and compare across PO / RL / EM.

  benchmark_gsm8k  -> test-split accuracy (few-shot CoT, greedy decode, exact-match)
  benchmark_imdb   -> win-rate vs the frozen base model, judged by a sentiment classifier

Greedy decode for determinism; uses the device-agnostic DEV from methods_lm.
"""
from __future__ import annotations

import numpy as np
import torch

from methods_lm import DEV


@torch.no_grad()
def _generate(model, tok, prompts, max_new=256, batch=16, temperature=0.0):
    """Continuation for a list of prompts (left-padded). Greedy by default (deterministic scoring);
    temperature>0 samples instead (used only by pass@k). Returns completion strings."""
    model.eval()
    tok.padding_side = "left"
    sample_kw = ({"do_sample": True, "temperature": temperature, "top_k": 0, "top_p": 1.0}
                 if temperature and temperature > 0 else {"do_sample": False})
    outs = []
    for i in range(0, len(prompts), batch):
        chunk = prompts[i:i + batch]
        enc = tok(chunk, return_tensors="pt", padding=True).to(DEV)
        gen = model.generate(**enc, max_new_tokens=max_new,
                             pad_token_id=tok.eos_token_id, **sample_kw)
        outs += tok.batch_decode(gen[:, enc.input_ids.shape[1]:], skip_special_tokens=True)
    return outs


def _rep4(text):
    """Fraction of REPEATED 4-grams (whitespace words) in a completion -- the degeneration/looping
    metric, computable on every compact eval_* record (the full text is only kept for the N dumps)."""
    ws = text.split()
    if len(ws) < 8:
        return 0.0
    grams = [tuple(ws[i:i + 4]) for i in range(len(ws) - 3)]
    return round(1.0 - len(set(grams)) / len(grams), 4)


# --------------------------------------------------------------------------- #
#  GSM8K: held-out test-split accuracy
# --------------------------------------------------------------------------- #
# ONE answer parser for train reward and eval scoring. benchmark.py used to carry its own copy and
# the two drifted: tasks._final_int tolerates degenerate markers ('#### ,' -> None) where the old
# copy raised ValueError, killing the whole benchmark pass after the cell had already trained.
from tasks import (  # noqa: E402
    GSM8K_DATASET_REVISION,
    _final_int,
    _gsm8k_gold,
    _gsm8k_train_validation_pools,
)


_GSM8K_PARTITION_SEED = 20260709
_GSM8K_TUNE_MAX = 400


def _gsm8k_eval_pool(n_items, eval_partition="all"):
    """Fixed disjoint pools for hyperparameter tuning and final reporting."""
    if eval_partition == "all":
        return np.arange(n_items, dtype=int)
    if eval_partition not in ("tune", "final"):
        raise ValueError(f"unknown GSM8K eval partition {eval_partition!r}")
    order = np.random.default_rng(_GSM8K_PARTITION_SEED).permutation(n_items)
    cut = min(_GSM8K_TUNE_MAX, max(1, n_items // 3))
    return order[:cut] if eval_partition == "tune" else order[cut:]


def _gsm8k_heldout(
    n_test,
    n_shots,
    seed,
    eval_partition="all",
    shot_bank_size=None,
):
    """Build aligned greedy/pass@k data under either legacy or train/validation/test protocols."""
    from datasets import load_dataset
    train = load_dataset(
        "openai/gsm8k",
        "main",
        split="train",
        revision=GSM8K_DATASET_REVISION,
    )
    test = load_dataset(
        "openai/gsm8k",
        "main",
        split="test",
        revision=GSM8K_DATASET_REVISION,
    )
    rng = np.random.default_rng(seed)
    if shot_bank_size is None:
        shot_bank_size = n_shots
    shot_bank_size = int(shot_bank_size)
    if shot_bank_size < n_shots:
        raise ValueError(
            f"shot_bank_size must be at least n_shots, got {shot_bank_size} < {n_shots}"
        )
    if eval_partition in ("validation", "test"):
        train_pool, validation_pool = _gsm8k_train_validation_pools(len(train))
        shot_bank = rng.permutation(train_pool)[:shot_bank_size]
        if eval_partition == "validation":
            eval_split = train
            pool = validation_pool
        else:
            eval_split = test
            pool = np.arange(len(test), dtype=int)
    else:
        shot_bank = rng.permutation(len(train))[:shot_bank_size]
        eval_split = test
        pool = _gsm8k_eval_pool(len(test), eval_partition)
    shot_idx = shot_bank[:n_shots]
    shots = "".join(f"Question: {train[int(i)]['question']}\nAnswer: {train[int(i)]['answer']}\n\n"
                    for i in shot_idx)
    if n_test > len(pool):
        raise ValueError(f"n_test={n_test} exceeds GSM8K {eval_partition} pool size {len(pool)}")
    idx = rng.permutation(pool)[:n_test]
    prompts = [shots + f"Question: {eval_split[int(i)]['question']}\nAnswer:" for i in idx]
    gold_answer = [_gsm8k_gold(eval_split[int(i)]["answer"]) for i in idx]
    return idx, prompts, gold_answer, eval_split


def benchmark_gsm8k(
    model,
    tok,
    n_test=200,
    n_shots=4,
    seed=0,
    max_new=256,
    batch=16,
    return_records=False,
    eval_partition="all",
    shot_bank_size=None,
):
    """Accuracy on held-out GSM8K validation or test questions.

    return_records=True also returns per-example dicts (question/completion/gold/pred/correct) from the
    SAME greedy pass that produced the score -- used by --dump-completions to eyeball whether a low
    number is genuine degradation (garbage/short reasoning) or just a parse miss."""
    idx, prompts, gold_answer, eval_split = _gsm8k_heldout(
        n_test,
        n_shots,
        seed,
        eval_partition=eval_partition,
        shot_bank_size=shot_bank_size,
    )
    comps = _generate(model, tok, prompts, max_new=max_new, batch=batch)
    preds = [_final_int(c) for c in comps]
    correct = [p == g for p, g in zip(preds, gold_answer)]
    acc = float(np.mean(correct))
    if not return_records:
        return acc
    recs = [dict(idx=int(i), question=eval_split[int(i)]["question"], completion=c, gold=g, pred=p, correct=bool(ok),
                 len=len(tok(c, add_special_tokens=False).input_ids),   # completion tokens: held-out length-vs-correctness
                 rep4=_rep4(c))                                         # repeated-4-gram rate: held-out degeneration
            for i, c, g, p, ok in zip(idx, comps, gold_answer, preds, correct)]
    return acc, recs


def passk_gsm8k(
    model,
    tok,
    n_test=100,
    k=8,
    n_shots=4,
    seed=0,
    temp=0.7,
    max_new=256,
    batch=16,
    eval_partition="all",
    shot_bank_size=None,
):
    """pass@k on held-out GSM8K: k sampled completions (temperature `temp`) per question. Returns
    (summary, records); records = per-question {idx, gold, n_correct, k}. The RLVR sharpening check:
    pass@1 rising while pass@k falls = the method narrowed the distribution rather than adding ability.
    Question idx values are the SAME split/permutation as benchmark_gsm8k(seed) -> records align."""
    idx, prompts, gold_answer, _ = _gsm8k_heldout(
        n_test,
        n_shots,
        seed,
        eval_partition=eval_partition,
        shot_bank_size=shot_bank_size,
    )
    n_correct = np.zeros(len(idx), dtype=int)
    for _ in range(k):                                     # k independent sampled passes
        comps = _generate(model, tok, prompts, max_new=max_new, batch=batch, temperature=temp)
        n_correct += np.array([_final_int(c) == g for c, g in zip(comps, gold_answer)], dtype=int)
    summary = {"pass1": float((n_correct / k).mean()),     # unbiased pass@1 under sampling
               f"pass{k}": float((n_correct > 0).mean())}  # pass@k (any of the k correct)
    records = [dict(idx=int(i), gold=g, n_correct=int(c), k=k) for i, g, c in zip(idx, gold_answer, n_correct)]
    return summary, records


# --------------------------------------------------------------------------- #
#  IMDB sentiment: win-rate vs the frozen base, classifier-judged
# --------------------------------------------------------------------------- #
_SENTIMENT = {}


def _sentiment_scores(texts, model_name="lvwerra/distilbert-imdb", batch=32):
    """P(positive) per text from a frozen sentiment classifier (cached)."""
    from transformers import AutoModelForSequenceClassification, AutoTokenizer
    if model_name not in _SENTIMENT:
        clf = AutoModelForSequenceClassification.from_pretrained(model_name).to(DEV).eval()
        ctok = AutoTokenizer.from_pretrained(model_name)
        _SENTIMENT[model_name] = (clf, ctok)
    clf, ctok = _SENTIMENT[model_name]
    out = []
    with torch.no_grad():
        for i in range(0, len(texts), batch):
            enc = ctok(texts[i:i + batch], return_tensors="pt", padding=True,
                       truncation=True, max_length=256).to(DEV)
            p = torch.softmax(clf(**enc).logits, -1)[:, 1]          # label 1 = positive
            out += p.cpu().tolist()
    return np.array(out)


def benchmark_imdb(model, tok, prompts, max_new=64, batch=16):
    """Win-rate vs frozen base: fraction of held-out prompts where the fine-tuned policy's
    completion is judged more positive than the base model's (same greedy decode)."""
    fine = _generate(model, tok, prompts, max_new=max_new, batch=batch)
    with model.disable_adapter():
        base = _generate(model, tok, prompts, max_new=max_new, batch=batch)
    s_fine = _sentiment_scores([p + c for p, c in zip(prompts, fine)])
    s_base = _sentiment_scores([p + c for p, c in zip(prompts, base)])
    return float(np.mean(s_fine > s_base)), float(s_fine.mean())
