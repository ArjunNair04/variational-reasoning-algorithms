"""RAFT -- iterative best-of-n / rejection-sampling SFT (Dong et al. 2023; ref RLHFlow/RAFT). β→∞ EM.

Per-prompt (LOCAL ranking, as the paper recommends for prompt-dependent rewards = GSM8K): accept only
completions ABOVE the round-mean reward (the rejection step -- without it, all-wrong prompts force SFT
on wrong CoT and the model collapses), keep each prompt's top-kp accepted, SFT on them; skip if none.
"""
from __future__ import annotations
import numpy as np
import torch

from common import (MODEL_NAME, load_model, seq_logprobs, kl_from_base, _rounds, sample_round,
                    comp_len, frac_correct, format_rate, mean_token_lp, build_gold_batch, gold_lp, maybe_eval)


def run_raft(task, rounds=40, B=64, G=4, seed=0, lr=1e-4, top_frac=0.25, epochs=1,
                model_name=MODEL_NAME, model_tok=None, micro=4, eval_every=0, eval_fn=None, log=print):
    model, tok = (model_tok if model_tok is not None else load_model(seed=seed, model=model_name))
    opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=lr)
    rng = np.random.default_rng(seed); recs, oracle, gen, gsteps = [], 0, 0, 0   # oracle == gen (all scored)
    gbatch = build_gold_batch(tok, task)                  # gold-CoT batch for the gold_lp diagnostic
    kp = max(1, int(top_frac * G))                        # per-prompt accepts (best-of-n)
    for t in _rounds(rounds):
        pids, pid_row, ids, mask, rew, texts = sample_round(model, tok, task, B, G, rng); oracle += B; gen += B
        fmt = format_rate(texts)                          # parseable-'####' rate (format vs math when acc drops)
        slp = mean_token_lp(model, ids, mask)             # policy-entropy proxy at θ_old on its OWN samples
        thresh = rew.mean()                               # rejection bar (above-mean = correct for binary r)
        sel = []
        for p in pids:
            idx = np.where(pid_row == p)[0]
            good = idx[rew[idx] > thresh]
            if len(good):
                sel.extend(good[np.argsort(rew[good])[-kp:]])   # this prompt's top-kp among accepted
        diag = dict(fmt=fmt, samp_lp=slp)                 # shared diagnostics for both branches below
        if not sel:                                       # nothing cleared the bar -> skip (no garbage SFT)
            tacc = maybe_eval(model, t, rounds, eval_every, eval_fn)
            recs.append(dict(round=t, oracle=oracle, gen=gen, gsteps=gsteps, mean_reward=float(rew.mean()),
                             frac_correct=frac_correct(rew), gen_len=comp_len(mask), n_accept=0,
                             gold_lp=gold_lp(model, gbatch), test_acc=tacc, **diag,
                             loss=float("nan"), kl=kl_from_base(model, ids, mask)))
            log(f"  [RAFT r{t:>3}] gen={gen:>6} R={rew.mean():.3f} accept=0 skip"); continue
        sel = np.array(sel, dtype=int)
        s_ids, s_mask = ids[sel.copy()], mask[sel.copy()]
        k = len(sel)
        model.train()
        rloss = 0.0
        for _ in range(epochs):                           # micro = memory only: accumulate, ONE SFT step
            opt.zero_grad()
            for i in range(0, k, micro):
                lp = seq_logprobs(model, s_ids[i:i + micro], s_mask[i:i + micro], grad=True, length_norm=True)
                loss = -lp.sum() / k                       # max Σ log π_θ(o|q) over the accepted set
                loss.backward(); rloss += float(loss)
            opt.step(); gsteps += 1
        kl = kl_from_base(model, ids, mask)
        glp = gold_lp(model, gbatch)                      # gold-CoT likelihood after this round's SFT step(s)
        tacc = maybe_eval(model, t, rounds, eval_every, eval_fn)   # opt-in held-out trajectory
        recs.append(dict(round=t, oracle=oracle, gen=gen, gsteps=gsteps, mean_reward=float(rew.mean()),
                         frac_correct=frac_correct(rew), gen_len=comp_len(mask), n_accept=k,
                         gold_lp=glp, test_acc=tacc, **diag,
                         loss=rloss / max(epochs, 1), kl=kl))
        log(f"  [RAFT r{t:>3}] gen={gen:>6} R={rew.mean():.3f} accept={k} len={comp_len(mask):.0f} kl={kl:+.3f}")
    return recs
