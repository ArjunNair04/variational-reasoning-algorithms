"""Run a sweep / finalist from a YAML config instead of long CLI arg lists.

Only the algos listed under `algos:` in the YAML are run. Runtime allocation fields
(`rounds`, `batch`, and `G`) and any registered hyperparameter may be a SCALAR
(one cell) or a LIST (sweep that axis -> Cartesian product), and is applied only where the trainer
accepts it: lr (all); epochs (GRPO/RLOO/DPO/RAFT update passes); iters (AC-EM M-step grad iterations);
beta (AC-AW/AAW, DPO, APL); anchor / causal / pi_temp / sup (AC-EM); clip / kl_coef
(GRPO, RLOO); top_frac (RAFT); pool_mult (APL); window (conditional VRO / legacy weighted-EM);
buffer_strategy, proposal_prompt, proposal_filter, proposal_policy,
responsibility_score (conditional VRO / AC-ALG1), responsibility_temperature,
responsibility_ess_floor, responsibility_policy, responsibility_refresh,
labelled_em_weight, answer_only_em_weight, labelled_proposal_prompt, answer_only_proposal_prompt,
labelled_numeric_constraint (including graph_hard), numeric_penalty, labelled_supervision,
compact_gold_weight, policy_kl_coef, supervised_weight, policy_anchor_mode,
policy_anchor_target_ratio, policy_anchor_beta_min, policy_anchor_beta_max, policy_anchor_ema,
update_geometry, step_acceptance, rollback_tolerance, rollback_max_backtracks,
rollback_shrink, and optimizer_state_scope
(AC-ALG1).
Remaining categorical/boolean knobs (weight, hindsight, length_norm,
offline, acq) are varied via named method variants instead.
Every cell becomes ONE invocation of run_sweep_lm.py with a unique --tag, so you keep
one-CSV-per-cell, resumability, the row-0 params blob, and the per-round trajectory JSONs.

    python run_yaml.py experiments.yaml
    python run_yaml.py experiments.yaml --gpus 2                       # split cells across 2 GPUs
    python run_yaml.py experiments.yaml --only AW-EM GRPO base   # subset of listed algos
    python run_yaml.py experiments.yaml --dry-run                      # list cells, run nothing

Multi-GPU: --gpus N fans out one pinned worker per card (CUDA_VISIBLE_DEVICES), each running a disjoint
slice of the cells (~Nx throughput, no DDP). --workers-per-gpu W runs W cells concurrently per card
(N*W workers total, round-robin onto the cards) to fill big-VRAM cards. A pre-set CUDA_VISIBLE_DEVICES
list is honoured. Per-shard logs go to <out>/run_shard<k>.log.

YAML schema (see experiments.yaml):
    tag_prefix: final60
    defaults: { task, model|models, rounds, seeds, seed_values, n_test, train_partition, eval_partition,
                batch, eval_batch, G, prompts, shots, grad_checkpoint, out,
                dump_completions, eval_every|eval_rounds, save_adapter,
                save_training_diagnostics, checkpoint_every,
                passk, passk_n }   # seed_values is optional; non-contiguous lists use --seed INDEX
    algos:
      base: {}
      AW-EM: { lr: 2.0e-4, epochs: 16 }
      GRPO:  { lr: [2.0e-5, 5.0e-5, 1.0e-4] }   # list -> 3 cells
      AC-CW: { lr: 1.0e-4, epochs: 8, causal: [0.5, 1, 2] }   # sweep the causal strength gamma
      # A list variant may set cell_id: concise_name to keep artifact names short.
    per_model: { gemma-2-2b-it: { GRPO: { lr: 1.0e-5 } } }   # optional per-(model,method) axis override

`models:` (a list) sweeps the base model as an extra axis -- each cell runs one model and the model goes
in its tag/CSV name (see experiments_secondary.yaml). `per_model:` overrides algos for a given model.

Idempotent: a cell whose CSV already exists is skipped, so you can scp + re-run / resume freely.
Prints sweep-level progress + ETA after every cell (same accounting as sweep.sh).
"""
from __future__ import annotations
import argparse
import itertools
import os
import re
import secrets
import subprocess
import sys
import time

import yaml

from hparams import KNOBS, flag


def _as_list(v):
    """A scalar config value means one cell; a list means sweep that axis."""
    if v is None:
        return [None]
    return v if isinstance(v, (list, tuple)) else [v]


def _fmt(s):
    return f"{s // 3600:d}h{(s % 3600) // 60:02d}m"


def _done_rows(csv):
    """Completed (model, method, seed) rows already in a cell's CSV; 0 if absent/unreadable.
    run_sweep_lm checkpoints the CSV after EVERY seed, so an interrupted multi-seed cell leaves a
    partial file -- existence alone must not mean done (the finalist runs 5 seeds/cell), else the
    remaining seeds are silently never run and the seed-mean quietly averages fewer seeds."""
    if not os.path.exists(csv):
        return 0
    try:
        import pandas as pd
        return len(pd.read_csv(csv))
    except Exception:
        return 0                                            # unreadable/empty -> rerun (resume no-ops per seed)


def _seed_selection(configured_seeds, requested_seed=None, seed_values=None):
    """Return ``(actual_seed0, count, tag_suffix)`` for a seed task.

    ``requested_seed`` remains an index into the configured seed family.  With
    no explicit ``seed_values`` this preserves the historical 0..N-1
    behaviour.  An explicit non-contiguous seed family is intentionally
    accepted only one array task at a time, because ``run_sweep_lm`` represents
    multi-seed execution as a contiguous ``seed0`` range.
    """
    configured_seeds = int(configured_seeds)
    if configured_seeds < 1:
        raise ValueError(f"configured seeds must be positive, got {configured_seeds}")
    if seed_values is not None:
        if not isinstance(seed_values, (list, tuple)):
            raise ValueError("defaults.seed_values must be a list of integers")
        try:
            seed_values = tuple(int(value) for value in seed_values)
        except (TypeError, ValueError) as exc:
            raise ValueError("defaults.seed_values must contain integers") from exc
        if len(seed_values) != configured_seeds:
            raise ValueError(
                "defaults.seeds must equal len(defaults.seed_values)"
            )
        if any(value < 0 for value in seed_values):
            raise ValueError("defaults.seed_values must be nonnegative")
        if len(set(seed_values)) != len(seed_values):
            raise ValueError("defaults.seed_values must be unique")
        if requested_seed is None:
            raise ValueError(
                "defaults.seed_values require --seed INDEX (one array task per seed)"
            )
    if requested_seed is None:
        return 0, configured_seeds, ""
    requested_seed = int(requested_seed)
    if not 0 <= requested_seed < configured_seeds:
        raise ValueError(
            f"requested seed {requested_seed} is outside configured range "
            f"0..{configured_seeds - 1}"
        )
    actual_seed = (
        seed_values[requested_seed]
        if seed_values is not None
        else requested_seed
    )
    return actual_seed, 1, f"_seed{actual_seed}"


def get_run_id(path, new_run=False):
    """Read the YAML's run_id, or generate one and WRITE it back (comment-preserving text edit, NOT a
    yaml re-dump). The id is reused on re-runs so the resumable sweep finds its CSVs; `new_run` forces
    a fresh one. It is stamped into every CSV name + row, linking outputs back to this config."""
    with open(path) as fh:
        text = fh.read()
    m = re.search(r"(?m)^run_id:\s*(\S+)\s*$", text)
    if m and not new_run:
        return m.group(1)
    rid = secrets.token_hex(4)                              # 8 hex chars, e.g. 'a1b2c3d4'
    if m:
        text = re.sub(r"(?m)^run_id:.*$", f"run_id: {rid}", text)   # replace (new_run)
    else:                                                  # insert before the first top-level key
        lines = text.splitlines(keepends=True)
        idx = next((i for i, ln in enumerate(lines)
                    if ln.strip() and not ln.startswith(("#", " ")) and ":" in ln), 0)
        lines.insert(idx, f"run_id: {rid}\n")
        text = "".join(lines)
    with open(path, "w") as fh:
        fh.write(text)
    return rid


# Per-algo sweepable axes: YAML key -> (run_sweep_lm flag, tag abbrev, caster), derived from the ONE
# knob registry (hparams.py -- registry order = tag order, so never reorder there). Scalar = 1 cell,
# list = sweep that axis; the Cartesian product over all set axes becomes one cell each (own CSV).
# Each axis is forwarded only to methods whose trainer accepts it (run_sweep_lm._accepts).
_AXES = [(k.key, flag(k.key), k.abbr, k.cast) for k in KNOBS]
_RUN_AXES = (
    ("rounds", "--rounds", "r", int),
    ("batch", "--batch", "B", int),
    ("G", "--G", "G", int),
)
_CELL_AXES = _RUN_AXES + tuple(_AXES)


def _axis_cli_args(axes):
    """Build argv tokens for configured axes without adding shell quotes to categorical values."""
    args = []
    for key, cli_flag, _abbr, _cast in _CELL_AXES:
        if key not in axes:
            continue
        value = axes[key]
        args += [cli_flag, value if isinstance(value, str) else repr(value)]
    return args


def _slug(s):
    """Filesystem-safe model token for the tag (raw HF ids contain '/')."""
    return str(s).replace("/", "-")


def _axis_tag_value(v):
    """Compact, filesystem-safe tag fragment for numeric or categorical axes."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return f"{v:g}"
    return _slug(v)


def _models(cfg):
    """The model axis: `models:` (a list) sweeps the base model as an extra dimension; a scalar
    `model:` (back-compat) is the single-model case. Defaults to the Qwen flagship."""
    d = cfg.get("defaults") or {}
    ms = d.get("models") or [d.get("model", "qwen2.5-1.5b-instruct")]
    return list(ms) if isinstance(ms, (list, tuple)) else [ms]


def _cells(cfg, only, run_id):
    """Expand the YAML `algos` map (x the model axis) into a flat list of cells (model, method, axes, tag).
    ANY numeric hyperparameter may be a scalar (1 cell) or a list (sweep). `per_model: {model: {method:
    {axis: val}}}` overrides algos for that (model, method) -- e.g. a secondary model whose screened
    optimum differs. The model appears in the tag/CSV name only when >1 is swept (single-model tags unchanged)."""
    prefix = f"{cfg.get('tag_prefix', 'exp')}_{run_id}"    # run_id in the tag -> in every CSV/traj name
    algos = cfg.get("algos") or {}
    per_model = cfg.get("per_model") or {}
    models = _models(cfg)
    multi = len(models) > 1
    cells = []
    for model in models:
        ov = per_model.get(model) or {}
        for method, method_spec in algos.items():
            if only and method not in only:
                continue
            variants = method_spec if isinstance(method_spec, list) else [method_spec or {}]
            override = ov.get(method) or {}
            if not isinstance(override, dict):
                raise ValueError(f"per_model override for {model}/{method} must be a mapping")
            for variant in variants:
                if not isinstance(variant, dict):
                    raise ValueError(f"each grid variant for {method} must be a mapping")
                spec = {**variant, **override}               # per-model override wins over each shared variant
                cell_id = spec.pop("cell_id", None)
                if cell_id is not None:
                    cell_id = str(cell_id)
                    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", cell_id):
                        raise ValueError(
                            "cell_id must be 1-64 filesystem-safe characters "
                            "starting with a letter or digit"
                        )
                unknown = set(spec) - {key for key, *_ in _CELL_AXES}
                if unknown:
                    raise ValueError(
                        f"unknown cell field(s) for {method}: {sorted(unknown)}"
                    )
                grids = [_as_list(spec.get(key)) for key, *_ in _CELL_AXES]
                for combo in itertools.product(*grids):
                    axes = {}
                    tag = prefix + (f"_{_slug(model)}" if multi else "") + f"_{method}"
                    if cell_id is not None:
                        tag += f"_{cell_id}"
                    for (key, _flag, abbr, cast), v in zip(_CELL_AXES, combo):
                        if v is None:
                            continue
                        v = cast(v)                          # PyYAML may hand back "2e-4" as a str
                        axes[key] = v
                        if cell_id is None:
                            tag += f"_{abbr}{_axis_tag_value(v)}"
                    cells.append((model, method, axes, tag))
    tags = [tag for *_rest, tag in cells]
    if len(tags) != len(set(tags)):
        raise ValueError("grid expansion produced duplicate cell tags")
    return cells


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config", help="path to the YAML experiment config")
    ap.add_argument("--only", nargs="+", default=None, help="run only these listed algos")
    ap.add_argument("--dry-run", action="store_true", help="print the cells and exit")
    ap.add_argument("--new-run", action="store_true",
                    help="force a fresh run_id (else reuse the YAML's, so the sweep resumes)")
    ap.add_argument("--gpus", type=int, default=1,
                    help="split cells across N GPUs (one sharded worker per card)")
    ap.add_argument("--workers-per-gpu", type=int, default=1,
                    help="run W cells concurrently per GPU (oversubscribe big-VRAM cards for more throughput)")
    ap.add_argument("--seed", type=int, default=None,
                    help="run one configured seed with a collision-free tag (for SGE seed arrays)")
    ap.add_argument("--shard", type=int, default=0, help=argparse.SUPPRESS)    # internal: this worker's index
    ap.add_argument("--nshard", type=int, default=1, help=argparse.SUPPRESS)   # internal: total worker count
    args = ap.parse_args()

    path = os.path.expanduser(args.config)
    with open(path) as fh:
        cfg = yaml.safe_load(fh)
    run_id = get_run_id(path, new_run=args.new_run)        # persisted FIRST, so every worker reuses the same id
    d = cfg.get("defaults") or {}
    task = d.get("task", "gsm8k")
    out = os.path.expanduser(d.get("out", "~/po_results"))
    seed_values = d.get("seed_values")
    configured_seeds = d.get(
        "seeds",
        len(seed_values) if isinstance(seed_values, (list, tuple)) else 1,
    )
    seed0, n_seeds, seed_suffix = _seed_selection(
        configured_seeds,
        args.seed,
        seed_values=seed_values,
    )
    if not args.dry_run:
        os.makedirs(out, exist_ok=True)

    # ---- multi-GPU fan-out (parent only): WORKERS_PER_GPU workers per card, disjoint slice of cells ----
    if args.nshard == 1 and not args.dry_run:              # nshard>1 => already a spawned worker
        cvd = os.environ.get("CUDA_VISIBLE_DEVICES")
        gpu_list = cvd.split(",") if cvd else [str(i) for i in range(args.gpus)]
        n = len(gpu_list) * args.workers_per_gpu           # total workers (round-robin onto the cards)
        if n > 1:
            print(f"=== {n}-worker run ({args.workers_per_gpu}/GPU x {len(gpu_list)} GPUs; "
                  f"progress: tail -f {out}/run_shard*.log) ===", flush=True)
            procs = []
            for k in range(n):
                dev = gpu_list[k % len(gpu_list)]
                env = {**os.environ, "CUDA_VISIBLE_DEVICES": dev}
                cmd = [sys.executable, os.path.abspath(__file__), args.config,
                       "--gpus", "1", "--workers-per-gpu", "1", "--shard", str(k), "--nshard", str(n)]
                if args.only:
                    cmd += ["--only", *args.only]
                if args.seed is not None:
                    cmd += ["--seed", str(args.seed)]
                fh = open(os.path.join(out, f"run_shard{k}.log"), "w")
                procs.append(subprocess.Popen(cmd, env=env, stdout=fh, stderr=subprocess.STDOUT))
                print(f"  shard {k}/{n} -> physical GPU {dev} (pid {procs[-1].pid})", flush=True)
            rc = 0
            for p in procs:
                rc |= p.wait()
            print(f"=== all {n} shards finished (rc={rc}) ===")
            sys.exit(rc)

    cells = _cells(cfg, set(args.only) if args.only else None, run_id)
    if seed_suffix:
        cells = [(model, method, axes, tag + seed_suffix)
                 for model, method, axes, tag in cells]
    if args.nshard > 1:                                    # worker: keep only this shard's 1/N slice
        cells = [c for i, c in enumerate(cells) if i % args.nshard == args.shard]
    if not cells:
        print("no cells to run (check `algos:` / --only)"); return

    seed_label = f"seed={seed0}" if args.seed is not None else f"seeds={n_seeds}"
    print(f"=== run_id={run_id} | {len(cells)} cells | {len(_models(cfg))} model(s) | task={task} "
          f"rounds={d.get('rounds')} {seed_label} ===")
    for model, method, axes, tag in cells:
        print(f"  {tag:48s}  model={model} method={method} " + " ".join(f"{k}={v}" for k, v in axes.items()))
    if args.dry_run:
        return

    sweep0 = time.time()
    run = runt = 0
    failures = []
    for i, (model, method, axes, tag) in enumerate(cells, 1):
        csv = os.path.join(out, f"sweep_{task}__{tag}.csv")
        have = _done_rows(csv)                              # one cell = one model x method x n_seeds rows
        if have >= n_seeds:
            print(f"[{i}/{len(cells)}] SKIP (done, {have}/{n_seeds} seeds): {tag}", flush=True); continue
        if have:
            print(f"[{i}/{len(cells)}] RESUME ({have}/{n_seeds} seeds): {tag}", flush=True)
        cmd = [sys.executable, os.path.join(os.path.dirname(__file__), "run_sweep_lm.py"),
               "--task", task, "--models", str(model),
               "--methods", method, "--seeds", str(n_seeds), "--seed0", str(seed0),
               "--rounds", str(d.get("rounds", 60)), "--batch", str(d.get("batch", 32)),
               "--eval-batch", str(d.get("eval_batch", 16)),
               "--G", str(d.get("G", 8)), "--prompts", str(d.get("prompts", 64)),
               "--shots", str(d.get("shots", 2)), "--n-test", str(d.get("n_test", 200)),
               "--train-partition", str(d.get("train_partition", "all")),
               "--eval-partition", str(d.get("eval_partition", "all")),
               "--out", out, "--tag", tag, "--run-id", run_id]
        if d.get("grad_checkpoint", True):
            cmd.append("--grad-checkpoint")
        if "lora_seed" in d and "lora_seed" not in axes:
            cmd += ["--lora-seed", str(int(d["lora_seed"]))]
        if "lora_alpha" in d and "lora_alpha" not in axes:
            cmd += ["--lora-alpha", str(int(d["lora_alpha"]))]
        if d.get("dump_completions"):                       # first-N full held-out generations to eyeball
            cmd += ["--dump-completions", str(d["dump_completions"])]
        if d.get("eval_every"):                             # opt-in held-out trajectory (AC-*; extra gen cost)
            cmd += ["--eval-every", str(d["eval_every"])]
        if d.get("eval_rounds"):
            values = d["eval_rounds"]
            if not isinstance(values, (list, tuple)):
                raise ValueError("defaults.eval_rounds must be a list of completed rounds")
            cmd += ["--eval-rounds", ",".join(str(int(value)) for value in values)]
        if d.get("save_adapter"):                           # persist each cell's LoRA adapter (post-hoc analyses)
            cmd.append("--save-adapter")
        if d.get("save_training_diagnostics"):              # AC-ALG1 samples/weights/buffer/gradient JSONL
            cmd.append("--save-training-diagnostics")
        if d.get("checkpoint_every"):
            cmd += ["--checkpoint-every", str(d["checkpoint_every"])]
        if d.get("passk"):                                  # end-of-cell pass@K sharpening check (finalists)
            cmd += ["--passk", str(d["passk"])]
            if d.get("passk_n"):
                cmd += ["--passk-n", str(d["passk_n"])]
        cmd += _axis_cli_args(axes)                          # forward each set axis to run_sweep_lm.py
        print(f"[{i}/{len(cells)}] {time.strftime('%H:%M:%S')}  RUN {tag}", flush=True)
        c0 = time.time()
        proc = subprocess.run(cmd, check=False)             # finish this shard, then return failure to SGE
        dt = int(time.time() - c0); run += 1; runt += dt
        if proc.returncode:
            failures.append((tag, proc.returncode))
        avg = runt // run; eta = avg * (len(cells) - i)
        status = "FAILED" if proc.returncode else "done"
        print(f"[{i}/{len(cells)}] {status} {tag} in {dt}s | avg {avg}s/cell | "
              f"elapsed {_fmt(int(time.time() - sweep0))} | ETA ~{_fmt(eta)}", flush=True)
    print(f"=== done in {_fmt(int(time.time() - sweep0))} -- CSVs: {out}/sweep_{task}__{cfg.get('tag_prefix','exp')}_*.csv ===")
    if failures:
        print(f"ERROR: {len(failures)} failed cell(s) in this shard:", file=sys.stderr)
        for tag, rc in failures:
            print(f"  {tag}: exit {rc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
