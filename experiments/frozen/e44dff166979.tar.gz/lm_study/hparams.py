"""THE hyperparameter-knob registry -- single source of truth for every numeric knob that can be
swept from a YAML axis or overridden from the CLI.

One Knob row drives everything that previously kept hand-synced copies (adding `gate` meant editing
five lists across three files, and that drift already shipped one real bug -- an _emit_yaml that
dropped non-lr keys):
    run_sweep_lm.py   argparse flags (--lr / --kl-coef / ...), _OVERRIDE_KEYS, _HPARAM_KEYS
    run_yaml.py       _AXES (YAML key -> CLI flag -> tag abbrev -> caster)
    sweep_collect.py  per-cell hyperparameter columns + the axis summary

ORDER IS LOAD-BEARING: registry order is tag order (run_yaml appends `_{abbr}{value}` per set axis),
and tags name the CSVs that resume/skip logic keys on. Append new knobs at the END; never reorder or
rename an abbrev -- test_lm_helpers.py pins the (key, abbr) pairs for exactly this reason.
"""
from collections import namedtuple

Knob = namedtuple("Knob", "key cast abbr help")

KNOBS = (
    Knob("lr", float, "lr", "override every method's default learning rate (for tuning/diagnostics)"),
    Knob("epochs", int, "e", "override update passes (GRPO PPO / RLOO / DPO / RAFT); ignored by AC-EM"),
    Knob("iters", int, "it", "override AC-EM M-step gradient iterations per round; ignored by methods without it"),
    Knob("beta", float, "b",
         "override beta where the method has one (EM advantage temp / DPO-APL); ignored by GRPO/RLOO/RAFT"),
    Knob("anchor", float, "anc",
         "override AC-EM base-prior anchor strength: w *= (p_base/p_theta)^anchor; ignored elsewhere"),
    Knob("causal", float, "c", "override AC-EM causal-tilt strength gamma (CVTO); ignored by methods without it"),
    Knob("pi_temp", float, "pt", "override AC-EM policy-factor temperature; ignored by methods without it"),
    Knob("sup", float, "sup",
         "AC-EM supervision fraction in [0,1] (M-step = (1-sup)*B_unsup + sup*B_sup; sup=1 = pure SFT, "
         "sup=0 = unsupervised); needs task.gold_solution; ignored elsewhere"),
    Knob("clip", float, "clip", "override GRPO PPO clip range; ignored elsewhere"),
    Knob("kl_coef", float, "kl",
         "override the KL-penalty coefficient (GRPO/RLOO reward shaping; AC-EM in-loss trust region)"),
    Knob("top_frac", float, "tf", "override RAFT top-quantile fraction; ignored elsewhere"),
    Knob("pool_mult", int, "pm", "override APL acquisition pool multiplier; ignored elsewhere"),
    Knob("window", int, "w",
         "override the history window (AC-EM repair: fresh-only M-step at 1; legacy weighted-EM cap)"),
    Knob("gate", float, "g",
         "AC-EM per-question evidence gate: a question gets M-step mass only if its best sample's "
         "per-token answer prob clears this floor (SNIS validity; 0 = off); ignored elsewhere"),
    Knob("sup_warmup", int, "wu",
         "AC-EM curriculum: run the first N rounds at sup=1 (gold SFT) then drop to sup; ignored elsewhere"),
    Knob("reset_every", int, "rst",
         "AC-EM ReST: re-init the LoRA adapter+optimiser to base every N rounds (drift reset); ignored elsewhere"),
    Knob("buffer_limit", int, "buf",
         "AC-ALG1 per-question trace-buffer cap; 0 = unbounded; gold trace is preserved"),
    Knob("labelled_frac", float, "lf",
         "AC-ALG1 fraction of answer-known prompts and per-round question budget assigned to labelled L"),
    Knob("buffer_strategy", str, "bufs",
         "AC-ALG1 buffer pruning strategy: fifo or hybrid"),
    Knob("proposal_prompt", str, "prop",
         "AC-ALG1 candidate-generation prompt: question, derive_only, answer_hint, answer_derive, "
         "tagged_zero_shot, or tagged_gold_rationale"),
    Knob("proposal_filter", str, "pf",
         "AC-ALG1 candidate admission: all or answer_correct"),
    Knob("responsibility_score", str, "rs",
         "AC-ALG1 E-step logit: joint or token_mean"),
    Knob("responsibility_temperature", float, "rt",
         "AC-ALG1 positive E-step softmax temperature"),
    Knob("labelled_em_weight", float, "lem",
         "AC-ALG1 coefficient on the labelled latent-buffer term B'_unsup"),
    Knob("labelled_proposal_prompt", str, "lprop",
         "AC-ALG1 candidate-generation prompt override for labelled L' questions"),
    Knob("answer_only_proposal_prompt", str, "uprop",
         "AC-ALG1 candidate-generation prompt override for answer-only U' questions"),
    Knob("labelled_numeric_constraint", str, "lnc",
         "AC-ALG1 labelled E-step arithmetic potential: off, hard, soft, or graph_hard"),
    Knob("numeric_penalty", float, "npen",
         "AC-ALG1 per-invalid-equation log penalty for the soft labelled numeric constraint"),
    Knob("labelled_supervision", str, "lsup",
         "AC-ALG1 B_sup target: gold, gold_compact_mix, gold_compact_set, or gold_graph_factorized"),
    Knob("compact_gold_weight", float, "cgw",
         "AC-ALG1 compact-target weight in gold_compact_mix supervision"),
    Knob("numeric_contradiction_penalty", float, "ncp",
         "AC-ALG1 per-gold-contradiction log penalty for the soft labelled numeric constraint"),
    Knob("numeric_missing_penalty", float, "nmp",
         "AC-ALG1 per-missing calculation-graph item log penalty for the soft labelled numeric constraint"),
    Knob("digit_token_weight", float, "dtw",
         "AC-ALG1 scale-preserving relative B_sup weight on digit-bearing target tokens"),
    Knob("trace_representation", str, "trep",
         "AC-ALG1 trace representation: reasoning or calculation_graph"),
    Knob("answer_only_em_weight", float, "uem",
         "AC-ALG1 coefficient on the answer-only latent-buffer term B_unsup"),
    Knob("policy_kl_coef", float, "pkl",
         "AC-ALG1 token-level KL-to-frozen-policy coefficient; zero measures an unanchored control"),
    Knob("supervised_weight", float, "sw",
         "AC-ALG1 coefficient on the supervised gold-rationale term B_sup"),
    Knob("policy_anchor_mode", str, "pam",
         "AC-ALG1 policy anchor: fixed coefficient or adaptive grad_ratio scaling"),
    Knob("policy_anchor_target_ratio", float, "rho",
         "AC-ALG1 target ||beta*g_KL|| / ||g_F|| for grad_ratio anchoring"),
    Knob("policy_anchor_beta_min", float, "pbmin",
         "AC-ALG1 lower clip for the adaptive policy-anchor coefficient"),
    Knob("policy_anchor_beta_max", float, "pbmax",
         "AC-ALG1 upper clip for the adaptive policy-anchor coefficient"),
    Knob("policy_anchor_ema", float, "pema",
         "AC-ALG1 EMA decay for adaptive policy-anchor gradient norms"),
    Knob("archive_limit", int, "arch",
         "L2R per-question trace archive cap; zero is unbounded"),
    Knob("replay_limit", int, "rep",
         "L2R per-question active replay cap after gold/elite/recent selection"),
    Knob("adaptive_max_g", int, "ag",
         "L2R maximum traces per question under adaptive sampling; zero uses fixed G"),
    Knob("adaptive_batch_g", int, "abg",
         "L2R traces added per unresolved question at each adaptive sampling pass"),
    Knob("adaptive_min_correct", int, "amc",
         "L2R correct proposals required before adaptive sampling stops for a question"),
    Knob("lora_r", int, "lorar",
         "LoRA rank loaded for a cell; structural L2R studies use rank two for surgical updates"),
    Knob("lora_alpha", int, "loraa",
         "LoRA alpha; set proportionally to rank when rank is an experimental factor"),
    Knob("lora_seed", int, "loras",
         "LoRA factor initialisation seed, decoupled from proposal and training randomness"),
    Knob("lora_trainable", str, "lorat",
         "L2R trainable adapter factors: all or b_only"),
    Knob("gradient_projection", str, "gproj",
         "L2R M-step gradient projection: none, basis, or a matched random subspace"),
    Knob("gradient_projection_rank", int, "gpr",
         "L2R empirical/random gradient-subspace rank; zero when projection is disabled"),
    Knob("buffer_replicates", int, "brep",
         "L2R parallel posterior buffers sharing the same total per-question proposal budget"),
    Knob("question_schedule", str, "qs",
         "L2R question schedule: uniform, cyclic, or failure/uncertainty/age priority"),
    Knob("schedule_exploration", float, "qse",
         "L2R priority-schedule fraction reserved for uniform exploration"),
    Knob("update_geometry", str, "ug",
         "AC-ALG1 M-step gradient combination: sum, mgda, normalized_mgda, or answer_primary"),
    Knob("step_acceptance", str, "sa",
         "AC-ALG1 post-Adam fixed-surrogate rule: none, total, componentwise, or answer_primary"),
    Knob("rollback_tolerance", float, "rbtol",
         "AC-ALG1 absolute no-harm tolerance used by safeguarded M-step acceptance"),
    Knob("rollback_max_backtracks", int, "rbn",
         "AC-ALG1 reduced-size candidate steps tried after a rollback"),
    Knob("rollback_shrink", float, "rbs",
         "AC-ALG1 learning-rate multiplier applied at each rollback backtrack"),
    Knob("optimizer_state_scope", str, "opts",
         "AC-ALG1 Adam state lifetime: persistent or outer_round"),
    Knob("proposal_policy", str, "ppol",
         "AC-ALG1 proposal sampler: current adapter or frozen_base"),
    Knob("responsibility_ess_floor", float, "ress",
         "AC-ALG1 one-sided minimum responsibility ESS fraction; zero disables it"),
    Knob("responsibility_policy", str, "rpol",
         "AC-ALG1 E-step scorer: current adapter or frozen_base"),
    Knob("responsibility_refresh", str, "rref",
         "AC-ALG1 E-step refresh: inner_step or outer_round"),
)

# Remaining categorical / boolean / memory-only knobs: varied via named method variants in the
# registry (never a YAML sweep axis or CLI flag), but still resolved into the params blob so every
# CSV self-describes. Sweepable categorical knobs belong in KNOBS above.
CONFIG_KEYS = ("weight", "hindsight", "offline", "micro", "length_norm", "acq",
               "train_span", "select", "centered", "dconsist", "frozen_critic", "gold_in_buffer",
               "policy_factor", "reader_mode", "reader_decode_filter")


def flag(key):
    """CLI flag for a knob key ('kl_coef' -> '--kl-coef'); argparse maps it back to `key` as the dest."""
    return "--" + key.replace("_", "-")
