"""Evaluation-only execution for a prepared final-method transfer task."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Mapping

import numpy as np

import benchmark as B
from math_answer_events import math_answers_equivalent, parse_math_answer_event
from methods_lm import MODEL_REVISIONS, MODELS, cuda_dtype
from prepare_qwen3_final_generality import TRANSFER_DATASETS
from tasks import GSM8K_DATASET_REVISION, _gsm8k_train_validation_pools


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_manifest(path: Path, expected_sha256: str) -> dict[str, Any]:
    observed = file_sha256(path)
    if observed != expected_sha256:
        raise ValueError(
            f"transfer manifest SHA-256 mismatch: expected {expected_sha256}, got {observed}"
        )
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1:
        raise ValueError("unsupported transfer manifest schema")
    if manifest.get("stage") != "frozen_external_transfer":
        raise ValueError("manifest is not a frozen external-transfer plan")
    if manifest.get("official_gsm8k_test_used") is not False:
        raise ValueError("manifest does not prove GSM8K official-test non-access")
    if manifest.get("datasets") != TRANSFER_DATASETS:
        raise ValueError("transfer dataset pins changed")
    tasks = manifest.get("tasks")
    if not isinstance(tasks, list) or len(tasks) != 56:
        raise ValueError("transfer manifest must contain exactly 56 tasks")
    if [task.get("task_index") for task in tasks] != list(range(1, 57)):
        raise ValueError("transfer task indices must be exactly 1..56")
    return manifest


def select_task(manifest: Mapping[str, Any], task_index: int) -> dict[str, Any]:
    if not 1 <= int(task_index) <= len(manifest["tasks"]):
        raise ValueError(f"task index {task_index} is outside the manifest")
    task = dict(manifest["tasks"][int(task_index) - 1])
    if task.get("task_index") != int(task_index):
        raise ValueError("task index does not match manifest order")
    if task.get("dataset") not in TRANSFER_DATASETS:
        raise ValueError("unknown transfer dataset")
    if task.get("model") != "qwen3-1.7b-base":
        raise ValueError("transfer model changed")
    if task.get("model_revision") != MODEL_REVISIONS["qwen3-1.7b-base"]:
        raise ValueError("transfer model revision changed")
    if task.get("role") == "frozen_base":
        if any(
            task.get(field) is not None
            for field in (
                "adapter_path",
                "adapter_receipt_path",
                "adapter_receipt_sha256",
            )
        ):
            raise ValueError("frozen base task unexpectedly names an adapter")
    else:
        for field in (
            "adapter_path",
            "adapter_receipt_path",
            "adapter_receipt_sha256",
        ):
            if not isinstance(task.get(field), str) or not task[field]:
                raise ValueError(f"trained transfer task omits {field}")
    return task


def verify_adapter(task: Mapping[str, Any]) -> None:
    if task["role"] == "frozen_base":
        return
    adapter = Path(task["adapter_path"]).expanduser()
    receipt = Path(task["adapter_receipt_path"]).expanduser()
    if not adapter.is_dir():
        raise ValueError(f"adapter directory does not exist: {adapter}")
    if not receipt.is_file():
        raise ValueError(f"adapter receipt does not exist: {receipt}")
    observed = file_sha256(receipt)
    if observed != task["adapter_receipt_sha256"]:
        raise ValueError(
            "adapter receipt SHA-256 mismatch: "
            f"expected {task['adapter_receipt_sha256']}, got {observed}"
        )
    if not any(
        (adapter / filename).is_file()
        for filename in ("adapter_model.safetensors", "adapter_model.bin")
    ):
        raise ValueError(f"adapter weights missing from {adapter}")
    if not (adapter / "adapter_config.json").is_file():
        raise ValueError(f"adapter config missing from {adapter}")
    receipt_payload = json.loads(receipt.read_text(encoding="utf-8"))
    if (
        not isinstance(receipt_payload, dict)
        or receipt_payload.get("schema_version") != 1
        or receipt_payload.get("status") != "complete"
    ):
        raise ValueError(f"adapter receipt is not a complete schema-v1 receipt: {receipt}")
    identity = receipt_payload.get("identity")
    if not isinstance(identity, dict):
        raise ValueError(f"adapter receipt identity missing: {receipt}")
    if (
        identity.get("method") != task["algorithm"]
        or int(identity.get("seed", -1)) != int(task["seed"])
        or identity.get("model") != task["model"]
    ):
        raise ValueError(f"adapter receipt coordinate changed: {receipt}")
    artifacts = receipt_payload.get("artifacts")
    if not isinstance(artifacts, list):
        raise ValueError(f"adapter receipt artifact list missing: {receipt}")
    by_path = {
        str(record.get("path")): record
        for record in artifacts
        if isinstance(record, dict)
    }
    required_names = ["adapter_config.json"]
    weights = [
        filename
        for filename in ("adapter_model.safetensors", "adapter_model.bin")
        if (adapter / filename).is_file()
    ]
    if len(weights) != 1:
        raise ValueError(f"adapter must contain exactly one supported weight file: {adapter}")
    required_names.extend(weights)
    for filename in required_names:
        relative = f"{adapter.name}/{filename}"
        record = by_path.get(relative)
        path = adapter / filename
        if not isinstance(record, dict):
            raise ValueError(f"receipt does not bind {relative}")
        if int(record.get("size", -1)) != path.stat().st_size:
            raise ValueError(f"receipt size mismatch for {path}")
        if record.get("sha256") != file_sha256(path):
            raise ValueError(f"receipt checksum mismatch for {path}")


def load_model(task: Mapping[str, Any]):
    import torch
    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer

    if not torch.cuda.is_available():
        raise RuntimeError("frozen transfer evaluation requires CUDA")
    preset = str(task["model"])
    model_id, _targets = MODELS[preset]
    revision = MODEL_REVISIONS[preset]
    tokenizer = AutoTokenizer.from_pretrained(model_id, revision=revision)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    base = AutoModelForCausalLM.from_pretrained(
        model_id,
        revision=revision,
        torch_dtype=cuda_dtype(),
        low_cpu_mem_usage=True,
    )
    if task["role"] == "frozen_base":
        model = base
    else:
        model = PeftModel.from_pretrained(
            base,
            str(Path(task["adapter_path"]).expanduser()),
            is_trainable=False,
        )
    model = model.to("cuda")
    model.eval()
    return model, tokenizer


def _validate_math500_payload(raw: bytes, expected_sha256: str) -> list[dict[str, Any]]:
    observed = hashlib.sha256(raw).hexdigest()
    if observed != expected_sha256:
        raise ValueError(
            f"MATH-500 SHA-256 mismatch: expected {expected_sha256}, got {observed}"
        )
    rows = []
    for line_number, raw_line in enumerate(raw.splitlines(), start=1):
        if not raw_line.strip():
            continue
        try:
            row = json.loads(raw_line)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"invalid MATH-500 JSONL row {line_number}") from exc
        required = {"problem", "answer", "subject", "level", "unique_id"}
        if not isinstance(row, dict) or not required.issubset(row):
            raise ValueError(f"MATH-500 row {line_number} has an unexpected schema")
        if not all(isinstance(row[field], str) and row[field] for field in ("problem", "answer", "unique_id")):
            raise ValueError(f"MATH-500 row {line_number} has an empty required field")
        rows.append(row)
    if len(rows) != 500:
        raise ValueError(f"MATH-500 must contain exactly 500 rows, got {len(rows)}")
    if len({row["unique_id"] for row in rows}) != 500:
        raise ValueError("MATH-500 unique_id values are not unique")
    return rows


def load_math500(path: Path, metadata: Mapping[str, Any]) -> list[dict[str, Any]]:
    try:
        raw = path.expanduser().read_bytes()
    except OSError as exc:
        raise RuntimeError(f"cannot read pinned MATH-500 file {path}") from exc
    return _validate_math500_payload(raw, str(metadata["sha256"]))


def build_math500_prompts(rows: list[dict[str, Any]], *, seed: int) -> list[str]:
    from datasets import load_dataset

    train = load_dataset(
        "openai/gsm8k",
        "main",
        split="train",
        revision=GSM8K_DATASET_REVISION,
    )
    train_pool, _validation_pool = _gsm8k_train_validation_pools(len(train))
    shots, _indices, _bank_size, _rng = B._gsm8k_demonstrations(
        train,
        3,
        seed,
        5,
        train_pool,
    )
    return [shots + f"Question: {row['problem']}\nAnswer:" for row in rows]


def score_math500(
    rows: list[dict[str, Any]],
    completions: list[str],
    metadata: list[dict[str, Any]],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if not (len(rows) == len(completions) == len(metadata)):
        raise ValueError("MATH-500 scoring inputs are not aligned")
    scored = []
    for row, completion, generation in zip(rows, completions, metadata):
        extracted = parse_math_answer_event(completion, mode="legacy")
        strict = parse_math_answer_event(completion, mode="strict_terminal_marker")
        extracted_correct = math_answers_equivalent(extracted.answer, row["answer"])
        strict_correct = strict.strict_valid and math_answers_equivalent(
            strict.answer, row["answer"]
        )
        scored.append(
            {
                "dataset_id": row["unique_id"],
                "subject": row["subject"],
                "level": row["level"],
                "gold": row["answer"],
                "completion": completion,
                "extracted_answer": extracted.answer,
                "extracted_correct": bool(extracted_correct),
                "strict_answer": strict.answer,
                "strict_valid": bool(strict.strict_valid),
                "strict_correct": bool(strict_correct),
                "generated_eos": bool(generation.get("generated_eos")),
                "generated_tokens_until_eos": generation.get(
                    "generated_tokens_until_eos"
                ),
                "hit_max_new_tokens": bool(generation.get("hit_max_new_tokens")),
            }
        )

    def mean(field: str) -> float:
        return float(np.mean([bool(row[field]) for row in scored]))

    metrics = {
        "final_extracted_answer_accuracy": mean("extracted_correct"),
        "final_strict_terminal_accuracy": mean("strict_correct"),
        "trajectory_auc": None,
        "natural_eos_rate": mean("generated_eos"),
        "token_limit_rate": mean("hit_max_new_tokens"),
    }
    return metrics, scored


def score_svamp_records(
    records: list[dict[str, Any]],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Expose conventional and strict SVAMP scores from one generation pass."""

    if not records:
        raise ValueError("SVAMP evaluation returned no records")
    normalized = []
    for index, raw_record in enumerate(records):
        record = dict(raw_record)
        if not isinstance(record.get("legacy_correct"), bool):
            raise ValueError(f"SVAMP record {index} omits legacy_correct")
        if not isinstance(record.get("strict_correct"), bool):
            raise ValueError(f"SVAMP record {index} omits strict_correct")
        record["extracted_correct"] = bool(record["legacy_correct"])
        normalized.append(record)

    def mean(field: str) -> float:
        return float(np.mean([bool(row.get(field)) for row in normalized]))

    metrics = {
        "final_extracted_answer_accuracy": mean("extracted_correct"),
        "final_strict_terminal_accuracy": mean("strict_correct"),
        "trajectory_auc": None,
        "natural_eos_rate": mean("generated_eos"),
        "token_limit_rate": mean("hit_max_new_tokens"),
    }
    return metrics, normalized


def evaluate(task: Mapping[str, Any], model, tokenizer, math500_path: Path | None):
    if task["dataset"] == "svamp":
        _strict_accuracy, records, metadata = B.benchmark_svamp_transfer(
            model,
            tokenizer,
            n_test=1000,
            n_shots=3,
            seed=int(task["seed"]),
            max_new=256,
            batch=16,
            shot_bank_size=5,
            answer_event_mode="strict_terminal_marker",
            train_partition="train",
        )
        metrics, records = score_svamp_records(records)
        return metrics, records, metadata
    if math500_path is None:
        raise ValueError("--math500-data is required for a MATH-500 task")
    rows = load_math500(math500_path, TRANSFER_DATASETS["math_500"])
    prompts = build_math500_prompts(rows, seed=int(task["seed"]))
    completions, generation = B._generate(
        model,
        tokenizer,
        prompts,
        max_new=512,
        batch=8,
        return_metadata=True,
    )
    metrics, records = score_math500(rows, completions, generation)
    metadata = {
        **TRANSFER_DATASETS["math_500"],
        "evaluation_prompt": "question",
        "demonstration_source": "openai/gsm8k:train",
        "demonstration_dataset_revision": GSM8K_DATASET_REVISION,
        "demonstration_shots": 3,
        "demonstration_shot_bank_size": 5,
        "official_gsm8k_test_accessed": False,
    }
    return metrics, records, metadata


def write_result(
    output: Path,
    *,
    task: Mapping[str, Any],
    manifest_sha256: str,
    execution_commit: str,
    metrics: Mapping[str, Any],
    records: list[dict[str, Any]],
    dataset_metadata: Mapping[str, Any],
    runtime: Mapping[str, Any],
) -> tuple[Path, Path]:
    output.mkdir(parents=True, exist_ok=True)
    stem = (
        f"transfer_task_{int(task['task_index']):03d}__{task['dataset']}__"
        f"{task['role']}__s{task['seed']}"
    )
    artifact = output / f"{stem}.json.gz"
    payload = {
        "schema_version": 1,
        "status": "complete",
        "manifest_sha256": manifest_sha256,
        "execution_commit": execution_commit,
        "official_gsm8k_test_used": False,
        "task": dict(task),
        "metrics": dict(metrics),
        "dataset": dict(dataset_metadata),
        "runtime": dict(runtime),
        "records": records,
    }
    with gzip.open(artifact, "wt", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True)
    receipt = output / f"{stem}.receipt.json"
    receipt.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "status": "complete",
                "task_index": int(task["task_index"]),
                "manifest_sha256": manifest_sha256,
                "execution_commit": execution_commit,
                "artifact": artifact.name,
                "artifact_sha256": file_sha256(artifact),
                "official_gsm8k_test_used": False,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return artifact, receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--task-index", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--execution-commit", required=True)
    parser.add_argument("--math500-data", type=Path)
    args = parser.parse_args()

    manifest = load_manifest(args.manifest, args.expected_manifest_sha256)
    task = select_task(manifest, args.task_index)
    verify_adapter(task)
    started = time.monotonic()
    model, tokenizer = load_model(task)
    try:
        import torch

        torch.cuda.reset_peak_memory_stats()
        metrics, records, dataset_metadata = evaluate(
            task, model, tokenizer, args.math500_data
        )
        runtime = {
            "elapsed_seconds": time.monotonic() - started,
            "accelerator_hours": (time.monotonic() - started) / 3600.0,
            "gpu_name": torch.cuda.get_device_name(0),
            "peak_gpu_memory_bytes": int(torch.cuda.max_memory_allocated()),
            "evaluated_examples": len(records),
            "generated_tokens": sum(
                int(row["generated_tokens_until_eos"]) for row in records
            ),
        }
    finally:
        del model
    artifact, receipt = write_result(
        args.output,
        task=task,
        manifest_sha256=args.expected_manifest_sha256,
        execution_commit=args.execution_commit,
        metrics=metrics,
        records=records,
        dataset_metadata=dataset_metadata,
        runtime=runtime,
    )
    print(f"wrote {artifact} and {receipt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
