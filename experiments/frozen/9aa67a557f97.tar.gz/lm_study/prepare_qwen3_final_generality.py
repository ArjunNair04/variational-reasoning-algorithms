"""Build post-confirmation transfer and model-scale plans from a frozen decision.

This module does not submit jobs.  It converts a completed, validation-only
final-method decision into two immutable inputs for later deployment:

* a seed-matched frozen-transfer manifest for SVAMP and MATH-500;
* a three-method Qwen3-8B GSM8K replication YAML.

The builder is deliberately fail-closed because the required adapters and
winner identities do not exist until the final seven-seed comparison finishes.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

import yaml


SCHEMA_VERSION = 1
EXPECTED_ANALYSIS_STATUS = "final_validation_confirmation_complete"
EXPECTED_METRIC_ORDER = [
    "final_extracted_answer_accuracy",
    "final_strict_terminal_accuracy",
    "normalized_extracted_trajectory_auc",
]
EXPECTED_ROLES = (
    "frozen_base",
    "posterior",
    "non_rl_self_training",
    "rl",
)
SCALE_COMPARATOR_ROLES = {"non_rl_self_training", "rl"}
SCALE_SEEDS = (1103, 1109, 1117)

QWEN17_MODEL = "qwen3-1.7b-base"
QWEN17_REVISION = "ea980cb0a6c2ae4b936e82123acc929f1cec04c1"
QWEN8_MODEL = "qwen3-8b-base"
QWEN8_REVISION = "49e3418fbbbca6ecbdf9608b4d22e5a407081db4"
GSM8K_REVISION = "740312add88f781978c0658806c59bc2815b9866"

TRANSFER_DATASETS = {
    "svamp": {
        "dataset_id": "SVAMP",
        "source_url": (
            "https://raw.githubusercontent.com/arkilpatel/SVAMP/"
            "689d7ccac74b9983a2ac7cc3b264f441b99e7c53/SVAMP.json"
        ),
        "revision": "689d7ccac74b9983a2ac7cc3b264f441b99e7c53",
        "sha256": "5be77703a6d891ae476d7c082787ad361392aa02453b132516cdd5f4e7934e3e",
        "split": "full",
        "rows": 1000,
    },
    "math_500": {
        "dataset_id": "HuggingFaceH4/MATH-500",
        "revision": "6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be",
        "filename": "test.jsonl",
        "sha256": "35dc41080a3680858b27fa7e0533d2d547825316fc5dafe5d316f4ccc5a06132",
        "split": "test",
        "rows": 500,
    },
}

REQUIRED_COMMON_DEFAULTS = {
    "task": "gsm8k",
    "model": QWEN17_MODEL,
    "rounds": 32,
    "prompts": 128,
    "shots": 3,
    "shot_bank_size": 5,
    "n_test": 400,
    "train_partition": "train",
    "eval_partition": "validation",
    "answer_event_mode": "strict_terminal_marker",
    # Base and RL cells do not teacher-force an answer target. Supervised cells
    # carry their EOS-complete target as a cell-level axis.
    "answer_target_termination": "none",
    "evaluation_prompt": "question",
    "task_seed_from_run_seed": True,
    "question_sampling": "epoch_shuffle",
    "lora_r": 16,
    "lora_alpha": 32,
    "lora_target_set": "attention_mlp",
    "save_adapter": True,
}


def _require_mapping(value: Any, *, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be an object")
    return value


def _require_nonempty_string(value: Any, *, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a nonempty string")
    return value.strip()


def _require_sha256(value: Any, *, field: str) -> str:
    text = _require_nonempty_string(value, field=field)
    if len(text) != 64 or any(character not in "0123456789abcdef" for character in text):
        raise ValueError(f"{field} must be a lowercase SHA-256 digest")
    return text


def _canonical_sha256(payload: Mapping[str, Any]) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def load_and_validate_decision(path: Path) -> dict[str, Any]:
    decision = json.loads(path.read_text(encoding="utf-8"))
    _require_mapping(decision, field="decision")
    if decision.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"decision.schema_version must be {SCHEMA_VERSION}")
    if decision.get("analysis_status") != EXPECTED_ANALYSIS_STATUS:
        raise ValueError(
            "decision is not a completed final validation confirmation"
        )
    if decision.get("official_test_used") is not False:
        raise ValueError("decision must prove official_test_used=false")
    if decision.get("metric_order") != EXPECTED_METRIC_ORDER:
        raise ValueError("decision.metric_order changed")

    _require_nonempty_string(
        decision.get("source_registry_id"), field="decision.source_registry_id"
    )
    _require_nonempty_string(
        decision.get("source_run_id"), field="decision.source_run_id"
    )
    _require_sha256(
        decision.get("source_config_sha256"),
        field="decision.source_config_sha256",
    )
    _require_sha256(
        decision.get("validator_marker_sha256"),
        field="decision.validator_marker_sha256",
    )

    seeds = decision.get("confirmation_seed_values")
    if (
        not isinstance(seeds, list)
        or len(seeds) != 7
        or any(isinstance(seed, bool) or not isinstance(seed, int) for seed in seeds)
        or len(set(seeds)) != 7
    ):
        raise ValueError(
            "decision.confirmation_seed_values must contain seven unique integers"
        )

    common_defaults = _require_mapping(
        decision.get("common_defaults"), field="decision.common_defaults"
    )
    for field, expected in REQUIRED_COMMON_DEFAULTS.items():
        if common_defaults.get(field) != expected:
            raise ValueError(
                f"decision.common_defaults.{field} must be {expected!r}, "
                f"got {common_defaults.get(field)!r}"
            )

    finalists = decision.get("finalists")
    if not isinstance(finalists, list) or len(finalists) != len(EXPECTED_ROLES):
        raise ValueError("decision.finalists must contain exactly four entries")
    by_role: dict[str, Mapping[str, Any]] = {}
    for index, raw_finalist in enumerate(finalists):
        finalist = _require_mapping(raw_finalist, field=f"decision.finalists[{index}]")
        role = _require_nonempty_string(
            finalist.get("role"), field=f"decision.finalists[{index}].role"
        )
        if role not in EXPECTED_ROLES or role in by_role:
            raise ValueError(f"unexpected or duplicate finalist role {role!r}")
        algorithm = _require_nonempty_string(
            finalist.get("algorithm"),
            field=f"decision.finalists[{index}].algorithm",
        )
        _require_nonempty_string(
            finalist.get("cell_id"),
            field=f"decision.finalists[{index}].cell_id",
        )
        axes = _require_mapping(
            finalist.get("axes"), field=f"decision.finalists[{index}].axes"
        )
        if "cell_id" in axes:
            raise ValueError("finalist axes must not repeat cell_id")
        adapters = finalist.get("adapter_by_seed")
        if role == "frozen_base":
            if algorithm != "base" or axes or adapters not in (None, [], {}):
                raise ValueError(
                    "frozen_base must use algorithm='base', empty axes, and no adapters"
                )
        else:
            if algorithm == "base" or not isinstance(adapters, list):
                raise ValueError(f"{role} must name a trained algorithm and adapters")
            adapter_seeds = []
            for adapter_index, raw_adapter in enumerate(adapters):
                adapter = _require_mapping(
                    raw_adapter,
                    field=f"decision.finalists[{index}].adapter_by_seed[{adapter_index}]",
                )
                seed = adapter.get("seed")
                if isinstance(seed, bool) or not isinstance(seed, int):
                    raise ValueError(f"{role} adapter seed must be an integer")
                adapter_seeds.append(seed)
                _require_nonempty_string(
                    adapter.get("path"), field=f"{role} adapter path"
                )
                _require_nonempty_string(
                    adapter.get("receipt_path"),
                    field=f"{role} adapter receipt_path",
                )
                _require_sha256(
                    adapter.get("receipt_sha256"),
                    field=f"{role} adapter receipt_sha256",
                )
            if sorted(adapter_seeds) != sorted(seeds):
                raise ValueError(
                    f"{role} must provide exactly one adapter for every confirmation seed"
                )
        by_role[role] = finalist

    if tuple(role for role in EXPECTED_ROLES if role in by_role) != EXPECTED_ROLES:
        raise ValueError("decision finalist roles changed")
    scale_comparator = decision.get("scale_comparator_role")
    if scale_comparator not in SCALE_COMPARATOR_ROLES:
        raise ValueError(
            "decision.scale_comparator_role must select the non-RL or RL finalist"
        )
    return decision


def _adapter_lookup(finalist: Mapping[str, Any]) -> dict[int, Mapping[str, Any]]:
    return {
        int(adapter["seed"]): adapter
        for adapter in finalist.get("adapter_by_seed") or []
    }


def build_transfer_manifest(decision: Mapping[str, Any]) -> dict[str, Any]:
    decision_sha256 = _canonical_sha256(decision)
    seeds = [int(seed) for seed in decision["confirmation_seed_values"]]
    finalists = {row["role"]: row for row in decision["finalists"]}
    tasks = []
    for dataset_name in ("svamp", "math_500"):
        for role in EXPECTED_ROLES:
            finalist = finalists[role]
            adapters = _adapter_lookup(finalist)
            for seed in seeds:
                adapter = adapters.get(seed)
                tasks.append(
                    {
                        "task_index": len(tasks) + 1,
                        "dataset": dataset_name,
                        "role": role,
                        "algorithm": finalist["algorithm"],
                        "cell_id": finalist["cell_id"],
                        "seed": seed,
                        "model": QWEN17_MODEL,
                        "model_revision": QWEN17_REVISION,
                        "adapter_path": adapter["path"] if adapter else None,
                        "adapter_receipt_path": (
                            adapter["receipt_path"] if adapter else None
                        ),
                        "adapter_receipt_sha256": (
                            adapter["receipt_sha256"] if adapter else None
                        ),
                    }
                )
    return {
        "schema_version": SCHEMA_VERSION,
        "stage": "frozen_external_transfer",
        "release_status": "prepared_requires_operator_approval",
        "source_registry_id": decision["source_registry_id"],
        "source_run_id": decision["source_run_id"],
        "source_decision_sha256": decision_sha256,
        "official_gsm8k_test_used": False,
        "datasets": TRANSFER_DATASETS,
        "reporting_order": EXPECTED_METRIC_ORDER,
        "prompt_contract": {
            "demonstration_source": "openai/gsm8k:train",
            "demonstration_dataset_revision": GSM8K_REVISION,
            "shots": 3,
            "shot_bank_size": 5,
            "evaluation_prompt": "question",
            "no_transfer_tuning": True,
        },
        "tasks": tasks,
    }


def _scale_cell(finalist: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "cell_id": f"Q8-{finalist['cell_id']}",
        **copy.deepcopy(dict(finalist["axes"])),
    }


def build_scale_payload(decision: Mapping[str, Any]) -> dict[str, Any]:
    finalists = {row["role"]: row for row in decision["finalists"]}
    selected_roles = (
        "frozen_base",
        "posterior",
        str(decision["scale_comparator_role"]),
    )
    selected = [finalists[role] for role in selected_roles]
    algorithms = [str(row["algorithm"]) for row in selected]
    if len(set(algorithms)) != len(algorithms):
        raise ValueError(
            "Qwen3-8B replication requires three distinct YAML algorithm keys"
        )

    defaults = copy.deepcopy(dict(decision["common_defaults"]))
    defaults.update(
        {
            "model": QWEN8_MODEL,
            "seeds": len(SCALE_SEEDS),
            "seed_values": list(SCALE_SEEDS),
            "grad_checkpoint": True,
            "out": (
                "~/po_results/2026-08-17/final-comparison/"
                "qwen3-8b-scale-replication__generated"
            ),
            "save_adapter": True,
        }
    )
    payload: dict[str, Any] = {
        "tag_prefix": "q3_8b_final_scale_replication",
        "diagnostic": {
            "stage": "post_confirmation_model_scale_replication",
            "evidence_class": "fresh_three_seed_robustness",
            "source_registry_id": decision["source_registry_id"],
            "source_run_id": decision["source_run_id"],
            "source_decision_sha256": _canonical_sha256(decision),
            "selected_roles": list(selected_roles),
            "model_id": "Qwen/Qwen3-8B-Base",
            "model_revision": QWEN8_REVISION,
            "dataset_id": "openai/gsm8k",
            "dataset_revision": GSM8K_REVISION,
            "official_test_used": False,
            "allowed_changes": [
                "model checkpoint and fresh seeds",
                "gradient checkpointing as a hardware-only memory control",
            ],
            "reporting_order": EXPECTED_METRIC_ORDER,
        },
        "defaults": defaults,
        "algos": {
            str(finalist["algorithm"]): _scale_cell(finalist)
            for finalist in selected
        },
    }
    identity = {
        "source_decision_sha256": payload["diagnostic"]["source_decision_sha256"],
        "selected_roles": payload["diagnostic"]["selected_roles"],
        "model_revision": QWEN8_REVISION,
        "seeds": list(SCALE_SEEDS),
    }
    run_id = _canonical_sha256(identity)[:8]
    payload["run_id"] = run_id
    payload["defaults"]["out"] = (
        "~/po_results/2026-08-17/final-comparison/"
        f"qwen3-8b-scale-replication__{run_id}"
    )
    return payload


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _write_yaml(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(dict(payload), sort_keys=False, width=100),
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--decision", type=Path, required=True)
    parser.add_argument("--transfer-manifest", type=Path)
    parser.add_argument("--scale-yaml", type=Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    if args.check_only and (args.transfer_manifest or args.scale_yaml):
        parser.error("--check-only cannot be combined with output paths")
    if not args.check_only and not (args.transfer_manifest and args.scale_yaml):
        parser.error("both --transfer-manifest and --scale-yaml are required")

    decision = load_and_validate_decision(args.decision)
    transfer = build_transfer_manifest(decision)
    scale = build_scale_payload(decision)
    if args.check_only:
        print("final generality decision contract valid")
        return 0
    _write_json(args.transfer_manifest, transfer)
    _write_yaml(args.scale_yaml, scale)
    print(
        f"prepared {len(transfer['tasks'])} transfer tasks and "
        f"{len(scale['algos']) * len(SCALE_SEEDS)} scale-replication cells"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
