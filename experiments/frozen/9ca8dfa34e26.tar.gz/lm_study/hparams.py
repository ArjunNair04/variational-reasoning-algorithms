"""THE hyperparameter-knob registry -- single source of truth for every numeric knob that can be
swept from a YAML axis or overridden from the CLI.

One Knob row drives everything that previously kept hand-synced copies (adding `gate` meant editing
five lists across three files, and that drift already shipped one real bug -- an _emit_yaml that
dropped non-lr keys):
    run_sweep_lm.py   argparse flags (--lr / --kl-coef / ...), _OVERRIDE_KEYS, _HPARAM_KEYS
    run_yaml.py       _AXES (YAML key -> CLI flag -> tag abbrev -> caster)
    sweep_collect.py  per-cell hyperparameter columns + the axis summary

ORDER IS LOAD-BEARING: registry order is tag order (run_yaml appends `_{abbr}{value}` per set axis),
and tags name the CSVs that resume/skip logic keys on. Append new knobs at the END; never reorder or
rename an abbrev -- test_lm_helpers.py pins the (key, abbr) pairs for exactly this reason.
"""
from collections import namedtuple

Knob = namedtuple("Knob", "key cast abbr help")

KNOBS = (
    Knob("lr", float, "lr", "override every method's default learning rate (for tuning/diagnostics)"),
    Knob("epochs", int, "e", "override update passes (GRPO PPO / RLOO / DPO / RAFT); ignored by AC-EM"),
    Knob("iters", int, "it", "override AC-EM M-step gradient iterations per round; ignored by methods without it"),
    Knob("beta", float, "b",
         "override beta where the method has one (EM advantage temp / DPO-APL); ignored by GRPO/RLOO/RAFT"),
    Knob("anchor", float, "anc",
         "override AC-EM base-prior anchor strength: w *= (p_base/p_theta)^anchor; ignored elsewhere"),
    Knob("causal", float, "c", "override AC-EM causal-tilt strength gamma (CVTO); ignored by methods without it"),
    Knob("pi_temp", float, "pt", "override AC-EM policy-factor temperature; ignored by methods without it"),
    Knob("sup", float, "sup",
         "AC-EM supervision fraction in [0,1] (M-step = (1-sup)*B_unsup + sup*B_sup; sup=1 = pure SFT, "
         "sup=0 = unsupervised); needs task.gold_solution; ignored elsewhere"),
    Knob("clip", float, "clip", "override GRPO PPO clip range; ignored elsewhere"),
    Knob("kl_coef", float, "kl",
         "override the KL-penalty coefficient (GRPO/RLOO reward shaping; AC-EM in-loss trust region)"),
    Knob("top_frac", float, "tf", "override RAFT top-quantile fraction; ignored elsewhere"),
    Knob("pool_mult", int, "pm", "override APL acquisition pool multiplier; ignored elsewhere"),
    Knob("window", int, "w",
         "override the history window (AC-EM repair: fresh-only M-step at 1; legacy weighted-EM cap)"),
    Knob("gate", float, "g",
         "AC-EM per-question evidence gate: a question gets M-step mass only if its best sample's "
         "per-token answer prob clears this floor (SNIS validity; 0 = off); ignored elsewhere"),
    Knob("sup_warmup", int, "wu",
         "AC-EM curriculum: run the first N rounds at sup=1 (gold SFT) then drop to sup; ignored elsewhere"),
    Knob("reset_every", int, "rst",
         "AC-EM ReST: re-init the LoRA adapter+optimiser to base every N rounds (drift reset); ignored elsewhere"),
    Knob("buffer_limit", int, "buf",
         "AC-ALG1 per-question trace-buffer cap; 0 = unbounded; gold trace is preserved"),
    Knob("labelled_frac", float, "lf",
         "AC-ALG1 fraction of answer-known prompts and per-round question budget assigned to labelled L"),
    Knob("buffer_strategy", str, "bufs",
         "AC-ALG1 buffer pruning strategy: fifo or hybrid"),
    Knob("proposal_prompt", str, "prop",
         "AC-ALG1 candidate-generation prompt: question, derive_only, answer_hint, answer_derive, "
         "tagged_zero_shot, or tagged_gold_rationale"),
    Knob("proposal_filter", str, "pf",
         "AC-ALG1 candidate admission: all or answer_correct"),
    Knob("responsibility_score", str, "rs",
         "AC-ALG1 E-step logit: joint or token_mean"),
    Knob("responsibility_temperature", float, "rt",
         "AC-ALG1 positive E-step softmax temperature"),
    Knob("labelled_em_weight", float, "lem",
         "AC-ALG1 coefficient on the labelled latent-buffer term B'_unsup"),
    Knob("labelled_proposal_prompt", str, "lprop",
         "AC-ALG1 candidate-generation prompt override for labelled L' questions"),
    Knob("answer_only_proposal_prompt", str, "uprop",
         "AC-ALG1 candidate-generation prompt override for answer-only U' questions"),
    Knob("labelled_numeric_constraint", str, "lnc",
         "AC-ALG1 labelled E-step arithmetic potential: off, hard, soft, or graph_hard"),
    Knob("numeric_penalty", float, "npen",
         "AC-ALG1 per-invalid-equation log penalty for the soft labelled numeric constraint"),
    Knob("labelled_supervision", str, "lsup",
         "AC-ALG1 B_sup target: gold, gold_compact_mix, gold_compact_set, or gold_graph_factorized"),
    Knob("compact_gold_weight", float, "cgw",
         "AC-ALG1 compact-target weight in gold_compact_mix supervision"),
    Knob("numeric_contradiction_penalty", float, "ncp",
         "AC-ALG1 per-gold-contradiction log penalty for the soft labelled numeric constraint"),
    Knob("numeric_missing_penalty", float, "nmp",
         "AC-ALG1 per-missing calculation-graph item log penalty for the soft labelled numeric constraint"),
    Knob("digit_token_weight", float, "dtw",
         "AC-ALG1 scale-preserving relative B_sup weight on digit-bearing target tokens"),
    Knob("trace_representation", str, "trep",
         "AC-ALG1 trace representation: reasoning or calculation_graph"),
    Knob("answer_only_em_weight", float, "uem",
         "AC-ALG1 coefficient on the answer-only latent-buffer term B_unsup"),
    Knob("policy_kl_coef", float, "pkl",
         "AC-ALG1 token-level KL-to-frozen-policy coefficient; zero measures an unanchored control"),
    Knob("supervised_weight", float, "sw",
         "AC-ALG1 coefficient on the supervised gold-rationale term B_sup"),
)

# Remaining categorical / boolean / memory-only knobs: varied via named method variants in the
# registry (never a YAML sweep axis or CLI flag), but still resolved into the params blob so every
# CSV self-describes. Sweepable categorical knobs belong in KNOBS above.
CONFIG_KEYS = ("weight", "hindsight", "offline", "micro", "length_norm", "acq",
               "train_span", "select", "centered", "dconsist", "frozen_critic", "gold_in_buffer")


def flag(key):
    """CLI flag for a knob key ('kl_coef' -> '--kl-coef'); argparse maps it back to `key` as the dest."""
    return "--" + key.replace("_", "-")
