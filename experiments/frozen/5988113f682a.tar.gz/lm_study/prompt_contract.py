"""Exact, machine-readable prompt provenance for GSM8K experiment cells."""

from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path
import secrets
from typing import Any

from prompting import build_proposal_prompt


PROMPT_CONTRACT_SCHEMA_VERSION = 1


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def build_gsm8k_prompt_contract(
    task,
    *,
    proposal_prompt: str,
    method: str,
    seed: int,
    tag: str,
    answer_event_mode: str,
    answer_target_termination: str,
) -> dict[str, Any]:
    """Render and validate every canonical and proposal prompt for one cell."""

    required = ("prompts", "gold_answer", "train_qi", "shot_qi")
    missing = [name for name in required if not hasattr(task, name)]
    if missing:
        raise ValueError(f"GSM8K prompt contract is missing task fields: {missing}")
    if len(task.prompts) != len(task.gold_answer) or len(task.prompts) != len(task.train_qi):
        raise ValueError("GSM8K prompt contract inputs do not align")

    rows = []
    for pid, (canonical, answer, dataset_index) in enumerate(
        zip(task.prompts, task.gold_answer, task.train_qi, strict=True)
    ):
        if not canonical.endswith("\nAnswer:"):
            raise ValueError(f"canonical prompt {pid} does not end in 'Answer:'")
        proposal = build_proposal_prompt(canonical, answer, proposal_prompt)
        injected_phrase = f"correct final answer is {answer}"
        canonical_has_injected_answer = injected_phrase in canonical
        proposal_has_injected_answer = injected_phrase in proposal
        if canonical_has_injected_answer:
            raise ValueError(f"canonical prompt {pid} contains the proposal-only answer hint")
        if proposal_prompt == "question":
            if proposal != canonical or proposal_has_injected_answer:
                raise ValueError("question-only proposal changed the canonical prompt")
        elif proposal == canonical or not proposal_has_injected_answer:
            raise ValueError("answer-conditioned proposal did not inject the gold answer")
        rows.append(
            {
                "pid": pid,
                "dataset_train_index": int(dataset_index),
                "gold_answer": str(answer),
                "canonical_prompt": canonical,
                "canonical_prompt_sha256": _sha256(canonical),
                "proposal_prompt": proposal,
                "proposal_prompt_sha256": _sha256(proposal),
                "proposal_differs_from_canonical": proposal != canonical,
                "canonical_contains_proposal_answer_hint": canonical_has_injected_answer,
                "proposal_contains_gold_answer_hint": proposal_has_injected_answer,
            }
        )

    return {
        "schema_version": PROMPT_CONTRACT_SCHEMA_VERSION,
        "method": str(method),
        "tag": str(tag),
        "training_seed": int(seed),
        "task_seed": int(seed),
        "proposal_prompt_mode": str(proposal_prompt),
        "answer_event_mode": str(answer_event_mode),
        "answer_target_termination": str(answer_target_termination),
        "shot_dataset_train_indices": [int(value) for value in task.shot_qi],
        "training_reconstruction": {
            "proposal_instruction_removed": True,
            "generated_answer_suffix_removed": True,
            "canonical_context_reused": True,
            "latent_factor": "sampled rationale tokens through the terminal #### marker",
            "answer_factor": (
                "teacher-forced gold answer followed by tokenizer EOS"
                if answer_target_termination == "eos"
                else "teacher-forced gold answer"
            ),
            "joint_mstep_row": (
                "canonical_prompt + latent_factor + answer_factor"
            ),
        },
        "rows": rows,
    }


def write_prompt_contract(path: str | Path, payload: dict[str, Any]) -> Path:
    """Atomically write a deterministic compressed prompt manifest."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(
        f".{target.name}.{os.getpid()}.{secrets.token_hex(6)}.tmp"
    )
    encoded = json.dumps(
        payload,
        sort_keys=True,
        ensure_ascii=True,
        separators=(",", ":"),
    ).encode("utf-8")
    try:
        with temporary.open("xb") as raw:
            with gzip.GzipFile(
                filename="", fileobj=raw, mode="wb", mtime=0
            ) as stream:
                stream.write(encoded)
            raw.flush()
            os.fsync(raw.fileno())
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return target
