#!/usr/bin/env python3
"""Analyse the frozen persistent-support L2R bridge.

The script is intentionally outcome-independent: cell identities, paired
contrasts, metrics, and release gates are fixed before the array completes.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from analysis.analyze_barber_eos_followup_pilots import (
    attach_derived_pass8,
    build_constant_baseline_summaries,
    build_summaries,
    load_cells,
    load_pass8,
    load_responsibility_diagnostics,
    paired_effects,
)


RUN_ID = "a74c1e6b"
SEEDS = (31, 47, 73)
CELLS = (
    "CTRL-base",
    "Q5-U-Joint",
    "PM-Joint",
    "PM-ACIS",
    "Q5-U-Answer",
    "Q5-U-Rationale",
)
TAG_RE = re.compile(
    r"_(CTRL-base|Q5-U-Joint|PM-Joint|PM-ACIS|Q5-U-Answer|Q5-U-Rationale)_seed(\d+)$"
)
CONTRASTS = (
    ("PM-Joint", "Q5-U-Joint", "support_measure"),
    ("PM-ACIS", "PM-Joint", "proposal_correction"),
    ("PM-ACIS", "Q5-U-Joint", "overall_challenger"),
    ("Q5-U-Answer", "Q5-U-Joint", "answer_only_mstep"),
    ("Q5-U-Rationale", "Q5-U-Joint", "rationale_only_mstep"),
    ("Q5-U-Joint", "CTRL-base", "joint_vs_frozen"),
)


def _gate(
    effects: dict[str, np.ndarray],
    *,
    low_ess: dict[int, float],
) -> dict[str, bool]:
    """Apply the preregistered PM-ACIS pilot gates."""

    immediate = effects["proposal_correction"]
    overall = effects["overall_challenger"]
    gates = {
        "finite_proposal_identity": True,
        "ESS_above_one_over_16_in_at_least_half_of_rounds_per_seed": (
            set(low_ess) == set(SEEDS)
            and all(value <= 0.5 for value in low_ess.values())
        ),
        "strict_AUC_positive_in_two_of_three_seeds_vs_PM_Joint": (
            int(np.sum(immediate["strict_auc"] > 0)) >= 2
        ),
        "strict_AUC_within_3pp_of_Q5_U_Joint": (
            float(np.mean(overall["strict_auc"])) >= -0.03
        ),
        "extracted_AUC_within_1pp_of_PM_Joint": (
            float(np.mean(immediate["legacy_auc"])) >= -0.01
        ),
        "natural_EOS_final_within_2pp_of_PM_Joint": (
            float(np.mean(immediate["natural_eos_final"])) >= -0.02
        ),
        "token_limit_final_not_over_2pp_worse_than_PM_Joint": (
            float(np.mean(immediate["hit_max_final"])) <= 0.02
        ),
    }
    gates["release_PM_ACIS_confirmation"] = all(gates.values())
    return gates


def analyse(artifact_dir: Path, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    cells = load_cells(
        artifact_dir,
        expected_run_id=RUN_ID,
        cells=CELLS,
        tag_re=TAG_RE,
        require_non_access=True,
    )
    baseline = cells[cells["cell"] == "CTRL-base"].copy()
    trained = cells[cells["cell"] != "CTRL-base"].copy()

    base_summaries = build_constant_baseline_summaries(baseline)
    base_summaries = attach_derived_pass8(
        base_summaries,
        load_pass8(
            baseline,
            artifact_dir,
            expected_run_id=RUN_ID,
            require_non_access=True,
        ),
    )
    curves, trained_summaries = build_summaries(
        trained,
        artifact_dir,
        baseline,
    )
    trained_summaries = attach_derived_pass8(
        trained_summaries,
        load_pass8(
            trained,
            artifact_dir,
            expected_run_id=RUN_ID,
            require_non_access=True,
        ),
    )
    summaries = pd.concat(
        [base_summaries, trained_summaries],
        ignore_index=True,
    )

    contrast_rows = []
    effects: dict[str, dict[str, np.ndarray]] = {}
    for index, (treatment, control, name) in enumerate(CONTRASTS):
        table, values = paired_effects(
            summaries,
            treatment=treatment,
            control=control,
            bootstrap_draws=50_000,
            bootstrap_seed=20260802 + 100 * index,
        )
        table.insert(0, "contrast", name)
        contrast_rows.append(table)
        effects[name] = values
    contrasts = pd.concat(contrast_rows, ignore_index=True)

    responsibility, low_ess = load_responsibility_diagnostics(
        trained,
        artifact_dir,
        importance_cell="PM-ACIS",
    )
    gates = _gate(effects, low_ess=low_ess)

    curves.to_csv(out_dir / "learning_curves.csv", index=False)
    summaries.to_csv(out_dir / "seed_summaries.csv", index=False)
    contrasts.to_csv(out_dir / "paired_contrasts.csv", index=False)
    responsibility.to_csv(out_dir / "responsibility_diagnostics.csv", index=False)
    decision = {
        "run_id": RUN_ID,
        "seeds": list(SEEDS),
        "official_test_used": False,
        "low_ESS_round_fraction_by_seed": {
            str(seed): value for seed, value in low_ess.items()
        },
        "gates": gates,
        "interpretation": (
            "At most one primary bridge challenger may advance. M-step-only "
            "cells remain diagnostics until separately confirmed."
        ),
    }
    (out_dir / "decision.json").write_text(
        json.dumps(decision, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return decision


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact_dir", type=Path)
    parser.add_argument("out_dir", type=Path)
    args = parser.parse_args()
    decision = analyse(args.artifact_dir.resolve(), args.out_dir.resolve())
    print(json.dumps(decision, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
