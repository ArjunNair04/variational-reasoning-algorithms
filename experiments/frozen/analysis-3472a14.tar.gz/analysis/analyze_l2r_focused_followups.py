#!/usr/bin/env python3
"""Analyse the frozen reader/ESS closure or posterior-credit pilot.

This analyser is frozen while both Beaker arrays are user-held and before any
outcome is inspected.  The paired training seed is the independent unit.
Checkpoint rounds and validation questions are repeated observations within a
seed.  The official GSM8K test split is never loaded or licensed by this file.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from analysis.analyze_barber_eos_repair import (
    _require_validation_non_access,
    exact_sign_flip_p,
    holm_adjust,
)
from analysis.analyze_barber_source_programme import paired_bootstrap, verify_mirror
from analysis.analyze_l2r_common_protocol_factorial import (
    BASE_CELL,
    CHECKPOINT_ROUNDS,
    CURVE_METRICS,
    _cell_seed_from_tag,
    _finite_float,
    _finite_mean,
    _nested,
    _normalized_auc,
    _optional_float,
    _read_json,
    _read_jsonl_gz,
    _require_record_non_access,
    _single_artifact,
)


@dataclass(frozen=True)
class StudySpec:
    name: str
    run_id: str
    cells: tuple[str, ...]
    seeds: tuple[int, ...]
    trained_cells: int
    primary_control: str

    @property
    def task_count(self) -> int:
        return len(self.cells) * len(self.seeds)


STUDIES = {
    "d2d17e2a": StudySpec(
        name="reader_ess_closure",
        run_id="d2d17e2a",
        cells=(
            BASE_CELL,
            "MOVING-ESS0",
            "FROZEN-ESS0",
            "MOVING-ESS50",
            "FROZEN-ESS50",
        ),
        seeds=(257, 263, 271, 277, 293, 307, 311),
        trained_cells=28,
        primary_control="MOVING-ESS0",
    ),
    "da48c781": StudySpec(
        name="posterior_credit_pilot",
        run_id="da48c781",
        cells=(
            BASE_CELL,
            "ANSWER-WEIGHTED",
            "CENTERED-TRACE",
            "SEGMENT-FLOW",
            "RLOO",
        ),
        seeds=(313, 317, 331),
        trained_cells=12,
        primary_control="ANSWER-WEIGHTED",
    ),
}


def load_design(config_path: Path) -> tuple[dict[str, Any], StudySpec, pd.DataFrame]:
    """Load and fail closed on the exact registered five-cell design."""

    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(config, dict) or str(config.get("run_id")) not in STUDIES:
        raise ValueError("configuration is not a registered focused follow-up")
    spec = STUDIES[str(config["run_id"])]
    defaults = dict(config.get("defaults") or {})
    diagnostic = dict(config.get("diagnostic") or {})
    fixed = dict(diagnostic.get("fixed_contract") or {})
    if tuple(defaults.get("seed_values") or ()) != spec.seeds:
        raise ValueError("registered seed set changed")
    if defaults.get("eval_partition") != "validation":
        raise ValueError("evaluation must use the train-derived validation partition")
    if fixed.get("official_test_used") is not False:
        raise ValueError("configuration does not seal the official test split")
    if tuple(defaults.get("eval_rounds") or ()) != CHECKPOINT_ROUNDS:
        raise ValueError("checkpoint schedule changed")
    if int(defaults.get("rounds", -1)) != 32 or int(defaults.get("n_test", -1)) != 400:
        raise ValueError("round count or development validation size changed")
    for key, expected in {
        "G": 8,
        "prompts": 128,
        "shots": 3,
        "lora_r": 16,
        "lora_alpha": 32,
        "lora_target_set": "attention_mlp",
        "answer_event_mode": "strict_terminal_marker",
    }.items():
        if defaults.get(key) != expected:
            raise ValueError(f"fixed common-protocol setting {key} changed")

    algos = config.get("algos") or {}
    rows = [
        {
            "cell": str((algos.get("base") or {}).get("cell_id")),
            "trainer_method": "base",
            "algorithm_profile": None,
            "latent_mstep_objective": None,
            "responsibility_answer_policy": None,
            "responsibility_ess_floor": math.nan,
        }
    ]
    for trainer in ("AC-ALG1", "RLOO"):
        variants = algos.get(trainer) or []
        if not isinstance(variants, list):
            raise ValueError(f"{trainer}: variants must be a list")
        for variant in variants:
            rows.append(
                {
                    "cell": str(variant.get("cell_id")),
                    "trainer_method": trainer,
                    "algorithm_profile": variant.get("algorithm_profile"),
                    "latent_mstep_objective": variant.get("latent_mstep_objective"),
                    "responsibility_answer_policy": variant.get(
                        "responsibility_answer_policy"
                    ),
                    "responsibility_ess_floor": variant.get(
                        "responsibility_ess_floor", math.nan
                    ),
                }
            )
    design = pd.DataFrame(rows)
    if tuple(design["cell"].astype(str)) != spec.cells:
        raise ValueError("five-cell order or identity changed")

    trained = design[design["trainer_method"] == "AC-ALG1"].set_index("cell")
    if spec.name == "reader_ess_closure":
        expected_axes = {
            "MOVING-ESS0": ("current", 0.0),
            "FROZEN-ESS0": ("frozen_base", 0.0),
            "MOVING-ESS50": ("current", 0.5),
            "FROZEN-ESS50": ("frozen_base", 0.5),
        }
        for cell, (reader, floor) in expected_axes.items():
            row = trained.loc[cell]
            if row["algorithm_profile"] != "l2r_reader_ess_closure":
                raise ValueError(f"{cell}: closure profile changed")
            if row["responsibility_answer_policy"] != reader or not math.isclose(
                float(row["responsibility_ess_floor"]), floor
            ):
                raise ValueError(f"{cell}: registered reader/ESS coordinate changed")
    else:
        expected_objectives = {
            "ANSWER-WEIGHTED": "joint",
            "CENTERED-TRACE": "centered_trace_answer",
            "SEGMENT-FLOW": "segment_responsibility_flow",
        }
        for cell, objective in expected_objectives.items():
            row = trained.loc[cell]
            if row["algorithm_profile"] != "l2r_credit_pilot":
                raise ValueError(f"{cell}: credit-pilot profile changed")
            if row["latent_mstep_objective"] != objective:
                raise ValueError(f"{cell}: registered credit objective changed")
        if bool(defaults.get("training_diagnostics_trace_tape")) is not True:
            raise ValueError("credit pilot must retain the audit trace tape")
    return config, spec, design


def verify_provenance(
    artifact_dir: Path,
    config_path: Path,
    marker_path: Path,
    spec: StudySpec,
    *,
    expected_commit: str,
    expected_source_job: str,
) -> dict[str, Any]:
    """Bind every task to the structured marker and immutable execution."""

    config_sha = hashlib.sha256(config_path.read_bytes()).hexdigest()
    marker = _read_json(marker_path)
    expected_marker = {
        "schema_version": 1,
        "status": "ok",
        "run_id": spec.run_id,
        "execution_commit": expected_commit,
        "configuration_sha256": config_sha,
        "source_job_id": expected_source_job,
    }
    for key, expected in expected_marker.items():
        if marker.get(key) != expected:
            raise ValueError(f"validator marker {key} mismatch")

    expected_coordinates = {
        (cell, seed): cell_index * len(spec.seeds) + seed_index + 1
        for cell_index, cell in enumerate(spec.cells)
        for seed_index, seed in enumerate(spec.seeds)
    }
    seen_coordinates: set[tuple[str, int]] = set()
    seen_fingerprints: set[str] = set()
    sweeps = sorted(artifact_dir.glob("sweep_*.csv"))
    if len(sweeps) != spec.task_count:
        raise ValueError(
            f"expected {spec.task_count} sweep files, found {len(sweeps)}"
        )
    for path in sweeps:
        frame = pd.read_csv(path)
        if len(frame) != 1:
            raise ValueError(f"{path.name}: expected one sweep row")
        row = frame.iloc[0]
        if str(row.get("run_id")) != spec.run_id:
            raise ValueError(f"{path.name}: run-ID mismatch")
        params_values = [
            value
            for value in frame.get("params", pd.Series(dtype=object)).tolist()
            if isinstance(value, str) and value.strip()
        ]
        if not params_values:
            raise ValueError(f"{path.name}: missing parameter blob")
        params = json.loads(params_values[0])
        if str(params.get("run_id")) != spec.run_id:
            raise ValueError(f"{path.name}: parameter run-ID mismatch")
        cell, seed = _cell_seed_from_tag(path.stem, spec.cells)
        coordinate = (cell, seed)
        if coordinate not in expected_coordinates or coordinate in seen_coordinates:
            raise ValueError(f"{path.name}: duplicate or unregistered coordinate")
        seen_coordinates.add(coordinate)
        observed_commit = str((params.get("env") or {}).get("commit", ""))
        if len(observed_commit) < 7 or not expected_commit.startswith(observed_commit):
            raise ValueError(f"{path.name}: execution commit mismatch")
        fingerprint = str(row.get("cell_fingerprint", ""))
        if not fingerprint or fingerprint in seen_fingerprints:
            raise ValueError(f"{path.name}: missing or duplicate cell fingerprint")
        seen_fingerprints.add(fingerprint)
    if seen_coordinates != set(expected_coordinates):
        raise ValueError("sweep cell/seed coverage is incomplete")
    return {
        **expected_marker,
        "task_count": spec.task_count,
        "official_test_used": False,
        "official_test_non_access_verified": True,
    }


def load_cell_results(
    artifact_dir: Path,
    spec: StudySpec,
    *,
    require_passk_non_access: bool = True,
) -> pd.DataFrame:
    """Load all terminal summaries with exact paired cell/seed coverage."""

    rows: list[dict[str, Any]] = []
    for path in sorted(artifact_dir.glob("cell_result_*.json")):
        payload = _read_json(path)
        identity = payload.get("identity") or {}
        result = payload.get("result") or {}
        if str(identity.get("run_id")) != spec.run_id or str(
            result.get("run_id")
        ) != spec.run_id:
            raise ValueError(f"{path.name}: run-ID mismatch")
        cell, seed = _cell_seed_from_tag(str(identity.get("tag")), spec.cells)
        if int(identity.get("seed", -1)) != seed:
            raise ValueError(f"{path.name}: identity seed disagrees with tag")
        _require_validation_non_access(result, context=path.name, prefix="eval")
        if require_passk_non_access:
            _require_validation_non_access(result, context=path.name, prefix="passk")
        row: dict[str, Any] = {
            "cell": cell,
            "seed": seed,
            "tag": str(identity["tag"]),
            "seconds": _finite_float(result.get("secs"), context=f"{path.name}/secs"),
            "accelerator_hours": _optional_float(
                result.get("accelerator_hours"),
                context=f"{path.name}/accelerator_hours",
            ),
            "generated_tokens": _optional_float(
                result.get("generated_tokens"),
                context=f"{path.name}/generated_tokens",
            ),
            "backward_tokens": _optional_float(
                result.get("backward_tokens"),
                context=f"{path.name}/backward_tokens",
            ),
        }
        for metric, key in CURVE_METRICS.items():
            row[f"{metric}_result_final"] = _finite_float(
                result.get(key), context=f"{path.name}/{key}"
            )
        rows.append(row)
    table = pd.DataFrame(rows)
    expected = {(cell, seed) for cell in spec.cells for seed in spec.seeds}
    observed = set(zip(table.get("cell", []), table.get("seed", []), strict=True))
    if observed != expected:
        raise ValueError(
            f"cell/seed mismatch; missing={sorted(expected-observed)}, "
            f"extra={sorted(observed-expected)}"
        )
    if table.duplicated(["cell", "seed"]).any():
        raise ValueError("duplicate cell/seed terminal result")
    return table.sort_values(["cell", "seed"]).reset_index(drop=True)


def build_curves(
    artifact_dir: Path, cells: pd.DataFrame, spec: StudySpec
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build paired round-0-to-32 curves and seed-level summaries."""

    base = cells[cells["cell"] == BASE_CELL].set_index("seed")
    points: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    for row in cells.to_dict("records"):
        cell = str(row["cell"])
        seed = int(row["seed"])
        base_row = base.loc[seed]
        rounds = [0]
        series = {
            metric: [float(base_row[f"{metric}_result_final"])]
            for metric in CURVE_METRICS
        }
        if cell == BASE_CELL:
            rounds.extend(CHECKPOINT_ROUNDS)
            for metric in CURVE_METRICS:
                series[metric].extend(
                    [float(row[f"{metric}_result_final"])] * len(CHECKPOINT_ROUNDS)
                )
        else:
            path = _single_artifact(
                artifact_dir,
                f"checkpoint_eval_*__{row['tag']}__*.jsonl.gz",
                f"{cell}/{seed}",
            )
            checkpoints = _read_jsonl_gz(path)
            observed_rounds = tuple(
                int(checkpoint.get("completed_rounds", -1))
                for checkpoint in checkpoints
            )
            if observed_rounds != CHECKPOINT_ROUNDS:
                raise ValueError(f"{path.name}: checkpoint schedule mismatch")
            rounds.extend(observed_rounds)
            for checkpoint in checkpoints:
                records = checkpoint.get("records") or []
                if len(records) != 400:
                    raise ValueError(f"{path.name}: expected 400 checkpoint records")
                for index, record in enumerate(records):
                    _require_record_non_access(
                        record,
                        context=(
                            f"{path.name}/round{checkpoint['completed_rounds']}/"
                            f"record{index}"
                        ),
                    )
                metrics = checkpoint.get("metrics") or {}
                for metric, key in CURVE_METRICS.items():
                    series[metric].append(
                        _finite_float(
                            metrics.get(key),
                            context=(
                                f"{path.name}/round{checkpoint['completed_rounds']}/{key}"
                            ),
                        )
                    )
        for metric in CURVE_METRICS:
            if not math.isclose(
                series[metric][-1],
                float(row[f"{metric}_result_final"]),
                abs_tol=1e-12,
            ):
                raise ValueError(f"{cell}/{seed}: checkpoint and terminal disagree")
        for position, completed_rounds in enumerate(rounds):
            points.append(
                {
                    "cell": cell,
                    "seed": seed,
                    "completed_rounds": completed_rounds,
                    **{metric: values[position] for metric, values in series.items()},
                }
            )
        late_positions = [index for index, value in enumerate(rounds) if value >= 8]
        summary: dict[str, Any] = {"cell": cell, "seed": seed}
        for metric, values in series.items():
            summary[f"{metric}_auc"] = _normalized_auc(values, rounds)
            summary[f"{metric}_final"] = float(values[-1])
        summary["late_peak_extracted"] = float(
            max(series["extracted"][index] for index in late_positions)
        )
        summary["late_peak_to_final_extracted_drop"] = (
            summary["late_peak_extracted"] - summary["extracted_final"]
        )
        summaries.append(summary)
    return pd.DataFrame(points), pd.DataFrame(summaries)


def load_pass8(artifact_dir: Path, cells: pd.DataFrame) -> pd.DataFrame:
    """Independently derive pass@8 from the 100 question-level records."""

    rows: list[dict[str, Any]] = []
    for row in cells.to_dict("records"):
        path = _single_artifact(
            artifact_dir,
            f"passk_gsm8k__{row['tag']}__*.json",
            f"{row['cell']}/{row['seed']}",
        )
        payload = _read_json(path)
        _require_validation_non_access(payload, context=path.name, prefix="passk")
        records = payload.get("records") or []
        if len(records) != 100 or any(record.get("k") != 8 for record in records):
            raise ValueError(f"{path.name}: expected 100 pass@8 records")
        for index, record in enumerate(records):
            _require_record_non_access(record, context=f"{path.name}/record{index}")
        derived = float(np.mean([int(record.get("n_correct", 0)) > 0 for record in records]))
        reported = _finite_float(payload.get("pass8"), context=f"{path.name}/pass8")
        if not math.isclose(derived, reported, abs_tol=1e-12):
            raise ValueError(f"{path.name}: reported pass@8 disagrees with records")
        rows.append({"cell": row["cell"], "seed": row["seed"], "pass8_final": derived})
    return pd.DataFrame(rows)


def _question_trace_groups(record: Mapping[str, Any]) -> list[list[Mapping[str, Any]]]:
    traces = _nested(record, "responsibilities", "traces") or []
    grouped: dict[tuple[str, int], list[Mapping[str, Any]]] = defaultdict(list)
    for trace in traces:
        if trace.get("partition") != "answer_only":
            continue
        grouped[(str(trace.get("partition")), int(trace.get("pid", -1)))].append(trace)
    if not grouped:
        steps = _nested(record, "inner_m_step", "steps") or []
        verified_no_update = bool(
            not traces
            and len(steps) == 4
            and all(
                step.get("status") == "rejected"
                and step.get("rejection_reason") == "no_gradient"
                and int(_nested(step, "support", "active_questions") or 0) == 0
                and int(_nested(step, "support", "active_traces") or 0) == 0
                and int(_nested(step, "support", "backward_tokens") or 0) == 0
                for step in steps
            )
            and int(_nested(record, "objective", "gradient_steps_this_round") or 0) == 0
            and int(_nested(record, "compute", "tokens", "backward") or 0) == 0
        )
        if verified_no_update:
            return []
        raise ValueError("diagnostics omit answer-only responsibility traces")
    return list(grouped.values())


def _softmax(values: Sequence[float]) -> np.ndarray:
    logits = np.asarray(values, dtype=float)
    if logits.ndim != 1 or len(logits) < 1 or not np.isfinite(logits).all():
        raise ValueError("responsibility logits must be finite and non-empty")
    shifted = logits - float(np.max(logits))
    weights = np.exp(shifted)
    return weights / float(np.sum(weights))


def _validate_question_weights(traces: Sequence[Mapping[str, Any]]) -> np.ndarray:
    weights = np.asarray([trace.get("responsibility") for trace in traces], dtype=float)
    if not np.isfinite(weights).all() or np.any(weights < 0):
        raise ValueError("post-floor responsibilities must be finite and nonnegative")
    if not math.isclose(float(weights.sum()), 1.0, abs_tol=1e-6):
        raise ValueError("question responsibilities do not sum to one")
    return weights


def load_mechanisms(
    artifact_dir: Path,
    cells: pd.DataFrame,
    design: pd.DataFrame,
    spec: StudySpec,
) -> pd.DataFrame:
    """Verify ESS and credit identities directly from round diagnostics."""

    ac_cells = set(
        design[design["trainer_method"] == "AC-ALG1"]["cell"].astype(str)
    )
    rows: list[dict[str, Any]] = []
    for cell_row in cells[cells["cell"].isin(ac_cells)].to_dict("records"):
        cell = str(cell_row["cell"])
        seed = int(cell_row["seed"])
        path = _single_artifact(
            artifact_dir,
            f"training_diagnostics_*__{cell_row['tag']}__*.jsonl.gz",
            f"{cell}/{seed}",
        )
        records = _read_jsonl_gz(path)
        if len(records) != 32:
            raise ValueError(f"{path.name}: expected 32 diagnostic rounds")
        completed = tuple(
            int(record.get("completed_rounds", int(record.get("round", -1)) + 1))
            for record in records
        )
        if completed != tuple(range(1, 33)):
            raise ValueError(f"{path.name}: diagnostic round schedule mismatch")
        if any(str(record.get("run_id")) != spec.run_id for record in records):
            raise ValueError(f"{path.name}: diagnostic run-ID mismatch")

        pre_ess: list[float] = []
        post_ess: list[float] = []
        floor_activations: list[float] = []
        maxima: list[float] = []
        centered_trace_sum_residuals: list[float] = []
        centered_answer_sum_residuals: list[float] = []
        segment_zero_sum_residuals: list[float] = []
        segment_terminal_residuals: list[float] = []
        observed_segment_counts: set[int] = set()
        active_mechanism_rounds = 0
        verified_no_gradient_rounds = 0
        accepted_gradient_steps = 0
        for record in records:
            groups = _question_trace_groups(record)
            if groups:
                active_mechanism_rounds += 1
            else:
                verified_no_gradient_rounds += 1
            accepted_gradient_steps += int(
                _nested(record, "objective", "gradient_steps_this_round") or 0
            )
            for traces in groups:
                weights = _validate_question_weights(traces)
                count = len(traces)
                post_ess.append(float(1.0 / np.sum(weights**2) / count))
                maxima.append(float(np.max(weights)))
                temperatures = np.asarray(
                    [trace.get("responsibility_temperature_used") for trace in traces],
                    dtype=float,
                )
                if not np.isfinite(temperatures).all():
                    raise ValueError("responsibility temperature is missing")
                floor_activations.append(float(np.max(temperatures) > 1.0 + 1e-10))

                logits = [trace.get("responsibility_logit") for trace in traces]
                raw = _softmax([float(value) for value in logits])
                pre_ess.append(float(1.0 / np.sum(raw**2) / count))

                if cell == "CENTERED-TRACE":
                    centered_trace_sum_residuals.append(
                        abs(float(np.sum(weights - 1.0 / count)))
                    )
                    centered_answer_sum_residuals.append(abs(float(np.sum(weights) - 1.0)))
                if cell == "SEGMENT-FLOW":
                    deltas = []
                    for trace in traces:
                        values = trace.get("segment_responsibility_deltas")
                        if not isinstance(values, list) or len(values) != 4:
                            raise ValueError(
                                "segment-flow trace omits four posterior deltas"
                            )
                        numeric = np.asarray(values, dtype=float)
                        if not np.isfinite(numeric).all():
                            raise ValueError("segment-flow deltas are nonfinite")
                        deltas.append(numeric)
                    matrix = np.stack(deltas)
                    observed_segment_counts.add(int(matrix.shape[1]))
                    segment_zero_sum_residuals.extend(
                        abs(float(value)) for value in np.sum(matrix, axis=0)
                    )
                    reconstructed = 1.0 / count + np.sum(matrix, axis=1)
                    segment_terminal_residuals.extend(
                        abs(float(value))
                        for value in reconstructed - weights
                    )
        tolerance = 1e-5
        centered_identity_pass = None
        if cell == "CENTERED-TRACE":
            centered_identity_pass = bool(
                centered_trace_sum_residuals
                and max(centered_trace_sum_residuals) <= tolerance
                and max(centered_answer_sum_residuals) <= tolerance
            )
            if not centered_identity_pass:
                raise ValueError("centered trace/answer coefficient identity failed")
        segment_identity_pass = None
        if cell == "SEGMENT-FLOW":
            segment_identity_pass = bool(
                observed_segment_counts == {4}
                and segment_zero_sum_residuals
                and max(segment_zero_sum_residuals) <= tolerance
                and max(segment_terminal_residuals) <= tolerance
            )
            if not segment_identity_pass:
                raise ValueError("segment responsibility-flow identity failed")
        rows.append(
            {
                "cell": cell,
                "seed": seed,
                "diagnostic_rounds": len(records),
                "active_mechanism_rounds": active_mechanism_rounds,
                "verified_no_gradient_rounds": verified_no_gradient_rounds,
                "active_mechanism_round_fraction": active_mechanism_rounds / len(records),
                "accepted_gradient_steps": accepted_gradient_steps,
                "mean_pre_floor_ess_fraction": _finite_mean(pre_ess),
                "mean_post_floor_ess_fraction": _finite_mean(post_ess),
                "ess_floor_activation_fraction": _finite_mean(floor_activations),
                "mean_max_responsibility": _finite_mean(maxima),
                "centered_identity_pass": centered_identity_pass,
                "centered_max_trace_sum_residual": (
                    max(centered_trace_sum_residuals)
                    if centered_trace_sum_residuals
                    else math.nan
                ),
                "centered_max_answer_sum_residual": (
                    max(centered_answer_sum_residuals)
                    if centered_answer_sum_residuals
                    else math.nan
                ),
                "segment_identity_pass": segment_identity_pass,
                "segment_count": (
                    next(iter(observed_segment_counts))
                    if observed_segment_counts == {4}
                    else math.nan
                ),
                "segment_max_zero_sum_residual": (
                    max(segment_zero_sum_residuals)
                    if segment_zero_sum_residuals
                    else math.nan
                ),
                "segment_max_terminal_residual": (
                    max(segment_terminal_residuals)
                    if segment_terminal_residuals
                    else math.nan
                ),
            }
        )
    return pd.DataFrame(rows).sort_values(["cell", "seed"]).reset_index(drop=True)


def _paired_difference(
    summaries: pd.DataFrame,
    treatment: str,
    control: str,
    metric: str,
    seeds: Sequence[int],
) -> pd.Series:
    pivot = summaries.pivot(index="seed", columns="cell", values=metric).reindex(seeds)
    if pivot[[treatment, control]].isna().any().any():
        raise ValueError(f"incomplete paired contrast {treatment} minus {control}")
    return pivot[treatment] - pivot[control]


def _contrast_record(
    name: str,
    treatment: str,
    control: str,
    metric: str,
    differences: pd.Series,
    *,
    draws: int,
    seed: int,
    primary: bool,
) -> dict[str, Any]:
    mean, low, high = paired_bootstrap(differences.to_numpy(float), draws, seed)
    return {
        "contrast": name,
        "treatment": treatment,
        "control": control,
        "metric": metric,
        "primary": primary,
        "observational_unit": "paired training seed",
        "n_seeds": int(len(differences)),
        "mean_difference": mean,
        "ci95_low": low,
        "ci95_high": high,
        "mean_difference_pp": 100.0 * mean,
        "positive_seeds": int((differences > 0).sum()),
        "exact_sign_flip_p": exact_sign_flip_p(differences.to_numpy(float)),
        "seed_differences": json.dumps(
            {str(int(index)): float(value) for index, value in differences.items()},
            sort_keys=True,
        ),
    }


def analyse_closure(
    summaries: pd.DataFrame,
    spec: StudySpec,
    *,
    draws: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Apply the registered stress-reproduction, 2x2 and rescue rules."""

    treatments = ("FROZEN-ESS0", "MOVING-ESS50", "FROZEN-ESS50")
    contrasts: list[dict[str, Any]] = []
    raw_primary: dict[str, float] = {}
    for offset, treatment in enumerate(treatments):
        differences = _paired_difference(
            summaries,
            treatment,
            spec.primary_control,
            "extracted_auc",
            spec.seeds,
        )
        record = _contrast_record(
            f"{treatment} minus {spec.primary_control}",
            treatment,
            spec.primary_control,
            "extracted_auc",
            differences,
            draws=draws,
            seed=seed + offset,
            primary=True,
        )
        contrasts.append(record)
        raw_primary[treatment] = float(record["exact_sign_flip_p"])
    adjusted = holm_adjust(raw_primary)
    for record in contrasts:
        record["holm_adjusted_p"] = adjusted[str(record["treatment"])]

    pivot = summaries.pivot(index="seed", columns="cell", values="extracted_auc").reindex(
        spec.seeds
    )
    interaction = (
        pivot["FROZEN-ESS50"]
        - pivot["MOVING-ESS50"]
        - pivot["FROZEN-ESS0"]
        + pivot["MOVING-ESS0"]
    )
    interaction_record = _contrast_record(
        "reader-by-ESS interaction",
        "2x2 interaction",
        "additive main effects",
        "extracted_auc",
        interaction,
        draws=draws,
        seed=seed + 100,
        primary=False,
    )
    interaction_record["holm_adjusted_p"] = math.nan
    contrasts.append(interaction_record)

    indexed = summaries.set_index(["cell", "seed"])
    stress_final = np.asarray(
        [indexed.loc[("MOVING-ESS0", value), "extracted_final"] for value in spec.seeds]
    )
    base_final = np.asarray(
        [indexed.loc[(BASE_CELL, value), "extracted_final"] for value in spec.seeds]
    )
    stress_drop = np.asarray(
        [
            indexed.loc[("MOVING-ESS0", value), "late_peak_to_final_extracted_drop"]
            for value in spec.seeds
        ]
    )
    stress_reproduced = bool(
        float(np.mean(stress_final - base_final)) < 0.0
        and float(np.mean(stress_drop)) > 0.03
    )

    gate_rows: list[dict[str, Any]] = []
    for treatment in treatments:
        auc_delta = _paired_difference(
            summaries,
            treatment,
            "MOVING-ESS0",
            "extracted_auc",
            spec.seeds,
        )
        final_delta = _paired_difference(
            summaries,
            treatment,
            BASE_CELL,
            "extracted_final",
            spec.seeds,
        )
        group = summaries[summaries["cell"] == treatment].set_index("seed").reindex(
            spec.seeds
        )
        gates = {
            "stress_cell_reproduced": stress_reproduced,
            "mean_auc_above_stress": float(auc_delta.mean()) > 0.0,
            "auc_positive_in_at_least_five_of_seven": int((auc_delta > 0).sum()) >= 5,
            "mean_final_no_worse_than_base": float(final_delta.mean()) >= 0.0,
            "mean_late_drop_at_most_3pp": float(
                group["late_peak_to_final_extracted_drop"].mean()
            )
            <= 0.03,
        }
        gate_rows.append(
            {
                "cell": treatment,
                "mean_auc_delta_vs_stress_pp": 100.0 * float(auc_delta.mean()),
                "positive_auc_seeds": int((auc_delta > 0).sum()),
                "mean_final_delta_vs_base_pp": 100.0 * float(final_delta.mean()),
                "mean_late_drop_pp": 100.0
                * float(group["late_peak_to_final_extracted_drop"].mean()),
                **gates,
                "passes_rescue_rule": all(gates.values()),
            }
        )
    decisions = {
        "stress_reproduced": stress_reproduced,
        "stress_mean_final_delta_vs_base_pp": 100.0
        * float(np.mean(stress_final - base_final)),
        "stress_mean_late_drop_pp": 100.0 * float(np.mean(stress_drop)),
        "closure_inconclusive": not stress_reproduced,
        "rescues": [
            row["cell"] for row in gate_rows if bool(row["passes_rescue_rule"])
        ],
        "primary_family": list(treatments),
        "holm_applied_only_to_primary_family": True,
    }
    return pd.DataFrame(contrasts), pd.DataFrame(gate_rows), decisions


def analyse_pilot(
    summaries: pd.DataFrame,
    spec: StudySpec,
    *,
    draws: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Apply the three-seed mechanism-pilot advancement rules."""

    contrast_specs = (
        ("CENTERED-TRACE", "ANSWER-WEIGHTED", True),
        ("SEGMENT-FLOW", "ANSWER-WEIGHTED", True),
        ("RLOO", "ANSWER-WEIGHTED", False),
        ("RLOO", BASE_CELL, False),
    )
    contrasts = []
    for offset, (treatment, control, primary) in enumerate(contrast_specs):
        differences = _paired_difference(
            summaries, treatment, control, "extracted_auc", spec.seeds
        )
        record = _contrast_record(
            f"{treatment} minus {control}",
            treatment,
            control,
            "extracted_auc",
            differences,
            draws=draws,
            seed=seed + offset,
            primary=primary,
        )
        record["holm_adjusted_p"] = math.nan
        contrasts.append(record)

    gate_rows: list[dict[str, Any]] = []
    for treatment in ("CENTERED-TRACE", "SEGMENT-FLOW"):
        auc_delta = _paired_difference(
            summaries,
            treatment,
            "ANSWER-WEIGHTED",
            "extracted_auc",
            spec.seeds,
        )
        final_delta = _paired_difference(
            summaries,
            treatment,
            BASE_CELL,
            "extracted_final",
            spec.seeds,
        )
        group = summaries[summaries["cell"] == treatment].set_index("seed").reindex(
            spec.seeds
        )
        gates = {
            "mean_auc_at_least_answer_weighted": float(auc_delta.mean()) >= 0.0,
            "auc_positive_in_at_least_two_of_three": int((auc_delta > 0).sum()) >= 2,
            "mean_final_no_worse_than_base": float(final_delta.mean()) >= 0.0,
            "mean_late_drop_at_most_3pp": float(
                group["late_peak_to_final_extracted_drop"].mean()
            )
            <= 0.03,
        }
        gate_rows.append(
            {
                "cell": treatment,
                "mean_auc_delta_vs_answer_weighted_pp": 100.0 * float(auc_delta.mean()),
                "positive_auc_seeds": int((auc_delta > 0).sum()),
                "mean_final_delta_vs_base_pp": 100.0 * float(final_delta.mean()),
                "mean_late_drop_pp": 100.0
                * float(group["late_peak_to_final_extracted_drop"].mean()),
                **gates,
                "passes_advancement_rule": all(gates.values()),
            }
        )
    passing = [row for row in gate_rows if bool(row["passes_advancement_rule"])]
    passing.sort(
        key=lambda row: (-float(row["mean_auc_delta_vs_answer_weighted_pp"]), row["cell"])
    )
    nominee = passing[0]["cell"] if passing else None
    decisions = {
        "pilot_can_establish_superiority": False,
        "novel_objectives_passing": [row["cell"] for row in passing],
        "maximum_one_confirmation_nominee": True,
        "confirmation_nominee": nominee,
        "rloo_is_descriptive_external_baseline": True,
    }
    return pd.DataFrame(contrasts), pd.DataFrame(gate_rows), decisions


def _markdown(table: pd.DataFrame) -> str:
    shown = table.copy()
    for column in shown.select_dtypes(include=["float"]).columns:
        shown[column] = shown[column].map(
            lambda value: "NA" if pd.isna(value) else f"{float(value):.4f}"
        )
    headers = [str(column) for column in shown.columns]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    lines.extend(
        "| " + " | ".join(map(str, row)) + " |"
        for row in shown.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def run_analysis(args: argparse.Namespace) -> dict[str, Any]:
    config_path = Path(args.config).resolve()
    artifact_dir = Path(args.artifact_dir).resolve()
    log_dir = Path(args.log_dir).resolve()
    out_dir = Path(args.out_dir).resolve()
    config, spec, design = load_design(config_path)
    provenance = verify_provenance(
        artifact_dir,
        config_path,
        Path(args.validator_marker).resolve(),
        spec,
        expected_commit=args.expected_execution_commit,
        expected_source_job=args.expected_source_job,
    )
    integrity = verify_mirror(
        artifact_dir,
        log_dir,
        expected_cells=spec.task_count,
        trained_cells=spec.trained_cells,
    )
    if integrity["issues"]:
        raise ValueError(f"mirror verification failed: {integrity['issues']}")

    cells = load_cell_results(artifact_dir, spec)
    curves, summaries = build_curves(artifact_dir, cells, spec)
    summaries = summaries.merge(
        load_pass8(artifact_dir, cells), on=["cell", "seed"], validate="one_to_one"
    ).merge(
        cells[
            [
                "cell",
                "seed",
                "seconds",
                "accelerator_hours",
                "generated_tokens",
                "backward_tokens",
            ]
        ],
        on=["cell", "seed"],
        validate="one_to_one",
    )
    mechanisms = load_mechanisms(artifact_dir, cells, design, spec)
    if spec.name == "reader_ess_closure":
        contrasts, gates, decisions = analyse_closure(
            summaries,
            spec,
            draws=args.bootstrap_draws,
            seed=args.bootstrap_seed,
        )
    else:
        contrasts, gates, decisions = analyse_pilot(
            summaries,
            spec,
            draws=args.bootstrap_draws,
            seed=args.bootstrap_seed,
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    curves.to_csv(out_dir / "checkpoint_curves.csv", index=False)
    summaries.to_csv(out_dir / "seed_summary.csv", index=False)
    mechanisms.to_csv(out_dir / "mechanism_summary.csv", index=False)
    contrasts.to_csv(out_dir / "paired_contrasts.csv", index=False)
    gates.to_csv(out_dir / "decision_gates.csv", index=False)
    payload = {
        "study": spec.name,
        "run_id": spec.run_id,
        "observational_unit": "paired training seed",
        "seeds": list(spec.seeds),
        "primary_metric": "normalized extracted-answer accuracy AUC, rounds 0-32",
        "late_peak_window": [8, 16, 24, 32],
        "bootstrap_draws": args.bootstrap_draws,
        "bootstrap_seed": args.bootstrap_seed,
        "official_test_used": False,
        "provenance": provenance,
        "integrity": integrity,
        "decisions": decisions,
    }
    (out_dir / "analysis_summary.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
    )
    report = [
        f"# {spec.name.replace('_', ' ').title()}",
        "",
        "The paired training seed is the independent unit. The official GSM8K test split was not used.",
        "",
        "## Decision gates",
        "",
        _markdown(gates),
        "",
        "## Paired contrasts",
        "",
        _markdown(contrasts),
        "",
        "## Frozen interpretation",
        "",
        "```json",
        json.dumps(decisions, indent=2, sort_keys=True),
        "```",
        "",
    ]
    (out_dir / "analysis.md").write_text("\n".join(report), encoding="utf-8")
    return payload


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact-dir", required=True)
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--validator-marker", required=True)
    parser.add_argument("--expected-execution-commit", required=True)
    parser.add_argument("--expected-source-job", required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=20_000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260807)
    args = parser.parse_args(argv)
    if args.bootstrap_draws < 1:
        parser.error("--bootstrap-draws must be positive")
    if len(args.expected_execution_commit) != 40:
        parser.error("--expected-execution-commit must be a full 40-character SHA")
    if not str(args.expected_source_job).isdigit():
        parser.error("--expected-source-job must be numeric")
    return args


def main(argv: Sequence[str] | None = None) -> int:
    print(json.dumps(run_analysis(parse_args(argv)), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
