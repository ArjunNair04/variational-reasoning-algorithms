#!/usr/bin/env python3
"""Fail-closed analysis for the Q5 support-reallocation experiment.

The paired training seed is the independent replicate. Final extracted Acc@1
is primary, strict final accuracy is secondary, and extracted trajectory AUC is
tertiary. Mechanism and compute metrics decide whether any gain is attributable
to the registered intervention and whether it preserves Q5's efficiency claim.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
LM_STUDY = REPOSITORY_ROOT / "lm_study"
if str(LM_STUDY) not in sys.path:
    sys.path.insert(0, str(LM_STUDY))

from run_yaml import _prepare_cells


RUN_ID = "d7c4e2b1"
RETRY_RUN_ID = "08b9d6a8"
ACCEPTED_RUN_IDS = {RUN_ID, RETRY_RUN_ID}
SEEDS = (1301, 1303, 1307)
CHECKPOINTS = (1, 2, 4, 8, 16, 24, 32)
CELL_ORDER = (
    "CTRL-base",
    "Q5-REF",
    "Q5-MORE",
    "Q5-BREADTH",
    "Q5-DIVERSE",
    "Q5-VERIFY",
)
Q5_CELLS = CELL_ORDER[1:]
CONTROL = "Q5-REF"
EXPECTED = {
    "Q5-REF": (64, 16, "fifo", "joint", "inner_step", 0, 2048),
    "Q5-MORE": (128, 32, "fifo", "joint", "inner_step", 0, 4096),
    "Q5-BREADTH": (128, 16, "fifo", "joint", "inner_step", 0, 4096),
    "Q5-DIVERSE": (
        128,
        32,
        "calculation_diverse",
        "joint",
        "inner_step",
        0,
        4096,
    ),
    "Q5-VERIFY": (64, 16, "fifo", "rollout_value", "outer_round", 1, 2048),
}
METRICS = ("final_extracted_acc1", "final_strict_acc1", "extracted_auc")


def _read_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ValueError(f"{path}: expected a JSON object")
    return value


def _read_jsonl_gz(path: Path) -> list[dict[str, Any]]:
    rows = []
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            try:
                row = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"{path}:{line_number}: invalid JSON") from error
            if not isinstance(row, dict):
                raise ValueError(f"{path}:{line_number}: expected an object")
            rows.append(row)
    return rows


def _finite(value: Any, context: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{context}: expected a finite number") from error
    if not math.isfinite(number):
        raise ValueError(f"{context}: expected a finite number")
    return number


def _mean(values: Sequence[Any]) -> float | None:
    finite = [float(value) for value in values if value is not None and math.isfinite(float(value))]
    return float(np.mean(finite)) if finite else None


def _require_no_test_access(payload: Mapping[str, Any], context: str) -> None:
    expected = {
        "eval_official_test_accessed": False,
        "eval_source_split": "train",
        "eval_dataset_splits_loaded": ["train"],
        "passk_official_test_accessed": False,
        "passk_eval_source_split": "train",
        "passk_dataset_splits_loaded": ["train"],
    }
    for field, value in expected.items():
        if payload.get(field) != value:
            raise ValueError(f"{context}: official-test boundary {field} changed")


def _require_eval_record(record: Mapping[str, Any], context: str) -> None:
    expected = {
        "official_test_accessed": False,
        "eval_source_split": "train",
        "dataset_splits_loaded": ["train"],
    }
    for field, value in expected.items():
        if record.get(field) != value:
            raise ValueError(f"{context}: evaluation provenance {field} changed")


def _artifact(root: Path, prefix: str, tag: str, method: str, seed: int, suffix: str) -> Path:
    return root / f"{prefix}_gsm8k__{tag}__{method}_s{seed}.{suffix}"


def load_design(config_path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    run_id = str(config.get("run_id")) if isinstance(config, dict) else ""
    if run_id not in ACCEPTED_RUN_IDS:
        raise ValueError("Q5 support-reallocation run ID changed")
    if run_id == RETRY_RUN_ID:
        retry_of = dict((config.get("diagnostic") or {}).get("retry_of") or {})
        if retry_of.get("run_id") != RUN_ID:
            raise ValueError("Q5 support-reallocation retry provenance changed")
    defaults = dict(config.get("defaults") or {})
    required_defaults = {
        "rounds": 32,
        "seed_values": list(SEEDS),
        "n_test": 400,
        "train_partition": "train",
        "eval_partition": "validation",
        "answer_event_mode": "strict_terminal_marker",
        "answer_target_termination": "eos",
        "evaluation_prompt": "question",
        "prompts": 128,
        "shots": 3,
        "shot_bank_size": 5,
        "question_sampling": "epoch_shuffle",
        "lora_r": 16,
        "lora_target_set": "attention_mlp",
        "eval_rounds": list(CHECKPOINTS),
    }
    for field, expected in required_defaults.items():
        if defaults.get(field) != expected:
            raise ValueError(f"default {field} changed")
    diagnostic = dict(config.get("diagnostic") or {})
    if dict(diagnostic.get("fixed_contract") or {}).get("official_test_used") is not False:
        raise ValueError("official-test prohibition missing")
    if diagnostic.get("require_protocol_outcome_diagnostics") is not True:
        raise ValueError("protocol outcome diagnostics are not required")

    cells = _prepare_cells(config, only=None, run_id=run_id, defaults=defaults)
    configured = {
        "base": [dict((config.get("algos") or {}).get("base") or {})],
        "AC-ALG1": [dict(value) for value in (config.get("algos") or {}).get("AC-ALG1", [])],
    }
    coordinates = []
    observed = set()
    for model, method, axes, base_tag in cells:
        candidates = [
            str(cell.get("cell_id") or "")
            for cell in configured.get(method, [])
            if str(cell.get("cell_id") or "") and base_tag.endswith("_" + str(cell["cell_id"]))
        ]
        if len(candidates) != 1:
            raise ValueError(f"cannot resolve registered cell from {base_tag}")
        cell_id = candidates[0]
        if cell_id not in CELL_ORDER or cell_id in observed:
            raise ValueError(f"unexpected or duplicate cell {cell_id}")
        observed.add(cell_id)
        settings = dict(axes)
        if cell_id != "CTRL-base":
            actual = (
                int(settings["batch"]),
                int(settings["G"]),
                settings["buffer_strategy"],
                settings["responsibility_score"],
                settings["responsibility_refresh"],
                int(settings["responsibility_verifier_rollouts"]),
                int(settings["batch"]) * 32,
            )
            if actual != EXPECTED[cell_id]:
                raise ValueError(f"{cell_id}: registered factor tuple changed: {actual}")
            expected_prompts = 256 if cell_id == "Q5-BREADTH" else 128
            if int(settings.get("prompts", defaults["prompts"])) != expected_prompts:
                raise ValueError(f"{cell_id}: optimization-question pool changed")
            invariant = {
                "algorithm_profile": "q5_support_reallocation",
                "iters": 1,
                "lr": 1.0e-5,
                "buffer_limit": 16,
                "buffer_semantics": "unique_set",
                "buffer_lifecycle": "persistent",
                "proposal_prompt": "answer_derive",
                "proposal_policy": "current",
                "responsibility_policy": "current",
                "responsibility_answer_policy": "current",
                "responsibility_posterior": "softmax_entropy",
                "variational_estimator": "delta_joint",
                "answer_only_em_weight": 1.0,
                "labelled_em_weight": 0.0,
                "supervised_weight": 0.0,
                "answer_target_termination": "eos",
                "lora_target_set": "attention_mlp",
            }
            for field, expected in invariant.items():
                if settings.get(field, defaults.get(field)) != expected:
                    raise ValueError(f"{cell_id}: invariant {field} changed")
        for seed in SEEDS:
            coordinates.append(
                {
                    "model": str(model),
                    "method": method,
                    "cell_id": cell_id,
                    "seed": seed,
                    "tag": f"{base_tag}_seed{seed}",
                    "settings": settings,
                }
            )
    if observed != set(CELL_ORDER) or len(coordinates) != 18:
        raise ValueError("expected one baseline and five Q5 cells across three seeds")
    return config, coordinates


def normalized_question_auc(base: np.ndarray, checkpoints: np.ndarray) -> np.ndarray:
    if checkpoints.shape != (len(CHECKPOINTS), len(base)):
        raise ValueError("checkpoint question matrix changed")
    values = np.vstack([base, checkpoints])
    rounds = np.asarray((0, *CHECKPOINTS), dtype=float)
    integrate = getattr(np, "trapezoid", None)
    if integrate is None:
        integrate = np.trapz
    return integrate(values, rounds, axis=0) / rounds[-1]


def binary_auroc(labels: Sequence[bool], scores: Sequence[float]) -> float | None:
    y = np.asarray(labels, dtype=bool)
    x = np.asarray(scores, dtype=float)
    if len(y) != len(x) or len(y) == 0 or y.all() or (~y).all() or not np.isfinite(x).all():
        return None
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty(len(x), dtype=float)
    start = 0
    while start < len(x):
        stop = start + 1
        while stop < len(x) and x[order[stop]] == x[order[start]]:
            stop += 1
        ranks[order[start:stop]] = (start + 1 + stop) / 2.0
        start = stop
    positives = int(y.sum())
    negatives = len(y) - positives
    return float((ranks[y].sum() - positives * (positives + 1) / 2) / (positives * negatives))


def expected_training_generations(
    cell_id: str,
    *,
    proposal_generations: int,
    verifier_calls: int,
) -> int:
    """Bind the runtime counter, which includes verifier rollouts for Q5-VERIFY."""
    return proposal_generations + (verifier_calls if cell_id == "Q5-VERIFY" else 0)


def _diagnostic_metrics(
    rows: Sequence[Mapping[str, Any]],
    *,
    cell_id: str,
    settings: Mapping[str, Any],
) -> dict[str, Any]:
    if len(rows) != 32:
        raise ValueError(f"{cell_id}: expected 32 diagnostic rows")
    proposals_per_round = int(settings["batch"])
    traces_per_question = int(settings["G"])
    if proposals_per_round % traces_per_question:
        raise ValueError(f"{cell_id}: proposal budget is not divisible by G")
    questions_per_round = proposals_per_round // traces_per_question
    generated = verifier_generated = backward = 0
    verifier_calls = 0
    retained_trace_opportunities = 0
    question_metrics: dict[str, list[float]] = {
        "effective_sample_size": [],
        "calculation_path_clusters": [],
        "calculation_path_effective_sample_size": [],
        "answer_correct_mass": [],
    }
    verifier_labels: list[bool] = []
    verifier_scores: list[float] = []
    for round_index, row in enumerate(rows):
        if int(row.get("round", -1)) != round_index:
            raise ValueError(f"{cell_id}: diagnostic round order changed")
        if row.get("algorithm_profile") != "q5_support_reallocation":
            raise ValueError(f"{cell_id}: profile changed in diagnostics")
        generation = dict(row.get("generation") or {})
        if generation.get("proposal_prompt") != "answer_derive":
            raise ValueError(f"{cell_id}: proposal prompt changed")
        if int(generation.get("this_round", -1)) != proposals_per_round:
            raise ValueError(f"{cell_id}: per-round proposal count changed")
        if int(generation.get("cumulative", -1)) != proposals_per_round * (round_index + 1):
            raise ValueError(f"{cell_id}: cumulative proposal count changed")
        minibatch = dict(row.get("minibatch") or {})
        pids = [int(value) for value in minibatch.get("answer_only_pids") or ()]
        if len(pids) != questions_per_round or len(set(pids)) != questions_per_round:
            raise ValueError(
                f"{cell_id}: expected {questions_per_round} distinct questions per round"
            )
        buffer = dict(row.get("buffer") or {})
        if buffer.get("strategy") != settings["buffer_strategy"]:
            raise ValueError(f"{cell_id}: buffer strategy changed")
        if int(buffer.get("limit_per_question", -1)) != 16:
            raise ValueError(f"{cell_id}: retained support limit changed")
        global_buffer_rows = int(buffer.get("rows", -1))
        active_buffer_questions = int(buffer.get("active_questions", -1))
        if (
            global_buffer_rows < 0
            or active_buffer_questions < questions_per_round
            or global_buffer_rows > active_buffer_questions * 16
        ):
            raise ValueError(
                f"{cell_id}: invalid persistent buffer summary "
                f"{(global_buffer_rows, active_buffer_questions)}"
            )
        responsibilities = dict(row.get("responsibilities") or {})
        retained_rows = len(responsibilities.get("traces") or ())
        if retained_rows > questions_per_round * 16:
            raise ValueError(f"{cell_id}: invalid active retained support size {retained_rows}")
        if retained_rows > global_buffer_rows:
            raise ValueError(f"{cell_id}: active support exceeds the persistent buffer")
        verifier = dict(responsibilities.get("verifier") or {})
        calls = int(verifier.get("calls_this_round", -1))
        traces = int(verifier.get("traces_this_round", -1))
        expected_calls = retained_rows if cell_id == "Q5-VERIFY" else 0
        if calls != expected_calls or traces != expected_calls:
            raise ValueError(
                f"{cell_id}: verifier calls/traces {(calls, traces)}, "
                f"expected {(expected_calls, expected_calls)}"
            )
        verifier_calls += calls
        retained_trace_opportunities += retained_rows
        for question in responsibilities.get("questions") or ():
            for name in question_metrics:
                value = question.get(name)
                if value is not None:
                    question_metrics[name].append(_finite(value, f"{cell_id}:{name}"))
        for trace in responsibilities.get("traces") or ():
            value = trace.get("verifier_value")
            label = trace.get("proposal_correct")
            if value is not None and label is not None:
                verifier_scores.append(_finite(value, f"{cell_id}:verifier_value"))
                verifier_labels.append(bool(label))
        tokens = dict((row.get("compute") or {}).get("tokens") or {})
        generated += int(_finite(tokens.get("generated"), f"{cell_id}:generated"))
        verifier_generated += int(
            _finite(tokens.get("verifier_generated"), f"{cell_id}:verifier_generated")
        )
        backward += int(_finite(tokens.get("backward"), f"{cell_id}:backward"))
    return {
        "proposal_generated_tokens": generated,
        "verifier_generated_tokens": verifier_generated,
        "total_generated_tokens": generated + verifier_generated,
        "backward_tokens": backward,
        "verifier_calls": verifier_calls,
        "retained_trace_opportunities": retained_trace_opportunities,
        "mean_effective_sample_size": _mean(question_metrics["effective_sample_size"]),
        "mean_calculation_path_clusters": _mean(question_metrics["calculation_path_clusters"]),
        "mean_calculation_path_effective_sample_size": _mean(
            question_metrics["calculation_path_effective_sample_size"]
        ),
        "mean_answer_correct_mass": _mean(question_metrics["answer_correct_mass"]),
        "verifier_auroc_vs_proposal_correct": binary_auroc(verifier_labels, verifier_scores),
        "verifier_brier_vs_proposal_correct": (
            float(np.mean((np.asarray(verifier_scores) - np.asarray(verifier_labels, dtype=float)) ** 2))
            if verifier_scores else None
        ),
    }


def load_results(
    artifact_dir: Path,
    config_path: Path,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    config, coordinates = load_design(config_path)
    run_id = str(config["run_id"])
    baselines: dict[int, dict[str, Any]] = {}
    question_rows: list[dict[str, Any]] = []
    seed_rows: list[dict[str, Any]] = []
    expected_results = set()

    for coordinate in coordinates:
        if coordinate["cell_id"] != "CTRL-base":
            continue
        seed = int(coordinate["seed"])
        tag = str(coordinate["tag"])
        result_path = _artifact(artifact_dir, "cell_result", tag, "base", seed, "json")
        eval_path = _artifact(artifact_dir, "eval", tag, "base", seed, "json")
        for path in (result_path, eval_path):
            if not path.is_file():
                raise ValueError(f"missing baseline artifact {path}")
        expected_results.add(result_path.resolve())
        payload = _read_json(result_path)
        result = dict(payload.get("result") or {})
        identity = dict(payload.get("identity") or {})
        if identity.get("tag") != tag or identity.get("seed") != seed or result.get("run_id") != run_id:
            raise ValueError(f"{result_path.name}: baseline identity mismatch")
        _require_no_test_access(result, result_path.name)
        records = list(_read_json(eval_path).get("records") or ())
        if len(records) != 400:
            raise ValueError(f"{eval_path.name}: expected 400 records")
        for index, record in enumerate(records):
            _require_eval_record(record, f"{eval_path.name}:{index}")
        baselines[seed] = {
            "result": result,
            "train_qi": tuple(result.get("train_qi") or ()),
            "shot_qi": tuple(result.get("shot_qi") or ()),
            "ids": tuple(int(record["idx"]) for record in records),
            "legacy": np.asarray([record.get("legacy_correct") is True for record in records], dtype=float),
            "strict": np.asarray([record.get("strict_correct") is True for record in records], dtype=float),
        }

    for coordinate in coordinates:
        cell_id = str(coordinate["cell_id"])
        if cell_id == "CTRL-base":
            continue
        seed = int(coordinate["seed"])
        tag = str(coordinate["tag"])
        result_path = _artifact(artifact_dir, "cell_result", tag, "AC-ALG1", seed, "json")
        eval_path = _artifact(artifact_dir, "eval", tag, "AC-ALG1", seed, "json")
        checkpoint_path = _artifact(
            artifact_dir, "checkpoint_eval", tag, "AC-ALG1", seed, "jsonl.gz"
        )
        diagnostic_path = _artifact(
            artifact_dir, "training_diagnostics", tag, "AC-ALG1", seed, "jsonl.gz"
        )
        for path in (result_path, eval_path, checkpoint_path, diagnostic_path):
            if not path.is_file():
                raise ValueError(f"missing registered artifact {path}")
        expected_results.add(result_path.resolve())
        payload = _read_json(result_path)
        result = dict(payload.get("result") or {})
        identity = dict(payload.get("identity") or {})
        if (
            identity.get("tag") != tag
            or identity.get("seed") != seed
            or identity.get("method") != "AC-ALG1"
            or result.get("run_id") != run_id
        ):
            raise ValueError(f"{result_path.name}: Q5 identity mismatch")
        _require_no_test_access(result, result_path.name)
        baseline = baselines[seed]
        train_qi = tuple(result.get("train_qi") or ())
        expected_train_questions = 256 if cell_id == "Q5-BREADTH" else 128
        if len(train_qi) != expected_train_questions or len(set(train_qi)) != expected_train_questions:
            raise ValueError(f"{cell_id}/{seed}: optimization-question pool changed")
        if cell_id == "Q5-BREADTH":
            if not set(baseline["train_qi"]).issubset(train_qi):
                raise ValueError(f"{cell_id}/{seed}: breadth pool does not contain paired reference pool")
        elif train_qi != baseline["train_qi"]:
            raise ValueError(f"{cell_id}/{seed}: optimization questions changed")
        if tuple(result.get("shot_qi") or ()) != baseline["shot_qi"]:
            raise ValueError(f"{cell_id}/{seed}: demonstrations changed")
        expected_proposals = EXPECTED[cell_id][-1]
        observed_train_generations = int(result.get("train_llm_gen", -1))
        if observed_train_generations < expected_proposals:
            raise ValueError(f"{cell_id}/{seed}: training proposal budget changed")
        if int(result.get("optimizer_steps", -1)) != 32:
            raise ValueError(f"{cell_id}/{seed}: optimizer-step count changed")

        final_records = list(_read_json(eval_path).get("records") or ())
        if len(final_records) != 400:
            raise ValueError(f"{eval_path.name}: expected 400 records")
        final_ids = tuple(int(record["idx"]) for record in final_records)
        if final_ids != baseline["ids"]:
            raise ValueError(f"{cell_id}/{seed}: validation questions changed")
        for index, record in enumerate(final_records):
            _require_eval_record(record, f"{eval_path.name}:{index}")
        final_legacy = np.asarray(
            [record.get("legacy_correct") is True for record in final_records], dtype=float
        )
        final_strict = np.asarray(
            [record.get("strict_correct") is True for record in final_records], dtype=float
        )
        checkpoint_rows = _read_jsonl_gz(checkpoint_path)
        if tuple(int(row.get("completed_rounds", -1)) for row in checkpoint_rows) != CHECKPOINTS:
            raise ValueError(f"{cell_id}/{seed}: checkpoint schedule changed")
        checkpoint_legacy = []
        checkpoint_strict = []
        for checkpoint in checkpoint_rows:
            metrics = dict(checkpoint.get("metrics") or {})
            if metrics.get("eval_official_test_accessed") is not False:
                raise ValueError(f"{cell_id}/{seed}: checkpoint accessed official test")
            records = list(checkpoint.get("records") or ())
            if tuple(int(record["idx"]) for record in records) != final_ids:
                raise ValueError(f"{cell_id}/{seed}: checkpoint question order changed")
            checkpoint_legacy.append(
                np.asarray([record.get("legacy_correct") is True for record in records], dtype=float)
            )
            checkpoint_strict.append(
                np.asarray([record.get("strict_correct") is True for record in records], dtype=float)
            )
        legacy_auc = normalized_question_auc(
            baseline["legacy"], np.asarray(checkpoint_legacy)
        )
        strict_auc = normalized_question_auc(
            baseline["strict"], np.asarray(checkpoint_strict)
        )
        diagnostics = _diagnostic_metrics(
            _read_jsonl_gz(diagnostic_path),
            cell_id=cell_id,
            settings=coordinate["settings"],
        )
        expected_train_generations = expected_training_generations(
            cell_id,
            proposal_generations=expected_proposals,
            verifier_calls=int(diagnostics["verifier_calls"]),
        )
        if observed_train_generations != expected_train_generations:
            raise ValueError(
                f"{cell_id}/{seed}: runtime generation accounting changed: "
                f"{observed_train_generations} != {expected_train_generations}"
            )
        final_extracted = float(final_legacy.mean())
        final_strict_value = float(final_strict.mean())
        if not math.isclose(final_extracted, _finite(result.get("test_acc_legacy"), result_path.name)):
            raise ValueError(f"{cell_id}/{seed}: final extracted metric does not reconstruct")
        if not math.isclose(final_strict_value, _finite(result.get("test_acc_strict"), result_path.name)):
            raise ValueError(f"{cell_id}/{seed}: final strict metric does not reconstruct")
        seed_rows.append(
            {
                "cell_id": cell_id,
                "seed": seed,
                "final_extracted_acc1": final_extracted,
                "final_strict_acc1": final_strict_value,
                "extracted_auc": float(legacy_auc.mean()),
                "strict_auc": float(strict_auc.mean()),
                "pass8": _finite(result.get("pass8"), result_path.name),
                "natural_eos_fraction": _finite(
                    result.get("eval_natural_eos_fraction"), result_path.name
                ),
                "accelerator_hours": _finite(result.get("accelerator_hours"), result_path.name),
                "proposal_calls": expected_proposals,
                "optimization_questions": expected_train_questions,
                "optimizer_steps": 32,
                **diagnostics,
            }
        )
        for index, question_id in enumerate(final_ids):
            question_rows.append(
                {
                    "cell_id": cell_id,
                    "seed": seed,
                    "question_id": question_id,
                    "final_extracted_acc1": final_legacy[index],
                    "final_strict_acc1": final_strict[index],
                    "extracted_auc": legacy_auc[index],
                }
            )

    observed_results = {path.resolve() for path in artifact_dir.glob("cell_result_*.json")}
    if observed_results != expected_results:
        raise ValueError("cell-result inventory does not match the 18-task design")
    seed_frame = pd.DataFrame(seed_rows)
    question_frame = pd.DataFrame(question_rows)
    if len(seed_frame) != 15 or seed_frame.duplicated(["cell_id", "seed"]).any():
        raise ValueError("Q5 seed-level coordinates are incomplete")
    if len(question_frame) != 6000:
        raise ValueError("Q5 question-level coordinates are incomplete")
    return seed_frame, question_frame


def nested_bootstrap(
    question_frame: pd.DataFrame,
    *,
    treatment: str,
    control: str,
    metric: str,
    draws: int,
    seed: int,
) -> tuple[float, float, float]:
    differences = []
    for replicate_seed in SEEDS:
        treatment_rows = question_frame[
            (question_frame["cell_id"] == treatment) & (question_frame["seed"] == replicate_seed)
        ].sort_values("question_id")
        control_rows = question_frame[
            (question_frame["cell_id"] == control) & (question_frame["seed"] == replicate_seed)
        ].sort_values("question_id")
        if tuple(treatment_rows["question_id"]) != tuple(control_rows["question_id"]):
            raise ValueError(f"{treatment}/{control}/{replicate_seed}: questions are not paired")
        differences.append(treatment_rows[metric].to_numpy(float) - control_rows[metric].to_numpy(float))
    cube = np.asarray(differences)
    rng = np.random.default_rng(seed)
    samples = np.empty(draws, dtype=float)
    for draw in range(draws):
        sampled_seeds = rng.integers(0, len(SEEDS), size=len(SEEDS))
        means = []
        for seed_index in sampled_seeds:
            question_indices = rng.integers(0, cube.shape[1], size=cube.shape[1])
            means.append(float(cube[seed_index, question_indices].mean()))
        samples[draw] = float(np.mean(means))
    return float(cube.mean()), float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def summarize_and_decide(
    seed_frame: pd.DataFrame,
    question_frame: pd.DataFrame,
    *,
    draws: int,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    summary = seed_frame.groupby("cell_id", as_index=False).mean(numeric_only=True)
    summary.insert(1, "seed_count", 3)
    control_summary = summary.set_index("cell_id").loc[CONTROL]
    more_summary = summary.set_index("cell_id").loc["Q5-MORE"]
    contrasts = []
    passing = []
    for cell_index, cell_id in enumerate(Q5_CELLS[1:], start=1):
        intervals = {
            metric: nested_bootstrap(
                question_frame,
                treatment=cell_id,
                control=CONTROL,
                metric=metric,
                draws=draws,
                seed=7300 + cell_index * 100 + metric_index,
            )
            for metric_index, metric in enumerate(METRICS)
        }
        row = summary.set_index("cell_id").loc[cell_id]
        accuracy_gates = {
            "final_gain_at_least_1pp": bool(
                intervals["final_extracted_acc1"][0] >= 0.01
            ),
            "strict_loss_at_most_1pp": bool(
                intervals["final_strict_acc1"][0] >= -0.01
            ),
            "auc_loss_at_most_1pp": bool(
                intervals["extracted_auc"][0] >= -0.01
            ),
        }
        if cell_id == "Q5-MORE":
            mechanism_gate = bool(
                row["proposal_calls"] > control_summary["proposal_calls"]
            )
        elif cell_id == "Q5-BREADTH":
            mechanism_gate = bool(
                row["proposal_calls"] == more_summary["proposal_calls"]
                and row["optimization_questions"] == 256
            )
        elif cell_id == "Q5-DIVERSE":
            mechanism_gate = bool(
                row["mean_calculation_path_clusters"] > more_summary["mean_calculation_path_clusters"]
                or row["mean_calculation_path_effective_sample_size"]
                > more_summary["mean_calculation_path_effective_sample_size"]
            )
        else:
            mechanism_gate = bool(
                row["verifier_calls"] == row["retained_trace_opportunities"]
                and 0 < row["verifier_calls"] <= 2048
                and math.isfinite(float(row["verifier_auroc_vs_proposal_correct"]))
            )
        record = {
            "cell_id": cell_id,
            **{
                f"{metric}_delta": values[0]
                for metric, values in intervals.items()
            },
            **{
                f"{metric}_ci_low": values[1]
                for metric, values in intervals.items()
            },
            **{
                f"{metric}_ci_high": values[2]
                for metric, values in intervals.items()
            },
            **{f"gate_{name}": value for name, value in accuracy_gates.items()},
            "gate_intended_mechanism_moved": mechanism_gate,
            "passes_all_gates": all(accuracy_gates.values()) and mechanism_gate,
        }
        contrasts.append(record)
        if record["passes_all_gates"]:
            passing.append(cell_id)
    selected = CONTROL
    if passing:
        ranked = summary[summary["cell_id"].isin(passing)].sort_values(
            ["final_extracted_acc1", "final_strict_acc1", "extracted_auc", "total_generated_tokens"],
            ascending=[False, False, False, True],
        )
        selected = str(ranked.iloc[0]["cell_id"])
    decision = {
        "schema_version": 1,
        "run_id": RUN_ID,
        "paired_seeds": list(SEEDS),
        "metric_order": list(METRICS),
        "selected_development_candidate": selected,
        "control_retained": selected == CONTROL,
        "fresh_seven_seed_confirmation_required": selected != CONTROL,
        "official_test_used": False,
        "contrasts": contrasts,
    }
    return summary, pd.DataFrame(contrasts), decision


def verify_marker(marker_path: Path, config_path: Path) -> dict[str, Any]:
    marker = _read_json(marker_path)
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    run_id = str(config.get("run_id")) if isinstance(config, dict) else ""
    if run_id not in ACCEPTED_RUN_IDS:
        raise ValueError("Q5 support-reallocation run ID changed")
    expected = {
        "status": "ok",
        "run_id": run_id,
        "configuration_sha256": hashlib.sha256(config_path.read_bytes()).hexdigest(),
    }
    for field, value in expected.items():
        if marker.get(field) != value:
            raise ValueError(f"validator marker {field} mismatch")
    for field in ("execution_commit", "source_job_id"):
        if not str(marker.get(field) or ""):
            raise ValueError(f"validator marker omits {field}")
    return marker


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=LM_STUDY / "experiments_qwen3_17b_q5_support_reallocation.yaml",
    )
    parser.add_argument("--validate-design-only", action="store_true")
    parser.add_argument("--artifacts", type=Path)
    parser.add_argument("--marker", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--bootstrap-draws", type=int, default=5000)
    args = parser.parse_args()
    load_design(args.config)
    if args.validate_design_only:
        print("validated 6 cells x 3 seeds")
        return 0
    if args.artifacts is None or args.marker is None or args.out is None:
        parser.error("--artifacts, --marker and --out are required for result analysis")
    marker = verify_marker(args.marker, args.config)
    seed_frame, question_frame = load_results(args.artifacts, args.config)
    summary, contrasts, decision = summarize_and_decide(
        seed_frame,
        question_frame,
        draws=args.bootstrap_draws,
    )
    decision["execution_commit"] = marker["execution_commit"]
    decision["source_job_id"] = marker["source_job_id"]
    decision["run_id"] = marker["run_id"]
    args.out.mkdir(parents=True, exist_ok=True)
    seed_frame.to_csv(args.out / "seed_metrics.csv", index=False)
    question_frame.to_csv(args.out / "question_metrics.csv", index=False)
    summary.to_csv(args.out / "configuration_summary.csv", index=False)
    contrasts.to_csv(args.out / "paired_contrasts.csv", index=False)
    (args.out / "decision.json").write_text(
        json.dumps(decision, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(summary.sort_values("final_extracted_acc1", ascending=False).to_string(index=False))
    print(json.dumps(decision, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
