"""Analyze the preregistered AC-ALG1 safeguarded-update experiments.

The focus study uses different outer-round widths, so every primary trajectory
is integrated over cumulative training generations rather than round number.
Repeated checkpoints are never treated as independent observations: seed signs
and paired held-out-question effects are reported separately.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from analysis.analyze_ac_alg1_numerical_study import (
        _paired_bootstrap_interval,
        load_cells,
        load_checkpoint_trajectories,
    )
except ModuleNotFoundError:  # Direct execution from analysis/.
    from analyze_ac_alg1_numerical_study import (
        _paired_bootstrap_interval,
        load_cells,
        load_checkpoint_trajectories,
    )


GEOMETRY_CONTRASTS = {
    "safeguard_minus_original": ("G1_sgem_total", "G0_original_sum"),
    "raw_pareto_minus_safeguard": ("G2_mgda", "G1_sgem_total"),
    "normalized_minus_raw_pareto": (
        "G3_normalized_mgda",
        "G2_mgda",
    ),
    "answer_primary_minus_safeguard": (
        "G4_answer_primary",
        "G1_sgem_total",
    ),
    "single_direction_safeguard_minus_original": (
        "G6_Bunsup_sgem",
        "G5_Bunsup",
    ),
}
FOCUS_CONTRASTS = {
    "safeguarded_breadth_minus_original_breadth": (
        "Q1_breadth_sgem",
        "Q0_breadth",
    ),
    "focus_it4_minus_safeguarded_breadth": (
        "Q2_focus_it4",
        "Q1_breadth_sgem",
    ),
    "focus_it16_minus_focus_it4": ("Q3_focus_it16", "Q2_focus_it4"),
}


def summarize_generation_curves(
    trajectories: pd.DataFrame,
    cells: pd.DataFrame,
    reference_accuracy: float,
) -> pd.DataFrame:
    """Integrate accuracy over cumulative generated training traces."""

    metadata = cells[["arm", "seed", "batch"]].drop_duplicates()
    merged = trajectories.merge(
        metadata,
        on=["arm", "seed"],
        how="left",
        validate="many_to_one",
    )
    if merged["batch"].isna().any():
        raise ValueError("every trajectory needs a resolved per-round batch size")
    merged["cumulative_generations"] = (
        merged["completed_rounds"].astype(float) * merged["batch"].astype(float)
    )

    rows = []
    for (arm, seed), group in merged.groupby(["arm", "seed"]):
        group = group.sort_values("cumulative_generations")
        generations = np.concatenate(
            ([0.0], group["cumulative_generations"].to_numpy(float))
        )
        accuracy = np.concatenate(
            ([reference_accuracy], group["test_acc"].to_numpy(float))
        )
        if len(np.unique(generations)) != len(generations):
            raise ValueError(f"duplicate generation checkpoints for {arm}/seed{seed}")
        final_generations = float(generations[-1])
        if final_generations <= 0:
            raise ValueError("a completed trajectory must have positive generation cost")
        peak = int(np.argmax(accuracy))
        rows.append({
            "arm": arm,
            "seed": int(seed),
            "n_checkpoints": len(group),
            "final_generations": int(final_generations),
            "normalized_accuracy_auc": float(
                np.trapezoid(accuracy, generations) / final_generations
            ),
            "peak_accuracy": float(accuracy[peak]),
            "peak_generations": int(generations[peak]),
            "minimum_accuracy": float(accuracy.min()),
            "final_accuracy": float(accuracy[-1]),
            "final_difference_from_base": float(
                accuracy[-1] - reference_accuracy
            ),
        })
    return pd.DataFrame(rows).sort_values(["seed", "arm"])


def seed_contrasts(
    curve_summary: pd.DataFrame,
    treatment_arm: str,
    control_arm: str,
) -> pd.DataFrame:
    """Return treatment-minus-control generation-AUC for every matched seed."""

    pivot = curve_summary.pivot(
        index="seed", columns="arm", values="normalized_accuracy_auc"
    )
    missing = {treatment_arm, control_arm} - set(pivot.columns)
    if missing:
        raise ValueError(f"missing configured arms: {sorted(missing)}")
    paired = pivot[[treatment_arm, control_arm]].dropna()
    return pd.DataFrame({
        "seed": paired.index.astype(int),
        "treatment_auc": paired[treatment_arm].to_numpy(float),
        "control_auc": paired[control_arm].to_numpy(float),
        "auc_difference": (
            paired[treatment_arm] - paired[control_arm]
        ).to_numpy(float),
    })


def question_generation_auc_contrasts(
    cells: pd.DataFrame,
    checkpoint_evaluations: dict[tuple[str, int, int], dict],
    treatment_arm: str,
    control_arm: str,
) -> pd.DataFrame:
    """Integrate paired correctness effects at shared generation checkpoints."""

    rows = []
    for seed in sorted(cells["seed"].unique()):
        seed_cells = cells[cells["seed"] == seed]
        by_arm = {
            str(cell["arm"]): cell
            for _, cell in seed_cells.iterrows()
        }
        if treatment_arm not in by_arm or control_arm not in by_arm:
            continue

        arm_records = {}
        for arm in (treatment_arm, control_arm):
            cell = by_arm[arm]
            tag = str(cell["tag"])
            batch = int(cell["batch"])
            arm_records[arm] = {
                int(completed_rounds) * batch: record
                for (record_tag, record_seed, completed_rounds), record
                in checkpoint_evaluations.items()
                if record_tag == tag and record_seed == int(seed)
            }
        shared_generations = sorted(
            set(arm_records[treatment_arm]) & set(arm_records[control_arm])
        )
        if not shared_generations:
            continue

        correctness = {}
        for arm in (treatment_arm, control_arm):
            correctness[arm] = {
                generations: {
                    int(item["idx"]): float(bool(item["correct"]))
                    for item in arm_records[arm][generations].get("records", [])
                }
                for generations in shared_generations
            }
        shared_questions = set.intersection(*(
            set(correctness[treatment_arm][generations])
            & set(correctness[control_arm][generations])
            for generations in shared_generations
        ))
        x = np.asarray([0, *shared_generations], dtype=float)
        for question_id in sorted(shared_questions):
            differences = np.asarray([
                0.0,
                *(
                    correctness[treatment_arm][generations][question_id]
                    - correctness[control_arm][generations][question_id]
                    for generations in shared_generations
                ),
            ])
            rows.append({
                "seed": int(seed),
                "idx": int(question_id),
                "auc_difference": float(
                    np.trapezoid(differences, x) / x[-1]
                ),
                "n_shared_checkpoints": len(shared_generations),
                "final_shared_generations": int(x[-1]),
            })
    return (
        pd.DataFrame(rows).sort_values(["seed", "idx"])
        if rows else pd.DataFrame()
    )


def frozen_decision(
    seed_effects: pd.DataFrame,
    question_effects: pd.DataFrame,
    practical_margin: float,
    draws: int,
    bootstrap_seed: int,
) -> dict:
    """Apply the frozen strong-support/futility/inconclusive rule."""

    seed_values = seed_effects["auc_difference"].to_numpy(float)
    question_values = (
        question_effects.groupby("idx")["auc_difference"].mean().to_numpy(float)
        if not question_effects.empty else np.asarray([], dtype=float)
    )
    low, high = _paired_bootstrap_interval(
        question_values,
        draws=draws,
        seed=bootstrap_seed,
    )
    positive = int(np.sum(seed_values > 0))
    mean = float(seed_values.mean()) if len(seed_values) else float("nan")
    if (
        len(seed_values)
        and positive == len(seed_values)
        and low > 0
        and mean >= practical_margin
    ):
        verdict = "strong_support"
    elif len(seed_values) and positive == 0 and high < practical_margin:
        verdict = "practical_futility"
    else:
        verdict = "inconclusive"
    return {
        "verdict": verdict,
        "practical_margin": practical_margin,
        "n_seeds": int(len(seed_values)),
        "positive_seed_differences": positive,
        "mean_auc_difference": mean,
        "n_question_clusters": int(len(question_values)),
        "question_cluster_ci95_low": low,
        "question_cluster_ci95_high": high,
        "scope_note": (
            "The question bootstrap conditions on the tested seeds; "
            "seed-level signs are a separate requirement."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result_dir", type=Path)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--study", choices=("geometry", "focus"), required=True)
    parser.add_argument("--reference-accuracy", type=float, default=0.7925)
    parser.add_argument("--practical-margin", type=float, default=0.01)
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260724)
    parser.add_argument("--write-dir", type=Path, default=None)
    args = parser.parse_args()

    result_dir = args.result_dir.expanduser()
    cells, _final_evaluations = load_cells(
        result_dir,
        args.prefix,
        args.config,
        final_rounds=10,
    )
    trajectories, checkpoint_evaluations = load_checkpoint_trajectories(
        result_dir, cells
    )
    curves = summarize_generation_curves(
        trajectories, cells, args.reference_accuracy
    )
    contrasts = (
        GEOMETRY_CONTRASTS if args.study == "geometry" else FOCUS_CONTRASTS
    )

    decisions = {}
    seed_tables = []
    question_tables = []
    for index, (name, (treatment, control)) in enumerate(contrasts.items()):
        seeds = seed_contrasts(curves, treatment, control)
        seeds.insert(0, "contrast", name)
        questions = question_generation_auc_contrasts(
            cells,
            checkpoint_evaluations,
            treatment,
            control,
        )
        if not questions.empty:
            questions.insert(0, "contrast", name)
        decisions[name] = frozen_decision(
            seeds,
            questions,
            practical_margin=args.practical_margin,
            draws=args.bootstrap_draws,
            bootstrap_seed=args.bootstrap_seed + index,
        )
        seed_tables.append(seeds)
        if not questions.empty:
            question_tables.append(questions)

    all_seeds = pd.concat(seed_tables, ignore_index=True)
    all_questions = (
        pd.concat(question_tables, ignore_index=True)
        if question_tables else pd.DataFrame()
    )

    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", None)
    print("=== GENERATION-NORMALIZED CURVES ===")
    print(curves.to_string(index=False))
    print("\n=== SEED-LEVEL CONTRASTS ===")
    print(all_seeds.to_string(index=False))
    print("\n=== FROZEN DECISIONS ===")
    print(json.dumps(decisions, indent=2, sort_keys=True))

    if args.write_dir is not None:
        args.write_dir.mkdir(parents=True, exist_ok=True)
        curves.to_csv(
            args.write_dir / f"{args.study}_generation_curve_summary.csv",
            index=False,
        )
        all_seeds.to_csv(
            args.write_dir / f"{args.study}_seed_contrasts.csv",
            index=False,
        )
        all_questions.to_csv(
            args.write_dir / f"{args.study}_question_contrasts.csv",
            index=False,
        )
        (
            args.write_dir / f"{args.study}_decisions.json"
        ).write_text(
            json.dumps(decisions, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
