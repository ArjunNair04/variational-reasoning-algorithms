#!/usr/bin/env python3
"""Frozen four-arm analysis for the matched Qwen3-1.7B GSM8K study.

This analyser joins the already validated frozen-base/PIS run ``388abde8``
to the GRPO/RLOO add-on ``11dd70d8``.  It fails closed on both validators,
every completion receipt and receipt-listed hash, terminal logs, paired
questions and prompts, the registered schedules and realised resources before
it reads the registered scientific endpoints.  The seven paired training
seeds are the sole inferential units; evaluation questions are reconstructed
only to verify aggregates and pairing.

The design and decision rules are constants rather than outcome-dependent
options.  In particular, final extracted Acc@1 is primary, strict terminal
accuracy is secondary, normalized extracted trajectory AUC is third, and AUC
cannot rescue a failed endpoint competitiveness gate.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
LM_STUDY = REPOSITORY_ROOT / "lm_study"
if str(LM_STUDY) not in sys.path:
    sys.path.insert(0, str(LM_STUDY))

from result_contract import (  # noqa: E402
    ResultContractError,
    validate_completion_receipt,
    validate_receipt_identity,
)


SOURCE_RUN_ID = "388abde8"
COMPARATOR_RUN_ID = "11dd70d8"
SOURCE_CONFIG_SHA256 = (
    "9964be71bde07738bf42d0c1da345cd2101a4014b9b65c14bfd75eeb23b2e06f"
)
COMPARATOR_CONFIG_SHA256 = (
    "17529c2042be2947bc0422a1c12c3c37e0502523bba9ac1b038537638a2d2a01"
)
SOURCE_MARKER_SHA256 = (
    "48e74b17ac26033b9d38a1dc92ef4261401d475cc756d375e405ddc3d121c279"
)
COMPARATOR_MARKER_SHA256 = (
    "489ef8e1cf1e3f379fcdc6a68fd940143ff5c7d4c3fcb07db56c9846b783b82c"
)
SOURCE_TRAINED_COMMIT = "5988113f682a1859fa2952227a25f22e4d2af42a"
SOURCE_RECOVERY_COMMIT = "9acfbcd6319ea4b944952f3455e283b4e28e2131"
SOURCE_VALIDATOR_COMMIT = SOURCE_RECOVERY_COMMIT
COMPARATOR_COMMIT = "056b86affe6b5acf6fcd500e062c75781171f7f7"
SOURCE_TRAINED_JOB = "7183847"
SOURCE_RECOVERY_JOB = "7186592"
SOURCE_VALIDATOR_JOB = "7186593"
COMPARATOR_JOB = "7217222"
COMPARATOR_VALIDATOR_JOB = "7217223"

SEEDS = (1009, 1013, 1019, 1021, 1031, 1033, 1039)
CHECKPOINTS = (1, 2, 4, 8, 16, 24, 32)
ROUNDS = (0, *CHECKPOINTS)
CELL_ORDER = (
    "CTRL-base",
    "PIS-S8-B8-U4",
    "GRPO-S8-B8-U4",
    "RLOO-S8-B8-U4",
)
METHOD_BY_CELL = {
    "CTRL-base": "base",
    "PIS-S8-B8-U4": "AC-ALG1",
    "GRPO-S8-B8-U4": "GRPO",
    "RLOO-S8-B8-U4": "RLOO",
}
RUN_BY_CELL = {
    "CTRL-base": SOURCE_RUN_ID,
    "PIS-S8-B8-U4": SOURCE_RUN_ID,
    "GRPO-S8-B8-U4": COMPARATOR_RUN_ID,
    "RLOO-S8-B8-U4": COMPARATOR_RUN_ID,
}
COMMIT_BY_CELL = {
    "CTRL-base": SOURCE_RECOVERY_COMMIT,
    "PIS-S8-B8-U4": SOURCE_TRAINED_COMMIT,
    "GRPO-S8-B8-U4": COMPARATOR_COMMIT,
    "RLOO-S8-B8-U4": COMPARATOR_COMMIT,
}
MODEL = "qwen3-1.7b-base"
MODEL_ID = "Qwen/Qwen3-1.7B-Base"
MODEL_REVISION = "ea980cb0a6c2ae4b936e82123acc929f1cec04c1"
DATASET_ID = "openai/gsm8k"
DATASET_REVISION = "740312add88f781978c0658806c59bc2815b9866"
EXPECTED_LORA_MODULES = {
    "q_proj",
    "k_proj",
    "v_proj",
    "o_proj",
    "gate_proj",
    "up_proj",
    "down_proj",
}
METRICS = (
    "final_extracted",
    "final_strict",
    "extracted_auc",
)
REPORTING_ORDER = (
    "final_extracted_answer_accuracy",
    "final_strict_terminal_accuracy",
    "normalized_extracted_accuracy_auc",
)
COMPETITIVENESS_MARGIN = -0.01
ONE_SIDED_ALPHA = 0.05
FAILURE_RE = re.compile(
    r"Traceback|CUDA out of memory|OutOfMemoryError|No space left on device|"
    r"Disk quota exceeded|FAILED",
    re.IGNORECASE,
)
TERMINAL_RE = re.compile(
    r"\[1/1\] done .*\n=== done .*\nGPU Epilog Script", re.DOTALL
)


@dataclass(frozen=True)
class CellEvidence:
    cell: str
    seed: int
    tag: str
    method: str
    run_id: str
    receipt_path: Path
    receipt: Mapping[str, Any]
    result: Mapping[str, Any]
    evaluation: Mapping[str, Any]
    final_records: Mapping[int, Mapping[str, Any]]
    checkpoints: Sequence[Mapping[str, Any]]
    diagnostics: Sequence[Mapping[str, Any]]
    passk: Mapping[str, Any]
    prompt: Mapping[str, Any]
    schedule: tuple[tuple[int, ...], ...]
    resources: Mapping[str, float]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{path}: invalid JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: expected a JSON object")
    return payload


def _read_json_gz(path: Path) -> dict[str, Any]:
    try:
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            payload = json.load(stream)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{path}: invalid compressed JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: expected a compressed JSON object")
    return payload


def _read_jsonl_gz(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            for line_number, line in enumerate(stream, start=1):
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError(f"{path}:{line_number}: expected an object")
                rows.append(row)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{path}: invalid compressed JSONL: {exc}") from exc
    return rows


def _finite(value: Any, *, context: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{context}: expected a finite number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{context}: expected a finite number")
    return result


def _close(observed: Any, expected: float, *, context: str) -> None:
    if not math.isclose(_finite(observed, context=context), expected, abs_tol=1e-12):
        raise ValueError(f"{context}: aggregate differs from reconstructed records")


def _require_fields(
    payload: Mapping[str, Any], expected: Mapping[str, Any], *, context: str
) -> None:
    mismatches = {
        key: (payload.get(key), value)
        for key, value in expected.items()
        if payload.get(key) != value
    }
    if mismatches:
        raise ValueError(f"{context}: field mismatch {mismatches}")


def _require_non_access(payload: Mapping[str, Any], *, context: str) -> None:
    _require_fields(
        payload,
        {
            "eval_official_test_accessed": False,
            "eval_source_split": "train",
            "eval_dataset_splits_loaded": ["train"],
        },
        context=context,
    )


def _require_record_non_access(record: Mapping[str, Any], *, context: str) -> None:
    _require_fields(
        record,
        {
            "official_test_accessed": False,
            "eval_source_split": "train",
            "dataset_splits_loaded": ["train"],
        },
        context=context,
    )


def _artifact(
    root: Path,
    receipt: Mapping[str, Any],
    *,
    prefix: str,
    suffix: str | None = None,
) -> Path:
    matches = []
    for record in receipt.get("artifacts") or []:
        relative = str(record.get("path") or "")
        name = Path(relative).name
        if name.startswith(prefix) and (suffix is None or name.endswith(suffix)):
            matches.append(root / relative)
    if len(matches) != 1:
        raise ValueError(
            f"receipt expected exactly one {prefix!r} artifact, found {len(matches)}"
        )
    return matches[0]


def _artifact_kinds(receipt: Mapping[str, Any]) -> tuple[str, ...]:
    kinds = []
    for record in receipt.get("artifacts") or []:
        relative = str(record.get("path") or "")
        name = Path(relative).name
        if name.startswith("cell_result_"):
            kinds.append("cell")
        elif name.startswith("checkpoint_eval_"):
            kinds.append("checkpoint")
        elif name.startswith("dump_"):
            kinds.append("dump")
        elif name.startswith("eval_"):
            kinds.append("eval")
        elif name.startswith("passk_"):
            kinds.append("passk")
        elif name.startswith("prompt_contract_"):
            kinds.append("prompt")
        elif name.startswith("training_diagnostics_"):
            kinds.append("training")
        elif name.startswith("traj_"):
            kinds.append("traj")
        elif name == "adapter_config.json" and relative.startswith("adapter_"):
            kinds.append("adapter_config")
        elif name in {"adapter_model.safetensors", "adapter_model.bin"} and relative.startswith(
            "adapter_"
        ):
            kinds.append("adapter_weights")
        else:
            raise ValueError(f"unregistered receipt artifact {relative!r}")
    return tuple(sorted(kinds))


def _expected_artifact_kinds(cell: str) -> tuple[str, ...]:
    if cell == "CTRL-base":
        kinds = ("cell", "dump", "eval", "passk", "prompt")
    elif cell == "PIS-S8-B8-U4":
        kinds = (
            "cell",
            "checkpoint",
            "dump",
            "eval",
            "passk",
            "prompt",
            "training",
            "traj",
        )
    else:
        kinds = (
            "adapter_config",
            "adapter_weights",
            "cell",
            "checkpoint",
            "dump",
            "eval",
            "passk",
            "prompt",
            "training",
            "traj",
        )
    return tuple(sorted(kinds))


def _load_frozen_config(path: Path, expected_sha: str) -> dict[str, Any]:
    observed_sha = _sha256(path)
    if observed_sha != expected_sha:
        raise ValueError(
            f"{path}: frozen configuration SHA changed: {observed_sha} != {expected_sha}"
        )
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: configuration is not a mapping")
    return payload


def validate_designs(source_config: Path, comparator_config: Path) -> dict[str, Any]:
    source = _load_frozen_config(source_config, SOURCE_CONFIG_SHA256)
    comparator = _load_frozen_config(comparator_config, COMPARATOR_CONFIG_SHA256)
    source_defaults = dict(source.get("defaults") or {})
    comparator_defaults = dict(comparator.get("defaults") or {})
    if str(source.get("run_id")) != SOURCE_RUN_ID:
        raise ValueError("source run ID changed")
    if str(comparator.get("run_id")) != COMPARATOR_RUN_ID:
        raise ValueError("comparator run ID changed")
    source_cells = tuple(
        str(item.get("cell_id"))
        for raw in (source.get("algos") or {}).values()
        for item in (raw if isinstance(raw, list) else [raw])
    )
    comparator_cells = tuple(
        str(item.get("cell_id"))
        for raw in (comparator.get("algos") or {}).values()
        for item in (raw if isinstance(raw, list) else [raw])
    )
    if source_cells != CELL_ORDER[:2] or comparator_cells != CELL_ORDER[2:]:
        raise ValueError("registered four-arm union or cell order changed")
    common_expected = {
        "task": "gsm8k",
        "model": MODEL,
        "rounds": 32,
        "seed_values": list(SEEDS),
        "n_test": 400,
        "train_partition": "train",
        "eval_partition": "validation",
        "answer_event_mode": "strict_terminal_marker",
        "evaluation_prompt": "question",
        "batch": 64,
        "G": 8,
        "prompts": 128,
        "shots": 3,
        "shot_bank_size": 5,
        "task_seed_from_run_seed": True,
        "question_sampling": "epoch_shuffle",
        "lora_r": 16,
        "lora_alpha": 32,
        "lora_target_set": "attention_mlp",
        "eval_rounds": list(CHECKPOINTS),
        "passk": 8,
        "passk_n": 100,
    }
    for label, defaults in (
        ("source", source_defaults),
        ("comparator", comparator_defaults),
    ):
        _require_fields(defaults, common_expected, context=f"{label} defaults")
    fixed = dict((comparator.get("diagnostic") or {}).get("fixed_contract") or {})
    _require_fields(
        fixed,
        {
            "optimization_questions": 128,
            "development_validation_questions": 400,
            "generated_completions_per_trained_cell": 2048,
            "update_passes_per_round": 4,
            "adapter_rank": 16,
            "adapter_alpha": 32,
            "official_test_used": False,
        },
        context="comparator fixed contract",
    )
    provenance = dict((comparator.get("diagnostic") or {}).get("provenance") or {})
    _require_fields(
        provenance,
        {
            "model_id": MODEL_ID,
            "model_revision": MODEL_REVISION,
            "dataset_id": DATASET_ID,
            "dataset_revision": DATASET_REVISION,
        },
        context="comparator provenance",
    )
    source_controls = dict(
        (comparator.get("diagnostic") or {}).get("source_controls") or {}
    )
    _require_fields(
        source_controls,
        {
            "run_id": SOURCE_RUN_ID,
            "marker_sha256": SOURCE_MARKER_SHA256,
            "cells": list(CELL_ORDER[:2]),
            "reuse_policy": "exact_existing_coordinates_only_no_rerun",
        },
        context="source-union contract",
    )
    reporting = tuple(
        (comparator.get("diagnostic") or {}).get("reporting_order") or ()
    )
    if reporting != REPORTING_ORDER:
        raise ValueError("registered reporting order changed")
    rules = " ".join(
        str(value)
        for value in (comparator.get("diagnostic") or {}).get("decision_rules") or []
    ).lower()
    for phrase in (
        "seven paired training seeds",
        "minus one point against both grpo and rloo",
        "at least five of seven seed effects are positive",
        "auc is secondary and cannot rescue",
    ):
        if phrase not in rules:
            raise ValueError(f"registered decision rule is absent: {phrase!r}")
    return {
        "source_config_sha256": SOURCE_CONFIG_SHA256,
        "comparator_config_sha256": COMPARATOR_CONFIG_SHA256,
        "cells": list(CELL_ORDER),
        "seeds": list(SEEDS),
        "reporting_order": list(REPORTING_ORDER),
        "official_test_used": False,
    }


def verify_markers(
    source_marker_path: Path,
    comparator_marker_path: Path,
) -> dict[str, Any]:
    if _sha256(source_marker_path) != SOURCE_MARKER_SHA256:
        raise ValueError("source PIS marker SHA-256 changed")
    source = _read_json(source_marker_path)
    _require_fields(
        source,
        {
            "schema_version": 2,
            "status": "ok",
            "run_id": SOURCE_RUN_ID,
            "configuration_sha256": SOURCE_CONFIG_SHA256,
            "validator_commit": SOURCE_VALIDATOR_COMMIT,
            "execution_segments": [
                {
                    "role": "base_recovery",
                    "source_job_id": SOURCE_RECOVERY_JOB,
                    "execution_commit": SOURCE_RECOVERY_COMMIT,
                    "task_range": [1, 7],
                },
                {
                    "role": "immutable_trained_cells",
                    "source_job_id": SOURCE_TRAINED_JOB,
                    "execution_commit": SOURCE_TRAINED_COMMIT,
                    "task_range": [8, 14],
                },
            ],
        },
        context="source marker",
    )
    recovery = dict(source.get("interruption_recovery") or {})
    _require_fields(
        recovery,
        {
            "recovery_tasks": [1, 7],
            "preserved_tasks": [8, 14],
            "duplicated_completed_tasks": 0,
        },
        context="source marker recovery",
    )
    comparator = _read_json(comparator_marker_path)
    if _sha256(comparator_marker_path) != COMPARATOR_MARKER_SHA256:
        raise ValueError("comparator marker SHA-256 changed")
    _require_fields(
        comparator,
        {
            "schema_version": 1,
            "status": "ok",
            "run_id": COMPARATOR_RUN_ID,
            "configuration_sha256": COMPARATOR_CONFIG_SHA256,
            "execution_commit": COMPARATOR_COMMIT,
            "source_job_id": COMPARATOR_JOB,
        },
        context="comparator marker",
    )
    if comparator.get("official_test_used", False) is not False:
        raise ValueError("comparator marker reports official-test access")
    return {
        "source_marker_sha256": SOURCE_MARKER_SHA256,
        "comparator_marker_sha256": COMPARATOR_MARKER_SHA256,
        "source_marker": source,
        "comparator_marker": comparator,
    }


def _validate_terminal_log(path: Path) -> str:
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"missing regular terminal log {path}")
    text = path.read_text(encoding="utf-8", errors="replace")
    failure = FAILURE_RE.search(text)
    if failure:
        raise ValueError(f"{path}: failure signature {failure.group(0)!r}")
    if not TERMINAL_RE.search(text):
        raise ValueError(f"{path}: terminal SGE success sequence is absent")
    return _sha256(path)


def verify_logs(
    *,
    source_log_dir: Path,
    source_validator_log: Path,
    comparator_log_dir: Path,
    comparator_validator_log: Path,
) -> dict[str, str]:
    expected: list[tuple[Path, str, int, str]] = []
    for task in range(1, 8):
        expected.append(
            (
                source_log_dir
                / f"qwen3_pis_confirmation.{SOURCE_RECOVERY_JOB}.{task}.log",
                "CTRL-base",
                task,
                SOURCE_RECOVERY_JOB,
            )
        )
    for task in range(8, 15):
        expected.append(
            (
                source_log_dir
                / f"qwen3_pis_confirmation.{SOURCE_TRAINED_JOB}.{task}.log",
                "PIS-S8-B8-U4",
                task,
                SOURCE_TRAINED_JOB,
            )
        )
    for task in range(1, 15):
        cell = CELL_ORDER[2 + ((task - 1) // len(SEEDS))]
        expected.append(
            (
                comparator_log_dir
                / f"qwen3_17b_gsm8k_matched_comparators.{COMPARATOR_JOB}.{task}.log",
                cell,
                task,
                COMPARATOR_JOB,
            )
        )
    hashes: dict[str, str] = {}
    for path, cell, task, _job in expected:
        hashes[str(path)] = _validate_terminal_log(path)
        text = path.read_text(encoding="utf-8", errors="replace")
        seed = SEEDS[(task - 1) % len(SEEDS)]
        if cell not in text or str(seed) not in text or "method=" not in text:
            raise ValueError(f"{path}: task/cell/seed mapping evidence is absent")
        if "H100" not in text:
            raise ValueError(f"{path}: H100 resource evidence is absent")
    validator_expectations = (
        (
            source_validator_log,
            f"qwen3_confirmation_base_recovery_validate.{SOURCE_VALIDATOR_JOB}.log",
            "validated segmented recovery",
        ),
        (
            comparator_validator_log,
            f"qwen3_l2r_focused_followup_validate.{COMPARATOR_VALIDATOR_JOB}.log",
            "validated",
        ),
    )
    for path, expected_name, required_text in validator_expectations:
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"missing regular validator log {path}")
        if path.name != expected_name:
            raise ValueError(f"validator log name changed: {path.name!r}")
        text = path.read_text(encoding="utf-8", errors="replace")
        failure = FAILURE_RE.search(text)
        if failure:
            raise ValueError(f"{path}: validator failure {failure.group(0)!r}")
        if required_text not in text:
            raise ValueError(f"{path}: validator success evidence is absent")
        hashes[str(path)] = _sha256(path)
    if len(hashes) != 30:
        raise ValueError(f"expected 30 exact source-bound logs, found {len(hashes)}")
    return hashes


def _validate_sweep_contract(
    sweep: Mapping[str, Any],
    method_parameters: Mapping[str, Any],
    *,
    cell: str,
    seed: int,
    context: str,
) -> None:
    common = {
        "rounds": 32,
        "B": 64,
        "G": 8,
        "seeds": 1,
        "seed0": seed,
        "n_test": 400,
        "train_partition": "train",
        "eval_partition": "validation",
        "answer_event_mode": "strict_terminal_marker",
        "answer_target_termination": (
            "eos" if cell == "PIS-S8-B8-U4" else "none"
        ),
        "evaluation_prompt": "question",
        "prompts": 128,
        "shots": 3,
        "shot_bank_size": 5,
        "task_seed_from_run_seed": True,
        "question_sampling": "epoch_shuffle",
        "eval_rounds": list(CHECKPOINTS),
        "passk": 8,
        "passk_n": 100,
    }
    _require_fields(sweep, common, context=context)
    if cell != "CTRL-base":
        if sweep.get("lora_target_set") != "attention_mlp":
            raise ValueError(f"{context}: LoRA target surface changed")
        modules = (sweep.get("lora_target_modules") or {}).get(MODEL)
        if not isinstance(modules, list) or set(str(value) for value in modules) != EXPECTED_LORA_MODULES:
            raise ValueError(f"{context}: resolved LoRA target modules changed")
    if cell == "PIS-S8-B8-U4":
        _require_fields(
            method_parameters,
            {
                "iters": 4,
                "buffer_limit": 8,
                "buffer_strategy": "fifo",
                "buffer_semantics": "multiset_legacy",
                "buffer_lifecycle": "fresh_round",
                "proposal_prompt": "question",
                "proposal_policy": "current",
                "responsibility_score": "joint",
                "responsibility_posterior": "softmax_entropy",
                "responsibility_temperature": 1.0,
                "responsibility_ess_floor": 0.0,
                "responsibility_policy": "current",
                "responsibility_answer_policy": "current",
                "responsibility_refresh": "outer_round",
                "variational_estimator": "prior_importance",
                "latent_mstep_objective": "joint",
                "update_geometry": "sum",
            },
            context=context,
        )
    elif cell == "GRPO-S8-B8-U4":
        _require_fields(
            method_parameters,
            {
                "epochs": 4,
                "proposal_prompt": "question",
                "reward_requires_eos": True,
                "lr": 1.0e-5,
                "clip": 0.2,
                "kl_coef": 0.02,
                "optimizer_step_scope": "batch",
            },
            context=context,
        )
    elif cell == "RLOO-S8-B8-U4":
        _require_fields(
            method_parameters,
            {
                "epochs": 4,
                "proposal_prompt": "question",
                "reward_requires_eos": True,
                "lr": 2.0e-5,
                "kl_coef": 0.03,
            },
            context=context,
        )


def _validate_adapter(receipt: Mapping[str, Any], root: Path, *, context: str) -> None:
    config_path = _artifact(root, receipt, prefix="adapter_config", suffix=".json")
    payload = _read_json(config_path)
    _require_fields(payload, {"r": 16, "lora_alpha": 32}, context=context)
    modules = payload.get("target_modules")
    if not isinstance(modules, list) or set(str(value) for value in modules) != EXPECTED_LORA_MODULES:
        raise ValueError(f"{context}: adapter target modules changed")


def _validate_prompt(
    payload: Mapping[str, Any],
    *,
    cell: str,
    method: str,
    seed: int,
    tag: str,
    train_qi: tuple[int, ...],
    shot_qi: tuple[int, ...],
) -> tuple[tuple[Any, ...], ...]:
    _require_fields(
        payload,
        {
            "schema_version": 1,
            "method": method,
            "tag": tag,
            "training_seed": seed,
            "task_seed": seed,
            "proposal_prompt_mode": "question",
            "answer_event_mode": "strict_terminal_marker",
            "shot_dataset_train_indices": list(shot_qi),
        },
        context=f"{cell}/{seed} prompt",
    )
    expected_termination = "eos" if cell == "PIS-S8-B8-U4" else "none"
    if payload.get("answer_target_termination") != expected_termination:
        raise ValueError(f"{cell}/{seed}: prompt answer termination changed")
    rows = payload.get("rows")
    if not isinstance(rows, list) or len(rows) != 128:
        raise ValueError(f"{cell}/{seed}: expected 128 prompt rows")
    normalized = []
    for position, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"{cell}/{seed}: malformed prompt row {position}")
        canonical = row.get("canonical_prompt")
        proposal = row.get("proposal_prompt")
        if not isinstance(canonical, str) or not isinstance(proposal, str):
            raise ValueError(f"{cell}/{seed}: prompt text is absent")
        _require_fields(
            row,
            {
                "pid": position,
                "dataset_train_index": train_qi[position],
                "canonical_prompt_sha256": _sha256_text(canonical),
                "proposal_prompt_sha256": _sha256_text(proposal),
                "proposal_differs_from_canonical": False,
                "canonical_contains_proposal_answer_hint": False,
                "proposal_contains_gold_answer_hint": False,
            },
            context=f"{cell}/{seed} prompt row {position}",
        )
        if canonical != proposal or not canonical.endswith("\nAnswer:"):
            raise ValueError(f"{cell}/{seed}: question-only prompt contract changed")
        normalized.append(
            (
                position,
                int(row["dataset_train_index"]),
                str(row.get("gold_answer")),
                canonical,
                proposal,
            )
        )
    return tuple(normalized)


def _validate_eval_records(
    records: Sequence[Mapping[str, Any]], *, context: str
) -> tuple[tuple[int, ...], dict[int, Mapping[str, Any]]]:
    if len(records) != 400:
        raise ValueError(f"{context}: expected 400 evaluation records")
    order = tuple(int(record.get("idx", -1)) for record in records)
    if len(set(order)) != 400 or any(value < 0 for value in order):
        raise ValueError(f"{context}: invalid question identity set")
    mapped: dict[int, Mapping[str, Any]] = {}
    for position, record in enumerate(records):
        row_context = f"{context}/record{position}"
        _require_record_non_access(record, context=row_context)
        for field in (
            "correct",
            "legacy_correct",
            "strict_correct",
            "strict_correct_and_eos",
            "generated_eos",
            "strict_format_failure",
            "hit_max_new_tokens",
        ):
            if not isinstance(record.get(field), bool):
                raise ValueError(f"{row_context}: {field} is not boolean")
        if record["correct"] is not record["strict_correct"]:
            raise ValueError(f"{row_context}: canonical correctness is not strict")
        if record["legacy_correct"] is not (
            record.get("legacy_pred") == record.get("gold")
        ):
            raise ValueError(f"{row_context}: extracted correctness is inconsistent")
        if record["strict_correct"] is not (
            record.get("strict_pred") == record.get("gold")
        ):
            raise ValueError(f"{row_context}: strict correctness is inconsistent")
        if record["strict_correct_and_eos"] is not (
            record["strict_correct"] and record["generated_eos"]
        ):
            raise ValueError(f"{row_context}: strict/EOS conjunction changed")
        if record.get("answer_event_mode") != "strict_terminal_marker":
            raise ValueError(f"{row_context}: answer event changed")
        gold = record.get("gold")
        if gold is None or str(gold) == "":
            raise ValueError(f"{row_context}: gold answer is absent")
        mapped[int(record["idx"])] = record
    return order, mapped


def _mean_bool(records: Sequence[Mapping[str, Any]], field: str) -> float:
    return float(np.mean([bool(row[field]) for row in records]))


def _validate_evaluation(
    payload: Mapping[str, Any], *, cell: str, seed: int
) -> tuple[tuple[int, ...], dict[int, Mapping[str, Any]], tuple[int, ...], tuple[int, ...]]:
    _require_non_access(payload, context=f"{cell}/{seed} evaluation")
    _require_fields(
        payload,
        {
            "run_id": RUN_BY_CELL[cell],
            "model": MODEL,
            "method": METHOD_BY_CELL[cell],
            "seed": seed,
            "passk_official_test_accessed": False,
            "passk_eval_source_split": "train",
            "passk_dataset_splits_loaded": ["train"],
            "passk_evaluation_prompt": "question",
        },
        context=f"{cell}/{seed} evaluation",
    )
    train_qi = tuple(int(value) for value in payload.get("train_qi") or ())
    shot_qi = tuple(int(value) for value in payload.get("shot_qi") or ())
    if len(train_qi) != 128 or len(set(train_qi)) != 128:
        raise ValueError(f"{cell}/{seed}: optimization-question support changed")
    if len(shot_qi) != 3 or len(set(shot_qi)) != 3:
        raise ValueError(f"{cell}/{seed}: three-shot support changed")
    order, mapped = _validate_eval_records(
        payload.get("records") or [], context=f"{cell}/{seed} final evaluation"
    )
    rows = list(mapped.values())
    _close(
        payload.get("test_acc_legacy"),
        _mean_bool(rows, "legacy_correct"),
        context=f"{cell}/{seed}/test_acc_legacy",
    )
    _close(
        payload.get("test_acc_strict"),
        _mean_bool(rows, "strict_correct"),
        context=f"{cell}/{seed}/test_acc_strict",
    )
    _close(
        payload.get("eval_strict_format_failure_fraction"),
        _mean_bool(rows, "strict_format_failure"),
        context=f"{cell}/{seed}/strict_format_failure",
    )
    _close(
        payload.get("eval_natural_eos_fraction"),
        _mean_bool(rows, "generated_eos"),
        context=f"{cell}/{seed}/natural_eos",
    )
    return order, mapped, train_qi, shot_qi


def _validate_checkpoints(
    rows: Sequence[Mapping[str, Any]],
    *,
    cell: str,
    seed: int,
    tag: str,
    final_order: tuple[int, ...],
    final_records: Mapping[int, Mapping[str, Any]],
) -> list[Mapping[int, Mapping[str, Any]]]:
    observed = tuple(int(row.get("completed_rounds", -1)) for row in rows)
    if observed != CHECKPOINTS:
        raise ValueError(f"{cell}/{seed}: checkpoint schedule changed: {observed}")
    mapped_rows = []
    for position, checkpoint in enumerate(rows):
        _require_fields(
            checkpoint,
            {
                "run_id": RUN_BY_CELL[cell],
                "model": MODEL,
                "task": "gsm8k",
                "method": METHOD_BY_CELL[cell],
                "seed": seed,
                "tag": tag,
                "completed_rounds": CHECKPOINTS[position],
            },
            context=f"{cell}/{seed} checkpoint {position}",
        )
        metrics = dict(checkpoint.get("metrics") or {})
        _require_non_access(metrics, context=f"{cell}/{seed} checkpoint metrics {position}")
        order, mapped = _validate_eval_records(
            checkpoint.get("records") or [],
            context=f"{cell}/{seed} checkpoint {CHECKPOINTS[position]}",
        )
        if order != final_order:
            raise ValueError(f"{cell}/{seed}: checkpoint question order changed")
        values = list(mapped.values())
        _close(
            metrics.get("test_acc_legacy"),
            _mean_bool(values, "legacy_correct"),
            context=f"{cell}/{seed}/checkpoint extracted",
        )
        _close(
            metrics.get("test_acc_strict"),
            _mean_bool(values, "strict_correct"),
            context=f"{cell}/{seed}/checkpoint strict",
        )
        mapped_rows.append(mapped)
    terminal = mapped_rows[-1]
    for question_id in final_order:
        for field in (
            "gold",
            "legacy_correct",
            "strict_correct",
            "generated_eos",
            "strict_format_failure",
            "hit_max_new_tokens",
        ):
            if terminal[question_id].get(field) != final_records[question_id].get(field):
                raise ValueError(
                    f"{cell}/{seed}: round-32 checkpoint and final {field} disagree"
                )
    return mapped_rows


def _validate_passk(
    payload: Mapping[str, Any], *, cell: str, seed: int, result: Mapping[str, Any]
) -> tuple[tuple[int, str], ...]:
    _require_fields(
        payload,
        {
            "run_id": RUN_BY_CELL[cell],
            "model": MODEL,
            "method": METHOD_BY_CELL[cell],
            "seed": seed,
            "passk_official_test_accessed": False,
            "passk_eval_source_split": "train",
            "passk_dataset_splits_loaded": ["train"],
            "passk_evaluation_prompt": "question",
        },
        context=f"{cell}/{seed} pass@8",
    )
    records = payload.get("records")
    if not isinstance(records, list) or len(records) != 100:
        raise ValueError(f"{cell}/{seed}: expected 100 pass@8 records")
    support = []
    passed = []
    for position, record in enumerate(records):
        _require_record_non_access(record, context=f"{cell}/{seed}/pass8/{position}")
        if int(record.get("k", -1)) != 8:
            raise ValueError(f"{cell}/{seed}: pass@8 K changed")
        n_correct = int(record.get("n_correct", -1))
        if not 0 <= n_correct <= 8:
            raise ValueError(f"{cell}/{seed}: invalid pass@8 count")
        support.append((int(record.get("idx", -1)), str(record.get("gold"))))
        passed.append(n_correct > 0)
    if len(set(support)) != 100 or any(index < 0 for index, _gold in support):
        raise ValueError(f"{cell}/{seed}: pass@8 question support changed")
    reconstructed = float(np.mean(passed))
    _close(payload.get("pass8"), reconstructed, context=f"{cell}/{seed}/pass8 payload")
    _close(result.get("pass8"), reconstructed, context=f"{cell}/{seed}/pass8 result")
    return tuple(support)


def _validate_dump(payload: Mapping[str, Any], *, cell: str, seed: int) -> None:
    _require_fields(
        payload,
        {"run_id": RUN_BY_CELL[cell], "method": METHOD_BY_CELL[cell], "seed": seed},
        context=f"{cell}/{seed} completion dump",
    )
    samples = payload.get("samples")
    if not isinstance(samples, list) or len(samples) != 100:
        raise ValueError(f"{cell}/{seed}: expected 100 saved completion samples")
    for position, sample in enumerate(samples):
        _require_record_non_access(sample, context=f"{cell}/{seed}/dump/{position}")


def _validate_diagnostics(
    diagnostics: Sequence[Mapping[str, Any]],
    *,
    cell: str,
    seed: int,
    tag: str,
) -> tuple[tuple[tuple[int, ...], ...], tuple[float, float, float]]:
    if len(diagnostics) != 32:
        raise ValueError(f"{cell}/{seed}: expected 32 training diagnostic rows")
    schedule: list[tuple[int, ...]] = []
    generated_total = backward_total = scored_total = 0.0
    for round_index, diagnostic in enumerate(diagnostics):
        _require_fields(
            diagnostic,
            {
                "run_id": RUN_BY_CELL[cell],
                "model": MODEL,
                "task": "gsm8k",
                "method": METHOD_BY_CELL[cell],
                "seed": seed,
                "tag": tag,
                "round": round_index,
                "completed_rounds": round_index + 1,
            },
            context=f"{cell}/{seed} diagnostic {round_index}",
        )
        if cell == "PIS-S8-B8-U4":
            _require_fields(
                diagnostic,
                {
                    "schema_version": 9,
                    "algorithm_profile": "l2r_common_factorial",
                    "answer_event_mode": "strict_terminal_marker",
                    "answer_target_termination": "eos",
                    "buffer_semantics": "multiset_legacy",
                    "buffer_lifecycle": "fresh_round",
                },
                context=f"{cell}/{seed} diagnostic {round_index}",
            )
            generation = dict(diagnostic.get("generation") or {})
            _require_fields(
                generation,
                {
                    "proposal_prompt": "question",
                    "this_round": 64,
                    "cumulative": 64 * (round_index + 1),
                },
                context=f"{cell}/{seed} generation {round_index}",
            )
            pids = tuple(
                int(value)
                for value in (diagnostic.get("minibatch") or {}).get(
                    "answer_only_pids", []
                )
            )
            responsibilities = dict(diagnostic.get("responsibilities") or {})
            _require_fields(
                responsibilities,
                {
                    "score": "joint",
                    "posterior": "softmax_entropy",
                    "temperature": 1.0,
                    "ess_floor_fraction": 0.0,
                    "policy": "current",
                    "answer_policy": "current",
                    "refresh": "outer_round",
                    "variational_estimator": "prior_importance",
                },
                context=f"{cell}/{seed} responsibilities {round_index}",
            )
            inner = dict(diagnostic.get("inner_m_step") or {})
            _require_fields(
                inner,
                {
                    "attempted_steps": 4,
                    "accepted_steps": 4,
                    "rejected_steps": 0,
                    "cumulative_accepted_steps": 4 * (round_index + 1),
                },
                context=f"{cell}/{seed} M-step {round_index}",
            )
            objective = dict(diagnostic.get("objective") or {})
            _require_fields(
                objective,
                {
                    "gradient_steps_this_round": 4,
                    "gradient_steps_cumulative": 4 * (round_index + 1),
                    "latent_mstep_objective": "joint",
                    "update_geometry": "sum",
                },
                context=f"{cell}/{seed} objective {round_index}",
            )
            tokens = dict((diagnostic.get("compute") or {}).get("tokens") or {})
            generated_total += _finite(
                tokens.get("generated"), context=f"{cell}/{seed} generated tokens"
            )
            backward_total += _finite(
                tokens.get("backward"), context=f"{cell}/{seed} backward tokens"
            )
            scored_total += _finite(
                tokens.get("scored"), context=f"{cell}/{seed} scored tokens"
            )
        else:
            family = "grpo" if cell.startswith("GRPO") else "rloo"
            _require_fields(
                diagnostic,
                {"schema_version": 1, "method_family": family},
                context=f"{cell}/{seed} diagnostic {round_index}",
            )
            generation = dict(diagnostic.get("generation") or {})
            _require_fields(
                generation,
                {
                    "generations_this_round": 64,
                    "generations_cumulative": 64 * (round_index + 1),
                    "questions_this_round": 8,
                    "question_exposures_cumulative": 8 * (round_index + 1),
                    "question_schedule_rng": "dedicated",
                },
                context=f"{cell}/{seed} generation {round_index}",
            )
            pids = tuple(int(value) for value in generation.get("question_ids_this_round") or ())
            optimizer = dict(diagnostic.get("optimizer") or {})
            _require_fields(
                optimizer,
                {
                    "gradient_steps_this_round": 4,
                    "gradient_steps_cumulative": 4 * (round_index + 1),
                },
                context=f"{cell}/{seed} optimizer {round_index}",
            )
            generated_total = _finite(
                generation.get("generated_tokens_cumulative"),
                context=f"{cell}/{seed} generated tokens",
            )
            backward_total = _finite(
                optimizer.get("backward_tokens_cumulative"),
                context=f"{cell}/{seed} backward tokens",
            )
            scored_total = float("nan")
        if len(pids) != 8 or len(set(pids)) != 8 or any(not 0 <= value < 128 for value in pids):
            raise ValueError(f"{cell}/{seed}: malformed round-{round_index} question schedule")
        schedule.append(pids)
    flattened = [value for row in schedule for value in row]
    counts = {value: flattened.count(value) for value in range(128)}
    if set(counts.values()) != {2}:
        raise ValueError(f"{cell}/{seed}: epoch-shuffle exposure schedule changed")
    if generated_total <= 0 or backward_total <= 0:
        raise ValueError(f"{cell}/{seed}: non-positive realised training tokens")
    if cell == "PIS-S8-B8-U4" and scored_total <= 0:
        raise ValueError(f"{cell}/{seed}: non-positive teacher-forced scoring tokens")
    return tuple(schedule), (generated_total, backward_total, scored_total)


def _read_json_list(path: Path) -> list[dict[str, Any]]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{path}: invalid JSON list: {exc}") from exc
    if not isinstance(payload, list) or not all(isinstance(row, dict) for row in payload):
        raise ValueError(f"{path}: expected a JSON object list")
    return payload


def _validate_trajectory(
    rows: Sequence[Mapping[str, Any]], *, cell: str, seed: int
) -> None:
    if len(rows) != 32 or tuple(int(row.get("round", -1)) for row in rows) != tuple(
        range(32)
    ):
        raise ValueError(f"{cell}/{seed}: training trajectory rounds changed")
    terminal = rows[-1]
    if int(terminal.get("llm_gen", terminal.get("gen", -1))) != 2048:
        raise ValueError(f"{cell}/{seed}: trajectory generation budget changed")
    if int(terminal.get("gsteps", -1)) != 128:
        raise ValueError(f"{cell}/{seed}: trajectory optimizer schedule changed")
    if cell in {"GRPO-S8-B8-U4", "RLOO-S8-B8-U4"}:
        if int(terminal.get("question_exposures", -1)) != 256:
            raise ValueError(f"{cell}/{seed}: question exposure count changed")
        if int(terminal.get("unique_questions_seen", -1)) != 128:
            raise ValueError(f"{cell}/{seed}: unique-question coverage changed")


def _resources(
    result: Mapping[str, Any],
    *,
    cell: str,
    seed: int,
    diagnostic_tokens: tuple[float, float, float] | None,
) -> dict[str, float]:
    train_generations = _finite(
        result.get("train_llm_gen"), context=f"{cell}/{seed}/train_llm_gen"
    )
    expected_train = 0.0 if cell == "CTRL-base" else 2048.0
    if train_generations != expected_train:
        raise ValueError(f"{cell}/{seed}: scheduled completions changed")
    raw_steps = result.get("optimizer_steps")
    optimizer_steps = 0.0 if cell == "CTRL-base" and raw_steps is None else _finite(
        raw_steps, context=f"{cell}/{seed}/optimizer_steps"
    )
    expected_steps = 0.0 if cell == "CTRL-base" else 128.0
    if optimizer_steps != expected_steps:
        raise ValueError(f"{cell}/{seed}: optimizer-step count changed")
    if cell == "CTRL-base":
        generated = backward = scored = 0.0
    else:
        assert diagnostic_tokens is not None
        generated, backward, scored = diagnostic_tokens
        if result.get("generated_tokens") is not None:
            _close(
                result.get("generated_tokens"),
                generated,
                context=f"{cell}/{seed}/generated_tokens",
            )
        if result.get("backward_tokens") is not None:
            _close(
                result.get("backward_tokens"),
                backward,
                context=f"{cell}/{seed}/backward_tokens",
            )
        if cell == "PIS-S8-B8-U4" and result.get("teacher_forced_scoring_tokens") is not None:
            _close(
                result.get("teacher_forced_scoring_tokens"),
                scored,
                context=f"{cell}/{seed}/teacher_forced_scoring_tokens",
            )
    resources = {
        "train_llm_gen": train_generations,
        "eval_llm_gen": _finite(result.get("eval_llm_gen"), context=f"{cell}/{seed}/eval_llm_gen"),
        "llm_gen": _finite(result.get("llm_gen"), context=f"{cell}/{seed}/llm_gen"),
        "generated_tokens": generated,
        "backward_tokens": backward,
        "teacher_forced_scoring_tokens": scored,
        "optimizer_steps": optimizer_steps,
        "model_forward_calls": _finite(
            result.get("model_forward_calls"), context=f"{cell}/{seed}/model_forward_calls"
        ),
        "model_forward_input_tokens": _finite(
            result.get("model_forward_input_tokens"),
            context=f"{cell}/{seed}/model_forward_input_tokens",
        ),
        "accelerator_hours": _finite(
            result.get("accelerator_hours"), context=f"{cell}/{seed}/accelerator_hours"
        ),
        "peak_cuda_reserved_gb": _finite(
            result.get("peak_cuda_reserved_gb"),
            context=f"{cell}/{seed}/peak_cuda_reserved_gb",
        ),
        "pass8": _finite(result.get("pass8"), context=f"{cell}/{seed}/pass8"),
    }
    _require_fields(
        result,
        {
            "run_id": RUN_BY_CELL[cell],
            "model": MODEL,
            "task": "gsm8k",
            "train_partition": "train",
            "eval_partition": "validation",
            "evaluation_prompt": "question",
            "task_seed": seed,
            "method": METHOD_BY_CELL[cell],
            "seed": seed,
            "accelerator_count": 1,
        },
        context=f"{cell}/{seed} result",
    )
    if "H100" not in str(result.get("accelerator_name")):
        raise ValueError(f"{cell}/{seed}: result is not bound to one H100")
    for field in (
        "eval_llm_gen",
        "llm_gen",
        "model_forward_calls",
        "model_forward_input_tokens",
        "accelerator_hours",
        "peak_cuda_reserved_gb",
    ):
        if resources[field] <= 0:
            raise ValueError(f"{cell}/{seed}: non-positive {field}")
    return resources


def _cell_from_tag(tag: str, *, seed: int, allowed: Sequence[str]) -> str:
    matches = [cell for cell in allowed if tag.endswith(f"_{cell}_seed{seed}")]
    if len(matches) != 1:
        raise ValueError(f"cannot resolve registered cell from tag {tag!r}")
    return matches[0]


def _receipt_manifest_entry(
    root: Path, path: Path, payload: Mapping[str, Any]
) -> dict[str, Any]:
    return {
        "path": path.name,
        "sha256": _sha256(path),
        "cell_fingerprint": payload.get("cell_fingerprint"),
        "artifacts": [
            {
                "path": str(record["path"]),
                "size": int(record["size"]),
                "sha256": str(record["sha256"]),
            }
            for record in payload.get("artifacts") or []
        ],
        "root": str(root),
    }


def _load_root(
    root: Path,
    *,
    allowed_cells: Sequence[str],
) -> tuple[dict[tuple[str, int], CellEvidence], list[dict[str, Any]]]:
    receipt_paths = sorted(root.glob("complete_*.json"))
    expected_count = len(allowed_cells) * len(SEEDS)
    if len(receipt_paths) != expected_count:
        raise ValueError(
            f"{root}: expected {expected_count} completion receipts, found {len(receipt_paths)}"
        )
    evidence: dict[tuple[str, int], CellEvidence] = {}
    manifest: list[dict[str, Any]] = []
    for receipt_path in receipt_paths:
        try:
            receipt = validate_completion_receipt(
                receipt_path, result_root=root, verify_hashes=True
            )
        except (ResultContractError, OSError) as exc:
            raise ValueError(f"{receipt_path}: invalid completion receipt: {exc}") from exc
        identity = dict(receipt.get("identity") or {})
        seed = int(identity.get("seed", -1))
        tag = str(identity.get("tag") or "")
        if seed not in SEEDS:
            raise ValueError(f"{receipt_path}: unregistered training seed {seed}")
        cell = _cell_from_tag(tag, seed=seed, allowed=allowed_cells)
        coordinate = (cell, seed)
        if coordinate in evidence:
            raise ValueError(f"{root}: duplicate coordinate {coordinate}")
        method = METHOD_BY_CELL[cell]
        run_id = RUN_BY_CELL[cell]
        try:
            validate_receipt_identity(
                receipt,
                {
                    "run_id": run_id,
                    "task": "gsm8k",
                    "model": MODEL,
                    "method": method,
                    "seed": seed,
                    "tag": tag,
                },
            )
        except ResultContractError as exc:
            raise ValueError(f"{receipt_path}: receipt identity mismatch: {exc}") from exc
        observed_kinds = _artifact_kinds(receipt)
        expected_kinds = _expected_artifact_kinds(cell)
        if observed_kinds != expected_kinds:
            raise ValueError(
                f"{receipt_path}: artifact schema changed: {observed_kinds} != {expected_kinds}"
            )

        cell_path = _artifact(root, receipt, prefix="cell_result_", suffix=".json")
        cell_payload = _read_json(cell_path)
        cell_identity = dict(cell_payload.get("identity") or {})
        if cell_identity != identity:
            raise ValueError(f"{cell_path}: cell and receipt identities differ")
        result = dict(cell_payload.get("result") or {})
        _require_non_access(result, context=f"{cell}/{seed} result")
        if result.get("cell_fingerprint") != receipt.get("cell_fingerprint"):
            raise ValueError(f"{cell_path}: cell fingerprint differs from receipt")
        if result.get("completion_receipt") != receipt_path.name:
            raise ValueError(f"{cell_path}: completion-receipt binding changed")
        try:
            params = json.loads(str(result.get("params") or ""))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{cell_path}: invalid params JSON") from exc
        if not isinstance(params, dict) or str(params.get("run_id")) != run_id:
            raise ValueError(f"{cell_path}: params run-ID mismatch")
        expected_configuration = dict(params)
        expected_configuration.pop("env", None)
        if identity.get("configuration") != expected_configuration:
            raise ValueError(f"{cell_path}: receipt configuration differs from runtime params")
        commit = str((params.get("env") or {}).get("commit") or "")
        if len(commit) < 7 or not COMMIT_BY_CELL[cell].startswith(commit):
            raise ValueError(f"{cell_path}: execution commit mismatch {commit!r}")
        sweep = dict(params.get("sweep") or {})
        method_parameters = dict((params.get("methods") or {}).get(method) or {})
        _validate_sweep_contract(
            sweep,
            method_parameters,
            cell=cell,
            seed=seed,
            context=f"{cell}/{seed} runtime contract",
        )
        expected_save_adapter = cell in {"GRPO-S8-B8-U4", "RLOO-S8-B8-U4"}
        if sweep.get("save_adapter") is not expected_save_adapter:
            raise ValueError(f"{cell}/{seed}: adapter-retention contract changed")
        sweep_path = root / f"sweep_gsm8k__{tag}.csv"
        if not sweep_path.is_file() or sweep_path.is_symlink():
            raise ValueError(f"{cell}/{seed}: exact sweep artifact is absent")
        with sweep_path.open(encoding="utf-8", newline="") as stream:
            sweep_rows = list(csv.DictReader(stream))
        if len(sweep_rows) != 1:
            raise ValueError(f"{sweep_path}: expected one sweep row")
        sweep_row = sweep_rows[0]
        if sweep_row.get("cell_fingerprint") != receipt.get("cell_fingerprint"):
            raise ValueError(f"{sweep_path}: sweep fingerprint differs from receipt")
        if json.loads(str(sweep_row.get("params") or "")) != params:
            raise ValueError(f"{sweep_path}: sweep params differ from cell result")
        if cell in {"GRPO-S8-B8-U4", "RLOO-S8-B8-U4"}:
            _validate_adapter(receipt, root, context=f"{cell}/{seed} adapter")

        eval_path = _artifact(root, receipt, prefix="eval_", suffix=".json")
        evaluation = _read_json(eval_path)
        final_order, final_records, train_qi, shot_qi = _validate_evaluation(
            evaluation, cell=cell, seed=seed
        )
        if tuple(int(value) for value in result.get("train_qi") or ()) != train_qi:
            raise ValueError(f"{cell}/{seed}: result/evaluation train questions differ")
        if tuple(int(value) for value in result.get("shot_qi") or ()) != shot_qi:
            raise ValueError(f"{cell}/{seed}: result/evaluation shots differ")
        prompt_path = _artifact(
            root, receipt, prefix="prompt_contract_", suffix=".json.gz"
        )
        prompt = _read_json_gz(prompt_path)
        _validate_prompt(
            prompt,
            cell=cell,
            method=method,
            seed=seed,
            tag=tag,
            train_qi=train_qi,
            shot_qi=shot_qi,
        )
        dump_path = _artifact(root, receipt, prefix="dump_", suffix=".json")
        _validate_dump(_read_json(dump_path), cell=cell, seed=seed)

        if cell == "CTRL-base":
            checkpoints: list[dict[str, Any]] = []
            diagnostics: list[dict[str, Any]] = []
            schedule: tuple[tuple[int, ...], ...] = ()
            diagnostic_tokens = None
        else:
            checkpoint_path = _artifact(
                root, receipt, prefix="checkpoint_eval_", suffix=".jsonl.gz"
            )
            checkpoints = _read_jsonl_gz(checkpoint_path)
            _validate_checkpoints(
                checkpoints,
                cell=cell,
                seed=seed,
                tag=tag,
                final_order=final_order,
                final_records=final_records,
            )
            diagnostics_path = _artifact(
                root, receipt, prefix="training_diagnostics_", suffix=".jsonl.gz"
            )
            diagnostics = _read_jsonl_gz(diagnostics_path)
            schedule, diagnostic_tokens = _validate_diagnostics(
                diagnostics, cell=cell, seed=seed, tag=tag
            )
            trajectory_path = _artifact(root, receipt, prefix="traj_", suffix=".json")
            _validate_trajectory(
                _read_json_list(trajectory_path), cell=cell, seed=seed
            )
        resources = _resources(
            result,
            cell=cell,
            seed=seed,
            diagnostic_tokens=diagnostic_tokens,
        )
        passk_path = _artifact(root, receipt, prefix="passk_", suffix=".json")
        passk = _read_json(passk_path)
        _validate_passk(passk, cell=cell, seed=seed, result=result)
        evidence[coordinate] = CellEvidence(
            cell=cell,
            seed=seed,
            tag=tag,
            method=method,
            run_id=run_id,
            receipt_path=receipt_path,
            receipt=receipt,
            result=result,
            evaluation=evaluation,
            final_records=final_records,
            checkpoints=checkpoints,
            diagnostics=diagnostics,
            passk=passk,
            prompt=prompt,
            schedule=schedule,
            resources=resources,
        )
        manifest_entry = _receipt_manifest_entry(root, receipt_path, receipt)
        manifest_entry.update(
            {
                "cell": cell,
                "seed": seed,
                "sweep_path": sweep_path.name,
                "sweep_sha256": _sha256(sweep_path),
                "execution_commit": COMMIT_BY_CELL[cell],
            }
        )
        manifest.append(manifest_entry)
    expected_coordinates = {
        (cell, seed) for cell in allowed_cells for seed in SEEDS
    }
    if set(evidence) != expected_coordinates:
        raise ValueError(f"{root}: coordinate coverage is incomplete")
    return evidence, manifest


def _gold_support(cell: CellEvidence) -> tuple[tuple[int, str], ...]:
    return tuple(
        (question_id, str(cell.final_records[question_id].get("gold")))
        for question_id in cell.final_records
    )


def _prompt_support(cell: CellEvidence) -> tuple[tuple[Any, ...], ...]:
    train_qi = tuple(int(value) for value in cell.evaluation.get("train_qi") or ())
    shot_qi = tuple(int(value) for value in cell.evaluation.get("shot_qi") or ())
    return _validate_prompt(
        cell.prompt,
        cell=cell.cell,
        method=cell.method,
        seed=cell.seed,
        tag=cell.tag,
        train_qi=train_qi,
        shot_qi=shot_qi,
    )


def verify_union_pairing(evidence: Mapping[tuple[str, int], CellEvidence]) -> None:
    global_validation_support: tuple[tuple[int, str], ...] | None = None
    for seed in SEEDS:
        coordinates = [evidence[(cell, seed)] for cell in CELL_ORDER]
        train_support = {
            tuple(int(value) for value in item.evaluation.get("train_qi") or ())
            for item in coordinates
        }
        shot_support = {
            tuple(int(value) for value in item.evaluation.get("shot_qi") or ())
            for item in coordinates
        }
        prompt_support = {_prompt_support(item) for item in coordinates}
        validation_support = {_gold_support(item) for item in coordinates}
        pass8_support = {
            tuple(
                (int(row.get("idx", -1)), str(row.get("gold")))
                for row in item.passk.get("records") or []
            )
            for item in coordinates
        }
        if len(train_support) != 1:
            raise ValueError(f"seed {seed}: optimization questions differ across arms")
        if len(shot_support) != 1 or len(prompt_support) != 1:
            raise ValueError(f"seed {seed}: demonstrations or prompts differ across arms")
        if len(validation_support) != 1:
            raise ValueError(f"seed {seed}: validation questions/golds differ across arms")
        if len(pass8_support) != 1:
            raise ValueError(f"seed {seed}: pass@8 questions/golds differ across arms")
        support = tuple(sorted(next(iter(validation_support))))
        if global_validation_support is None:
            global_validation_support = support
        elif support != global_validation_support:
            raise ValueError("evaluation question identities changed across paired seeds")
        grpo_schedule = evidence[("GRPO-S8-B8-U4", seed)].schedule
        rloo_schedule = evidence[("RLOO-S8-B8-U4", seed)].schedule
        if grpo_schedule != rloo_schedule:
            raise ValueError(f"seed {seed}: registered GRPO/RLOO question schedules differ")


def load_union_results(
    *,
    source_root: Path,
    comparator_root: Path,
) -> tuple[dict[tuple[str, int], CellEvidence], list[dict[str, Any]]]:
    source, source_manifest = _load_root(source_root, allowed_cells=CELL_ORDER[:2])
    comparator, comparator_manifest = _load_root(
        comparator_root, allowed_cells=CELL_ORDER[2:]
    )
    overlap = set(source) & set(comparator)
    if overlap:
        raise ValueError(f"source/add-on coordinate overlap is forbidden: {sorted(overlap)}")
    evidence = {**source, **comparator}
    expected = {(cell, seed) for cell in CELL_ORDER for seed in SEEDS}
    if set(evidence) != expected:
        raise ValueError("four-arm union is incomplete")
    verify_union_pairing(evidence)
    return evidence, [*source_manifest, *comparator_manifest]


def _normalized_auc(values: np.ndarray) -> np.ndarray:
    if values.ndim != 2 or values.shape[1] != len(ROUNDS):
        raise ValueError("trajectory AUC requires the exact registered schedule")
    integrate = getattr(np, "trapezoid", None)
    if integrate is None:  # NumPy < 2
        integrate = np.trapz
    return integrate(values, np.asarray(ROUNDS, dtype=float), axis=1) / 32.0


def build_metrics(
    evidence: Mapping[tuple[str, int], CellEvidence]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    question_rows: list[dict[str, Any]] = []
    seed_rows: list[dict[str, Any]] = []
    resource_rows: list[dict[str, Any]] = []
    for seed in SEEDS:
        base = evidence[("CTRL-base", seed)]
        order = tuple(base.final_records)
        base_extracted = np.asarray(
            [bool(base.final_records[index]["legacy_correct"]) for index in order],
            dtype=float,
        )
        base_strict = np.asarray(
            [bool(base.final_records[index]["strict_correct"]) for index in order],
            dtype=float,
        )
        for cell in CELL_ORDER:
            item = evidence[(cell, seed)]
            extracted = np.empty((400, len(ROUNDS)), dtype=float)
            strict = np.empty((400, len(ROUNDS)), dtype=float)
            extracted[:, 0] = base_extracted
            strict[:, 0] = base_strict
            if cell == "CTRL-base":
                extracted[:, 1:] = base_extracted[:, None]
                strict[:, 1:] = base_strict[:, None]
            else:
                for checkpoint_index, checkpoint in enumerate(item.checkpoints, start=1):
                    mapped = {
                        int(record["idx"]): record
                        for record in checkpoint.get("records") or []
                    }
                    extracted[:, checkpoint_index] = [
                        bool(mapped[index]["legacy_correct"]) for index in order
                    ]
                    strict[:, checkpoint_index] = [
                        bool(mapped[index]["strict_correct"]) for index in order
                    ]
            final_extracted = np.asarray(
                [bool(item.final_records[index]["legacy_correct"]) for index in order],
                dtype=float,
            )
            final_strict = np.asarray(
                [bool(item.final_records[index]["strict_correct"]) for index in order],
                dtype=float,
            )
            if not np.array_equal(extracted[:, -1], final_extracted):
                raise ValueError(f"{cell}/{seed}: final extracted reconstruction changed")
            if not np.array_equal(strict[:, -1], final_strict):
                raise ValueError(f"{cell}/{seed}: final strict reconstruction changed")
            extracted_auc = _normalized_auc(extracted)
            strict_auc = _normalized_auc(strict)
            late_columns = [index for index, round_value in enumerate(ROUNDS) if round_value >= 8]
            question_late_drop = (
                extracted[:, late_columns].max(axis=1) - extracted[:, -1]
            )
            seed_late_drop = float(
                extracted[:, late_columns].mean(axis=0).max()
                - extracted[:, -1].mean()
            )
            for position, question_id in enumerate(order):
                record = item.final_records[question_id]
                question_rows.append(
                    {
                        "cell": cell,
                        "seed": seed,
                        "question_id": question_id,
                        "gold": str(record.get("gold")),
                        "final_extracted": float(final_extracted[position]),
                        "final_strict": float(final_strict[position]),
                        "extracted_auc": float(extracted_auc[position]),
                        "strict_auc": float(strict_auc[position]),
                        "question_late_peak_to_final_extracted_drop": float(
                            question_late_drop[position]
                        ),
                        "natural_eos": float(bool(record["generated_eos"])),
                        "strict_format_failure": float(
                            bool(record["strict_format_failure"])
                        ),
                        "hit_token_limit": float(bool(record["hit_max_new_tokens"])),
                    }
                )
            seed_rows.append(
                {
                    "cell": cell,
                    "seed": seed,
                    "final_extracted": float(final_extracted.mean()),
                    "final_strict": float(final_strict.mean()),
                    "extracted_auc": float(extracted_auc.mean()),
                    "strict_auc": float(strict_auc.mean()),
                    "late_peak_to_final_extracted_drop": seed_late_drop,
                    "natural_eos": float(
                        np.mean(
                            [
                                bool(item.final_records[index]["generated_eos"])
                                for index in order
                            ]
                        )
                    ),
                    "strict_format_failure": float(
                        np.mean(
                            [
                                bool(
                                    item.final_records[index][
                                        "strict_format_failure"
                                    ]
                                )
                                for index in order
                            ]
                        )
                    ),
                    "hit_token_limit": float(
                        np.mean(
                            [
                                bool(item.final_records[index]["hit_max_new_tokens"])
                                for index in order
                            ]
                        )
                    ),
                    "pass8": float(item.resources["pass8"]),
                }
            )
            resource_rows.append(
                {"cell": cell, "seed": seed, **dict(item.resources)}
            )
    questions = pd.DataFrame(question_rows)
    seeds = pd.DataFrame(seed_rows)
    resources = pd.DataFrame(resource_rows)
    if len(questions) != len(CELL_ORDER) * len(SEEDS) * 400:
        raise ValueError("question-metric union is incomplete")
    expected = {(cell, seed) for cell in CELL_ORDER for seed in SEEDS}
    if set(zip(seeds["cell"], seeds["seed"], strict=True)) != expected:
        raise ValueError("seed-metric union is incomplete")
    return questions, seeds, resources


def exact_paired_seed_bootstrap(values: Sequence[float]) -> np.ndarray:
    """All 7^7 ordinary bootstrap means for the seven paired seed effects."""

    observed = np.asarray(values, dtype=float)
    if observed.shape != (7,) or not np.isfinite(observed).all():
        raise ValueError("exact paired bootstrap requires seven finite seed effects")
    totals = observed.copy()
    for _ in range(6):
        totals = (totals[:, None] + observed[None, :]).reshape(-1)
    return totals / 7.0


def _exact_sign_flip_p(values: Sequence[float]) -> float:
    observed = np.asarray(values, dtype=float)
    point = abs(float(observed.mean()))
    signs = np.asarray(
        [
            [1.0 if mask & (1 << bit) else -1.0 for bit in range(7)]
            for mask in range(1 << 7)
        ]
    )
    return float(np.mean(np.abs((signs * observed).mean(axis=1)) >= point - 1e-15))


def paired_contrasts(seed_metrics: pd.DataFrame) -> pd.DataFrame:
    pairs = (
        ("trained_vs_base", "PIS-S8-B8-U4", "CTRL-base"),
        ("trained_vs_base", "GRPO-S8-B8-U4", "CTRL-base"),
        ("trained_vs_base", "RLOO-S8-B8-U4", "CTRL-base"),
        ("registered_pis_competitiveness", "PIS-S8-B8-U4", "GRPO-S8-B8-U4"),
        ("registered_pis_competitiveness", "PIS-S8-B8-U4", "RLOO-S8-B8-U4"),
        ("comparator_description", "GRPO-S8-B8-U4", "RLOO-S8-B8-U4"),
    )
    rows = []
    for family, treatment, control in pairs:
        for metric in METRICS:
            pivot = seed_metrics.pivot(index="seed", columns="cell", values=metric).reindex(
                SEEDS
            )
            differences = (pivot[treatment] - pivot[control]).to_numpy(float)
            distribution = exact_paired_seed_bootstrap(differences)
            low_one = float(np.quantile(distribution, ONE_SIDED_ALPHA))
            low_two, high_two = np.quantile(distribution, [0.025, 0.975])
            rows.append(
                {
                    "family": family,
                    "treatment": treatment,
                    "control": control,
                    "metric": metric,
                    "observational_unit": "paired training seed",
                    "seed_count": 7,
                    "bootstrap": "exact ordinary paired-seed bootstrap (7^7 resamples)",
                    "mean_difference": float(differences.mean()),
                    "mean_difference_pp": 100.0 * float(differences.mean()),
                    "one_sided_95_lower": low_one,
                    "one_sided_95_lower_pp": 100.0 * low_one,
                    "two_sided_95_low": float(low_two),
                    "two_sided_95_high": float(high_two),
                    "two_sided_95_low_pp": 100.0 * float(low_two),
                    "two_sided_95_high_pp": 100.0 * float(high_two),
                    "positive_seeds": int((differences > 0).sum()),
                    "zero_seeds": int((differences == 0).sum()),
                    "negative_seeds": int((differences < 0).sum()),
                    "exact_two_sided_sign_flip_p": _exact_sign_flip_p(differences),
                    "seed_differences_json": json.dumps(
                        {
                            str(seed): float(value)
                            for seed, value in zip(SEEDS, differences, strict=True)
                        },
                        sort_keys=True,
                    ),
                }
            )
    return pd.DataFrame(rows)


def summarize_methods(
    seed_metrics: pd.DataFrame, resources: pd.DataFrame
) -> pd.DataFrame:
    resource_fields = tuple(
        field for field in resources.columns if field not in {"cell", "seed"}
    )
    rows = []
    for cell in CELL_ORDER:
        metrics = seed_metrics[seed_metrics["cell"] == cell]
        cost = resources[resources["cell"] == cell]
        row: dict[str, Any] = {
            "cell": cell,
            "seed_count": len(metrics),
            **{
                field: float(metrics[field].mean())
                for field in (
                    "final_extracted",
                    "final_strict",
                    "extracted_auc",
                    "strict_auc",
                    "late_peak_to_final_extracted_drop",
                    "natural_eos",
                    "strict_format_failure",
                    "hit_token_limit",
                    "pass8",
                )
            },
        }
        for field in resource_fields:
            row[f"mean_{field}"] = float(cost[field].mean())
            row[f"sd_{field}"] = float(cost[field].std(ddof=1))
        rows.append(row)
    return pd.DataFrame(rows)


def _registered_primary_row(
    contrasts: pd.DataFrame, comparator: str
) -> Mapping[str, Any]:
    selected = contrasts[
        (contrasts["family"] == "registered_pis_competitiveness")
        & (contrasts["treatment"] == "PIS-S8-B8-U4")
        & (contrasts["control"] == comparator)
        & (contrasts["metric"] == "final_extracted")
    ]
    if len(selected) != 1:
        raise ValueError(f"missing registered primary contrast against {comparator}")
    return selected.iloc[0].to_dict()


def build_decision(contrasts: pd.DataFrame) -> dict[str, Any]:
    gates: dict[str, Any] = {}
    for comparator in ("GRPO-S8-B8-U4", "RLOO-S8-B8-U4"):
        row = _registered_primary_row(contrasts, comparator)
        lower = float(row["one_sided_95_lower"])
        positive = int(row["positive_seeds"])
        gates[comparator] = {
            "metric": "final_extracted_answer_accuracy",
            "contrast": f"PIS-S8-B8-U4 minus {comparator}",
            "mean_difference": float(row["mean_difference"]),
            "one_sided_95_lower": lower,
            "positive_seeds": positive,
            "competitive_margin": COMPETITIVENESS_MARGIN,
            "competitive": lower > COMPETITIVENESS_MARGIN,
            "superior": lower > 0.0 and positive >= 5,
        }
    competitive = all(item["competitive"] for item in gates.values())
    superior_to_both = all(item["superior"] for item in gates.values())
    return {
        "schema_version": 1,
        "analysis_status": "complete",
        "classification": (
            "pis_competitive_with_both_matched_comparators"
            if competitive
            else "pis_not_competitive_with_both_matched_comparators"
        ),
        "pis_competitive_with_both": competitive,
        "pis_superior_to_both": superior_to_both,
        "gates": gates,
        "reporting_order": list(REPORTING_ORDER),
        "inferential_unit": "paired training seed",
        "one_sided_alpha": ONE_SIDED_ALPHA,
        "competitiveness_rule": "lower bound strictly exceeds -0.01 against both comparators",
        "superiority_rule": "lower bound strictly exceeds zero and at least five of seven seed effects are positive",
        "auc_can_rescue_endpoint": False,
        "official_test_used": False,
    }


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def run_analysis(args: argparse.Namespace) -> dict[str, Any]:
    design = validate_designs(args.source_config, args.comparator_config)
    markers = verify_markers(args.source_marker, args.comparator_marker)
    log_hashes = verify_logs(
        source_log_dir=args.source_log_dir,
        source_validator_log=args.source_validator_log,
        comparator_log_dir=args.comparator_log_dir,
        comparator_validator_log=args.comparator_validator_log,
    )
    evidence, receipt_manifest = load_union_results(
        source_root=args.source_root,
        comparator_root=args.comparator_root,
    )
    questions, seeds, resources = build_metrics(evidence)
    contrasts = paired_contrasts(seeds)
    summary = summarize_methods(seeds, resources)
    decision = build_decision(contrasts)
    provenance = {
        "schema_version": 1,
        "analysis_contract": "frozen four-arm source union",
        "design": design,
        "markers": markers,
        "jobs": {
            "source_base_recovery": SOURCE_RECOVERY_JOB,
            "source_trained": SOURCE_TRAINED_JOB,
            "source_validator": SOURCE_VALIDATOR_JOB,
            "comparator_payload": COMPARATOR_JOB,
            "comparator_validator": COMPARATOR_VALIDATOR_JOB,
        },
        "commits": {
            "source_base_recovery": SOURCE_RECOVERY_COMMIT,
            "source_trained": SOURCE_TRAINED_COMMIT,
            "source_validator": SOURCE_VALIDATOR_COMMIT,
            "comparator": COMPARATOR_COMMIT,
        },
        "log_sha256": log_hashes,
        "receipts": receipt_manifest,
        "receipt_count": len(receipt_manifest),
        "official_test_used": False,
    }
    analysis = {
        "schema_version": 1,
        "analysis_status": "complete",
        "logical_run_ids": [SOURCE_RUN_ID, COMPARATOR_RUN_ID],
        "cell_order": list(CELL_ORDER),
        "seed_values": list(SEEDS),
        "question_count": 400,
        "checkpoint_rounds": list(CHECKPOINTS),
        "reporting_order": list(REPORTING_ORDER),
        "primary_metric": "final_extracted_answer_accuracy",
        "secondary_metric": "final_strict_terminal_accuracy",
        "third_metric": "normalized_extracted_accuracy_auc",
        "inferential_unit": "paired training seed",
        "uncertainty": "exact ordinary paired-seed bootstrap over all 7^7 resamples",
        "question_rows_are_independent_units": False,
        "auc_can_rescue_endpoint": False,
        "official_test_used": False,
        "decision_file": "decision.json",
        "limitations": [
            "The fixed 400-question training-derived validation partition has been repeatedly used for development.",
            "The base/PIS and GRPO/RLOO segments use distinct immutable execution commits; this analysis therefore verifies their exact scientific union rather than assuming equivalence.",
            "Scheduled completions and optimizer steps are matched, while realised token and accelerator costs are reported and may differ.",
            "The official GSM8K test remains sealed.",
        ],
    }
    args.output_dir.mkdir(parents=True, exist_ok=False)
    questions.to_csv(args.output_dir / "question_metrics.csv.gz", index=False)
    seeds.to_csv(args.output_dir / "seed_metrics.csv", index=False)
    resources.to_csv(args.output_dir / "seed_resources.csv", index=False)
    summary.to_csv(args.output_dir / "method_summary.csv", index=False)
    contrasts.to_csv(args.output_dir / "paired_contrasts.csv", index=False)
    tradeoffs = summary[
        [
            "cell",
            "final_extracted",
            "final_strict",
            "extracted_auc",
            *[column for column in summary.columns if column.startswith("mean_")],
        ]
    ]
    tradeoffs.to_csv(args.output_dir / "accuracy_resource_tradeoffs.csv", index=False)
    _write_json(args.output_dir / "decision.json", decision)
    _write_json(args.output_dir / "provenance_manifest.json", provenance)
    _write_json(args.output_dir / "analysis.json", analysis)
    return decision


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source-config",
        type=Path,
        default=LM_STUDY / "experiments_qwen3_17b_pis_confirmation.yaml",
    )
    parser.add_argument(
        "--comparator-config",
        type=Path,
        default=LM_STUDY / "experiments_qwen3_17b_gsm8k_matched_comparators.yaml",
    )
    parser.add_argument("--source-root", type=Path)
    parser.add_argument("--source-marker", type=Path)
    parser.add_argument("--source-log-dir", type=Path)
    parser.add_argument("--source-validator-log", type=Path)
    parser.add_argument("--comparator-root", type=Path)
    parser.add_argument("--comparator-marker", type=Path)
    parser.add_argument("--comparator-log-dir", type=Path)
    parser.add_argument("--comparator-validator-log", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--validate-design-only", action="store_true")
    args = parser.parse_args()
    design = validate_designs(args.source_config, args.comparator_config)
    if args.validate_design_only:
        print(json.dumps(design, sort_keys=True))
        return 0
    required = (
        "source_root",
        "source_marker",
        "source_log_dir",
        "source_validator_log",
        "comparator_root",
        "comparator_marker",
        "comparator_log_dir",
        "comparator_validator_log",
        "output_dir",
    )
    missing = [name for name in required if getattr(args, name) is None]
    if missing:
        parser.error(f"full analysis requires: {', '.join(missing)}")
    decision = run_analysis(args)
    print(json.dumps(decision, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
