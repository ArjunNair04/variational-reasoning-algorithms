"""Analyze a matched joint-score versus token-mean AC-ALG1 stability study.

The primary estimand is the normalized validation-accuracy area under the
rounds 0--30 curve (AUC). Round 0 is the frozen four-shot reference. AUC is
reported by seed, then contrasted at the held-out-question level so repeated
checkpoints are not treated as independent observations.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from analysis.analyze_ac_alg1_numerical_study import (
        _exact_mcnemar_p,
        _paired_bootstrap_interval,
        load_cells,
        load_checkpoint_trajectories,
    )
except ModuleNotFoundError:  # Direct execution from analysis/.
    from analyze_ac_alg1_numerical_study import (
        _exact_mcnemar_p,
        _paired_bootstrap_interval,
        load_cells,
        load_checkpoint_trajectories,
    )


def summarize_curves(
    trajectories: pd.DataFrame,
    reference_accuracy: float,
    slope_start_round: int = 10,
) -> pd.DataFrame:
    """Summarize one validation trajectory per arm and seed."""

    rows: list[dict] = []
    for (arm, seed), group in trajectories.groupby(["arm", "seed"]):
        group = group.sort_values("completed_rounds")
        rounds = np.concatenate(([0.0], group["completed_rounds"].to_numpy(float)))
        accuracy = np.concatenate(([reference_accuracy], group["test_acc"].to_numpy(float)))
        final_round = float(rounds[-1])
        auc = float(np.trapezoid(accuracy, rounds) / final_round)
        peak_index = int(np.argmax(accuracy))
        slope_mask = rounds >= slope_start_round
        slope = (
            float(np.polyfit(rounds[slope_mask], accuracy[slope_mask], 1)[0] * 100.0)
            if int(slope_mask.sum()) >= 2
            else float("nan")
        )

        row = {
            "arm": arm,
            "seed": int(seed),
            "n_checkpoints": len(group),
            "final_round": int(final_round),
            "normalized_accuracy_auc": auc,
            "normalized_accuracy_deficit_auc": reference_accuracy - auc,
            "peak_accuracy": float(accuracy[peak_index]),
            "peak_round": int(rounds[peak_index]),
            "final_accuracy": float(accuracy[-1]),
            "final_difference_from_base": float(accuracy[-1] - reference_accuracy),
            "slope_round10_to_final_pp_per_round": slope,
        }
        for label, drop in (("2pp", 0.02), ("5pp", 0.05)):
            eligible = rounds[(rounds > 0) & (accuracy <= reference_accuracy - drop)]
            row[f"first_{label}_drop_round"] = (
                int(eligible[0]) if len(eligible) else float("nan")
            )
            row[f"avoided_{label}_drop_through_final"] = not len(eligible)
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["seed", "arm"])


def aggregate_trajectories(
    trajectories: pd.DataFrame,
    reference_accuracy: float,
) -> pd.DataFrame:
    """Aggregate checkpoints across seeds after adding the shared round-zero base."""

    arms = sorted(trajectories["arm"].unique())
    seeds = sorted(trajectories["seed"].unique())
    round_zero = pd.DataFrame([
        {
            "arm": arm,
            "seed": int(seed),
            "completed_rounds": 0,
            "test_acc": reference_accuracy,
        }
        for arm in arms
        for seed in seeds
    ])
    combined = pd.concat(
        [round_zero, trajectories[["arm", "seed", "completed_rounds", "test_acc"]]],
        ignore_index=True,
    )
    return (
        combined.groupby(["arm", "completed_rounds"], as_index=False)
        .agg(
            n_seeds=("seed", "nunique"),
            mean_accuracy=("test_acc", "mean"),
            min_accuracy=("test_acc", "min"),
            max_accuracy=("test_acc", "max"),
            std_accuracy=("test_acc", "std"),
        )
        .sort_values(["arm", "completed_rounds"])
    )


def seed_auc_contrasts(
    curve_summary: pd.DataFrame,
    joint_arm: str,
    token_arm: str,
) -> pd.DataFrame:
    """Return token-mean minus joint AUC for every matched seed."""

    pivot = curve_summary.pivot(
        index="seed", columns="arm", values="normalized_accuracy_auc"
    )
    missing = {joint_arm, token_arm} - set(pivot.columns)
    if missing:
        raise ValueError(f"missing configured arms: {sorted(missing)}")
    paired = pivot[[joint_arm, token_arm]].dropna().copy()
    return pd.DataFrame({
        "seed": paired.index.astype(int),
        "joint_auc": paired[joint_arm].to_numpy(float),
        "token_mean_auc": paired[token_arm].to_numpy(float),
        "token_minus_joint_auc": (
            paired[token_arm] - paired[joint_arm]
        ).to_numpy(float),
    })


def question_auc_contrasts(
    table: pd.DataFrame,
    checkpoint_evaluations: dict[tuple[str, int, int], dict],
    joint_arm: str,
    token_arm: str,
) -> pd.DataFrame:
    """Integrate paired correctness differences for each question and seed."""

    rows: list[dict] = []
    for seed in sorted(table["seed"].unique()):
        tags = {
            str(cell["arm"]): str(cell["tag"])
            for _, cell in table[table["seed"] == seed].iterrows()
        }
        if joint_arm not in tags or token_arm not in tags:
            continue
        joint_rounds = {
            rounds: record
            for (tag, checkpoint_seed, rounds), record in checkpoint_evaluations.items()
            if tag == tags[joint_arm] and checkpoint_seed == int(seed)
        }
        token_rounds = {
            rounds: record
            for (tag, checkpoint_seed, rounds), record in checkpoint_evaluations.items()
            if tag == tags[token_arm] and checkpoint_seed == int(seed)
        }
        shared_rounds = sorted(set(joint_rounds) & set(token_rounds))
        if not shared_rounds:
            continue

        joint_by_round = {
            rounds: {
                int(item["idx"]): float(bool(item["correct"]))
                for item in joint_rounds[rounds].get("records", [])
            }
            for rounds in shared_rounds
        }
        token_by_round = {
            rounds: {
                int(item["idx"]): float(bool(item["correct"]))
                for item in token_rounds[rounds].get("records", [])
            }
            for rounds in shared_rounds
        }
        shared_questions = set.intersection(
            *(set(joint_by_round[rounds]) & set(token_by_round[rounds])
              for rounds in shared_rounds)
        )
        x = np.array([0, *shared_rounds], dtype=float)
        for question_id in sorted(shared_questions):
            differences = np.array([
                0.0,
                *(
                    token_by_round[rounds][question_id]
                    - joint_by_round[rounds][question_id]
                    for rounds in shared_rounds
                ),
            ])
            rows.append({
                "seed": int(seed),
                "idx": int(question_id),
                "token_minus_joint_auc": float(
                    np.trapezoid(differences, x) / float(shared_rounds[-1])
                ),
                "n_shared_checkpoints": len(shared_rounds),
                "final_round": int(shared_rounds[-1]),
            })
    return pd.DataFrame(rows).sort_values(["seed", "idx"]) if rows else pd.DataFrame()


def checkpoint_contrasts(
    table: pd.DataFrame,
    checkpoint_evaluations: dict[tuple[str, int, int], dict],
    joint_arm: str,
    token_arm: str,
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Compute paired token-minus-joint accuracy at every shared checkpoint."""

    rows: list[dict] = []
    for seed in sorted(table["seed"].unique()):
        tags = {
            str(cell["arm"]): str(cell["tag"])
            for _, cell in table[table["seed"] == seed].iterrows()
        }
        if joint_arm not in tags or token_arm not in tags:
            continue
        rounds = sorted({
            checkpoint_round
            for tag, checkpoint_seed, checkpoint_round in checkpoint_evaluations
            if checkpoint_seed == int(seed) and tag in {tags[joint_arm], tags[token_arm]}
            and (tags[joint_arm], int(seed), checkpoint_round) in checkpoint_evaluations
            and (tags[token_arm], int(seed), checkpoint_round) in checkpoint_evaluations
        })
        for completed_rounds in rounds:
            joint = {
                int(item["idx"]): bool(item["correct"])
                for item in checkpoint_evaluations[
                    (tags[joint_arm], int(seed), completed_rounds)
                ].get("records", [])
            }
            token = {
                int(item["idx"]): bool(item["correct"])
                for item in checkpoint_evaluations[
                    (tags[token_arm], int(seed), completed_rounds)
                ].get("records", [])
            }
            shared = sorted(set(joint) & set(token))
            joint_values = np.array([joint[idx] for idx in shared], dtype=float)
            token_values = np.array([token[idx] for idx in shared], dtype=float)
            differences = token_values - joint_values
            fixed = int(np.sum((token_values == 1) & (joint_values == 0)))
            broke = int(np.sum((token_values == 0) & (joint_values == 1)))
            low, high = _paired_bootstrap_interval(
                differences,
                draws=draws,
                seed=bootstrap_seed + int(seed) * 100 + completed_rounds,
            )
            rows.append({
                "seed": int(seed),
                "completed_rounds": int(completed_rounds),
                "n_paired": len(shared),
                "token_minus_joint_accuracy": float(differences.mean()),
                "ci95_low": low,
                "ci95_high": high,
                "fixed_vs_joint": fixed,
                "broke_vs_joint": broke,
                "mcnemar_exact_p": _exact_mcnemar_p(fixed, broke),
            })
    return pd.DataFrame(rows).sort_values(["seed", "completed_rounds"])


def aggregate_decision(
    seed_contrasts: pd.DataFrame,
    question_contrasts: pd.DataFrame,
    draws: int,
    bootstrap_seed: int,
) -> dict:
    """Apply the frozen strong/directional/unsupported decision rule."""

    seed_values = seed_contrasts["token_minus_joint_auc"].to_numpy(float)
    by_question = (
        question_contrasts.groupby("idx")["token_minus_joint_auc"].mean()
        if not question_contrasts.empty
        else pd.Series(dtype=float)
    )
    question_values = by_question.to_numpy(float)
    low, high = _paired_bootstrap_interval(
        question_values,
        draws=draws,
        seed=bootstrap_seed,
    )
    positive_seeds = int(np.sum(seed_values > 0))
    mean_difference = float(seed_values.mean()) if len(seed_values) else float("nan")
    if len(seed_values) and positive_seeds == len(seed_values) and low > 0:
        verdict = "strong_support"
    elif len(seed_values) and positive_seeds >= math.ceil(len(seed_values) / 2) and mean_difference > 0:
        verdict = "directional_support"
    else:
        verdict = "unsupported"
    return {
        "verdict": verdict,
        "n_seeds": int(len(seed_values)),
        "positive_seed_auc_differences": positive_seeds,
        "mean_token_minus_joint_auc": mean_difference,
        "n_question_clusters": int(len(question_values)),
        "question_cluster_ci95_low": low,
        "question_cluster_ci95_high": high,
        "scope_note": (
            "The question-cluster interval conditions on the three tested seeds; "
            "seed-level signs are reported separately."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result_dir", type=Path)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--joint-arm", default="C0")
    parser.add_argument("--token-arm", default="C1")
    parser.add_argument("--reference-accuracy", type=float, default=0.7925)
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260721)
    parser.add_argument("--write-dir", type=Path, default=None)
    args = parser.parse_args()

    table, _ = load_cells(
        args.result_dir.expanduser(), args.prefix, args.config, final_rounds=10
    )
    trajectories, checkpoint_evaluations = load_checkpoint_trajectories(
        args.result_dir.expanduser(), table
    )
    curves = summarize_curves(trajectories, args.reference_accuracy)
    aggregate_curves = aggregate_trajectories(trajectories, args.reference_accuracy)
    seeds = seed_auc_contrasts(curves, args.joint_arm, args.token_arm)
    questions = question_auc_contrasts(
        table, checkpoint_evaluations, args.joint_arm, args.token_arm
    )
    checkpoints = checkpoint_contrasts(
        table,
        checkpoint_evaluations,
        args.joint_arm,
        args.token_arm,
        args.bootstrap_draws,
        args.bootstrap_seed,
    )
    decision = aggregate_decision(
        seeds, questions, args.bootstrap_draws, args.bootstrap_seed
    )

    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", None)
    print("=== COLLAPSE CURVE SUMMARY ===")
    print(curves.to_string(index=False))
    print("\n=== SEED-LEVEL AUC CONTRASTS ===")
    print(seeds.to_string(index=False))
    print("\n=== FROZEN DECISION ===")
    print(json.dumps(decision, indent=2, sort_keys=True))

    if args.write_dir is not None:
        args.write_dir.mkdir(parents=True, exist_ok=True)
        table.sort_values(["seed", "arm"]).to_csv(
            args.write_dir / "collapse_cell_mechanism_summary.csv", index=False
        )
        curves.to_csv(args.write_dir / "collapse_curve_summary.csv", index=False)
        aggregate_curves.to_csv(
            args.write_dir / "collapse_aggregate_trajectories.csv", index=False
        )
        seeds.to_csv(args.write_dir / "collapse_seed_auc_contrasts.csv", index=False)
        questions.to_csv(args.write_dir / "collapse_question_auc_contrasts.csv", index=False)
        checkpoints.to_csv(args.write_dir / "collapse_checkpoint_contrasts.csv", index=False)
        (args.write_dir / "collapse_decision.json").write_text(
            json.dumps(decision, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
