#!/usr/bin/env python3
"""Analyse answer-conditioned PIS against its paired native-PIS control.

The native PIS coordinates come only from the contemporaneous final-method
confirmation. The add-on changes the proposal distribution and applies the
mathematically required sample-time importance correction. Paired training
seed is the independent replicate; matched validation questions are resampled
inside each seed for uncertainty intervals.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
LM_STUDY = REPOSITORY_ROOT / "lm_study"
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))
if str(LM_STUDY) not in sys.path:
    sys.path.insert(0, str(LM_STUDY))

from generate_qwen3_17b_answer_conditioned_pis_addon import (  # noqa: E402
    CELL_ID as ADDON_CELL,
    RUN_ID as ADDON_RUN_ID,
    build_payload as build_addon_payload,
)
from generate_qwen3_17b_final_method_confirmation import (  # noqa: E402
    CHECKPOINTS,
    RUN_ID as CONTROL_RUN_ID,
    SEEDS,
    build_payload as build_control_payload,
)
from result_contract import (  # noqa: E402
    ResultContractError,
    validate_completion_receipt,
    validate_receipt_identity,
)
from run_yaml import _prepare_cells  # noqa: E402
from validate_yaml_run import (  # noqa: E402
    _validate_answer_conditioned_importance_diagnostics,
)

from analysis.analyze_qwen3_final_method_confirmation import (  # noqa: E402
    _artifact,
    _finite,
    _read_json,
    _read_json_gz,
    _read_jsonl_gz,
    _records_by_question,
    _require_non_access,
    _resource_totals,
    verify_marker as verify_control_marker,
)


CONTROL_CELL = "PIS-S8-B8-U4"
BASE_CELL = "CTRL-base"
CELL_ORDER = (CONTROL_CELL, ADDON_CELL)
METRICS = ("final_extracted", "final_strict", "extracted_auc", "strict_auc")
REPORTING_ORDER = (
    "final_extracted_answer_accuracy",
    "final_strict_terminal_accuracy",
    "normalized_extracted_trajectory_auc",
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _raw_cell(config: Mapping[str, Any], cell_id: str) -> tuple[str, dict[str, Any]]:
    matches = []
    for method, raw in (config.get("algos") or {}).items():
        variants = raw if isinstance(raw, list) else [raw]
        for variant in variants:
            cell = dict(variant)
            if cell.get("cell_id") == cell_id:
                matches.append((str(method), cell))
    if len(matches) != 1:
        raise ValueError(f"expected exactly one configured cell {cell_id!r}")
    return matches[0]


def _prepared_tag(config: Mapping[str, Any], cell_id: str) -> tuple[str, str]:
    raw_method, _raw = _raw_cell(config, cell_id)
    prepared = _prepare_cells(
        dict(config),
        only=None,
        run_id=str(config["run_id"]),
        defaults=dict(config["defaults"]),
    )
    raw_ids = []
    for _method, raw in (config.get("algos") or {}).items():
        variants = raw if isinstance(raw, list) else [raw]
        raw_ids.extend(str(variant.get("cell_id")) for variant in variants)
    index = raw_ids.index(cell_id)
    model, method, _axes, tag = prepared[index]
    if str(model) != "qwen3-1.7b-base" or str(method) != raw_method:
        raise ValueError(f"{cell_id}: prepared model or method changed")
    return raw_method, str(tag)


def load_design(
    control_config_path: Path,
    addon_config_path: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    control = yaml.safe_load(control_config_path.read_text(encoding="utf-8"))
    addon = yaml.safe_load(addon_config_path.read_text(encoding="utf-8"))
    if control != build_control_payload():
        raise ValueError("control configuration differs from its frozen generator")
    if addon != build_addon_payload():
        raise ValueError("add-on configuration differs from its frozen generator")
    control_defaults = dict(control["defaults"])
    addon_defaults = dict(addon["defaults"])
    control_defaults.pop("out")
    addon_defaults.pop("out")
    if addon_defaults != control_defaults:
        raise ValueError("control and add-on common defaults differ")
    _control_method, control_cell = _raw_cell(control, CONTROL_CELL)
    _addon_method, addon_cell = _raw_cell(addon, ADDON_CELL)
    expected_changes = {
        "cell_id": (CONTROL_CELL, ADDON_CELL),
        "algorithm_profile": (
            "l2r_common_factorial",
            "l2r_answer_conditioned_importance",
        ),
        "proposal_prompt": ("question", "answer_derive"),
        "variational_estimator": (
            "prior_importance",
            "answer_conditioned_importance",
        ),
    }
    observed_changes = {
        key: (control_cell.get(key), addon_cell.get(key))
        for key in set(control_cell) | set(addon_cell)
        if control_cell.get(key) != addon_cell.get(key)
    }
    if observed_changes != expected_changes:
        raise ValueError(f"unexpected add-on intervention: {observed_changes}")
    return control, addon


def verify_addon_marker(
    marker_path: Path,
    config_path: Path,
    *,
    expected_commit: str,
    expected_source_job: str,
) -> dict[str, Any]:
    marker = _read_json(marker_path)
    expected = {
        "schema_version": 1,
        "status": "ok",
        "run_id": ADDON_RUN_ID,
        "execution_commit": expected_commit,
        "configuration_sha256": _sha256(config_path),
        "source_job_id": expected_source_job,
    }
    mismatches = {
        field: (marker.get(field), value)
        for field, value in expected.items()
        if marker.get(field) != value
    }
    if mismatches:
        raise ValueError(f"add-on validator marker mismatch: {mismatches}")
    return marker


def _prompt_contract(
    payload: Mapping[str, Any],
    *,
    tag: str,
    seed: int,
    mode: str,
) -> dict[int, str]:
    expected = {
        "schema_version": 1,
        "tag": tag,
        "training_seed": seed,
        "proposal_prompt_mode": mode,
        "answer_event_mode": "strict_terminal_marker",
    }
    mismatches = {
        field: (payload.get(field), value)
        for field, value in expected.items()
        if payload.get(field) != value
    }
    if mismatches:
        raise ValueError(f"{tag}: prompt-contract mismatch {mismatches}")
    rows = payload.get("rows")
    if not isinstance(rows, list) or len(rows) != 128:
        raise ValueError(f"{tag}: expected 128 prompt-contract rows")
    canonical: dict[int, str] = {}
    for row in rows:
        index = int(row.get("dataset_train_index", -1))
        digest = str(row.get("canonical_prompt_sha256") or "")
        if index < 0 or index in canonical or len(digest) != 64:
            raise ValueError(f"{tag}: malformed prompt-contract row")
        if row.get("canonical_contains_proposal_answer_hint") is not False:
            raise ValueError(f"{tag}: canonical prompt contains an answer hint")
        if row.get("proposal_contains_gold_answer_hint") is not (
            mode == "answer_derive"
        ):
            raise ValueError(f"{tag}: proposal answer-hint status changed")
        canonical[index] = digest
    return canonical


def _coordinate(
    artifact_dir: Path,
    config: Mapping[str, Any],
    *,
    cell_id: str,
    seed: int,
    expected_commit: str,
    prompt_mode: str,
    require_importance_identity: bool,
) -> dict[str, Any]:
    method, base_tag = _prepared_tag(config, cell_id)
    tag = f"{base_tag}_seed{seed}"
    run_id = str(config["run_id"])
    receipt_path = artifact_dir / f"complete_gsm8k__{tag}__{method}_s{seed}.json"
    try:
        receipt = validate_completion_receipt(
            receipt_path, result_root=artifact_dir, verify_hashes=True
        )
        validate_receipt_identity(
            receipt,
            {
                "run_id": run_id,
                "task": "gsm8k",
                "model": "qwen3-1.7b-base",
                "method": method,
                "seed": seed,
                "tag": tag,
            },
        )
    except (OSError, ResultContractError) as exc:
        raise ValueError(f"{receipt_path}: invalid receipt: {exc}") from exc

    result_path = _artifact(
        artifact_dir, receipt, prefix="cell_result_", suffix=".json"
    )
    result = dict(_read_json(result_path).get("result") or {})
    _require_non_access(result, context=result_path.name)
    params = json.loads(str(result.get("params") or ""))
    observed_commit = str((params.get("env") or {}).get("commit") or "")
    if not observed_commit or not expected_commit.startswith(observed_commit):
        raise ValueError(f"{result_path}: execution commit mismatch")
    sweep = dict(params.get("sweep") or {})
    if method != "base":
        expected_sweep = {
            "lora_target_set": "attention_mlp",
            "G": 8,
            "B": 64,
        }
        for field, value in expected_sweep.items():
            if sweep.get(field) != value:
                raise ValueError(f"{result_path}: {field} changed")
        method_params = dict((params.get("methods") or {}).get(method) or {})
        expected_method = {
            "responsibility_refresh": "outer_round",
            "buffer_lifecycle": "fresh_round",
            "buffer_semantics": "multiset_legacy",
            "iters": 4,
            "buffer_limit": 8,
            "proposal_prompt": prompt_mode,
            "variational_estimator": (
                "answer_conditioned_importance"
                if require_importance_identity
                else "prior_importance"
            ),
        }
        for field, value in expected_method.items():
            if method_params.get(field) != value:
                raise ValueError(f"{result_path}: {field} changed")
        if int(result.get("train_llm_gen", -1)) != 2048:
            raise ValueError(f"{result_path}: proposal budget changed")
        if int(result.get("optimizer_steps", -1)) != 128:
            raise ValueError(f"{result_path}: optimiser schedule changed")

    eval_path = _artifact(artifact_dir, receipt, prefix="eval_", suffix=".json")
    evaluation = _read_json(eval_path)
    _require_non_access(evaluation, context=eval_path.name)
    order, final_records = _records_by_question(
        evaluation.get("records") or [], context=eval_path.name
    )
    train_questions = tuple(int(value) for value in evaluation.get("train_qi") or ())
    if len(train_questions) != 128 or len(set(train_questions)) != 128:
        raise ValueError(f"{eval_path}: optimisation-question schedule changed")

    checkpoint_records = []
    diagnostics = []
    if method != "base":
        checkpoint_path = _artifact(
            artifact_dir, receipt, prefix="checkpoint_eval_", suffix=".jsonl.gz"
        )
        checkpoints = _read_jsonl_gz(checkpoint_path)
        if tuple(int(row.get("completed_rounds", -1)) for row in checkpoints) != CHECKPOINTS:
            raise ValueError(f"{checkpoint_path}: checkpoint schedule changed")
        for index, checkpoint in enumerate(checkpoints):
            records_order, records = _records_by_question(
                checkpoint.get("records") or [],
                context=f"{checkpoint_path.name}/{index}",
            )
            if records_order != order:
                raise ValueError(f"{checkpoint_path}: question order changed")
            checkpoint_records.append(records)

        diagnostics_path = _artifact(
            artifact_dir,
            receipt,
            prefix="training_diagnostics_",
            suffix=".jsonl.gz",
        )
        diagnostics = _read_jsonl_gz(diagnostics_path)
        if len(diagnostics) != 32:
            raise ValueError(f"{diagnostics_path}: expected 32 diagnostic rows")
        if require_importance_identity:
            problems: list[str] = []
            _validate_answer_conditioned_importance_diagnostics(
                problems,
                path=diagnostics_path,
                diagnostics=diagnostics,
            )
            if problems:
                raise ValueError("; ".join(problems))

    prompt_path = _artifact(
        artifact_dir, receipt, prefix="prompt_contract_", suffix=".json.gz"
    )
    prompt_hashes = _prompt_contract(
        _read_json_gz(prompt_path), tag=tag, seed=seed, mode=prompt_mode
    )
    if method == "base":
        return {
            "cell": cell_id,
            "seed": seed,
            "order": order,
            "final": final_records,
            "checkpoints": [],
            "train_questions": train_questions,
            "prompt_hashes": prompt_hashes,
            "resources": None,
            "mechanism": None,
        }
    generated, backward, scored = _resource_totals(method, result, diagnostics)
    ess = []
    maximum = []
    correction = []
    for diagnostic in diagnostics:
        partition = (
            ((diagnostic.get("responsibilities") or {}).get("partitions") or {}).get(
                "answer_only"
            )
            or {}
        )
        ess.append(
            _finite(
                partition.get("mean_effective_sample_size_fraction"),
                context=f"{tag}/ESS",
            )
        )
        maximum.append(
            _finite(
                partition.get("mean_max_responsibility"),
                context=f"{tag}/max responsibility",
            )
        )
        if require_importance_identity:
            traces = (diagnostic.get("responsibilities") or {}).get("traces") or []
            correction.extend(
                _finite(
                    trace.get("log_importance_correction"),
                    context=f"{tag}/importance correction",
                )
                for trace in traces
            )
    return {
        "cell": cell_id,
        "seed": seed,
        "order": order,
        "final": final_records,
        "checkpoints": checkpoint_records,
        "train_questions": train_questions,
        "prompt_hashes": prompt_hashes,
        "resources": {
            "cell": cell_id,
            "seed": seed,
            "generated_tokens": generated,
            "backward_tokens": backward,
            "teacher_forced_scoring_tokens": scored,
            "optimizer_steps": 128,
            "accelerator_hours": _finite(
                result.get("accelerator_hours"), context=f"{tag}/accelerator hours"
            ),
            "pass8": _finite(result.get("pass8"), context=f"{tag}/pass8"),
        },
        "mechanism": {
            "cell": cell_id,
            "seed": seed,
            "mean_ess_fraction": float(np.mean(ess)),
            "minimum_round_ess_fraction": float(np.min(ess)),
            "mean_max_responsibility": float(np.mean(maximum)),
            "mean_log_importance_correction": (
                float(np.mean(correction)) if correction else math.nan
            ),
        },
    }


def _normalized_auc(values: np.ndarray) -> np.ndarray:
    rounds = np.asarray((0, *CHECKPOINTS), dtype=float)
    if values.shape != (400, len(rounds)):
        raise ValueError(f"unexpected trajectory shape {values.shape}")
    return np.trapezoid(values, rounds, axis=1) / float(CHECKPOINTS[-1])


def build_metrics(
    control_artifact_dir: Path,
    addon_artifact_dir: Path,
    control: Mapping[str, Any],
    addon: Mapping[str, Any],
    *,
    control_commit: str,
    addon_commit: str,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    question_rows = []
    seed_rows = []
    resource_rows = []
    mechanism_rows = []
    for seed in SEEDS:
        base = _coordinate(
            control_artifact_dir,
            control,
            cell_id=BASE_CELL,
            seed=seed,
            expected_commit=control_commit,
            prompt_mode="question",
            require_importance_identity=False,
        )
        native = _coordinate(
            control_artifact_dir,
            control,
            cell_id=CONTROL_CELL,
            seed=seed,
            expected_commit=control_commit,
            prompt_mode="question",
            require_importance_identity=False,
        )
        corrected = _coordinate(
            addon_artifact_dir,
            addon,
            cell_id=ADDON_CELL,
            seed=seed,
            expected_commit=addon_commit,
            prompt_mode="answer_derive",
            require_importance_identity=True,
        )
        for candidate in (native, corrected):
            if candidate["order"] != base["order"]:
                raise ValueError(f"{candidate['cell']}/{seed}: validation support changed")
            if candidate["train_questions"] != base["train_questions"]:
                raise ValueError(f"{candidate['cell']}/{seed}: training schedule changed")
            if candidate["prompt_hashes"] != base["prompt_hashes"]:
                raise ValueError(f"{candidate['cell']}/{seed}: canonical prompt changed")

            order = candidate["order"]
            extracted = np.empty((400, len(CHECKPOINTS) + 1), dtype=float)
            strict = np.empty_like(extracted)
            extracted[:, 0] = [
                bool(base["final"][question]["legacy_correct"]) for question in order
            ]
            strict[:, 0] = [
                bool(base["final"][question]["strict_correct"]) for question in order
            ]
            for position, records in enumerate(candidate["checkpoints"], start=1):
                extracted[:, position] = [
                    bool(records[question]["legacy_correct"]) for question in order
                ]
                strict[:, position] = [
                    bool(records[question]["strict_correct"]) for question in order
                ]
            final_extracted = np.asarray(
                [bool(candidate["final"][question]["legacy_correct"]) for question in order],
                dtype=float,
            )
            final_strict = np.asarray(
                [bool(candidate["final"][question]["strict_correct"]) for question in order],
                dtype=float,
            )
            if not np.array_equal(extracted[:, -1], final_extracted):
                raise ValueError(f"{candidate['cell']}/{seed}: final extracted mismatch")
            if not np.array_equal(strict[:, -1], final_strict):
                raise ValueError(f"{candidate['cell']}/{seed}: final strict mismatch")
            extracted_auc = _normalized_auc(extracted)
            strict_auc = _normalized_auc(strict)
            for index, question in enumerate(order):
                question_rows.append(
                    {
                        "cell": candidate["cell"],
                        "seed": seed,
                        "question_id": question,
                        "final_extracted": final_extracted[index],
                        "final_strict": final_strict[index],
                        "extracted_auc": extracted_auc[index],
                        "strict_auc": strict_auc[index],
                    }
                )
            seed_rows.append(
                {
                    "cell": candidate["cell"],
                    "seed": seed,
                    "final_extracted": float(final_extracted.mean()),
                    "final_strict": float(final_strict.mean()),
                    "extracted_auc": float(extracted_auc.mean()),
                    "strict_auc": float(strict_auc.mean()),
                }
            )
            resource_rows.append(candidate["resources"])
            mechanism_rows.append(candidate["mechanism"])
    return (
        pd.DataFrame(question_rows),
        pd.DataFrame(seed_rows),
        pd.DataFrame(resource_rows),
        pd.DataFrame(mechanism_rows),
    )


def question_cube(question_metrics: pd.DataFrame) -> np.ndarray:
    cube = np.empty((2, len(SEEDS), 400, len(METRICS)), dtype=float)
    reference_ids = None
    for seed_index, seed in enumerate(SEEDS):
        for cell_index, cell in enumerate(CELL_ORDER):
            frame = question_metrics[
                (question_metrics["cell"] == cell)
                & (question_metrics["seed"] == seed)
            ].sort_values("question_id")
            ids = tuple(int(value) for value in frame["question_id"])
            if len(ids) != 400:
                raise ValueError(f"{cell}/{seed}: incomplete question support")
            if reference_ids is None:
                reference_ids = ids
            elif ids != reference_ids:
                raise ValueError(f"{cell}/{seed}: unpaired question support")
            cube[cell_index, seed_index] = frame[list(METRICS)].to_numpy(float)
    return cube


def nested_paired_bootstrap(
    cube: np.ndarray,
    *,
    draws: int,
    seed: int,
    chunk_size: int = 250,
) -> np.ndarray:
    if cube.shape != (2, len(SEEDS), 400, len(METRICS)):
        raise ValueError(f"unexpected metric cube shape {cube.shape}")
    if draws < 1 or chunk_size < 1:
        raise ValueError("bootstrap draws and chunk size must be positive")
    rng = np.random.default_rng(seed)
    output = np.empty((draws, len(METRICS)), dtype=float)
    differences = cube[1] - cube[0]
    for start in range(0, draws, chunk_size):
        stop = min(start + chunk_size, draws)
        count = stop - start
        sampled_seeds = rng.integers(0, len(SEEDS), size=(count, len(SEEDS)))
        sampled_questions = rng.integers(0, 400, size=(count, len(SEEDS), 400))
        chunk = np.zeros((count, len(METRICS)), dtype=float)
        for replicate in range(len(SEEDS)):
            selected = differences[sampled_seeds[:, replicate]]
            indices = sampled_questions[:, replicate, :, None]
            sampled = np.take_along_axis(selected, indices, axis=1)
            chunk += sampled.mean(axis=1)
        output[start:stop] = chunk / float(len(SEEDS))
    return output


def contrast_table(
    seed_metrics: pd.DataFrame,
    cube: np.ndarray,
    bootstrap: np.ndarray,
) -> pd.DataFrame:
    rows = []
    pivot = {
        metric: seed_metrics.pivot(index="seed", columns="cell", values=metric).reindex(
            SEEDS
        )
        for metric in METRICS
    }
    for metric_index, metric in enumerate(METRICS):
        seed_effects = pivot[metric][ADDON_CELL] - pivot[metric][CONTROL_CELL]
        low, high = np.quantile(bootstrap[:, metric_index], [0.025, 0.975])
        point = float((cube[1, :, :, metric_index] - cube[0, :, :, metric_index]).mean())
        rows.append(
            {
                "treatment": ADDON_CELL,
                "control": CONTROL_CELL,
                "metric": metric,
                "mean_difference": point,
                "mean_difference_pp": 100.0 * point,
                "hierarchical_ci95_low": float(low),
                "hierarchical_ci95_high": float(high),
                "hierarchical_ci95_low_pp": 100.0 * float(low),
                "hierarchical_ci95_high_pp": 100.0 * float(high),
                "positive_seeds": int((seed_effects > 0).sum()),
            }
        )
    return pd.DataFrame(rows)


def decision_from_contrasts(contrasts: pd.DataFrame) -> dict[str, Any]:
    indexed = contrasts.set_index("metric")
    final = indexed.loc["final_extracted"]
    strict = indexed.loc["final_strict"]
    auc = indexed.loc["extracted_auc"]
    gates = {
        "exact_importance_identity_and_finite_proposals": True,
        "final_extracted_superiority": float(final["hierarchical_ci95_low"]) > 0.0,
        "final_extracted_noninferiority_1pp": (
            float(final["hierarchical_ci95_low"]) > -0.01
        ),
        "strict_final_noninferiority_2pp": (
            float(strict["hierarchical_ci95_low"]) > -0.02
        ),
        "extracted_auc_noninferiority_1pp": (
            float(auc["hierarchical_ci95_low"]) > -0.01
        ),
        "five_of_seven_positive_final_effects": int(final["positive_seeds"]) >= 5,
    }
    gates["advance_as_superior"] = all(
        gates[name]
        for name in (
            "exact_importance_identity_and_finite_proposals",
            "final_extracted_superiority",
            "strict_final_noninferiority_2pp",
            "extracted_auc_noninferiority_1pp",
            "five_of_seven_positive_final_effects",
        )
    )
    gates["retain_as_mechanism_positive"] = all(
        gates[name]
        for name in (
            "exact_importance_identity_and_finite_proposals",
            "final_extracted_noninferiority_1pp",
            "strict_final_noninferiority_2pp",
            "extracted_auc_noninferiority_1pp",
        )
    )
    return gates


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--control-config", type=Path, required=True)
    parser.add_argument("--control-artifact-dir", type=Path, required=True)
    parser.add_argument("--control-marker", type=Path, required=True)
    parser.add_argument("--control-commit", required=True)
    parser.add_argument("--control-source-job", required=True)
    parser.add_argument("--addon-config", type=Path, required=True)
    parser.add_argument("--addon-artifact-dir", type=Path, required=True)
    parser.add_argument("--addon-marker", type=Path, required=True)
    parser.add_argument("--addon-commit", required=True)
    parser.add_argument("--addon-source-job", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=20_000)
    parser.add_argument("--bootstrap-seed", type=int, default=2_026_081_802)
    args = parser.parse_args()

    control, addon = load_design(args.control_config, args.addon_config)
    control_marker = verify_control_marker(
        args.control_marker,
        args.control_config,
        expected_commit=args.control_commit,
        expected_source_job=args.control_source_job,
    )
    addon_marker = verify_addon_marker(
        args.addon_marker,
        args.addon_config,
        expected_commit=args.addon_commit,
        expected_source_job=args.addon_source_job,
    )
    questions, seeds, resources, mechanism = build_metrics(
        args.control_artifact_dir,
        args.addon_artifact_dir,
        control,
        addon,
        control_commit=args.control_commit,
        addon_commit=args.addon_commit,
    )
    cube = question_cube(questions)
    bootstrap = nested_paired_bootstrap(
        cube, draws=args.bootstrap_draws, seed=args.bootstrap_seed
    )
    contrasts = contrast_table(seeds, cube, bootstrap)
    decision = decision_from_contrasts(contrasts)
    summary = (
        seeds.groupby("cell", as_index=False)[list(METRICS)]
        .mean()
        .set_index("cell")
        .reindex(CELL_ORDER)
        .reset_index()
    )
    analysis = {
        "schema_version": 1,
        "analysis_status": "complete",
        "control_run_id": CONTROL_RUN_ID,
        "addon_run_id": ADDON_RUN_ID,
        "official_test_used": False,
        "metric_order": list(REPORTING_ORDER),
        "observational_unit": "paired training seed",
        "uncertainty": (
            "nested paired bootstrap over training seeds and matched validation questions"
        ),
        "bootstrap_draws": args.bootstrap_draws,
        "bootstrap_seed": args.bootstrap_seed,
        "control_marker": control_marker,
        "addon_marker": addon_marker,
        "decision_gates": decision,
        "limitations": [
            "The 400-question training-derived validation partition was reused during development.",
            "The proposal and its required correction change together, so this study estimates their combined effect.",
            "The official GSM8K test remains sealed.",
        ],
    }
    args.output_dir.mkdir(parents=True, exist_ok=False)
    questions.to_csv(args.output_dir / "question_metrics.csv.gz", index=False)
    seeds.to_csv(args.output_dir / "seed_metrics.csv", index=False)
    resources.to_csv(args.output_dir / "seed_resources.csv", index=False)
    mechanism.to_csv(args.output_dir / "mechanism_diagnostics.csv", index=False)
    summary.to_csv(args.output_dir / "method_summary.csv", index=False)
    contrasts.to_csv(args.output_dir / "paired_contrasts.csv", index=False)
    _write_json(args.output_dir / "analysis.json", analysis)
    print(json.dumps(analysis, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
