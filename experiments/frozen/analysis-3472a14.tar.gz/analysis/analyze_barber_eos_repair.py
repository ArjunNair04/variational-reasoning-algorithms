"""Analyse the matched no-EOS/EOS Barber answer-factor screen.

The paired run seed is the observational unit. Repeated checkpoints and
question-level records are measurements within a seed, not independent
replicates. This three-seed screen can nominate at most one confirmation
candidate; it cannot select a method or license official-test evaluation.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import itertools
import json
import math
import re
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

from analysis.analyze_barber_source_programme import (
    CHECKPOINT_ROUNDS,
    paired_bootstrap,
    verify_mirror,
)


SEEDS = (31, 47, 73)
BASE_CELL = "CTRL-base"
PAIRS = {
    "F001": ("NOEOS-F001", "EOS-F001"),
    "F111": ("NOEOS-F111", "EOS-F111"),
    "Q4": ("NOEOS-Q4", "EOS-Q4"),
    "Q5": ("NOEOS-Q5", "EOS-Q5"),
}
CELLS = (BASE_CELL, *(cell for pair in PAIRS.values() for cell in pair))

METRICS = {
    "strict": "test_acc_strict",
    "legacy": "test_acc_legacy",
    "strict_correct_eos": "eval_strict_correct_and_eos_fraction",
    "natural_eos": "eval_natural_eos_fraction",
    "hit_max": "eval_hit_max_new_fraction",
    "multiple_marker": "eval_multiple_marker_fraction",
    "nonterminal": "eval_nonterminal_marker_fraction",
    "direct_answer_only": "eval_direct_answer_only_fraction",
    "nonempty_reasoning": "eval_nonempty_reasoning_fraction",
    "strict_correct_reasoning": "eval_strict_correct_with_reasoning_fraction",
}
ENDPOINT_ONLY_METRICS = {
    "eos_given_strict_correct": "eval_eos_given_strict_correct_fraction",
}
RESULT_METRICS = {**METRICS, **ENDPOINT_ONLY_METRICS}
CONTRAST_SPECS = {
    "strict_auc": ("strict_auc", True),
    "strict_round10": ("strict_round10", False),
    "strict_final": ("strict_final", False),
    "legacy_auc": ("legacy_auc", False),
    "legacy_final": ("legacy_final", False),
    "strict_correct_eos_auc": ("strict_correct_eos_auc", False),
    "natural_eos_final": ("natural_eos_final", False),
    "eos_given_strict_correct_final": (
        "eos_given_strict_correct_final",
        False,
    ),
    "hit_max_final": ("hit_max_final", False),
    "multiple_marker_final": ("multiple_marker_final", False),
    "nonterminal_final": ("nonterminal_final", False),
    "direct_answer_only_final": ("direct_answer_only_final", False),
    "nonempty_reasoning_final": ("nonempty_reasoning_final", False),
    "strict_correct_reasoning_final": (
        "strict_correct_reasoning_final",
        False,
    ),
    "pass8_final": ("pass8_final", False),
}

TAG_RE = re.compile(
    r"_(CTRL-base|(?:NOEOS|EOS)-(?:F001|F111|Q4|Q5))_seed(\d+)$"
)


def extract_cell_seed(tag: str) -> tuple[str, int]:
    """Extract the registered cell and seed from an artifact identity tag."""

    match = TAG_RE.search(tag)
    if not match:
        raise ValueError(f"cannot extract EOS cell/seed from tag: {tag}")
    return match.group(1), int(match.group(2))


def _read_jsonl_gz(path: Path) -> list[dict[str, Any]]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _finite_float(value: Any, *, context: str) -> float:
    if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
        raise ValueError(f"{context}: expected a finite numeric value, found {value!r}")
    return float(value)


def _optional_finite_float(value: Any, *, context: str) -> float:
    if value is None:
        return math.nan
    return _finite_float(value, context=context)


def _require_validation_non_access(
    payload: Mapping[str, Any], *, context: str, prefix: str = "eval"
) -> None:
    source_key = (
        "passk_eval_source_split"
        if prefix == "passk"
        else "eval_source_split"
    )
    loaded_key = f"{prefix}_dataset_splits_loaded"
    if payload.get(f"{prefix}_official_test_accessed") is not False:
        raise ValueError(f"{context}: official-test non-access is not proven")
    if payload.get(source_key) != "train":
        raise ValueError(f"{context}: evaluation source split is not train")
    if payload.get(loaded_key) != ["train"]:
        raise ValueError(f"{context}: loaded dataset splits are not ['train']")


def load_cells(artifact_dir: Path, *, expected_run_id: str) -> pd.DataFrame:
    """Load and validate all 9 x 3 terminal cell summaries."""

    rows: list[dict[str, Any]] = []
    for path in sorted(artifact_dir.glob("cell_result_*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        identity = payload["identity"]
        result = payload["result"]
        if str(identity.get("run_id")) != expected_run_id:
            raise ValueError(
                f"{path.name}: run ID {identity.get('run_id')!r}, "
                f"expected {expected_run_id!r}"
            )
        _require_validation_non_access(
            result, context=path.name, prefix="eval"
        )
        _require_validation_non_access(
            result, context=path.name, prefix="passk"
        )
        cell, seed = extract_cell_seed(identity["tag"])
        configuration = identity["configuration"]
        termination = configuration["sweep"].get("answer_target_termination", "none")
        expected_termination = "eos" if cell.startswith("EOS-") else "none"
        if termination != expected_termination:
            raise ValueError(
                f"{identity['tag']}: termination={termination!r}, "
                f"expected {expected_termination!r}"
            )
        row = {
            "cell": cell,
            "seed": seed,
            "tag": identity["tag"],
            "run_id": str(identity["run_id"]),
            "termination": termination,
            "seconds": _finite_float(result["secs"], context=f"{cell}/{seed}/secs"),
        }
        for metric, key in RESULT_METRICS.items():
            row[f"{metric}_final"] = _optional_finite_float(
                result.get(key), context=f"{cell}/{seed}/{key}"
            )
        rows.append(row)

    table = pd.DataFrame(rows)
    expected = {(cell, seed) for cell in CELLS for seed in SEEDS}
    observed = set(zip(table["cell"], table["seed"], strict=True))
    if observed != expected:
        raise ValueError(
            f"cell/seed mismatch; missing={sorted(expected - observed)}, "
            f"extra={sorted(observed - expected)}"
        )
    if table.duplicated(["cell", "seed"]).any():
        raise ValueError("duplicate cell/seed result")
    run_ids = set(table["run_id"])
    if len(run_ids) != 1:
        raise ValueError(f"mixed run IDs in artifact mirror: {sorted(run_ids)}")
    return table.sort_values(["cell", "seed"]).reset_index(drop=True)


def load_pass8(
    cells: pd.DataFrame,
    artifact_dir: Path,
    *,
    expected_run_id: str,
) -> pd.DataFrame:
    """Load pass@8 from per-question records and verify validation provenance."""

    rows: list[dict[str, Any]] = []
    for cell in cells.to_dict("records"):
        path = _single_artifact(
            artifact_dir,
            f"passk_gsm8k__{cell['tag']}__*_s{cell['seed']}.json",
            f"{cell['tag']}/pass@8",
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        if str(payload.get("run_id")) != expected_run_id:
            raise ValueError(f"{path.name}: run ID mismatch")
        _require_validation_non_access(
            payload, context=path.name, prefix="passk"
        )
        records = payload.get("records")
        if not isinstance(records, list) or len(records) != 100:
            raise ValueError(f"{path.name}: expected 100 pass@8 records")
        if any(record.get("k") != 8 for record in records):
            raise ValueError(f"{path.name}: expected k=8 in every record")
        for index, record in enumerate(records):
            if record.get("official_test_accessed") is not False:
                raise ValueError(
                    f"{path.name}: record {index} lacks non-access evidence"
                )
            if record.get("eval_source_split") != "train":
                raise ValueError(
                    f"{path.name}: record {index} source split is not train"
                )
            if record.get("dataset_splits_loaded") != ["train"]:
                raise ValueError(
                    f"{path.name}: record {index} loaded splits are not ['train']"
                )
        derived = float(
            np.mean([int(record["n_correct"]) > 0 for record in records])
        )
        reported = _finite_float(
            payload.get("pass8"), context=f"{path.name}/pass8"
        )
        if not math.isclose(derived, reported, abs_tol=1e-12, rel_tol=0.0):
            raise ValueError(
                f"{path.name}: pass@8 summary {reported} != derived {derived}"
            )
        rows.append(
            {"cell": cell["cell"], "seed": int(cell["seed"]), "pass8_final": derived}
        )
    return pd.DataFrame(rows)


def _single_artifact(artifact_dir: Path, pattern: str, context: str) -> Path:
    matches = list(artifact_dir.glob(pattern))
    if len(matches) != 1:
        raise ValueError(f"{context}: expected one artifact, found {matches}")
    return matches[0]


def build_curves(cells: pd.DataFrame, artifact_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build checkpoint curves and normalized round-0-to-30 AUC summaries."""

    baseline = cells[cells["cell"] == BASE_CELL].set_index("seed")
    points: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    for row in cells.to_dict("records"):
        seed = int(row["seed"])
        base = baseline.loc[seed]
        checkpoint_records: list[dict[str, Any]] = []
        rounds = [0]
        series = {
            metric: [float(base[f"{metric}_final"])]
            for metric in METRICS
        }
        if row["cell"] == BASE_CELL:
            rounds.extend(CHECKPOINT_ROUNDS)
            for metric in METRICS:
                series[metric].extend(
                    [float(row[f"{metric}_final"])] * len(CHECKPOINT_ROUNDS)
                )
        else:
            checkpoint = _single_artifact(
                artifact_dir,
                f"checkpoint_eval_*__{row['tag']}__*.jsonl.gz",
                row["tag"],
            )
            records = _read_jsonl_gz(checkpoint)
            checkpoint_records = records
            observed_rounds = tuple(
                int(record["completed_rounds"]) for record in records
            )
            if observed_rounds != CHECKPOINT_ROUNDS:
                raise ValueError(
                    f"{row['tag']}: checkpoint rounds={observed_rounds}, "
                    f"expected={CHECKPOINT_ROUNDS}"
                )
            if any(len(record.get("records", [])) != 400 for record in records):
                raise ValueError(f"{row['tag']}: checkpoint evaluation is not 400 rows")
            rounds.extend(observed_rounds)
            for metric, key in METRICS.items():
                series[metric].extend(
                    _finite_float(
                        record["metrics"][key],
                        context=f"{row['tag']}/round{record['completed_rounds']}/{key}",
                    )
                    for record in records
                )

        for index, completed_rounds in enumerate(rounds):
            points.append({
                "cell": row["cell"],
                "seed": seed,
                "completed_rounds": completed_rounds,
                **{metric: values[index] for metric, values in series.items()},
            })
        summary = {
            "cell": row["cell"],
            "seed": seed,
            "termination": row["termination"],
            "seconds": row["seconds"],
        }
        for metric, values in series.items():
            auc = float(np.trapezoid(values, rounds) / max(rounds))
            round10 = values[rounds.index(10)]
            summary.update({
                f"{metric}_auc": auc,
                f"{metric}_round10": round10,
                f"{metric}_final": values[-1],
            })
        for metric, key in ENDPOINT_ONLY_METRICS.items():
            if row["cell"] == BASE_CELL:
                round10 = float(row[f"{metric}_final"])
            else:
                round10_record = next(
                    record
                    for record in checkpoint_records
                    if int(record["completed_rounds"]) == 10
                )
                round10 = _optional_finite_float(
                    round10_record["metrics"].get(key),
                    context=f"{row['tag']}/round10/{key}",
                )
            summary.update(
                {
                    f"{metric}_round10": round10,
                    f"{metric}_final": float(row[f"{metric}_final"]),
                }
            )
        summaries.append(summary)
    return pd.DataFrame(points), pd.DataFrame(summaries)


def exact_sign_flip_p(differences: Sequence[float]) -> float:
    """Return an exact two-sided paired sign-flip p-value."""

    values = np.asarray(differences, dtype=float)
    if values.ndim != 1 or len(values) < 1 or not np.isfinite(values).all():
        raise ValueError("differences must be a finite non-empty vector")
    observed = abs(float(np.mean(values)))
    permuted = [
        abs(float(np.mean(values * np.asarray(signs, dtype=float))))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(permuted) >= observed - 1e-15))


def holm_adjust(p_values: Mapping[str, float]) -> dict[str, float]:
    """Apply Holm's step-down family-wise adjustment."""

    ordered = sorted(p_values.items(), key=lambda item: item[1])
    adjusted: dict[str, float] = {}
    running = 0.0
    count = len(ordered)
    for rank, (name, value) in enumerate(ordered):
        running = max(running, min(1.0, (count - rank) * float(value)))
        adjusted[name] = running
    return adjusted


def paired_contrasts(
    summaries: pd.DataFrame,
    *,
    bootstrap_draws: int,
    bootstrap_seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Calculate paired effects and the preregistered nomination gates."""

    indexed = summaries.set_index(["cell", "seed"])
    contrast_rows: list[dict[str, Any]] = []
    primary_p: dict[str, float] = {}
    pair_deltas: dict[str, dict[str, np.ndarray]] = {}
    for pair_index, (family, (control, treatment)) in enumerate(PAIRS.items()):
        pair_deltas[family] = {}
        for metric_index, (label, (summary_key, primary)) in enumerate(
            CONTRAST_SPECS.items()
        ):
            treated = np.asarray(
                [indexed.loc[(treatment, seed), summary_key] for seed in SEEDS],
                dtype=float,
            )
            untreated = np.asarray(
                [indexed.loc[(control, seed), summary_key] for seed in SEEDS],
                dtype=float,
            )
            all_differences = treated - untreated
            differences = all_differences[np.isfinite(all_differences)]
            pair_deltas[family][label] = differences
            if len(differences):
                mean, low, high = paired_bootstrap(
                    differences,
                    draws=bootstrap_draws,
                    seed=bootstrap_seed + 100 * pair_index + metric_index,
                )
                p_value = exact_sign_flip_p(differences)
                median = float(np.median(differences))
                positive = int(np.sum(differences > 0))
            else:
                mean = low = high = median = p_value = math.nan
                positive = 0
            contrast_rows.append({
                "family": family,
                "control": control,
                "treatment": treatment,
                "metric": label,
                "n_seeds": len(differences),
                "mean_difference_pp": 100 * mean,
                "median_difference_pp": 100 * median,
                "ci95_low_pp": 100 * low,
                "ci95_high_pp": 100 * high,
                "positive_seeds": positive,
                "exact_sign_flip_p": p_value,
            })
            if primary:
                if len(differences) != len(SEEDS):
                    raise ValueError(
                        f"{family}/{label}: primary contrast is missing a seed"
                    )
                primary_p[family] = p_value

    adjusted = holm_adjust(primary_p)
    for row in contrast_rows:
        row["holm_adjusted_p"] = (
            adjusted[row["family"]] if row["metric"] == "strict_auc" else math.nan
        )

    gate_rows: list[dict[str, Any]] = []
    for family, metrics in pair_deltas.items():
        strict = metrics["strict_auc"]
        required = (
            "strict_correct_eos_auc",
            "natural_eos_final",
            "hit_max_final",
            "legacy_auc",
            "direct_answer_only_final",
        )
        if any(len(metrics[key]) != len(SEEDS) for key in required):
            raise ValueError(f"{family}: candidate gate metric is missing a seed")
        gates = {
            "positive_mean_strict_auc": float(np.mean(strict)) > 0,
            "positive_median_strict_auc": float(np.median(strict)) > 0,
            "two_of_three_positive_strict_auc": int(np.sum(strict > 0)) >= 2,
            "positive_mean_strict_correct_eos_auc": (
                float(np.mean(metrics["strict_correct_eos_auc"])) > 0
            ),
            "increased_mean_natural_eos_rate": (
                float(np.mean(metrics["natural_eos_final"])) > 0
            ),
            "reduced_mean_token_limit_rate": (
                float(np.mean(metrics["hit_max_final"])) < 0
            ),
            "no_mean_legacy_auc_loss": (
                float(np.mean(metrics["legacy_auc"])) >= 0
            ),
            "no_mean_direct_answer_only_increase": (
                float(np.mean(metrics["direct_answer_only_final"])) <= 0
            ),
        }
        gate_rows.append({
            "family": family,
            "mean_strict_auc_effect_pp": 100 * float(np.mean(strict)),
            **gates,
            "passes_all_candidate_gates": all(gates.values()),
        })
    return pd.DataFrame(contrast_rows), pd.DataFrame(gate_rows)


def load_first_step_diagnostics(
    cells: pd.DataFrame, artifact_dir: Path
) -> pd.DataFrame:
    """Extract first overall M-step target counts and component-gradient norms."""

    rows: list[dict[str, Any]] = []
    trained = cells[cells["cell"] != BASE_CELL]
    for cell in trained.to_dict("records"):
        path = _single_artifact(
            artifact_dir,
            f"training_diagnostics_*__{cell['tag']}__*.jsonl.gz",
            cell["tag"],
        )
        diagnostics = _read_jsonl_gz(path)
        if len(diagnostics) != 30:
            raise ValueError(f"{cell['tag']}: expected 30 diagnostics, found {len(diagnostics)}")
        steps = (diagnostics[0].get("inner_m_step") or {}).get("steps") or []
        if not steps:
            raise ValueError(f"{cell['tag']}: first round has no inner M-step")
        first = steps[0]
        support = first.get("support") or {}
        norms = (first.get("component_gradient_geometry") or {}).get("norms") or {}
        row = {
            "cell": cell["cell"],
            "seed": cell["seed"],
            "termination": cell["termination"],
        }
        for key in (
            "supervised_backward_tokens",
            "supervised_backward_eos_tokens",
            "buffer_backward_tokens",
            "buffer_backward_eos_tokens",
            "backward_tokens",
            "backward_eos_tokens",
        ):
            value = support.get(key)
            if not isinstance(value, int) or value < 0:
                raise ValueError(f"{cell['tag']}: invalid support field {key}={value!r}")
            row[key] = value
        for key in ("B_sup", "B_prime_unsup", "B_unsup", "total"):
            row[f"gradient_norm_{key}"] = _finite_float(
                norms.get(key), context=f"{cell['tag']}/gradient_norm_{key}"
            )
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["cell", "seed"]).reset_index(drop=True)


def _markdown_table(table: pd.DataFrame) -> str:
    def render(value: Any) -> str:
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.3f}"
        return str(value)

    headers = [str(column) for column in table.columns]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    lines.extend(
        "| " + " | ".join(render(value) for value in row) + " |"
        for row in table.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def write_report(
    path: Path,
    summaries: pd.DataFrame,
    contrasts: pd.DataFrame,
    gates: pd.DataFrame,
    nominee: str | None,
    integrity: Mapping[str, Any],
) -> None:
    cell_table = (
        summaries.groupby("cell", as_index=False)
        .agg(
            strict_auc=("strict_auc", "mean"),
            strict_round10=("strict_round10", "mean"),
            strict_final=("strict_final", "mean"),
            legacy_auc=("legacy_auc", "mean"),
            natural_eos_final=("natural_eos_final", "mean"),
            eos_given_strict_correct_final=(
                "eos_given_strict_correct_final",
                "mean",
            ),
            hit_max_final=("hit_max_final", "mean"),
            direct_answer_only_final=("direct_answer_only_final", "mean"),
            pass8_final=("pass8_final", "mean"),
        )
    )
    for column in cell_table.columns[1:]:
        cell_table[column] = 100 * cell_table[column]
    primary = contrasts[contrasts["metric"] == "strict_auc"][
        [
            "family",
            "mean_difference_pp",
            "median_difference_pp",
            "ci95_low_pp",
            "ci95_high_pp",
            "positive_seeds",
            "exact_sign_flip_p",
            "holm_adjusted_p",
        ]
    ]
    endpoint = contrasts[
        contrasts["metric"].isin(
            [
                "strict_round10",
                "strict_final",
                "natural_eos_final",
                "eos_given_strict_correct_final",
                "hit_max_final",
                "direct_answer_only_final",
                "pass8_final",
            ]
        )
    ][
        [
            "family",
            "metric",
            "n_seeds",
            "mean_difference_pp",
            "ci95_low_pp",
            "ci95_high_pp",
        ]
    ]
    decision = (
        f"`{nominee}` is nominated for a seven-seed confirmation."
        if nominee is not None
        else "No family passes every preregistered candidate gate."
    )
    text = [
        "# EOS-complete answer-factor screen",
        "",
        "The paired seed is the observational unit. This is a three-seed "
        "validation-only screen. Runtime records and the validator marker prove "
        "that only the GSM8K training split was loaded.",
        "",
        "## Cell outcomes",
        "",
        _markdown_table(cell_table),
        "",
        "## Paired strict-AUC contrasts",
        "",
        _markdown_table(primary),
        "",
        "## Registered endpoint contrasts",
        "",
        _markdown_table(endpoint),
        "",
        "## Candidate gates",
        "",
        _markdown_table(gates),
        "",
        "## Registered decision",
        "",
        decision,
        "",
        "A nomination is not method selection. Selection requires the registered "
        "seven fresh-seed confirmation and a positive paired 95% interval lower "
        "bound while terminal behaviour improves without legacy-AUC loss.",
        "",
        "## Mirror integrity",
        "",
        "```json",
        json.dumps(integrity, indent=2, sort_keys=True),
        "```",
        "",
    ]
    path.write_text("\n".join(text), encoding="utf-8")


def verify_analysis_provenance(
    *,
    artifact_dir: Path,
    config_path: Path,
    marker_path: Path,
    expected_run_id: str,
    expected_commit: str,
    expected_source_job_id: str,
) -> dict[str, Any]:
    """Bind the analysis to one config, execution revision, job, and validator."""

    config_bytes = config_path.read_bytes()
    config_sha256 = hashlib.sha256(config_bytes).hexdigest()
    config = yaml.safe_load(config_bytes)
    if str(config.get("run_id")) != expected_run_id:
        raise ValueError("analysis config run ID does not match expectation")
    official_test_declared = (
        ((config.get("diagnostic") or {}).get("partitions") or {}).get(
            "official_test_used"
        )
    )
    if official_test_declared is not False:
        raise ValueError("analysis config does not declare official_test_used=false")
    if (config.get("defaults") or {}).get("eval_partition") != "validation":
        raise ValueError("analysis config does not use train-derived validation")

    marker = json.loads(marker_path.read_text(encoding="utf-8"))
    expected_marker = {
        "status": "ok",
        "run_id": expected_run_id,
        "execution_commit": expected_commit,
        "configuration_sha256": config_sha256,
        "source_job_id": expected_source_job_id,
    }
    for field, expected in expected_marker.items():
        if marker.get(field) != expected:
            raise ValueError(
                f"validator marker {field}={marker.get(field)!r}, "
                f"expected {expected!r}"
            )
    if marker.get("schema_version") != 1:
        raise ValueError("validator marker schema_version is not 1")

    sweep_files = sorted(artifact_dir.glob("sweep_*.csv"))
    if len(sweep_files) != len(CELLS) * len(SEEDS):
        raise ValueError(
            f"expected 27 sweep files for provenance, found {len(sweep_files)}"
        )
    observed_commits: set[str] = set()
    for path in sweep_files:
        table = pd.read_csv(path)
        if len(table) != 1:
            raise ValueError(f"{path.name}: expected one sweep row")
        row = table.iloc[0].to_dict()
        if str(row.get("run_id")) != expected_run_id:
            raise ValueError(f"{path.name}: sweep run ID mismatch")
        params = json.loads(str(row.get("params")))
        if str(params.get("run_id")) != expected_run_id:
            raise ValueError(f"{path.name}: params run ID mismatch")
        commit = str((params.get("env") or {}).get("commit", ""))
        if not commit or not expected_commit.startswith(commit):
            raise ValueError(
                f"{path.name}: execution commit {commit!r} does not match "
                f"{expected_commit!r}"
            )
        observed_commits.add(commit)
    return {
        "run_id": expected_run_id,
        "execution_commit": expected_commit,
        "observed_short_commits": sorted(observed_commits),
        "configuration": str(config_path),
        "configuration_sha256": config_sha256,
        "validator_marker": str(marker_path),
        "source_job_id": expected_source_job_id,
        "official_test_used": False,
        "official_test_non_access_verified": True,
    }


def run_analysis(args: argparse.Namespace) -> dict[str, Any]:
    artifact_dir = Path(args.artifact_dir).resolve()
    log_dir = Path(args.log_dir).resolve()
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    provenance = verify_analysis_provenance(
        artifact_dir=artifact_dir,
        config_path=Path(args.config).resolve(),
        marker_path=Path(args.validator_marker).resolve(),
        expected_run_id=args.expected_run_id,
        expected_commit=args.expected_commit,
        expected_source_job_id=args.expected_source_job_id,
    )

    integrity = verify_mirror(
        artifact_dir,
        log_dir,
        expected_cells=27,
        trained_cells=24,
    )
    if integrity["issues"]:
        raise ValueError(f"mirror verification failed: {integrity['issues']}")

    cells = load_cells(
        artifact_dir, expected_run_id=args.expected_run_id
    )
    curves, summaries = build_curves(cells, artifact_dir)
    pass8 = load_pass8(
        cells,
        artifact_dir,
        expected_run_id=args.expected_run_id,
    )
    summaries = summaries.merge(
        pass8,
        on=["cell", "seed"],
        how="left",
        validate="one_to_one",
    )
    contrasts, gates = paired_contrasts(
        summaries,
        bootstrap_draws=args.bootstrap_draws,
        bootstrap_seed=args.bootstrap_seed,
    )
    first_step = load_first_step_diagnostics(cells, artifact_dir)

    eligible = gates[gates["passes_all_candidate_gates"]]
    nominee = (
        str(
            eligible.sort_values(
                "mean_strict_auc_effect_pp", ascending=False
            ).iloc[0]["family"]
        )
        if len(eligible)
        else None
    )

    curves.to_csv(out_dir / "checkpoint_curves.csv", index=False)
    summaries.to_csv(out_dir / "seed_summary.csv", index=False)
    contrasts.to_csv(out_dir / "paired_contrasts.csv", index=False)
    gates.to_csv(out_dir / "candidate_gates.csv", index=False)
    first_step.to_csv(out_dir / "first_step_target_and_gradients.csv", index=False)
    payload = {
        "run_id": str(cells["run_id"].iloc[0]),
        "observational_unit": "paired seed",
        "seeds": list(SEEDS),
        "official_test_used": provenance["official_test_used"],
        "official_test_non_access_verified": provenance[
            "official_test_non_access_verified"
        ],
        "nominee": nominee,
        "nominee_is_selected_method": False,
        "provenance": provenance,
        "integrity": integrity,
    }
    (out_dir / "analysis_summary.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
    )
    write_report(
        out_dir / "analysis.md",
        summaries,
        contrasts,
        gates,
        nominee,
        integrity,
    )
    return payload


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact-dir", required=True)
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--validator-marker", required=True)
    parser.add_argument("--expected-run-id", required=True)
    parser.add_argument("--expected-commit", required=True)
    parser.add_argument("--expected-source-job-id", required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=20_000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260730)
    args = parser.parse_args(argv)
    if args.bootstrap_draws < 1:
        parser.error("--bootstrap-draws must be positive")
    return args


def main(argv: Sequence[str] | None = None) -> int:
    payload = run_analysis(parse_args(argv))
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
