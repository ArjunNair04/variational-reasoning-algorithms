#!/usr/bin/env python3
"""Preregistered analysis for the 2026-07-24 L2R proposal and shot studies."""
from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def _read_json(path: Path):
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _read_jsonl_gz(path: Path) -> list[dict]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _tag(path: Path) -> str:
    return path.stem.split("__", 1)[1]


def _params(row: pd.Series) -> tuple[dict, dict]:
    raw = row.get("params")
    payload = json.loads(raw) if isinstance(raw, str) and raw else {}
    sweep = payload.get("sweep") or {}
    method = str(row["method"])
    return sweep, (payload.get("methods") or {}).get(method) or {}


def _rows(root: Path, prefix: str) -> list[dict]:
    output = []
    paths = sorted(root.rglob(f"sweep_gsm8k__{prefix}*.csv"))
    if not paths:
        raise FileNotFoundError(f"no {prefix!r} sweep CSVs below {root}")
    for path in paths:
        frame = pd.read_csv(path)
        if len(frame) != 1:
            raise ValueError(f"{path}: expected one seed-sharded row, found {len(frame)}")
        row = frame.iloc[0]
        sweep, method_params = _params(row)
        output.append({
            "path": path,
            "tag": _tag(path),
            "row": row,
            "method": str(row["method"]),
            "seed": int(row["seed"]),
            "shots": int(sweep.get("shots", 4)),
            "rounds": int(sweep.get("rounds", 0)),
            "sweep": sweep,
            "method_params": method_params,
        })
    return output


def _eval_records(cell: dict) -> dict[int, bool]:
    path = (
        cell["path"].parent
        / f"eval_gsm8k__{cell['tag']}__{cell['method']}_s{cell['seed']}.json"
    )
    payload = _read_json(path)
    return {
        int(record["idx"]): bool(record["correct"])
        for record in payload.get("records") or []
    }


def _checkpoint_records(cell: dict) -> list[tuple[int, dict[int, bool]]]:
    path = (
        cell["path"].parent
        / (
            f"checkpoint_eval_gsm8k__{cell['tag']}__"
            f"{cell['method']}_s{cell['seed']}.jsonl.gz"
        )
    )
    rows = _read_jsonl_gz(path)
    return [
        (
            int(row["completed_rounds"]),
            {
                int(record["idx"]): bool(record["correct"])
                for record in row.get("records") or []
            },
        )
        for row in rows
    ]


def per_question_auc(
    base: dict[int, bool],
    checkpoints: list[tuple[int, dict[int, bool]]],
    rounds: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return aligned question ids and trapezoidal correctness AUCs."""

    if rounds <= 0:
        raise ValueError("rounds must be positive")
    maps = [(0, base), *checkpoints]
    if maps[-1][0] != rounds:
        raise ValueError(
            f"checkpoint schedule ends at {maps[-1][0]}, expected {rounds}"
        )
    common = sorted(set.intersection(*(set(values) for _, values in maps)))
    if not common:
        raise ValueError("checkpoint evaluations share no question ids")
    times = np.asarray([time for time, _ in maps], dtype=np.float64)
    values = np.asarray(
        [[float(records[idx]) for idx in common] for _, records in maps],
        dtype=np.float64,
    )
    auc = np.trapezoid(values, times, axis=0) / rounds
    return np.asarray(common, dtype=np.int64), auc


def retention_and_rescue(
    base: dict[int, bool],
    trained: dict[int, bool],
) -> tuple[float, float, int, int]:
    common = sorted(set(base) & set(trained))
    correct = [idx for idx in common if base[idx]]
    wrong = [idx for idx in common if not base[idx]]
    retention = float(np.mean([trained[idx] for idx in correct])) if correct else math.nan
    rescue = float(np.mean([trained[idx] for idx in wrong])) if wrong else math.nan
    fixed = sum(not base[idx] and trained[idx] for idx in common)
    broken = sum(base[idx] and not trained[idx] for idx in common)
    return retention, rescue, fixed, broken


def hierarchical_interval(
    deltas: dict[int, np.ndarray],
    *,
    draws: int = 10000,
    seed: int = 20260724,
) -> dict:
    """Seed-by-question bootstrap for a paired method contrast."""

    seeds = sorted(deltas)
    if not seeds:
        raise ValueError("no seed-level deltas")
    rng = np.random.default_rng(seed)
    observed = float(np.mean([np.mean(deltas[value]) for value in seeds]))
    samples = np.empty(draws, dtype=np.float64)
    for draw in range(draws):
        selected = rng.choice(seeds, size=len(seeds), replace=True)
        seed_means = []
        for selected_seed in selected:
            values = np.asarray(deltas[int(selected_seed)], dtype=np.float64)
            indices = rng.integers(0, len(values), size=len(values))
            seed_means.append(float(values[indices].mean()))
        samples[draw] = float(np.mean(seed_means))
    low, high = np.quantile(samples, [0.025, 0.975])
    return {
        "mean": observed,
        "ci95": [float(low), float(high)],
        "seed_means": {
            str(value): float(np.mean(deltas[value])) for value in seeds
        },
        "draws": draws,
    }


def _diagnostic_means(cell: dict) -> dict:
    path = (
        cell["path"].parent
        / (
            f"training_diagnostics_gsm8k__{cell['tag']}__"
            f"{cell['method']}_s{cell['seed']}.jsonl.gz"
        )
    )
    rows = _read_jsonl_gz(path)

    def mean_nested(section, key):
        values = [
            row.get(section, {}).get(key)
            for row in rows
            if row.get(section, {}).get(key) is not None
        ]
        return float(np.mean(values)) if values else math.nan

    traces = [
        trace
        for row in rows
        for trace in (row.get("sampled_traces") or [])
    ]
    return {
        "proposal_correct_fraction": mean_nested(
            "generation", "proposal_correct_fraction"
        ),
        "target_mentioned_before_final_fraction": mean_nested(
            "generation", "target_mentioned_before_final_fraction"
        ),
        "target_before_equation_fraction": mean_nested(
            "generation", "target_before_equation_fraction"
        ),
        "equation_fraction": mean_nested("generation", "equation_fraction"),
        "format_fraction": mean_nested("generation", "format_fraction"),
        "model_correct_mass": mean_nested("posterior", "model_correct_mass"),
        "ess_fraction": mean_nested("posterior", "ess_fraction"),
        "posterior_max_weight": mean_nested("posterior", "max_weight"),
        "posterior_weight_length_corr": mean_nested(
            "posterior", "weight_length_corr"
        ),
        "mean_generated_tokens": float(np.mean([
            trace.get("generated_tokens", math.nan) for trace in traces
        ])) if traces else math.nan,
        "mean_reasoning_tokens": float(np.mean([
            trace.get("h_tokens", math.nan) for trace in traces
        ])) if traces else math.nan,
        "sampled_trace_count": len(traces),
    }


def analyze_answer_support(root: Path, output: Path) -> dict:
    cells = _rows(root, "q3_l2r_answer_support_26b1de41")
    base = {cell["seed"]: cell for cell in cells if cell["method"] == "base"}
    trained = [cell for cell in cells if cell["method"] != "base"]
    if len(base) != 3 or len(trained) != 9:
        raise ValueError(
            f"answer-support study expected 3 base and 9 trained rows, "
            f"found {len(base)} and {len(trained)}"
        )

    summaries = []
    auc_vectors = {}
    for cell in trained:
        base_cell = base[cell["seed"]]
        base_records = _eval_records(base_cell)
        final_records = _eval_records(cell)
        _ids, auc = per_question_auc(
            base_records,
            _checkpoint_records(cell),
            cell["rounds"],
        )
        retention, rescue, fixed, broken = retention_and_rescue(
            base_records,
            final_records,
        )
        proposal = str(cell["method_params"].get("proposal_prompt", "question"))
        auc_vectors[(proposal, cell["seed"])] = auc
        diagnostics = _diagnostic_means(cell)
        summaries.append({
            "proposal_prompt": proposal,
            "seed": cell["seed"],
            "base_accuracy": float(base_cell["row"]["test_acc"]),
            "final_accuracy": float(cell["row"]["test_acc"]),
            "validation_auc": float(auc.mean()),
            "auc_delta_vs_base": float(
                auc.mean() - float(base_cell["row"]["test_acc"])
            ),
            "base_correct_retention": retention,
            "base_wrong_rescue": rescue,
            "fixed_questions": fixed,
            "broken_questions": broken,
            **diagnostics,
        })
    summary = pd.DataFrame(summaries).sort_values(["proposal_prompt", "seed"])
    summary.to_csv(output / "answer_conditioned_support_summary.csv", index=False)

    contrasts = {}
    for proposal in ("answer_derive", "answer_derive_first"):
        deltas = {
            seed: (
                auc_vectors[(proposal, seed)]
                - auc_vectors[("question", seed)]
            )
            for seed in sorted(base)
        }
        contrasts[f"{proposal}_minus_question"] = hierarchical_interval(deltas)
    result = {
        "study": "qwen3_l2r_answer_conditioned_support",
        "run_id": "26b1de41",
        "contrasts": contrasts,
        "interpretation": (
            "Performance promotion requires a lower confidence bound above zero; "
            "proposal and leakage diagnostics remain separate mechanism checks."
        ),
    }
    (output / "answer_conditioned_support_contrasts.json").write_text(
        json.dumps(result, indent=2) + "\n",
        encoding="utf-8",
    )
    return result


def analyze_prompt_base(root: Path, output: Path) -> dict:
    """Analyse the frozen zero-to-four-shot calibration without training data."""

    base_cells = _rows(root, "q3_prompt_shot_base_e742c983")
    if len(base_cells) != 15:
        raise ValueError(
            f"prompt calibration expected 15 base rows, found {len(base_cells)}"
        )

    summaries = []
    correctness = {}
    for cell in base_cells:
        payload = _read_json(
            cell["path"].parent
            / f"eval_gsm8k__{cell['tag']}__base_s{cell['seed']}.json"
        )
        records = payload.get("records") or []
        correctness[(cell["shots"], cell["seed"])] = {
            int(record["idx"]): float(bool(record["correct"]))
            for record in records
        }
        summaries.append({
            "shots": cell["shots"],
            "seed": cell["seed"],
            "accuracy": float(cell["row"]["test_acc"]),
            "pass1": float(cell["row"].get("pass1", math.nan)),
            "pass8": float(cell["row"].get("pass8", math.nan)),
            "parse_rate": float(np.mean([
                record.get("pred") is not None for record in records
            ])),
            "mean_completion_length": float(np.mean([
                record.get("len", math.nan) for record in records
            ])),
            "mean_repeated_fourgram_fraction": float(np.mean([
                record.get("rep4", math.nan) for record in records
            ])),
            "n_records": len(records),
        })
    base_frame = pd.DataFrame(summaries).sort_values(["shots", "seed"])
    base_frame.to_csv(output / "prompt_shot_base_summary.csv", index=False)

    aggregates = (
        base_frame.groupby("shots", as_index=False)
        .agg(
            accuracy_mean=("accuracy", "mean"),
            accuracy_std=("accuracy", "std"),
            pass1_mean=("pass1", "mean"),
            pass1_std=("pass1", "std"),
            pass8_mean=("pass8", "mean"),
            pass8_std=("pass8", "std"),
            parse_rate_mean=("parse_rate", "mean"),
            completion_length_mean=("mean_completion_length", "mean"),
            repeated_fourgram_mean=("mean_repeated_fourgram_fraction", "mean"),
        )
    )
    aggregates.to_csv(
        output / "prompt_shot_base_aggregates.csv",
        index=False,
    )

    seeds = sorted(base_frame["seed"].unique())
    contrasts = {}
    for shots in (0, 1, 2, 3):
        deltas = {}
        for seed in seeds:
            candidate = correctness[(shots, int(seed))]
            reference = correctness[(4, int(seed))]
            common = sorted(set(candidate) & set(reference))
            if not common:
                raise ValueError(
                    f"shot {shots} and shot 4 share no questions for seed {seed}"
                )
            deltas[int(seed)] = np.asarray(
                [candidate[idx] - reference[idx] for idx in common],
                dtype=np.float64,
            )
        contrasts[f"shot{shots}_minus_shot4"] = hierarchical_interval(deltas)

    means = base_frame.groupby("shots", as_index=True).mean(numeric_only=True)
    four = means.loc[4]
    suitability = {
        "four_shot_accuracy": float(four["accuracy"]),
        "largest_lower_shot_headroom": float(
            max(
                float(four["accuracy"] - means.loc[shots, "accuracy"])
                for shots in (0, 1, 2, 3)
            )
        ),
        "four_shot_parse_rate": float(four["parse_rate"]),
        "four_shot_pass8_minus_greedy": float(
            four["pass8"] - four["accuracy"]
        ),
    }
    suitability["retain_qwen_primary"] = bool(
        suitability["four_shot_accuracy"] < 0.90
        and suitability["largest_lower_shot_headroom"] >= 0.03
        and suitability["four_shot_parse_rate"] >= 0.98
        and suitability["four_shot_pass8_minus_greedy"] >= 0.03
    )

    result = {
        "study": "qwen3_prompt_shot_base",
        "run_id": "e742c983",
        "model_suitability": suitability,
        "contrasts": contrasts,
        "interpretation": (
            "Shot-count contrasts are paired by seed and validation question. "
            "They calibrate prompt sensitivity and do not estimate a training effect."
        ),
    }
    (output / "prompt_shot_base_contrasts.json").write_text(
        json.dumps(result, indent=2) + "\n",
        encoding="utf-8",
    )
    return result


def analyze_prompt_shots(base_root: Path, train_root: Path, output: Path) -> dict:
    base_cells = _rows(base_root, "q3_prompt_shot_base_e742c983")
    train_cells = _rows(train_root, "q3_prompt_shot_train_b4a0f86a")
    base = {
        (cell["shots"], cell["seed"]): cell
        for cell in base_cells
    }
    if len(base) != 15 or len(train_cells) != 60:
        raise ValueError(
            f"prompt study expected 15 base and 60 trained rows, "
            f"found {len(base)} and {len(train_cells)}"
        )

    summaries = []
    deltas = {}
    for cell in train_cells:
        key = (cell["shots"], cell["seed"])
        base_cell = base[key]
        base_records = _eval_records(base_cell)
        final_records = _eval_records(cell)
        question_ids, trained_auc = per_question_auc(
            base_records,
            _checkpoint_records(cell),
            cell["rounds"],
        )
        base_auc = np.asarray(
            [float(base_records[int(idx)]) for idx in question_ids],
            dtype=np.float64,
        )
        retention, rescue, fixed, broken = retention_and_rescue(
            base_records,
            final_records,
        )
        method_key = (cell["method"], cell["shots"], cell["seed"])
        deltas[method_key] = trained_auc - base_auc
        summaries.append({
            "method": cell["method"],
            "shots": cell["shots"],
            "seed": cell["seed"],
            "base_accuracy": float(base_cell["row"]["test_acc"]),
            "final_accuracy": float(cell["row"]["test_acc"]),
            "validation_auc": float(trained_auc.mean()),
            "auc_delta_vs_base": float((trained_auc - base_auc).mean()),
            "base_correct_retention": retention,
            "base_wrong_rescue": rescue,
            "fixed_questions": fixed,
            "broken_questions": broken,
            "train_llm_gen": float(cell["row"].get("train_llm_gen", math.nan)),
            "generated_tokens": float(
                cell["row"].get("generated_tokens", math.nan)
            ),
            "backward_tokens": float(
                cell["row"].get("backward_tokens", math.nan)
            ),
        })
    summary = pd.DataFrame(summaries).sort_values(["method", "shots", "seed"])
    summary.to_csv(output / "prompt_shot_training_summary.csv", index=False)

    contrasts = {}
    for method in sorted(summary["method"].unique()):
        for shots in (0, 1, 2, 3, 4):
            key = f"{method}_shot{shots}_minus_base"
            contrasts[key] = hierarchical_interval({
                seed: deltas[(method, shots, seed)]
                for seed in sorted({cell["seed"] for cell in base_cells})
                if (method, shots, seed) in deltas
            })
        for shots in (0, 1, 2, 3):
            key = f"{method}_shot{shots}_minus_shot4_training_effect"
            contrasts[key] = hierarchical_interval({
                seed: (
                    deltas[(method, shots, seed)]
                    - deltas[(method, 4, seed)]
                )
                for seed in sorted({cell["seed"] for cell in base_cells})
            })
    for comparator in ("RFT", "GRPO", "RLOO"):
        for shots in (0, 1, 2, 3, 4):
            key = f"L2R-Frozen-NoGold_minus_{comparator}_shot{shots}"
            contrasts[key] = hierarchical_interval({
                seed: (
                    deltas[("L2R-Frozen-NoGold", shots, seed)]
                    - deltas[(comparator, shots, seed)]
                )
                for seed in sorted({cell["seed"] for cell in base_cells})
            })

    base_summary = []
    for cell in base_cells:
        records = _eval_records(cell)
        payload = _read_json(
            cell["path"].parent
            / f"eval_gsm8k__{cell['tag']}__base_s{cell['seed']}.json"
        )
        parse_rate = float(np.mean([
            record.get("pred") is not None
            for record in payload.get("records", [])
        ]))
        base_summary.append({
            "shots": cell["shots"],
            "seed": cell["seed"],
            "accuracy": float(cell["row"]["test_acc"]),
            "pass1": float(cell["row"].get("pass1", math.nan)),
            "pass8": float(cell["row"].get("pass8", math.nan)),
            "parse_rate": parse_rate,
            "n_records": len(records),
        })
    base_frame = pd.DataFrame(base_summary)
    base_frame.to_csv(output / "prompt_shot_base_summary.csv", index=False)
    means = base_frame.groupby("shots", as_index=True).mean(numeric_only=True)
    four = means.loc[4]
    lower_gap = float(
        max(
            float(four["accuracy"] - means.loc[shots, "accuracy"])
            for shots in (0, 1, 2, 3)
        )
    )
    pass8_gap = float(four["pass8"] - four["accuracy"])
    suitability = {
        "four_shot_accuracy": float(four["accuracy"]),
        "largest_lower_shot_headroom": lower_gap,
        "four_shot_parse_rate": float(four["parse_rate"]),
        "four_shot_pass8_minus_greedy": pass8_gap,
    }
    suitability["retain_qwen_primary"] = bool(
        suitability["four_shot_accuracy"] < 0.90
        and lower_gap >= 0.03
        and suitability["four_shot_parse_rate"] >= 0.98
        and pass8_gap >= 0.03
    )

    result = {
        "study": "qwen3_prompt_shot_training",
        "base_run_id": "e742c983",
        "training_run_id": "b4a0f86a",
        "model_suitability": suitability,
        "contrasts": contrasts,
    }
    (output / "prompt_shot_contrasts.json").write_text(
        json.dumps(result, indent=2) + "\n",
        encoding="utf-8",
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--answer-dir", type=Path)
    parser.add_argument("--prompt-base-dir", type=Path)
    parser.add_argument("--prompt-train-dir", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    result = {}
    if args.answer_dir:
        result["answer_support"] = analyze_answer_support(
            args.answer_dir.expanduser(),
            args.out,
        )
    if args.prompt_train_dir and not args.prompt_base_dir:
        parser.error("--prompt-train-dir requires --prompt-base-dir")
    if args.prompt_base_dir and not args.prompt_train_dir:
        result["prompt_base"] = analyze_prompt_base(
            args.prompt_base_dir.expanduser(),
            args.out,
        )
    if args.prompt_base_dir and args.prompt_train_dir:
        result["prompt_shots"] = analyze_prompt_shots(
            args.prompt_base_dir.expanduser(),
            args.prompt_train_dir.expanduser(),
            args.out,
        )
    if not result:
        parser.error("supply --answer-dir and/or both prompt directories")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
