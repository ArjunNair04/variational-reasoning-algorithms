"""Analyze the three-seed AC-ALG1 latent-only objective factorial.

The trained corners are B'_unsup only, B_unsup only, and their sum. The
frozen four-shot Qwen model supplies the empty corner. Accuracy is evaluated
only on the fixed training-derived validation partition.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from analysis.analyze_ac_alg1_collapse_stability import (
        aggregate_trajectories,
        summarize_curves,
    )
    from analysis.analyze_ac_alg1_numerical_study import (
        _artifact_dir,
        _mean,
        _paired_bootstrap_interval,
        _read_jsonl_gz,
        load_cells,
        load_checkpoint_trajectories,
        load_reference_outcomes,
        paired_checkpoint_reference_contrasts,
        paired_reference_contrasts,
    )
    from analysis.analyze_ac_alg1_objective_terms import (
        aggregate_question_effects,
        factorial_effects,
        selection_decision,
    )
except ModuleNotFoundError:  # Direct execution from analysis/.
    from analyze_ac_alg1_collapse_stability import (
        aggregate_trajectories,
        summarize_curves,
    )
    from analyze_ac_alg1_numerical_study import (
        _artifact_dir,
        _mean,
        _paired_bootstrap_interval,
        _read_jsonl_gz,
        load_cells,
        load_checkpoint_trajectories,
        load_reference_outcomes,
        paired_checkpoint_reference_contrasts,
        paired_reference_contrasts,
    )
    from analyze_ac_alg1_objective_terms import (
        aggregate_question_effects,
        factorial_effects,
        selection_decision,
    )


ARM_MAP = {"C0": "T10", "C1": "T01", "C2": "T11"}
TRAINED_ARMS = ("T10", "T01", "T11")


def load_latent_only_factorial(
    result_dir: Path,
    prefix: str,
    config: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[tuple[str, int, int], dict]]:
    """Load and relabel the three trained latent-only corners."""

    table, _ = load_cells(result_dir, prefix, config, final_rounds=10)
    trajectories, evaluations = load_checkpoint_trajectories(result_dir, table)
    table["arm"] = table["arm"].map(ARM_MAP)
    trajectories["arm"] = trajectories["arm"].map(ARM_MAP)
    if set(table["arm"]) != set(TRAINED_ARMS):
        raise ValueError(
            f"expected latent-only arms {sorted(TRAINED_ARMS)}, "
            f"found {sorted(table['arm'].dropna().unique())}"
        )
    return table, trajectories, evaluations


def add_frozen_corner_to_curves(
    trained_curves: pd.DataFrame,
    seeds: list[int],
    reference_accuracy: float,
) -> pd.DataFrame:
    """Add the no-update frozen model as T00 to seed-level curve summaries."""

    frozen = pd.DataFrame([
        {
            "arm": "T00",
            "seed": int(seed),
            "n_checkpoints": 15,
            "final_round": 30,
            "normalized_accuracy_auc": reference_accuracy,
            "normalized_accuracy_deficit_auc": 0.0,
            "peak_accuracy": reference_accuracy,
            "peak_round": 0,
            "final_accuracy": reference_accuracy,
            "final_difference_from_base": 0.0,
            "slope_round10_to_final_pp_per_round": 0.0,
            "first_2pp_drop_round": np.nan,
            "avoided_2pp_drop_through_final": True,
            "first_5pp_drop_round": np.nan,
            "avoided_5pp_drop_through_final": True,
        }
        for seed in seeds
    ])
    return (
        pd.concat([frozen, trained_curves], ignore_index=True)
        .sort_values(["seed", "arm"])
        .reset_index(drop=True)
    )


def add_frozen_corner_to_trajectories(
    trained: pd.DataFrame,
    seeds: list[int],
    reference_accuracy: float,
) -> pd.DataFrame:
    """Add a constant T00 trajectory at every observed checkpoint."""

    rounds = sorted(int(value) for value in trained["completed_rounds"].unique())
    frozen = pd.DataFrame([
        {
            "arm": "T00",
            "seed": int(seed),
            "completed_rounds": completed_rounds,
            "test_acc": reference_accuracy,
        }
        for seed in seeds
        for completed_rounds in rounds
    ])
    return pd.concat([frozen, trained], ignore_index=True)


def question_factorial_effects_against_frozen(
    table: pd.DataFrame,
    evaluations: dict[tuple[str, int, int], dict],
    reference: dict[int, bool],
) -> pd.DataFrame:
    """Integrate paired factorial effects for each held-out question."""

    rows: list[dict] = []
    for seed in sorted(int(value) for value in table["seed"].unique()):
        seed_table = table[table["seed"] == seed]
        tags = {str(row["arm"]): str(row["tag"]) for _, row in seed_table.iterrows()}
        if set(TRAINED_ARMS) - set(tags):
            continue
        records_by_arm = {
            arm: {
                completed_rounds: record
                for (tag, checkpoint_seed, completed_rounds), record in evaluations.items()
                if tag == tags[arm] and checkpoint_seed == seed
            }
            for arm in TRAINED_ARMS
        }
        shared_rounds = sorted(
            set.intersection(*(set(records_by_arm[arm]) for arm in TRAINED_ARMS))
        )
        if not shared_rounds:
            continue
        correct = {
            arm: {
                completed_rounds: {
                    int(item["idx"]): float(bool(item["correct"]))
                    for item in records_by_arm[arm][completed_rounds].get("records", [])
                }
                for completed_rounds in shared_rounds
            }
            for arm in TRAINED_ARMS
        }
        shared_questions = set(reference)
        for arm in TRAINED_ARMS:
            for completed_rounds in shared_rounds:
                shared_questions &= set(correct[arm][completed_rounds])
        x = np.array([0, *shared_rounds], dtype=float)
        for idx in sorted(shared_questions):
            base = float(reference[idx])
            values = {"T00": np.full(len(x), base, dtype=float)}
            for arm in TRAINED_ARMS:
                values[arm] = np.array([
                    base,
                    *(correct[arm][completed_rounds][idx]
                      for completed_rounds in shared_rounds),
                ])
            effects = {
                "Bprime_at_Bunsup0": values["T10"] - values["T00"],
                "Bprime_at_Bunsup1": values["T11"] - values["T01"],
                "Bunsup_at_Bprime0": values["T01"] - values["T00"],
                "Bunsup_at_Bprime1": values["T11"] - values["T10"],
                "interaction": (
                    values["T11"] - values["T10"] - values["T01"] + values["T00"]
                ),
            }
            rows.append({
                "seed": seed,
                "idx": int(idx),
                "n_shared_checkpoints": len(shared_rounds),
                "final_round": int(shared_rounds[-1]),
                **{
                    name: float(np.trapezoid(effect, x) / float(shared_rounds[-1]))
                    for name, effect in effects.items()
                },
            })
    return pd.DataFrame(rows).sort_values(["seed", "idx"]) if rows else pd.DataFrame()


def _window_summary(records: list[dict], window_name: str, selected: list[dict]) -> dict:
    labelled = [
        record.get("responsibilities", {}).get("partitions", {}).get("labelled", {})
        for record in selected
    ]
    answer_only = [
        record.get("responsibilities", {}).get("partitions", {}).get("answer_only", {})
        for record in selected
    ]
    generation = [record.get("generation", {}) for record in selected]
    objective = [record.get("objective", {}) for record in selected]
    geometry = [record.get("gradient_geometry", {}) for record in selected]
    return {
        "window": window_name,
        "window_rounds": len(selected),
        "first_completed_round": int(selected[0]["completed_rounds"]),
        "last_completed_round": int(selected[-1]["completed_rounds"]),
        "proposal_acceptance": _mean(
            item.get("filter", {}).get("acceptance_fraction") for item in generation
        ),
        "sample_correct_fraction": _mean(
            item.get("samples", {}).get("correct_fraction") for item in generation
        ),
        "gold_mass": _mean(item.get("mean_gold_mass") for item in labelled),
        "gold_top1": _mean(item.get("gold_top1_fraction") for item in labelled),
        "labelled_ess_fraction": _mean(
            item.get("mean_effective_sample_size_fraction") for item in labelled
        ),
        "answer_only_ess_fraction": _mean(
            item.get("mean_effective_sample_size_fraction") for item in answer_only
        ),
        "graph_node_coverage": _mean(
            item.get("mean_numeric_graph_node_coverage") for item in labelled
        ),
        "graph_edge_coverage": _mean(
            item.get("mean_numeric_graph_edge_coverage") for item in labelled
        ),
        "B_sup": _mean(item.get("B_sup") for item in objective),
        "B_prime_unsup": _mean(item.get("B_prime_unsup") for item in objective),
        "B_unsup": _mean(item.get("B_unsup") for item in objective),
        "grad_norm_B_sup": _mean(
            item.get("norms", {}).get("B_sup") for item in geometry
        ),
        "grad_norm_B_prime_unsup": _mean(
            item.get("norms", {}).get("B_prime_unsup") for item in geometry
        ),
        "grad_norm_B_unsup": _mean(
            item.get("norms", {}).get("B_unsup") for item in geometry
        ),
        "grad_norm_total": _mean(
            item.get("norms", {}).get("total") for item in geometry
        ),
        "grad_cos_Bprime_Bunsup": _mean(
            item.get("cosines", {}).get("B_prime_unsup__B_unsup")
            for item in geometry
        ),
        "grad_cos_Bsup_Bprime": _mean(
            item.get("cosines", {}).get("B_sup__B_prime_unsup")
            for item in geometry
        ),
        "grad_cos_Bsup_Bunsup": _mean(
            item.get("cosines", {}).get("B_sup__B_unsup")
            for item in geometry
        ),
        "diagnostic_rounds": len(records),
    }


def mechanism_windows(result_dir: Path, table: pd.DataFrame) -> pd.DataFrame:
    """Summarize the first and last five training rounds per cell."""

    diagnostic_dir = _artifact_dir(result_dir, "training_diagnostics")
    rows: list[dict] = []
    for _, cell in table.iterrows():
        seed = int(cell["seed"])
        path = diagnostic_dir / (
            f"training_diagnostics_gsm8k__{cell['tag']}__AC-ALG1_s{seed}.jsonl.gz"
        )
        records = sorted(_read_jsonl_gz(path), key=lambda item: item["completed_rounds"])
        for window_name, selected in (("early", records[:5]), ("late", records[-5:])):
            rows.append({
                "arm": cell["arm"],
                "seed": seed,
                **_window_summary(records, window_name, selected),
            })
    return pd.DataFrame(rows).sort_values(["seed", "arm", "window"])


def aggregate_checkpoint_reference_effects(
    table: pd.DataFrame,
    evaluations: dict[tuple[str, int, int], dict],
    reference: dict[int, bool],
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Aggregate each checkpoint over seeds while clustering by question."""

    rows: list[dict] = []
    for arm in TRAINED_ARMS:
        arm_table = table[table["arm"] == arm]
        tags = {int(row["seed"]): str(row["tag"]) for _, row in arm_table.iterrows()}
        shared_rounds = sorted(set.intersection(*(
            {
                completed_rounds
                for (tag, checkpoint_seed, completed_rounds) in evaluations
                if tag == seed_tag and checkpoint_seed == seed
            }
            for seed, seed_tag in tags.items()
        )))
        for completed_rounds in shared_rounds:
            by_seed: dict[int, dict[int, float]] = {}
            for seed, tag in tags.items():
                record = evaluations[(tag, seed, completed_rounds)]
                by_seed[seed] = {
                    int(item["idx"]): float(bool(item["correct"]))
                    - float(reference[int(item["idx"])])
                    for item in record.get("records", [])
                    if int(item["idx"]) in reference
                }
            shared_questions = set(reference)
            for values in by_seed.values():
                shared_questions &= set(values)
            clustered = np.array([
                np.mean([by_seed[seed][idx] for seed in sorted(by_seed)])
                for idx in sorted(shared_questions)
            ])
            seed_effects = np.array([
                np.mean([by_seed[seed][idx] for idx in sorted(shared_questions)])
                for seed in sorted(by_seed)
            ])
            low, high = _paired_bootstrap_interval(
                clustered,
                draws=draws,
                seed=bootstrap_seed + completed_rounds + 100 * TRAINED_ARMS.index(arm),
            )
            rows.append({
                "arm": arm,
                "completed_rounds": int(completed_rounds),
                "n_seeds": len(by_seed),
                "n_question_clusters": len(clustered),
                "mean_accuracy": float(reference and np.mean(list(reference.values())))
                + float(clustered.mean()),
                "mean_difference_from_base": float(clustered.mean()),
                "min_seed_difference": float(seed_effects.min()),
                "max_seed_difference": float(seed_effects.max()),
                "positive_seeds": int(np.sum(seed_effects > 0)),
                "negative_seeds": int(np.sum(seed_effects < 0)),
                "ci95_low": low,
                "ci95_high": high,
            })
    return pd.DataFrame(rows).sort_values(["arm", "completed_rounds"])


def trace_comparisons(
    result_dir: Path,
    table: pd.DataFrame,
    reference_records: dict[int, dict],
) -> pd.DataFrame:
    """Join the fixed completion sample to frozen four-shot generations."""

    dump_dir = _artifact_dir(result_dir, "completion_dumps")
    rows: list[dict] = []
    for _, cell in table.iterrows():
        seed = int(cell["seed"])
        path = dump_dir / f"dump_gsm8k__{cell['tag']}__AC-ALG1_s{seed}.json"
        payload = json.loads(path.read_text())
        for sample in payload.get("samples", []):
            idx = int(sample["idx"])
            base = reference_records.get(idx)
            if base is None:
                continue
            base_correct = bool(base["correct"])
            trained_correct = bool(sample["correct"])
            transition = (
                "fixed" if trained_correct and not base_correct
                else "regressed" if base_correct and not trained_correct
                else "both_correct" if base_correct
                else "both_wrong"
            )
            rows.append({
                "arm": cell["arm"],
                "seed": seed,
                "idx": idx,
                "transition": transition,
                "question": sample["question"],
                "gold": sample["gold"],
                "base_pred": base["pred"],
                "base_completion": base["completion"],
                "trained_pred": sample["pred"],
                "trained_completion": sample["completion"],
            })
    return pd.DataFrame(rows).sort_values(["arm", "seed", "idx"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result_dir", type=Path)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--reference-records", type=Path, required=True)
    parser.add_argument("--reference-condition", default="four_shot")
    parser.add_argument("--reference-accuracy", type=float, default=0.7925)
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260722)
    parser.add_argument("--write-dir", type=Path, default=None)
    args = parser.parse_args()

    result_dir = args.result_dir.expanduser()
    table, trained_trajectories, checkpoint_evaluations = load_latent_only_factorial(
        result_dir, args.prefix, args.config
    )
    seeds = sorted(int(value) for value in table["seed"].unique())
    trained_curves = summarize_curves(trained_trajectories, args.reference_accuracy)
    curves = add_frozen_corner_to_curves(
        trained_curves, seeds, args.reference_accuracy
    )
    all_trajectories = add_frozen_corner_to_trajectories(
        trained_trajectories, seeds, args.reference_accuracy
    )
    aggregate_curves = aggregate_trajectories(
        all_trajectories, args.reference_accuracy
    )
    seed_effects = factorial_effects(curves)
    raw_reference_records = [
        record
        for record in _read_jsonl_gz(args.reference_records.expanduser())
        if record.get("condition") == args.reference_condition
    ]
    reference_records = {
        int(record["idx"]): record for record in raw_reference_records
    }
    reference = {
        idx: bool(record["correct"]) for idx, record in reference_records.items()
    }
    question_effects = question_factorial_effects_against_frozen(
        table, checkpoint_evaluations, reference
    )
    aggregate_effects = aggregate_question_effects(
        seed_effects,
        question_effects,
        args.bootstrap_draws,
        args.bootstrap_seed,
    )
    final_reference = paired_reference_contrasts(
        table,
        {
            (str(row["tag"]), int(row["seed"])): json.loads(
                (_artifact_dir(result_dir, "evaluations") / (
                    f"eval_gsm8k__{row['tag']}__AC-ALG1_s{int(row['seed'])}.json"
                )).read_text()
            )
            for _, row in table.iterrows()
        },
        reference,
        args.reference_condition,
        args.bootstrap_draws,
        args.bootstrap_seed,
    )
    checkpoint_reference = paired_checkpoint_reference_contrasts(
        table,
        checkpoint_evaluations,
        reference,
        args.reference_condition,
        args.bootstrap_draws,
        args.bootstrap_seed,
    )
    checkpoint_aggregate = aggregate_checkpoint_reference_effects(
        table,
        checkpoint_evaluations,
        reference,
        args.bootstrap_draws,
        args.bootstrap_seed,
    )
    windows = mechanism_windows(result_dir, table)
    window_aggregate = (
        windows.groupby(["arm", "window"], as_index=False)
        .mean(numeric_only=True)
        .sort_values(["arm", "window"])
    )
    traces = trace_comparisons(result_dir, table, reference_records)
    trace_summary = (
        traces.groupby(["arm", "transition"], as_index=False)
        .size()
        .rename(columns={"size": "sample_count"})
    )
    decision = selection_decision(curves)
    decision["frozen_not_worse_than_every_latent_arm"] = decision.pop(
        "supervised_only_not_worse_than_every_latent_arm"
    )

    pd.set_option("display.width", 240)
    pd.set_option("display.max_columns", None)
    print("=== LATENT-ONLY CURVES ===")
    print(curves.to_string(index=False))
    print("\n=== SEED-LEVEL FACTORIAL EFFECTS ===")
    print(seed_effects.to_string(index=False))
    print("\n=== QUESTION-CLUSTER FACTORIAL EFFECTS ===")
    print(aggregate_effects.to_string(index=False))
    print("\n=== FINAL VERSUS FROZEN BASE ===")
    print(final_reference.to_string(index=False))
    print("\n=== BEST MEAN CHECKPOINT PER ARM ===")
    print(
        checkpoint_aggregate.loc[
            checkpoint_aggregate.groupby("arm")["mean_difference_from_base"].idxmax()
        ].sort_values("arm").to_string(index=False)
    )
    print("\n=== EARLY/LATE MECHANISMS ===")
    print(windows.to_string(index=False))
    print("\n=== FROZEN SELECTION ===")
    print(json.dumps(decision, indent=2, sort_keys=True))

    if args.write_dir is not None:
        args.write_dir.mkdir(parents=True, exist_ok=True)
        outputs = {
            "latent_curve_summary.csv": curves,
            "latent_aggregate_trajectories.csv": aggregate_curves,
            "latent_seed_factorial_effects.csv": seed_effects,
            "latent_question_factorial_effects.csv": question_effects,
            "latent_aggregate_factorial_effects.csv": aggregate_effects,
            "latent_final_reference_contrasts.csv": final_reference,
            "latent_checkpoint_reference_contrasts.csv": checkpoint_reference,
            "latent_checkpoint_reference_aggregate.csv": checkpoint_aggregate,
            "latent_mechanism_windows.csv": windows,
            "latent_mechanism_window_aggregate.csv": window_aggregate,
            "latent_cell_mechanism_summary.csv": table,
            "latent_trace_transition_summary.csv": trace_summary,
        }
        for filename, frame in outputs.items():
            frame.to_csv(args.write_dir / filename, index=False)
        (args.write_dir / "latent_selection.json").write_text(
            json.dumps(decision, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        with (args.write_dir / "latent_trace_comparisons.jsonl").open(
            "w", encoding="utf-8"
        ) as handle:
            for record in traces.to_dict(orient="records"):
                handle.write(json.dumps(record, ensure_ascii=True) + "\n")


if __name__ == "__main__":
    main()
