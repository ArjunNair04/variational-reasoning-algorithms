#!/usr/bin/env python3
"""Analyse the preregistered Qwen3 prompt-information-path diagnostic.

The study intentionally reuses historical controls. Q5 and frozen-base
controls support strict-terminal metrics; the older GRPO/RLOO controls expose
only extracted-answer accuracy. The script preserves that evidence boundary.
"""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


SEEDS = (31, 47, 73)
ACTIVE_RUN_ID = "5ad4dd9d"
Q5_ACTIVE_RUN_ID = "e5754f6d"
Q5_CONTROL_RUN_ID = "5ab7eecd"
COMPARATOR_CONTROL_RUN_ID = "b4a0f86a"
Q5_CAPABILITY_TOLERANCE = -0.03
Q5_EXTRACTED_TOLERANCE = -0.01
Q5_TERMINATION_TOLERANCE = 0.02
Q5_MIN_PROPOSAL_CORRECT_FRACTION = 0.10
Q5_MAX_ALL_WRONG_QUESTION_FRACTION = 0.50
Q5_MIN_CORRECT_TRACE_MASS = 0.50
Q5_MIN_ESS_FRACTION = 1.0 / 16.0
Q5_MAX_POSTERIOR_CHURN_TV = 0.15


def _single(root: Path, pattern: str) -> Path:
    matches = sorted(root.glob(pattern))
    if len(matches) != 1:
        raise ValueError(
            f"expected one artifact for {root / pattern}, found {len(matches)}"
        )
    return matches[0]


def _json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _jsonl_gz(path: Path) -> list[dict]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle]


def _record_rate(records: Iterable[dict], field: str) -> float:
    values = [record.get(field) for record in records]
    if not values or any(not isinstance(value, bool) for value in values):
        return float("nan")
    return float(np.mean(values))


def _nonterminal_marker_rate(records: list[dict]) -> float:
    if not records:
        return float("nan")
    return float(np.mean([
        bool(record.get("has_answer_marker"))
        and record.get("answer_marker_terminal") is False
        for record in records
    ]))


def _verify_official_access(
    records: list[dict], path: Path, *, require_explicit_non_access: bool
) -> None:
    values = [record.get("official_test_accessed") for record in records]
    if require_explicit_non_access:
        if not values or any(value is not False for value in values):
            raise ValueError(f"{path}: official-test non-access was not verified")
    elif any(value is True for value in values):
        raise ValueError(f"{path}: historical control accessed official-test data")


def _checkpoint_rows(
    root: Path,
    pattern: str,
    *,
    cell: str,
    seed: int,
    expected_run_id: str,
    require_explicit_non_access: bool,
) -> list[dict]:
    path = _single(root, pattern)
    payloads = _jsonl_gz(path)
    if not payloads:
        raise ValueError(f"{path}: empty checkpoint stream")
    rows = []
    for payload in payloads:
        if str(payload.get("run_id")) != expected_run_id:
            raise ValueError(f"{path}: run ID mismatch")
        records = payload.get("records") or []
        metrics = payload.get("metrics") or {}
        _verify_official_access(
            records,
            path,
            require_explicit_non_access=require_explicit_non_access,
        )
        strict = metrics.get("test_acc_strict")
        if strict is None:
            strict = _record_rate(records, "strict_correct")
        extracted = metrics.get("test_acc_legacy", metrics.get("test_acc"))
        rows.append(
            {
                "cell": cell,
                "seed": seed,
                "round": int(payload["completed_rounds"]),
                "strict_accuracy": float(strict) if strict is not None else np.nan,
                "extracted_accuracy": float(extracted),
                "natural_eos_rate": _record_rate(records, "generated_eos"),
                "multiple_marker_rate": float(
                    np.mean([
                        (record.get("answer_marker_count") or 0) > 1
                        for record in records
                    ])
                ) if records and "answer_marker_count" in records[0] else np.nan,
                "nonterminal_rate": _nonterminal_marker_rate(records),
                "nonempty_reasoning_rate": _record_rate(
                    records, "has_nonempty_reasoning"
                ),
                "direct_answer_only_rate": _record_rate(
                    records, "direct_answer_only"
                ),
            }
        )
    rounds = [row["round"] for row in rows]
    if len(rounds) != len(set(rounds)) or rounds != sorted(rounds):
        raise ValueError(f"{path}: checkpoint rounds are not unique and ordered")
    return rows


def _final_row(
    root: Path,
    pattern: str,
    *,
    cell: str,
    seed: int,
    expected_run_id: str,
    require_explicit_non_access: bool,
) -> dict:
    path = _single(root, pattern)
    payload = _json(path)
    if str(payload.get("run_id")) != expected_run_id:
        raise ValueError(f"{path}: run ID mismatch")
    records = payload.get("records") or []
    _verify_official_access(
        records,
        path,
        require_explicit_non_access=require_explicit_non_access,
    )
    return {
        "cell": cell,
        "seed": seed,
        "strict_accuracy": _record_rate(records, "strict_correct"),
        "extracted_accuracy": _record_rate(records, "legacy_correct"),
        "natural_eos_rate": _record_rate(records, "generated_eos"),
        "multiple_marker_rate": float(
            np.mean([
                (record.get("answer_marker_count") or 0) > 1
                for record in records
            ])
        ) if records and "answer_marker_count" in records[0] else np.nan,
        "nonterminal_rate": _nonterminal_marker_rate(records),
        "nonempty_reasoning_rate": _record_rate(records, "has_nonempty_reasoning"),
        "direct_answer_only_rate": _record_rate(records, "direct_answer_only"),
    }


def normalized_auc(group: pd.DataFrame, metric: str, baseline: float) -> float:
    values = group[["round", metric]].dropna().sort_values("round")
    if values.empty:
        return float("nan")
    rounds = np.concatenate(([0.0], values["round"].to_numpy(dtype=float)))
    scores = np.concatenate(([baseline], values[metric].to_numpy(dtype=float)))
    return float(np.trapezoid(scores, rounds) / rounds[-1])


def paired_interval(values: np.ndarray, *, draws: int = 20000) -> tuple[float, float]:
    if values.shape != (3,):
        raise ValueError(f"expected exactly three paired seeds, found {values.shape}")
    rng = np.random.default_rng(20260731)
    means = values[rng.integers(0, len(values), size=(draws, len(values)))].mean(1)
    return tuple(float(value) for value in np.quantile(means, [0.025, 0.975]))


def _weighted_mean(values: list[tuple[float, int]]) -> float:
    finite = [(value, weight) for value, weight in values if np.isfinite(value)]
    total = sum(weight for _, weight in finite)
    return (
        float(sum(value * weight for value, weight in finite) / total)
        if total
        else float("nan")
    )


def load_q5_mechanism_diagnostics(root: Path) -> pd.DataFrame:
    """Aggregate predeclared support and posterior diagnostics by seed."""

    rows = []
    for seed in SEEDS:
        path = _single(root, f"training_diagnostics_*Q5-Q_seed{seed}*.jsonl.gz")
        payloads = _jsonl_gz(path)
        if len(payloads) != 30:
            raise ValueError(f"{path}: expected 30 diagnostic rounds")
        correct: list[tuple[float, int]] = []
        format_rates: list[tuple[float, int]] = []
        correct_mass: list[tuple[float, int]] = []
        ess: list[tuple[float, int]] = []
        max_responsibility: list[tuple[float, int]] = []
        churn: list[float] = []
        all_wrong = 0
        question_groups = 0
        generated_tokens = 0
        backward_tokens = 0
        for payload in payloads:
            if str(payload.get("run_id")) != Q5_ACTIVE_RUN_ID:
                raise ValueError(f"{path}: run ID mismatch")
            samples = payload["generation"]["samples"]
            sample_count = int(samples["count"])
            correct.append((float(samples["correct_fraction"]), sample_count))
            format_rates.append((float(samples["format_fraction"]), sample_count))
            outcomes = samples["question_outcomes"]
            all_wrong += int(outcomes["all_wrong"])
            question_groups += sum(int(value) for value in outcomes.values())

            partition = payload["responsibilities"]["partitions"]["answer_only"]
            question_count = int(partition["question_count"])
            correct_mass.append(
                (float(partition["mean_answer_correct_mass"]), question_count)
            )
            ess.append(
                (
                    float(partition["mean_effective_sample_size_fraction"]),
                    question_count,
                )
            )
            max_responsibility.append(
                (float(partition["mean_max_responsibility"]), question_count)
            )
            churn.append(
                float(payload["responsibilities"][
                    "inter_refresh_total_variation_mean"
                ])
            )
            tokens = payload["compute"]["tokens"]
            generated_tokens += int(tokens["generated"])
            backward_tokens += int(tokens["backward"])
        rows.append(
            {
                "seed": seed,
                "proposal_correct_fraction": _weighted_mean(correct),
                "proposal_format_fraction": _weighted_mean(format_rates),
                "all_wrong_question_fraction": (
                    all_wrong / question_groups if question_groups else np.nan
                ),
                "correct_trace_mass": _weighted_mean(correct_mass),
                "ess_fraction": _weighted_mean(ess),
                "max_responsibility": _weighted_mean(max_responsibility),
                "posterior_churn_tv": float(np.mean(churn)),
                "generated_tokens": generated_tokens,
                "backward_tokens": backward_tokens,
            }
        )
    return pd.DataFrame(rows)


def classify_q5_outcome(
    auc_table: pd.DataFrame,
    diagnostics: pd.DataFrame,
) -> dict:
    """Apply frozen diagnostic gates without selecting a final method."""

    indexed = auc_table.set_index(["cell", "seed"])

    def delta(metric: str) -> np.ndarray:
        return np.asarray(
            [
                indexed.loc[("Q5-Q", seed), metric]
                - indexed.loc[("Q5-AD", seed), metric]
                for seed in SEEDS
            ],
            dtype=float,
        )

    metric_deltas = {
        metric: delta(metric)
        for metric in (
            "strict_auc",
            "extracted_auc",
            "final_strict_accuracy",
            "final_extracted_accuracy",
            "final_natural_eos_rate",
            "final_nonterminal_rate",
        )
    }
    diagnostic_index = diagnostics.set_index("seed").reindex(SEEDS)
    gates = {
        "strict_AUC_within_3pp": float(metric_deltas["strict_auc"].mean())
        >= Q5_CAPABILITY_TOLERANCE,
        "final_strict_within_3pp": float(
            metric_deltas["final_strict_accuracy"].mean()
        ) >= Q5_CAPABILITY_TOLERANCE,
        "extracted_AUC_within_1pp": float(
            metric_deltas["extracted_auc"].mean()
        ) >= Q5_EXTRACTED_TOLERANCE,
        "natural_EOS_drop_at_most_2pp": float(
            metric_deltas["final_natural_eos_rate"].mean()
        ) >= -Q5_TERMINATION_TOLERANCE,
        "nonterminal_increase_at_most_2pp": float(
            metric_deltas["final_nonterminal_rate"].mean()
        ) <= Q5_TERMINATION_TOLERANCE,
        "proposal_correct_fraction_at_least_10pct": float(
            diagnostic_index["proposal_correct_fraction"].mean()
        ) >= Q5_MIN_PROPOSAL_CORRECT_FRACTION,
        "all_wrong_question_fraction_at_most_50pct": float(
            diagnostic_index["all_wrong_question_fraction"].mean()
        ) <= Q5_MAX_ALL_WRONG_QUESTION_FRACTION,
        "correct_trace_mass_at_least_50pct": float(
            diagnostic_index["correct_trace_mass"].mean()
        ) >= Q5_MIN_CORRECT_TRACE_MASS,
        "ESS_above_single_trace_floor_in_every_seed": bool(
            (
                diagnostic_index["ess_fraction"]
                > Q5_MIN_ESS_FRACTION
            ).all()
        ),
        "posterior_churn_at_most_0_15_in_every_seed": bool(
            (
                diagnostic_index["posterior_churn_tv"]
                <= Q5_MAX_POSTERIOR_CHURN_TV
            ).all()
        ),
    }
    support_ok = (
        gates["proposal_correct_fraction_at_least_10pct"]
        and gates["all_wrong_question_fraction_at_most_50pct"]
    )
    posterior_ok = (
        gates["correct_trace_mass_at_least_50pct"]
        and gates["ESS_above_single_trace_floor_in_every_seed"]
        and gates["posterior_churn_at_most_0_15_in_every_seed"]
    )
    capability_ok = (
        gates["strict_AUC_within_3pp"]
        and gates["final_strict_within_3pp"]
    )
    terminal_ok = (
        gates["natural_EOS_drop_at_most_2pp"]
        and gates["nonterminal_increase_at_most_2pp"]
    )
    if not support_ok:
        diagnosis = "proposal_support_failure"
    elif not posterior_ok:
        diagnosis = "posterior_selection_or_stability_failure"
    elif not terminal_ok and gates["extracted_AUC_within_1pp"]:
        diagnosis = "terminal_behaviour_failure"
    elif not capability_ok:
        diagnosis = "m_step_or_generalisation_failure"
    else:
        diagnosis = "question_only_proposal_path_viable"
    return {
        "gates": gates,
        "diagnosis": diagnosis,
        "method_selection_allowed": False,
        "metric_deltas_by_seed": {
            metric: values.tolist()
            for metric, values in metric_deltas.items()
        },
    }


def build_analysis(
    active_dir: Path,
    q5_active_dir: Path,
    q5_control_dir: Path,
    comparator_control_dir: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    curves: list[dict] = []
    finals: list[dict] = []
    for seed in SEEDS:
        curves += _checkpoint_rows(
            q5_active_dir,
            f"checkpoint_eval_*Q5-Q_seed{seed}*.jsonl.gz",
            cell="Q5-Q", seed=seed, expected_run_id=Q5_ACTIVE_RUN_ID,
            require_explicit_non_access=True,
        )
        curves += _checkpoint_rows(
            q5_control_dir,
            f"checkpoint_eval_*_EOS-Q5_seed{seed}*.jsonl.gz",
            cell="Q5-AD", seed=seed, expected_run_id=Q5_CONTROL_RUN_ID,
            require_explicit_non_access=False,
        )
        for method in ("GRPO", "RLOO"):
            curves += _checkpoint_rows(
                active_dir,
                f"checkpoint_eval_*{method}-{ 'AD' }_seed{seed}*.jsonl.gz",
                cell=f"{method}-AD", seed=seed, expected_run_id=ACTIVE_RUN_ID,
                require_explicit_non_access=True,
            )
            curves += _checkpoint_rows(
                comparator_control_dir,
                f"checkpoint_eval_*{method}_shot4_seed{seed}*.jsonl.gz",
                cell=f"{method}-Q", seed=seed,
                expected_run_id=COMPARATOR_CONTROL_RUN_ID,
                require_explicit_non_access=False,
            )
        finals.append(_final_row(
            active_dir, f"eval_*BASE-AD_seed{seed}*.json",
            cell="BASE-AD", seed=seed, expected_run_id=ACTIVE_RUN_ID,
            require_explicit_non_access=True,
        ))
        finals.append(_final_row(
            q5_control_dir, f"eval_*CTRL-base_seed{seed}*.json",
            cell="BASE-Q", seed=seed, expected_run_id=Q5_CONTROL_RUN_ID,
            require_explicit_non_access=False,
        ))

    curve_table = pd.DataFrame(curves)
    final_table = pd.DataFrame(finals)
    strict_baseline = {
        int(row.seed): float(row.strict_accuracy)
        for row in final_table[final_table.cell == "BASE-Q"].itertuples()
    }
    extracted_baseline = {
        int(row.seed): float(row.extracted_accuracy)
        for row in final_table[final_table.cell == "BASE-Q"].itertuples()
    }
    baseline_metrics = {
        metric: {
            int(row.seed): float(getattr(row, metric))
            for row in final_table[final_table.cell == "BASE-Q"].itertuples()
        }
        for metric in (
            "strict_accuracy",
            "extracted_accuracy",
            "natural_eos_rate",
            "multiple_marker_rate",
            "nonterminal_rate",
            "nonempty_reasoning_rate",
            "direct_answer_only_rate",
        )
    }
    auc_rows = []
    for (cell, seed), group in curve_table.groupby(["cell", "seed"]):
        row = {
            "cell": cell,
            "seed": int(seed),
        }
        final = group.sort_values("round").iloc[-1]
        for metric, baseline_by_seed in baseline_metrics.items():
            stem = metric.removesuffix("_accuracy").removesuffix("_rate")
            row[f"{stem}_auc"] = normalized_auc(
                group, metric, baseline_by_seed[int(seed)]
            )
            row[f"final_{metric}"] = final[metric]
        auc_rows.append(row)
    auc_table = pd.DataFrame(auc_rows)

    contrasts = []
    for intervention, control, metric in (
        ("Q5-Q", "Q5-AD", "strict_auc"),
        ("GRPO-AD", "GRPO-Q", "extracted_auc"),
        ("RLOO-AD", "RLOO-Q", "extracted_auc"),
    ):
        left = auc_table[auc_table.cell == intervention].set_index("seed")
        right = auc_table[auc_table.cell == control].set_index("seed")
        delta = (left[metric] - right[metric]).reindex(SEEDS).to_numpy(float)
        low, high = paired_interval(delta)
        contrasts.append({
            "contrast": f"{intervention}_minus_{control}",
            "metric": metric,
            "mean_delta": float(delta.mean()),
            "interval_low": low,
            "interval_high": high,
            "seed_deltas": delta.tolist(),
            "evidence_class": "cross_run_diagnostic",
        })
    base = final_table.pivot(index="seed", columns="cell")
    delta = (
        base["strict_accuracy"]["BASE-AD"]
        - base["strict_accuracy"]["BASE-Q"]
    ).reindex(SEEDS).to_numpy(float)
    low, high = paired_interval(delta)
    contrasts.append({
        "contrast": "BASE-AD_minus_BASE-Q",
        "metric": "final_strict_accuracy",
        "mean_delta": float(delta.mean()),
        "interval_low": low,
        "interval_high": high,
        "seed_deltas": delta.tolist(),
        "evidence_class": "gold_answer_exposed_upper_bound",
    })
    return curve_table, pd.concat([auc_table, final_table], ignore_index=True), pd.DataFrame(contrasts)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--active-dir", type=Path, required=True)
    parser.add_argument("--q5-active-dir", type=Path, required=True)
    parser.add_argument("--q5-control-dir", type=Path, required=True)
    parser.add_argument("--comparator-control-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    curves, summaries, contrasts = build_analysis(
        args.active_dir,
        args.q5_active_dir,
        args.q5_control_dir,
        args.comparator_control_dir,
    )
    args.out_dir.mkdir(parents=True, exist_ok=True)
    curves.to_csv(args.out_dir / "prompt_path_curves.csv", index=False)
    summaries.to_csv(args.out_dir / "prompt_path_summaries.csv", index=False)
    contrasts.to_csv(args.out_dir / "prompt_path_contrasts.csv", index=False)
    q5_diagnostics = load_q5_mechanism_diagnostics(args.q5_active_dir)
    q5_diagnostics.to_csv(
        args.out_dir / "q5_question_only_mechanism_diagnostics.csv",
        index=False,
    )
    auc_only = summaries[summaries["cell"].isin(["Q5-Q", "Q5-AD"])].dropna(
        subset=["strict_auc"]
    )
    q5_decision = classify_q5_outcome(auc_only, q5_diagnostics)
    payload = {
        "run_id": ACTIVE_RUN_ID,
        "q5_retry_run_id": Q5_ACTIVE_RUN_ID,
        "q5_retry_cell": "Q5-Q",
        "method_selection_allowed": False,
        "official_test_used": False,
        "q5_preoutcome_decision": q5_decision,
        "contrasts": contrasts.to_dict("records"),
        "limitations": [
            "All effects reuse historical controls and are diagnostic.",
            "Historical GRPO/RLOO controls support extracted, not strict, AUC.",
            "BASE-AD exposes the gold answer during evaluation and is not deployable.",
            "Q5-Q comes from the isolated three-seed retry after the original "
            "in-array cells failed profile validation.",
        ],
    }
    (args.out_dir / "prompt_path_decision.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
