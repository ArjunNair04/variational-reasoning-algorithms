#!/usr/bin/env python3
"""Analyse the separate fresh-seed Q5-reader and PIS confirmations.

The studies share fresh seed identities for precision, but they retain their
native protocols and are not a causal Q5-versus-PIS comparison. The paired
training seed is the independent unit in each study. Final extracted Acc@1 is
reported first, strict final accuracy second and checkpoint AUC third.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from analysis.analyze_barber_eos_repair import exact_sign_flip_p
from analysis.analyze_barber_source_programme import paired_bootstrap
from analysis.analyze_l2r_common_protocol_factorial import (
    BASE_CELL,
    _cell_seed_from_tag,
    _finite_float,
    _read_json,
    _read_jsonl_gz,
    _require_record_non_access,
    _single_artifact,
)


SEEDS = (1009, 1013, 1019, 1021, 1031, 1033, 1039)
METRICS = {
    "extracted": "test_acc_legacy",
    "strict": "test_acc_strict",
    "format_failure": "eval_strict_format_failure_fraction",
    "natural_eos": "eval_natural_eos_fraction",
}


@dataclass(frozen=True)
class ConfirmationSpec:
    name: str
    run_id: str
    cells: tuple[str, ...]
    rounds: int
    checkpoints: tuple[int, ...]
    trained_method: str

    @property
    def task_count(self) -> int:
        return len(self.cells) * len(SEEDS)


SPECS = {
    "q5": ConfirmationSpec(
        name="q5_reader_confirmation",
        run_id="1d4eebd8",
        cells=(BASE_CELL, "EOS-Q5-M", "EOS-Q5-F"),
        rounds=30,
        checkpoints=(1, 2, 3, 5, 10, 15, 20, 30),
        trained_method="AC-ALG1",
    ),
    "pis": ConfirmationSpec(
        name="pis_confirmation",
        run_id="388abde8",
        cells=(BASE_CELL, "PIS-S8-B8-U4"),
        rounds=32,
        checkpoints=(1, 2, 4, 8, 16, 24, 32),
        trained_method="AC-ALG1",
    ),
    "q5_refresh": ConfirmationSpec(
        name="q5_responsibility_refresh",
        run_id="f2d3b51e",
        cells=("EOS-Q5-M-OUTER",),
        rounds=30,
        checkpoints=(1, 2, 3, 5, 10, 15, 20, 30),
        trained_method="AC-ALG1",
    ),
}

EXPECTED_PROPOSAL_MODES = {
    BASE_CELL: "question",
    "EOS-Q5-M": "answer_derive",
    "EOS-Q5-F": "answer_derive",
    "EOS-Q5-M-OUTER": "answer_derive",
    "PIS-S8-B8-U4": "question",
}


def _require_terminal_non_access(result: Mapping[str, Any], *, context: str) -> None:
    expected = {
        "eval_official_test_accessed": False,
        "eval_source_split": "train",
        "eval_dataset_splits_loaded": ["train"],
    }
    for key, value in expected.items():
        if result.get(key) != value:
            raise ValueError(f"{context}: official-test boundary {key} mismatch")


def _base_metric_value(
    base: pd.DataFrame,
    *,
    seed: int,
    metric: str,
    summarized: bool,
) -> float:
    suffix = "_final" if summarized else "_result_final"
    return _finite_float(
        base.loc[seed, f"{metric}{suffix}"],
        context=f"base/{seed}/{metric}{suffix}",
    )


def _normalized_auc(values: Sequence[float], rounds: Sequence[int], horizon: int) -> float:
    values_array = np.asarray(values, dtype=float)
    rounds_array = np.asarray(rounds, dtype=float)
    if (
        len(values_array) != len(rounds_array)
        or len(values_array) < 2
        or not np.isfinite(values_array).all()
        or not np.all(np.diff(rounds_array) > 0)
        or int(rounds_array[0]) != 0
        or int(rounds_array[-1]) != int(horizon)
    ):
        raise ValueError("AUC requires the complete registered checkpoint schedule")
    return float(np.trapezoid(values_array, rounds_array) / float(horizon))


def load_design(config_path: Path, study: str) -> tuple[dict[str, Any], ConfirmationSpec]:
    spec = SPECS[study]
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(config, dict) or str(config.get("run_id")) != spec.run_id:
        raise ValueError("configuration run ID does not match the requested study")
    defaults = dict(config.get("defaults") or {})
    if tuple(defaults.get("seed_values") or ()) != SEEDS:
        raise ValueError("fresh seed set changed")
    if int(defaults.get("rounds", -1)) != spec.rounds:
        raise ValueError("round horizon changed")
    if tuple(defaults.get("eval_rounds") or ()) != spec.checkpoints:
        raise ValueError("checkpoint schedule changed")
    if defaults.get("train_partition") != "train" or defaults.get("eval_partition") != "validation":
        raise ValueError("train-derived partition contract changed")
    if defaults.get("answer_event_mode") != "strict_terminal_marker":
        raise ValueError("strict answer event changed")
    if dict((config.get("diagnostic") or {}).get("fixed_contract") or {}).get(
        "official_test_used"
    ) is not False:
        raise ValueError("official-test prohibition is missing")
    configured_cells: list[str] = []
    for raw in (config.get("algos") or {}).values():
        variants = raw if isinstance(raw, list) else [raw]
        configured_cells.extend(str(variant.get("cell_id")) for variant in variants)
    if tuple(configured_cells) != spec.cells:
        raise ValueError(f"configured cells changed: {configured_cells!r}")
    return config, spec


def verify_provenance(
    artifact_dir: Path,
    config_path: Path,
    marker_path: Path,
    spec: ConfirmationSpec,
    *,
    expected_commit: str,
    expected_source_job: str,
    expected_recovery_commit: str | None = None,
    expected_recovery_source_job: str | None = None,
) -> dict[str, Any]:
    marker = _read_json(marker_path)
    expected_common = {
        "status": "ok",
        "run_id": spec.run_id,
        "configuration_sha256": hashlib.sha256(config_path.read_bytes()).hexdigest(),
    }
    for key, value in expected_common.items():
        if marker.get(key) != value:
            raise ValueError(f"validator marker {key} mismatch")
    if marker.get("schema_version") == 1:
        if expected_recovery_commit or expected_recovery_source_job:
            raise ValueError("single-execution marker cannot bind a base recovery")
        for key, value in {
            "execution_commit": expected_commit,
            "source_job_id": expected_source_job,
        }.items():
            if marker.get(key) != value:
                raise ValueError(f"validator marker {key} mismatch")
        cell_commits = {cell: expected_commit for cell in spec.cells}
    elif marker.get("schema_version") == 2:
        if not expected_recovery_commit or not expected_recovery_source_job:
            raise ValueError("segmented marker requires base-recovery provenance")
        expected_segments = [
            {
                "role": "base_recovery",
                "source_job_id": expected_recovery_source_job,
                "execution_commit": expected_recovery_commit,
                "task_range": [1, len(SEEDS)],
            },
            {
                "role": "immutable_trained_cells",
                "source_job_id": expected_source_job,
                "execution_commit": expected_commit,
                "task_range": [len(SEEDS) + 1, spec.task_count],
            },
        ]
        if marker.get("execution_segments") != expected_segments:
            raise ValueError("validator marker execution segments mismatch")
        if BASE_CELL not in spec.cells:
            raise ValueError("base-recovery marker used for a study without a base cell")
        cell_commits = {
            cell: expected_recovery_commit if cell == BASE_CELL else expected_commit
            for cell in spec.cells
        }
    else:
        raise ValueError("validator marker schema mismatch")
    sweeps = sorted(artifact_dir.glob("sweep_*.csv"))
    if len(sweeps) != spec.task_count:
        raise ValueError(f"expected {spec.task_count} sweep files, found {len(sweeps)}")
    observed: set[tuple[str, int]] = set()
    fingerprints: set[str] = set()
    for path in sweeps:
        frame = pd.read_csv(path)
        if len(frame) != 1:
            raise ValueError(f"{path.name}: expected one sweep row")
        row = frame.iloc[0]
        cell, seed = _cell_seed_from_tag(path.stem, spec.cells)
        coordinate = (cell, seed)
        if seed not in SEEDS or coordinate in observed:
            raise ValueError(f"{path.name}: duplicate or unregistered coordinate")
        observed.add(coordinate)
        params = json.loads(str(row.get("params") or ""))
        if str(params.get("run_id")) != spec.run_id:
            raise ValueError(f"{path.name}: run-ID mismatch")
        commit = str((params.get("env") or {}).get("commit", ""))
        cell_commit = cell_commits[cell]
        if len(commit) < 7 or not cell_commit.startswith(commit):
            raise ValueError(f"{path.name}: execution commit mismatch")
        fingerprint = str(row.get("cell_fingerprint") or "")
        if not fingerprint or fingerprint in fingerprints:
            raise ValueError(f"{path.name}: missing or duplicate fingerprint")
        fingerprints.add(fingerprint)
    expected_coordinates = {(cell, seed) for cell in spec.cells for seed in SEEDS}
    if observed != expected_coordinates:
        raise ValueError("sweep coordinate coverage is incomplete")

    manifests = sorted(artifact_dir.glob("prompt_contract_*.json.gz"))
    if len(manifests) != spec.task_count:
        raise ValueError(
            f"expected {spec.task_count} prompt contracts, found {len(manifests)}"
        )
    manifest_coordinates: set[tuple[str, int]] = set()
    for path in manifests:
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            payload = json.load(stream)
        if payload.get("schema_version") != 1:
            raise ValueError(f"{path.name}: prompt-contract schema mismatch")
        cell, seed = _cell_seed_from_tag(str(payload.get("tag")), spec.cells)
        coordinate = (cell, seed)
        if coordinate in manifest_coordinates:
            raise ValueError(f"{path.name}: duplicate prompt coordinate")
        manifest_coordinates.add(coordinate)
        if int(payload.get("training_seed", -1)) != seed:
            raise ValueError(f"{path.name}: prompt-contract seed mismatch")
        expected_mode = EXPECTED_PROPOSAL_MODES[cell]
        if payload.get("proposal_prompt_mode") != expected_mode:
            raise ValueError(f"{path.name}: proposal-prompt mode mismatch")
        rows = payload.get("rows")
        if not isinstance(rows, list) or not rows:
            raise ValueError(f"{path.name}: prompt rows are absent")
        for row in rows:
            if row.get("canonical_contains_proposal_answer_hint") is not False:
                raise ValueError(f"{path.name}: answer hint leaked into canonical prompt")
            expected_hint = expected_mode != "question"
            if row.get("proposal_contains_gold_answer_hint") is not expected_hint:
                raise ValueError(f"{path.name}: proposal answer-hint mismatch")
    if manifest_coordinates != expected_coordinates:
        raise ValueError("prompt-contract coordinate coverage is incomplete")
    return {
        **expected_common,
        "schema_version": marker["schema_version"],
        "execution_segments": marker.get("execution_segments"),
        "task_count": spec.task_count,
        "prompt_contract_count": len(manifests),
        "official_test_used": False,
    }


def load_curves(
    artifact_dir: Path,
    spec: ConfirmationSpec,
    *,
    baseline_summaries: pd.DataFrame | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    terminal_rows: list[dict[str, Any]] = []
    for path in sorted(artifact_dir.glob("cell_result_*.json")):
        payload = _read_json(path)
        identity = payload.get("identity") or {}
        result = payload.get("result") or {}
        if str(identity.get("run_id")) != spec.run_id or str(result.get("run_id")) != spec.run_id:
            raise ValueError(f"{path.name}: run-ID mismatch")
        cell, seed = _cell_seed_from_tag(str(identity.get("tag")), spec.cells)
        if int(identity.get("seed", -1)) != seed:
            raise ValueError(f"{path.name}: seed identity mismatch")
        _require_terminal_non_access(result, context=path.name)
        terminal_rows.append(
            {
                "cell": cell,
                "seed": seed,
                "tag": str(identity.get("tag")),
                **{
                    f"{metric}_result_final": _finite_float(
                        result.get(key), context=f"{path.name}/{key}"
                    )
                    for metric, key in METRICS.items()
                },
            }
        )
    terminal = pd.DataFrame(terminal_rows)
    expected = {(cell, seed) for cell in spec.cells for seed in SEEDS}
    if set(zip(terminal.get("cell", []), terminal.get("seed", []), strict=True)) != expected:
        raise ValueError("terminal cell/seed coverage is incomplete")
    if terminal.duplicated(["cell", "seed"]).any():
        raise ValueError("duplicate terminal coordinate")

    if BASE_CELL in spec.cells:
        base = terminal[terminal["cell"] == BASE_CELL].set_index("seed")
        base_is_summarized = False
    elif baseline_summaries is not None:
        base = baseline_summaries[
            baseline_summaries["cell"] == BASE_CELL
        ].set_index("seed")
        if tuple(sorted(int(value) for value in base.index)) != SEEDS:
            raise ValueError("external round-zero baseline is incomplete")
        base_is_summarized = True
    else:
        raise ValueError("study without a base cell requires external round-zero metrics")
    points: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    for row in terminal.to_dict("records"):
        cell = str(row["cell"])
        seed = int(row["seed"])
        rounds = [0]
        series = {
            metric: [
                _base_metric_value(
                    base,
                    seed=seed,
                    metric=metric,
                    summarized=base_is_summarized,
                )
            ]
            for metric in METRICS
        }
        if cell == BASE_CELL:
            rounds.extend(spec.checkpoints)
            for metric in METRICS:
                series[metric].extend(
                    [float(row[f"{metric}_result_final"])] * len(spec.checkpoints)
                )
        else:
            checkpoint_path = _single_artifact(
                artifact_dir,
                f"checkpoint_eval_*__{row['tag']}__*.jsonl.gz",
                f"{cell}/{seed}",
            )
            checkpoints = _read_jsonl_gz(checkpoint_path)
            observed_rounds = tuple(int(item.get("completed_rounds", -1)) for item in checkpoints)
            if observed_rounds != spec.checkpoints:
                raise ValueError(f"{checkpoint_path.name}: checkpoint schedule mismatch")
            rounds.extend(observed_rounds)
            for checkpoint in checkpoints:
                records = checkpoint.get("records") or []
                if len(records) != 400:
                    raise ValueError(f"{checkpoint_path.name}: expected 400 records")
                for index, record in enumerate(records):
                    _require_record_non_access(
                        record,
                        context=f"{checkpoint_path.name}/record{index}",
                    )
                checkpoint_metrics = checkpoint.get("metrics") or {}
                for metric, key in METRICS.items():
                    series[metric].append(
                        _finite_float(
                            checkpoint_metrics.get(key),
                            context=f"{checkpoint_path.name}/{key}",
                        )
                    )
        summary: dict[str, Any] = {"cell": cell, "seed": seed}
        for metric, values in series.items():
            if not math.isclose(values[-1], float(row[f"{metric}_result_final"]), abs_tol=1e-12):
                raise ValueError(f"{cell}/{seed}: checkpoint and terminal disagree")
            summary[f"{metric}_final"] = float(values[-1])
            summary[f"{metric}_auc"] = _normalized_auc(values, rounds, spec.rounds)
        late = [value for completed, value in zip(rounds, series["extracted"]) if completed >= 8]
        summary["late_peak_to_final_extracted_drop"] = float(max(late) - series["extracted"][-1])
        summaries.append(summary)
        for position, completed in enumerate(rounds):
            points.append(
                {
                    "cell": cell,
                    "seed": seed,
                    "completed_rounds": completed,
                    **{metric: values[position] for metric, values in series.items()},
                }
            )
    return pd.DataFrame(points), pd.DataFrame(summaries)


def _paired(
    summaries: pd.DataFrame,
    treatment: str,
    control: str,
    metric: str,
) -> pd.Series:
    pivot = summaries.pivot(index="seed", columns="cell", values=metric).reindex(SEEDS)
    if pivot[[treatment, control]].isna().any().any():
        raise ValueError(f"incomplete paired contrast {treatment} minus {control}")
    return pivot[treatment] - pivot[control]


def _contrast(
    summaries: pd.DataFrame,
    treatment: str,
    control: str,
    metric: str,
    *,
    draws: int,
    seed: int,
) -> dict[str, Any]:
    differences = _paired(summaries, treatment, control, metric)
    mean, low, high = paired_bootstrap(differences.to_numpy(float), draws, seed)
    return {
        "treatment": treatment,
        "control": control,
        "metric": metric,
        "observational_unit": "paired training seed",
        "mean_difference": mean,
        "ci95_low": low,
        "ci95_high": high,
        "mean_difference_pp": 100.0 * mean,
        "positive_seeds": int((differences > 0).sum()),
        "exact_sign_flip_p": exact_sign_flip_p(differences.to_numpy(float)),
        "seed_differences": {
            str(int(index)): float(value) for index, value in differences.items()
        },
    }


def analyze_q5(summaries: pd.DataFrame, *, draws: int, seed: int) -> tuple[pd.DataFrame, dict[str, Any]]:
    contrast_specs = (
        ("EOS-Q5-F", "EOS-Q5-M", "strict_auc"),
        ("EOS-Q5-M", BASE_CELL, "extracted_final"),
        ("EOS-Q5-M", BASE_CELL, "strict_final"),
        ("EOS-Q5-M", BASE_CELL, "strict_auc"),
        ("EOS-Q5-F", BASE_CELL, "extracted_final"),
        ("EOS-Q5-F", BASE_CELL, "strict_final"),
        ("EOS-Q5-F", BASE_CELL, "strict_auc"),
    )
    contrasts = pd.DataFrame(
        [
            _contrast(summaries, treatment, control, metric, draws=draws, seed=seed + index)
            for index, (treatment, control, metric) in enumerate(contrast_specs)
        ]
    )
    reader = contrasts.iloc[0]
    if float(reader["ci95_low"]) > 0.0:
        candidate = "EOS-Q5-F"
    elif float(reader["ci95_high"]) < 0.0:
        candidate = "EOS-Q5-M"
    else:
        candidate = "EOS-Q5-M"
    candidate_auc = contrasts[
        (contrasts["treatment"] == candidate)
        & (contrasts["control"] == BASE_CELL)
        & (contrasts["metric"] == "strict_auc")
    ].iloc[0]
    extracted_auc = _paired(summaries, candidate, BASE_CELL, "extracted_auc")
    format_final = _paired(summaries, candidate, BASE_CELL, "format_failure_final")
    reader_resolved = bool(float(reader["ci95_low"]) > 0.0 or float(reader["ci95_high"]) < 0.0)
    gates = {
        "reader_interval_excludes_zero": reader_resolved,
        "candidate_strict_auc_lower_interval_above_zero": float(candidate_auc["ci95_low"]) > 0.0,
        "candidate_mean_extracted_auc_not_worse_than_3pp": float(extracted_auc.mean()) >= -0.03,
        "candidate_mean_format_failure_not_worse_than_3pp": float(format_final.mean()) <= 0.03,
    }
    selected = candidate if all(gates.values()) else None
    if selected:
        decision = "reader_selected"
    elif reader_resolved:
        decision = "reader_contrast_resolved_no_capability_selection"
    else:
        decision = "reader_unresolved_retain_moving"
    return contrasts, {
        "decision": decision,
        "selected_reader_cell": selected,
        "fallback_reader_cell": "EOS-Q5-M",
        "gates": gates,
    }


def analyze_pis(summaries: pd.DataFrame, *, draws: int, seed: int) -> tuple[pd.DataFrame, dict[str, Any]]:
    treatment = "PIS-S8-B8-U4"
    metrics = ("extracted_final", "strict_final", "extracted_auc")
    contrasts = pd.DataFrame(
        [
            _contrast(summaries, treatment, BASE_CELL, metric, draws=draws, seed=seed + index)
            for index, metric in enumerate(metrics)
        ]
    )
    by_metric = contrasts.set_index("metric")
    format_difference = _paired(summaries, treatment, BASE_CELL, "format_failure_final")
    late = summaries[summaries["cell"] == treatment]["late_peak_to_final_extracted_drop"]
    gates = {
        "final_extracted_lower_interval_above_zero": float(by_metric.loc["extracted_final", "ci95_low"]) > 0.0,
        "final_extracted_positive_in_at_least_five_seeds": int(by_metric.loc["extracted_final", "positive_seeds"]) >= 5,
        "mean_strict_final_not_worse_than_2pp": float(by_metric.loc["strict_final", "mean_difference"]) >= -0.02,
        "extracted_auc_lower_interval_above_zero": float(by_metric.loc["extracted_auc", "ci95_low"]) > 0.0,
        "mean_late_drop_at_most_3pp": float(late.mean()) <= 0.03,
        "mean_format_failure_not_worse_than_3pp": float(format_difference.mean()) <= 0.03,
    }
    return contrasts, {
        "decision": "pis_confirmed" if all(gates.values()) else "pis_not_confirmed",
        "gates": gates,
    }


def analyze_q5_refresh(
    summaries: pd.DataFrame,
    *,
    draws: int,
    seed: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Apply the frozen outer-round versus inner-step Q5 decision rule."""

    treatment = "EOS-Q5-M-OUTER"
    control = "EOS-Q5-M"
    metrics = (
        "extracted_final",
        "strict_final",
        "strict_auc",
        "format_failure_final",
    )
    contrasts = pd.DataFrame(
        [
            _contrast(
                summaries,
                treatment,
                control,
                metric,
                draws=draws,
                seed=seed + index,
            )
            for index, metric in enumerate(metrics)
        ]
    )
    by_metric = contrasts.set_index("metric")
    gates = {
        "strict_auc_lower_interval_above_zero": float(
            by_metric.loc["strict_auc", "ci95_low"]
        ) > 0.0,
        "mean_final_extracted_not_worse_than_3pp": float(
            by_metric.loc["extracted_final", "mean_difference"]
        ) >= -0.03,
        "mean_final_strict_not_worse_than_3pp": float(
            by_metric.loc["strict_final", "mean_difference"]
        ) >= -0.03,
        "mean_format_failure_not_worse_than_3pp": float(
            by_metric.loc["format_failure_final", "mean_difference"]
        ) <= 0.03,
    }
    return contrasts, {
        "decision": "outer_round_selected" if all(gates.values()) else "inner_step_retained",
        "selected_refresh": "outer_round" if all(gates.values()) else "inner_step",
        "gates": gates,
    }


def _means(summaries: pd.DataFrame, spec: ConfirmationSpec) -> list[dict[str, Any]]:
    ordered = [
        "extracted_final",
        "strict_final",
        "extracted_auc",
        "strict_auc",
        "late_peak_to_final_extracted_drop",
        "format_failure_final",
        "natural_eos_final",
    ]
    return [
        {
            "cell": cell,
            **{
                metric: float(summaries[summaries["cell"] == cell][metric].mean())
                for metric in ordered
            },
        }
        for cell in spec.cells
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--study", choices=tuple(SPECS), required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--artifact-dir", type=Path, required=True)
    parser.add_argument("--marker", type=Path, required=True)
    parser.add_argument("--expected-commit", required=True)
    parser.add_argument("--expected-source-job", required=True)
    parser.add_argument("--expected-recovery-commit")
    parser.add_argument("--expected-recovery-source-job")
    parser.add_argument("--reference-config", type=Path)
    parser.add_argument("--reference-artifact-dir", type=Path)
    parser.add_argument("--reference-marker", type=Path)
    parser.add_argument("--reference-expected-source-job")
    parser.add_argument("--reference-expected-recovery-commit")
    parser.add_argument("--reference-expected-recovery-source-job")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=20_000)
    parser.add_argument("--bootstrap-seed", type=int, default=2_026_081_502)
    args = parser.parse_args()

    _config, spec = load_design(args.config, args.study)
    provenance = verify_provenance(
        args.artifact_dir,
        args.config,
        args.marker,
        spec,
        expected_commit=args.expected_commit,
        expected_source_job=args.expected_source_job,
        expected_recovery_commit=args.expected_recovery_commit,
        expected_recovery_source_job=args.expected_recovery_source_job,
    )
    reference_provenance = None
    reference_curves = None
    if args.study == "q5_refresh":
        required_reference = {
            "reference_config": args.reference_config,
            "reference_artifact_dir": args.reference_artifact_dir,
            "reference_marker": args.reference_marker,
            "reference_expected_source_job": args.reference_expected_source_job,
            "reference_expected_recovery_commit": (
                args.reference_expected_recovery_commit
            ),
            "reference_expected_recovery_source_job": (
                args.reference_expected_recovery_source_job
            ),
        }
        missing = [name for name, value in required_reference.items() if value is None]
        if missing:
            raise ValueError(f"Q5 refresh analysis requires {missing}")
        reference_spec = SPECS["q5"]
        load_design(args.reference_config, "q5")
        reference_provenance = verify_provenance(
            args.reference_artifact_dir,
            args.reference_config,
            args.reference_marker,
            reference_spec,
            expected_commit=args.expected_commit,
            expected_source_job=args.reference_expected_source_job,
            expected_recovery_commit=args.reference_expected_recovery_commit,
            expected_recovery_source_job=(
                args.reference_expected_recovery_source_job
            ),
        )
        reference_curves, reference_summaries = load_curves(
            args.reference_artifact_dir,
            reference_spec,
        )
        curves, outer_summaries = load_curves(
            args.artifact_dir,
            spec,
            baseline_summaries=reference_summaries,
        )
        summaries = pd.concat(
            [
                reference_summaries[
                    reference_summaries["cell"].isin([BASE_CELL, "EOS-Q5-M"])
                ],
                outer_summaries,
            ],
            ignore_index=True,
        )
    else:
        curves, summaries = load_curves(args.artifact_dir, spec)
    if args.study == "q5":
        contrasts, decision = analyze_q5(
            summaries, draws=args.bootstrap_draws, seed=args.bootstrap_seed
        )
    elif args.study == "pis":
        contrasts, decision = analyze_pis(
            summaries, draws=args.bootstrap_draws, seed=args.bootstrap_seed
        )
    else:
        contrasts, decision = analyze_q5_refresh(
            summaries, draws=args.bootstrap_draws, seed=args.bootstrap_seed
        )
    payload = {
        "schema_version": 1,
        "study": spec.name,
        "run_id": spec.run_id,
        "observational_unit": "paired training seed",
        "metric_reporting_order": ["final_extracted", "final_strict", "auc"],
        "cell_means": (
            _means(summaries, spec)
            if args.study != "q5_refresh"
            else [
                {
                    "cell": cell,
                    **{
                        metric: float(
                            summaries[summaries["cell"] == cell][metric].mean()
                        )
                        for metric in (
                            "extracted_final",
                            "strict_final",
                            "extracted_auc",
                            "strict_auc",
                            "late_peak_to_final_extracted_drop",
                            "format_failure_final",
                            "natural_eos_final",
                        )
                    },
                }
                for cell in (BASE_CELL, "EOS-Q5-M", "EOS-Q5-M-OUTER")
            ]
        ),
        "decision": decision,
        "provenance": provenance,
        "reference_provenance": reference_provenance,
        "cross_protocol_warning": (
            "Q5 and PIS retain different prompts, proposals, support semantics, "
            "round horizons and LoRA surfaces; do not interpret their numerical "
            "difference as a causal method contrast."
            if args.study in {"q5", "pis"}
            else None
        ),
    }
    args.output_dir.mkdir(parents=True, exist_ok=False)
    curves.to_csv(args.output_dir / "learning_curves.csv", index=False)
    if reference_curves is not None:
        reference_curves.to_csv(
            args.output_dir / "reference_learning_curves.csv",
            index=False,
        )
    summaries.to_csv(args.output_dir / "seed_metrics.csv", index=False)
    contrasts.to_csv(args.output_dir / "paired_contrasts.csv", index=False)
    (args.output_dir / "decision.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(payload, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
