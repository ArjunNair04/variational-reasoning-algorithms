#!/usr/bin/env python3
"""Analyse the preregistered Q5 question-only M-step learning-rate screen."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import numpy as np
import pandas as pd


RUN_ID = "7b5c0a3f"
SEEDS = (31, 47, 73)
TRAINED_CELLS = ("Q5Q-LR3", "Q5Q-LR10", "Q5Q-LR30")
LEARNING_RATES = {
    "Q5Q-LR3": 3.0e-6,
    "Q5Q-LR10": 1.0e-5,
    "Q5Q-LR30": 3.0e-5,
}
EXPECTED_ROUNDS = (1, 2, 3, 5, 10, 15, 20, 30)


def _single(root: Path, pattern: str) -> Path:
    matches = sorted(root.glob(pattern))
    if len(matches) != 1:
        raise ValueError(f"expected one {pattern!r} in {root}, found {len(matches)}")
    return matches[0]


def _read_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _read_jsonl_gz(path: Path) -> list[dict]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle]


def _rate(records: list[dict], field: str) -> float:
    values = [record.get(field) for record in records]
    if not values or any(not isinstance(value, bool) for value in values):
        raise ValueError(f"records omit boolean field {field}")
    return float(np.mean(values))


def _verify_records(records: list[dict], path: Path) -> None:
    if len(records) != 400:
        raise ValueError(f"{path}: expected 400 validation records")
    for index, record in enumerate(records):
        if record.get("official_test_accessed") is not False:
            raise ValueError(f"{path}: record {index} lacks non-access proof")
        if record.get("eval_source_split") != "train":
            raise ValueError(f"{path}: record {index} is not train-derived")
        if record.get("dataset_splits_loaded") != ["train"]:
            raise ValueError(f"{path}: record {index} loaded another split")


def normalized_auc(rounds: np.ndarray, values: np.ndarray) -> float:
    if rounds.ndim != 1 or values.shape != rounds.shape or len(rounds) < 2:
        raise ValueError("AUC requires matched one-dimensional arrays")
    if rounds[0] != 0 or np.any(np.diff(rounds) <= 0):
        raise ValueError("AUC rounds must start at zero and increase")
    return float(np.trapezoid(values, rounds) / rounds[-1])


def paired_interval(values: np.ndarray, *, draws: int = 20000) -> tuple[float, float]:
    if values.shape != (3,):
        raise ValueError("paired interval requires exactly three seeds")
    rng = np.random.default_rng(20260803)
    sampled = values[rng.integers(0, 3, size=(draws, 3))].mean(axis=1)
    return tuple(float(value) for value in np.quantile(sampled, [0.025, 0.975]))


def load_results(root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    base_rows = []
    curve_rows = []
    for seed in SEEDS:
        base_path = _single(root, f"eval_*CTRL-base_seed{seed}*.json")
        base_payload = _read_json(base_path)
        if str(base_payload.get("run_id")) != RUN_ID:
            raise ValueError(f"{base_path}: run ID mismatch")
        base_records = base_payload.get("records") or []
        _verify_records(base_records, base_path)
        base_rows.append(
            {
                "seed": seed,
                "strict_accuracy": _rate(base_records, "strict_correct"),
                "extracted_accuracy": _rate(base_records, "legacy_correct"),
                "natural_eos_rate": _rate(base_records, "generated_eos"),
            }
        )
        for cell in TRAINED_CELLS:
            path = _single(root, f"checkpoint_eval_*{cell}_seed{seed}*.jsonl.gz")
            payloads = _read_jsonl_gz(path)
            observed_rounds = tuple(int(row["completed_rounds"]) for row in payloads)
            if observed_rounds != EXPECTED_ROUNDS:
                raise ValueError(f"{path}: checkpoint schedule mismatch")
            for payload in payloads:
                if str(payload.get("run_id")) != RUN_ID:
                    raise ValueError(f"{path}: run ID mismatch")
                records = payload.get("records") or []
                _verify_records(records, path)
                curve_rows.append(
                    {
                        "cell": cell,
                        "learning_rate": LEARNING_RATES[cell],
                        "seed": seed,
                        "round": int(payload["completed_rounds"]),
                        "strict_accuracy": _rate(records, "strict_correct"),
                        "extracted_accuracy": _rate(records, "legacy_correct"),
                        "natural_eos_rate": _rate(records, "generated_eos"),
                    }
                )
    return pd.DataFrame(base_rows), pd.DataFrame(curve_rows)


def summarize(base: pd.DataFrame, curves: pd.DataFrame) -> pd.DataFrame:
    base_by_seed = base.set_index("seed")
    rows = []
    for (cell, seed), group in curves.groupby(["cell", "seed"]):
        ordered = group.sort_values("round")
        initial = base_by_seed.loc[int(seed)]
        rounds = np.concatenate(([0.0], ordered["round"].to_numpy(float)))
        strict = np.concatenate((
            [float(initial["strict_accuracy"])],
            ordered["strict_accuracy"].to_numpy(float),
        ))
        extracted = np.concatenate((
            [float(initial["extracted_accuracy"])],
            ordered["extracted_accuracy"].to_numpy(float),
        ))
        final = ordered.iloc[-1]
        rows.append(
            {
                "cell": cell,
                "learning_rate": LEARNING_RATES[cell],
                "seed": int(seed),
                "strict_auc": normalized_auc(rounds, strict),
                "extracted_auc": normalized_auc(rounds, extracted),
                "final_strict_accuracy": float(final["strict_accuracy"]),
                "final_extracted_accuracy": float(final["extracted_accuracy"]),
                "final_natural_eos_rate": float(final["natural_eos_rate"]),
                "best_strict_accuracy": float(strict.max()),
                "best_to_final_drop": float(strict.max() - strict[-1]),
                "base_strict_accuracy": float(initial["strict_accuracy"]),
                "base_natural_eos_rate": float(initial["natural_eos_rate"]),
            }
        )
    return pd.DataFrame(rows)


def decide(summary: pd.DataFrame) -> dict:
    candidates = []
    cells = []
    for cell in TRAINED_CELLS:
        rows = summary[summary.cell == cell].set_index("seed").reindex(SEEDS)
        if rows.isna().any().any():
            raise ValueError(f"{cell}: incomplete seed table")
        auc_delta = (
            rows["strict_auc"] - rows["base_strict_accuracy"]
        ).to_numpy(float)
        final_delta = (
            rows["final_strict_accuracy"] - rows["base_strict_accuracy"]
        ).to_numpy(float)
        eos_delta = (
            rows["final_natural_eos_rate"] - rows["base_natural_eos_rate"]
        ).to_numpy(float)
        low, high = paired_interval(auc_delta)
        gates = {
            "strict_auc_positive_in_at_least_two_seeds": int((auc_delta > 0).sum()) >= 2,
            "final_strict_positive_in_at_least_two_seeds": int((final_delta > 0).sum()) >= 2,
            "mean_final_strict_above_base": float(final_delta.mean()) > 0,
            "mean_natural_eos_drop_at_most_2pp": float(eos_delta.mean()) >= -0.02,
            "mean_best_to_final_drop_at_most_5pp": float(rows["best_to_final_drop"].mean()) <= 0.05,
        }
        record = {
            "cell": cell,
            "learning_rate": LEARNING_RATES[cell],
            "mean_strict_auc": float(rows["strict_auc"].mean()),
            "mean_strict_auc_delta_from_base": float(auc_delta.mean()),
            "strict_auc_delta_interval": [low, high],
            "mean_final_strict_delta_from_base": float(final_delta.mean()),
            "mean_natural_eos_delta_from_base": float(eos_delta.mean()),
            "mean_best_to_final_drop": float(rows["best_to_final_drop"].mean()),
            "gates": gates,
            "viable": all(gates.values()),
        }
        cells.append(record)
        if record["viable"]:
            candidates.append(record)

    selected = None
    if candidates:
        selected = max(
            candidates,
            key=lambda row: (
                row["mean_strict_auc"],
                row["mean_final_strict_delta_from_base"],
                -row["learning_rate"],
            ),
        )
    kl_released = bool(
        selected is not None and selected["mean_best_to_final_drop"] > 0.02
    )
    return {
        "run_id": RUN_ID,
        "observational_unit": "training seed",
        "method_selection_allowed": False,
        "selected_development_candidate": (
            selected["cell"] if selected is not None else None
        ),
        "kl_screen_released": kl_released,
        "stop_mstep_branch": selected is None,
        "cells": cells,
        "rules": {
            "maximum_selected_candidates": 1,
            "kl_only_if_selected_candidate_has_mean_best_to_final_drop_above_2pp": True,
            "official_test_used": False,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    base, curves = load_results(args.result_dir)
    summary = summarize(base, curves)
    decision = decide(summary)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    base.to_csv(args.out_dir / "q5_lr_base.csv", index=False)
    curves.to_csv(args.out_dir / "q5_lr_curves.csv", index=False)
    summary.to_csv(args.out_dir / "q5_lr_seed_summary.csv", index=False)
    (args.out_dir / "q5_lr_decision.json").write_text(
        json.dumps(decision, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
