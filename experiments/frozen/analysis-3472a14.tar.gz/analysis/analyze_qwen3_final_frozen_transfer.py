#!/usr/bin/env python3
"""Pre-registered analysis for the frozen Qwen3 transfer study."""

from __future__ import annotations

import argparse
import csv
import gzip
import json
from pathlib import Path
import sys
from typing import Any, Iterable, Mapping

import numpy as np


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
LM_STUDY = REPOSITORY_ROOT / "lm_study"
if str(LM_STUDY) not in sys.path:
    sys.path.insert(0, str(LM_STUDY))

from evaluate_qwen3_final_transfer import load_manifest  # noqa: E402
from validate_qwen3_final_frozen_transfer import (  # noqa: E402
    artifact_stem,
    validate_task_output,
)


ROLE_ORDER = ("frozen_base", "posterior", "non_rl_self_training", "rl")
PRIMARY_METRICS = (
    "final_extracted_answer_accuracy",
    "final_strict_terminal_accuracy",
)
RECORD_FIELDS = {
    "final_extracted_answer_accuracy": "extracted_correct",
    "final_strict_terminal_accuracy": "strict_correct",
}


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: expected a JSON object")
    return payload


def _read_json_gz(path: Path) -> dict[str, Any]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: expected a compressed JSON object")
    return payload


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            writer.writerows(rows)


def paired_nested_interval(
    differences: np.ndarray,
    *,
    draws: int,
    seed: int,
) -> tuple[float, float, float]:
    """Bootstrap paired seeds and paired questions without breaking alignment."""

    values = np.asarray(differences, dtype=float)
    if values.ndim != 2 or min(values.shape) < 1:
        raise ValueError("paired differences must be a non-empty seed-by-question matrix")
    if draws < 100:
        raise ValueError("bootstrap draws must be at least 100")
    rng = np.random.default_rng(seed)
    estimates = np.empty(draws, dtype=float)
    n_seeds, n_questions = values.shape
    for draw in range(draws):
        seed_indices = rng.integers(0, n_seeds, size=n_seeds)
        question_indices = rng.integers(0, n_questions, size=n_questions)
        estimates[draw] = values[np.ix_(seed_indices, question_indices)].mean()
    return (
        float(values.mean()),
        float(np.quantile(estimates, 0.025)),
        float(np.quantile(estimates, 0.975)),
    )


def _task_payloads(
    manifest: Mapping[str, Any],
    *,
    output_root: Path,
    manifest_sha256: str,
    execution_commit: str,
) -> dict[tuple[str, str, int], dict[str, Any]]:
    payloads: dict[tuple[str, str, int], dict[str, Any]] = {}
    problems = []
    for task in manifest["tasks"]:
        problems.extend(
            validate_task_output(
                task,
                output_root=output_root,
                manifest_sha256=manifest_sha256,
                execution_commit=execution_commit,
            )
        )
        key = (str(task["dataset"]), str(task["role"]), int(task["seed"]))
        artifact = output_root / f"{artifact_stem(task)}.json.gz"
        if artifact.is_file():
            payloads[key] = _read_json_gz(artifact)
    if problems:
        raise ValueError("; ".join(problems))
    if len(payloads) != 56:
        raise ValueError(f"expected 56 unique task payloads, got {len(payloads)}")
    return payloads


def _records_by_id(payload: Mapping[str, Any], field: str) -> dict[str, float]:
    records = payload["records"]
    return {str(row["dataset_id"]): float(bool(row[field])) for row in records}


def _aligned_difference(
    payloads: Mapping[tuple[str, str, int], Mapping[str, Any]],
    *,
    dataset: str,
    challenger: str,
    reference: str,
    seeds: Iterable[int],
    field: str,
) -> np.ndarray:
    rows = []
    reference_ids: list[str] | None = None
    for seed in seeds:
        challenger_values = _records_by_id(
            payloads[(dataset, challenger, int(seed))], field
        )
        reference_values = _records_by_id(
            payloads[(dataset, reference, int(seed))], field
        )
        if set(challenger_values) != set(reference_values):
            raise ValueError(
                f"paired dataset IDs changed for {dataset}, seed {seed}, "
                f"{challenger} versus {reference}"
            )
        ids = sorted(reference_values)
        if reference_ids is None:
            reference_ids = ids
        elif ids != reference_ids:
            raise ValueError(f"dataset ID support changed across {dataset} seeds")
        rows.append(
            [challenger_values[item] - reference_values[item] for item in ids]
        )
    return np.asarray(rows, dtype=float)


def analyze(
    manifest_path: Path,
    *,
    expected_manifest_sha256: str,
    marker_path: Path,
    output_root: Path,
    analysis_dir: Path,
    bootstrap_draws: int,
    bootstrap_seed: int,
) -> dict[str, Any]:
    manifest = load_manifest(manifest_path, expected_manifest_sha256)
    marker = _read_json(marker_path)
    if marker.get("status") != "ok" or marker.get("stage") != "frozen_external_transfer":
        raise ValueError("transfer validator marker is not status-ok")
    if marker.get("manifest_sha256") != expected_manifest_sha256:
        raise ValueError("validator marker manifest identity changed")
    if marker.get("official_gsm8k_test_used") is not False:
        raise ValueError("validator marker reports official-test access")
    execution_commit = str(marker.get("execution_commit") or "")
    payloads = _task_payloads(
        manifest,
        output_root=output_root,
        manifest_sha256=expected_manifest_sha256,
        execution_commit=execution_commit,
    )
    seeds = sorted({int(task["seed"]) for task in manifest["tasks"]})
    datasets = ("svamp", "math_500")

    summary_rows: list[dict[str, Any]] = []
    for dataset in datasets:
        for role in ROLE_ORDER:
            selected = [payloads[(dataset, role, seed)] for seed in seeds]
            task = selected[0]["task"]
            row: dict[str, Any] = {
                "dataset": dataset,
                "role": role,
                "algorithm": task["algorithm"],
                "cell_id": task["cell_id"],
                "seeds": len(seeds),
                "questions_per_seed": len(selected[0]["records"]),
            }
            for metric in PRIMARY_METRICS:
                values = [float(payload["metrics"][metric]) for payload in selected]
                row[metric] = float(np.mean(values))
                row[f"{metric}_seed_sd"] = float(np.std(values, ddof=1))
            for metric in ("natural_eos_rate", "token_limit_rate"):
                row[metric] = float(
                    np.mean([float(payload["metrics"][metric]) for payload in selected])
                )
            row["accelerator_hours"] = float(
                sum(float(payload["runtime"]["accelerator_hours"]) for payload in selected)
            )
            row["generated_tokens"] = int(
                sum(int(payload["runtime"]["generated_tokens"]) for payload in selected)
            )
            summary_rows.append(row)

    contrast_pairs = (
        ("posterior", "frozen_base"),
        ("non_rl_self_training", "frozen_base"),
        ("rl", "frozen_base"),
        ("posterior", "non_rl_self_training"),
        ("posterior", "rl"),
    )
    contrast_rows: list[dict[str, Any]] = []
    contrast_index = 0
    for dataset in datasets:
        for challenger, reference in contrast_pairs:
            for metric in PRIMARY_METRICS:
                differences = _aligned_difference(
                    payloads,
                    dataset=dataset,
                    challenger=challenger,
                    reference=reference,
                    seeds=seeds,
                    field=RECORD_FIELDS[metric],
                )
                point, low, high = paired_nested_interval(
                    differences,
                    draws=bootstrap_draws,
                    seed=bootstrap_seed + contrast_index,
                )
                contrast_index += 1
                contrast_rows.append(
                    {
                        "dataset": dataset,
                        "challenger": challenger,
                        "reference": reference,
                        "metric": metric,
                        "difference": point,
                        "difference_pp": 100.0 * point,
                        "ci_low": low,
                        "ci_high": high,
                        "ci_low_pp": 100.0 * low,
                        "ci_high_pp": 100.0 * high,
                        "paired_seeds": len(seeds),
                        "paired_questions": differences.shape[1],
                    }
                )

    analysis_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(analysis_dir / "method_summary.csv", summary_rows)
    _write_csv(analysis_dir / "paired_contrasts.csv", contrast_rows)
    result = {
        "schema_version": 1,
        "analysis_status": "frozen_transfer_complete_no_retuning",
        "source_registry_id": manifest["source_registry_id"],
        "source_run_id": manifest["source_run_id"],
        "source_decision_sha256": manifest["source_decision_sha256"],
        "manifest_sha256": expected_manifest_sha256,
        "validator_source_job_id": marker["source_job_id"],
        "validator_source_job_ids": marker.get(
            "source_job_ids", [marker["source_job_id"]]
        ),
        "execution_commit": execution_commit,
        "official_gsm8k_test_used": False,
        "metric_order": list(PRIMARY_METRICS),
        "trajectory_auc": "not_applicable_no_training",
        "datasets": list(datasets),
        "roles": list(ROLE_ORDER),
        "seed_values": seeds,
        "bootstrap": {
            "method": "paired_seed_and_question_nonparametric",
            "draws": bootstrap_draws,
            "seed": bootstrap_seed,
            "interval": 0.95,
        },
        "interpretation_rule": (
            "Transfer results test frozen generality only. They do not select, "
            "retune, stop, or otherwise modify any method."
        ),
        "method_summary": summary_rows,
        "paired_contrasts": contrast_rows,
    }
    (analysis_dir / "analysis.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--marker", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--analysis-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=10_000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260820)
    args = parser.parse_args()
    result = analyze(
        args.manifest.expanduser(),
        expected_manifest_sha256=args.expected_manifest_sha256,
        marker_path=args.marker.expanduser(),
        output_root=args.output.expanduser(),
        analysis_dir=args.analysis_dir.expanduser(),
        bootstrap_draws=args.bootstrap_draws,
        bootstrap_seed=args.bootstrap_seed,
    )
    print(
        f"analysed {len(result['roles'])} roles across "
        f"{len(result['datasets'])} frozen transfer datasets"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
