"""Analyze the complete three-term AC-ALG1 objective factorial.

The seven trained subsets combine the supervised-weight-one objective study,
the supervised-weight-zero latent-only study, and the matched token-mean full
objective arm. The frozen four-shot model supplies the empty subset. All
outcomes use the fixed training-derived GSM8K validation partition.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from analysis.analyze_ac_alg1_collapse_stability import (
        aggregate_trajectories,
        summarize_curves,
    )
    from analysis.analyze_ac_alg1_latent_only import (
        _window_summary,
        load_latent_only_factorial,
    )
    from analysis.analyze_ac_alg1_numerical_study import (
        _artifact_dir,
        _paired_bootstrap_interval,
        _read_jsonl_gz,
        load_cells,
        load_checkpoint_trajectories,
    )
except ModuleNotFoundError:  # Direct execution from analysis/.
    from analyze_ac_alg1_collapse_stability import (
        aggregate_trajectories,
        summarize_curves,
    )
    from analyze_ac_alg1_latent_only import _window_summary, load_latent_only_factorial
    from analyze_ac_alg1_numerical_study import (
        _artifact_dir,
        _paired_bootstrap_interval,
        _read_jsonl_gz,
        load_cells,
        load_checkpoint_trajectories,
    )


# Bits are (B_sup, B'_unsup, B_unsup).
ARMS = ("A000", "A100", "A010", "A001", "A110", "A101", "A011", "A111")
TRAINED_ARMS = tuple(arm for arm in ARMS if arm != "A000")
ARM_LABELS = {
    "A000": "frozen",
    "A100": "B_sup",
    "A010": "Bprime_unsup",
    "A001": "B_unsup",
    "A110": "B_sup+Bprime_unsup",
    "A101": "B_sup+B_unsup",
    "A011": "Bprime_unsup+B_unsup",
    "A111": "B_sup+Bprime_unsup+B_unsup",
}


def _effect_series(pivot: pd.DataFrame) -> dict[str, pd.Series]:
    """Return conditional, marginal, and interaction effects."""

    effects = {
        "Bsup_at_L0_U0": pivot["A100"] - pivot["A000"],
        "Bsup_at_L1_U0": pivot["A110"] - pivot["A010"],
        "Bsup_at_L0_U1": pivot["A101"] - pivot["A001"],
        "Bsup_at_L1_U1": pivot["A111"] - pivot["A011"],
        "Bprime_at_S0_U0": pivot["A010"] - pivot["A000"],
        "Bprime_at_S1_U0": pivot["A110"] - pivot["A100"],
        "Bprime_at_S0_U1": pivot["A011"] - pivot["A001"],
        "Bprime_at_S1_U1": pivot["A111"] - pivot["A101"],
        "Bunsup_at_S0_L0": pivot["A001"] - pivot["A000"],
        "Bunsup_at_S1_L0": pivot["A101"] - pivot["A100"],
        "Bunsup_at_S0_L1": pivot["A011"] - pivot["A010"],
        "Bunsup_at_S1_L1": pivot["A111"] - pivot["A110"],
    }
    effects["Bsup_marginal"] = sum(
        effects[name] for name in effects if name.startswith("Bsup_at_")
    ) / 4.0
    effects["Bprime_marginal"] = sum(
        effects[name] for name in effects if name.startswith("Bprime_at_")
    ) / 4.0
    effects["Bunsup_marginal"] = sum(
        effects[name] for name in effects if name.startswith("Bunsup_at_")
    ) / 4.0
    effects.update({
        "Bsup_x_Bprime_at_U0": (
            pivot["A110"] - pivot["A100"] - pivot["A010"] + pivot["A000"]
        ),
        "Bsup_x_Bprime_at_U1": (
            pivot["A111"] - pivot["A101"] - pivot["A011"] + pivot["A001"]
        ),
        "Bsup_x_Bunsup_at_L0": (
            pivot["A101"] - pivot["A100"] - pivot["A001"] + pivot["A000"]
        ),
        "Bsup_x_Bunsup_at_L1": (
            pivot["A111"] - pivot["A110"] - pivot["A011"] + pivot["A010"]
        ),
        "Bprime_x_Bunsup_at_S0": (
            pivot["A011"] - pivot["A010"] - pivot["A001"] + pivot["A000"]
        ),
        "Bprime_x_Bunsup_at_S1": (
            pivot["A111"] - pivot["A110"] - pivot["A101"] + pivot["A100"]
        ),
        "three_way_interaction": (
            pivot["A111"] - pivot["A110"] - pivot["A101"] - pivot["A011"]
            + pivot["A100"] + pivot["A010"] + pivot["A001"] - pivot["A000"]
        ),
    })
    return effects


CONTRASTS = tuple(_effect_series(pd.DataFrame({arm: [0.0] for arm in ARMS})))


def seed_factorial_effects(curves: pd.DataFrame) -> pd.DataFrame:
    """Compute three-term AUC effects separately for each seed."""

    pivot = curves.pivot(index="seed", columns="arm", values="normalized_accuracy_auc")
    missing = set(ARMS) - set(pivot.columns)
    if missing:
        raise ValueError(f"missing three-term-factorial arms: {sorted(missing)}")
    pivot = pivot[list(ARMS)].dropna()
    effects = _effect_series(pivot)
    return pd.DataFrame({
        "seed": pivot.index.astype(int),
        **{arm: pivot[arm].to_numpy(float) for arm in ARMS},
        **{name: values.to_numpy(float) for name, values in effects.items()},
    })


def load_three_term_factorial(
    latent_result_dir: Path,
    latent_prefix: str,
    latent_config: Path,
    supervised_result_dir: Path,
    supervised_prefix: str,
    supervised_config: Path,
    full_result_dir: Path,
    full_prefix: str,
    full_config: Path,
    full_arm: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[tuple[str, int, int], dict]]:
    """Load and relabel all seven trained objective subsets."""

    latent, latent_trajectories, latent_evaluations = load_latent_only_factorial(
        latent_result_dir, latent_prefix, latent_config
    )
    latent_map = {"T10": "A010", "T01": "A001", "T11": "A011"}
    latent["arm"] = latent["arm"].map(latent_map)
    latent_trajectories["arm"] = latent_trajectories["arm"].map(latent_map)
    latent["result_dir"] = str(latent_result_dir)

    supervised, _ = load_cells(
        supervised_result_dir, supervised_prefix, supervised_config, final_rounds=10
    )
    supervised_trajectories, supervised_evaluations = load_checkpoint_trajectories(
        supervised_result_dir, supervised
    )
    supervised_map = {"C0": "A100", "C1": "A110", "C2": "A101"}
    supervised["arm"] = supervised["arm"].map(supervised_map)
    supervised_trajectories["arm"] = supervised_trajectories["arm"].map(
        supervised_map
    )
    supervised["result_dir"] = str(supervised_result_dir)

    full, _ = load_cells(full_result_dir, full_prefix, full_config, final_rounds=10)
    full_trajectories, full_evaluations = load_checkpoint_trajectories(
        full_result_dir, full
    )
    full = full[full["arm"] == full_arm].copy()
    full_trajectories = full_trajectories[
        full_trajectories["arm"] == full_arm
    ].copy()
    full["arm"] = "A111"
    full_trajectories["arm"] = "A111"
    full["result_dir"] = str(full_result_dir)

    table = pd.concat(
        [frame.dropna(axis=1, how="all") for frame in (latent, supervised, full)],
        ignore_index=True,
    )
    trajectories = pd.concat(
        [latent_trajectories, supervised_trajectories, full_trajectories],
        ignore_index=True,
    )
    if set(table["arm"]) != set(TRAINED_ARMS):
        raise ValueError(
            f"expected trained arms {sorted(TRAINED_ARMS)}, "
            f"found {sorted(table['arm'].dropna().unique())}"
        )
    return table, trajectories, {
        **latent_evaluations,
        **supervised_evaluations,
        **full_evaluations,
    }


def mechanism_windows(table: pd.DataFrame) -> pd.DataFrame:
    """Summarize early and late diagnostics across the three source studies."""

    rows = []
    for _, cell in table.iterrows():
        seed = int(cell["seed"])
        diagnostic_dir = _artifact_dir(Path(cell["result_dir"]), "training_diagnostics")
        path = diagnostic_dir / (
            f"training_diagnostics_gsm8k__{cell['tag']}__AC-ALG1_s{seed}.jsonl.gz"
        )
        records = sorted(_read_jsonl_gz(path), key=lambda item: item["completed_rounds"])
        for window_name, selected in (("early", records[:5]), ("late", records[-5:])):
            rows.append({
                "arm": cell["arm"],
                "label": ARM_LABELS[cell["arm"]],
                "seed": seed,
                **_window_summary(records, window_name, selected),
            })
    return pd.DataFrame(rows).sort_values(["arm", "seed", "window"])


def add_frozen_curves(
    trained: pd.DataFrame, seeds: list[int], reference_accuracy: float
) -> pd.DataFrame:
    """Insert the constant frozen model as the empty objective subset."""

    frozen = pd.DataFrame([
        {
            "arm": "A000",
            "seed": seed,
            "n_checkpoints": 15,
            "final_round": 30,
            "normalized_accuracy_auc": reference_accuracy,
            "normalized_accuracy_deficit_auc": 0.0,
            "peak_accuracy": reference_accuracy,
            "peak_round": 0,
            "final_accuracy": reference_accuracy,
            "final_difference_from_base": 0.0,
            "slope_round10_to_final_pp_per_round": 0.0,
            "first_2pp_drop_round": np.nan,
            "avoided_2pp_drop_through_final": True,
            "first_5pp_drop_round": np.nan,
            "avoided_5pp_drop_through_final": True,
        }
        for seed in seeds
    ])
    return pd.concat([frozen, trained], ignore_index=True).sort_values(["seed", "arm"])


def add_frozen_trajectories(
    trained: pd.DataFrame, seeds: list[int], reference_accuracy: float
) -> pd.DataFrame:
    rounds = sorted(int(value) for value in trained["completed_rounds"].unique())
    frozen = pd.DataFrame([
        {
            "arm": "A000",
            "seed": seed,
            "completed_rounds": completed_rounds,
            "test_acc": reference_accuracy,
        }
        for seed in seeds
        for completed_rounds in rounds
    ])
    return pd.concat([frozen, trained], ignore_index=True)


def question_auc_effects(
    table: pd.DataFrame,
    evaluations: dict[tuple[str, int, int], dict],
    reference: dict[int, bool],
) -> pd.DataFrame:
    """Compute all factorial effects on paired per-question trajectory AUC."""

    rows: list[dict] = []
    for seed in sorted(int(value) for value in table["seed"].unique()):
        seed_table = table[table["seed"] == seed]
        tags = {str(row["arm"]): str(row["tag"]) for _, row in seed_table.iterrows()}
        if set(TRAINED_ARMS) - set(tags):
            continue
        records_by_arm = {
            arm: {
                completed_rounds: record
                for (tag, checkpoint_seed, completed_rounds), record in evaluations.items()
                if tag == tags[arm] and checkpoint_seed == seed
            }
            for arm in TRAINED_ARMS
        }
        shared_rounds = sorted(
            set.intersection(*(set(records_by_arm[arm]) for arm in TRAINED_ARMS))
        )
        correct = {
            arm: {
                completed_rounds: {
                    int(item["idx"]): float(bool(item["correct"]))
                    for item in records_by_arm[arm][completed_rounds].get("records", [])
                }
                for completed_rounds in shared_rounds
            }
            for arm in TRAINED_ARMS
        }
        shared_questions = set(reference)
        for arm in TRAINED_ARMS:
            for completed_rounds in shared_rounds:
                shared_questions &= set(correct[arm][completed_rounds])
        x = np.array([0, *shared_rounds], dtype=float)
        for idx in sorted(shared_questions):
            base = float(reference[idx])
            arm_auc = {"A000": base}
            for arm in TRAINED_ARMS:
                y = np.array([
                    base,
                    *(correct[arm][completed_rounds][idx]
                      for completed_rounds in shared_rounds),
                ])
                arm_auc[arm] = float(np.trapezoid(y, x) / shared_rounds[-1])
            pivot = pd.DataFrame({arm: [arm_auc[arm]] for arm in ARMS})
            effects = _effect_series(pivot)
            rows.append({
                "seed": seed,
                "idx": idx,
                "n_shared_checkpoints": len(shared_rounds),
                "final_round": int(shared_rounds[-1]),
                **{arm: arm_auc[arm] for arm in ARMS},
                **{name: float(values.iloc[0]) for name, values in effects.items()},
            })
    return pd.DataFrame(rows).sort_values(["seed", "idx"])


def aggregate_factorial_effects(
    seeds: pd.DataFrame,
    questions: pd.DataFrame,
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Summarize seed signs and paired question-cluster intervals."""

    rows = []
    for offset, contrast in enumerate(CONTRASTS):
        seed_values = seeds[contrast].to_numpy(float)
        clustered = questions.groupby("idx")[contrast].mean().to_numpy(float)
        low, high = _paired_bootstrap_interval(
            clustered, draws=draws, seed=bootstrap_seed + offset
        )
        rows.append({
            "contrast": contrast,
            "mean_seed_auc_effect": float(seed_values.mean()),
            "positive_seeds": int(np.sum(seed_values > 0)),
            "negative_seeds": int(np.sum(seed_values < 0)),
            "n_seeds": len(seed_values),
            "n_question_clusters": len(clustered),
            "question_cluster_ci95_low": low,
            "question_cluster_ci95_high": high,
        })
    return pd.DataFrame(rows)


def aggregate_checkpoint_reference_effects(
    table: pd.DataFrame,
    evaluations: dict[tuple[str, int, int], dict],
    reference: dict[int, bool],
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Compare every trained arm/checkpoint with frozen paired predictions."""

    rows = []
    for arm_index, arm in enumerate(TRAINED_ARMS):
        arm_table = table[table["arm"] == arm]
        tags = {int(row["seed"]): str(row["tag"]) for _, row in arm_table.iterrows()}
        shared_rounds = sorted(set.intersection(*(
            {
                completed_rounds
                for (tag, checkpoint_seed, completed_rounds) in evaluations
                if tag == seed_tag and checkpoint_seed == seed
            }
            for seed, seed_tag in tags.items()
        )))
        for completed_rounds in shared_rounds:
            by_seed = {}
            lengths = []
            for seed, tag in tags.items():
                record = evaluations[(tag, seed, completed_rounds)]
                lengths.extend(
                    float(item["len"])
                    for item in record.get("records", [])
                    if item.get("len") is not None
                )
                by_seed[seed] = {
                    int(item["idx"]): float(bool(item["correct"]))
                    - float(reference[int(item["idx"])])
                    for item in record.get("records", [])
                    if int(item["idx"]) in reference
                }
            shared_questions = set(reference)
            for values in by_seed.values():
                shared_questions &= set(values)
            clustered = np.array([
                np.mean([by_seed[seed][idx] for seed in sorted(by_seed)])
                for idx in sorted(shared_questions)
            ])
            seed_effects = np.array([
                np.mean([by_seed[seed][idx] for idx in sorted(shared_questions)])
                for seed in sorted(by_seed)
            ])
            low, high = _paired_bootstrap_interval(
                clustered,
                draws=draws,
                seed=bootstrap_seed + completed_rounds + 100 * arm_index,
            )
            rows.append({
                "arm": arm,
                "label": ARM_LABELS[arm],
                "completed_rounds": completed_rounds,
                "n_seeds": len(by_seed),
                "n_question_clusters": len(clustered),
                "mean_accuracy": float(np.mean(list(reference.values())))
                + float(clustered.mean()),
                "mean_difference_from_base": float(clustered.mean()),
                "min_seed_difference": float(seed_effects.min()),
                "max_seed_difference": float(seed_effects.max()),
                "positive_seeds": int(np.sum(seed_effects > 0)),
                "negative_seeds": int(np.sum(seed_effects < 0)),
                "ci95_low": low,
                "ci95_high": high,
                "mean_completion_tokens": float(np.mean(lengths)) if lengths else np.nan,
                "completion_cap_fraction": (
                    float(np.mean(np.asarray(lengths) >= 256.0)) if lengths else np.nan
                ),
            })
    return pd.DataFrame(rows).sort_values(["arm", "completed_rounds"])


def selection_decision(curves: pd.DataFrame) -> dict:
    pivot = curves.pivot(index="seed", columns="arm", values="normalized_accuracy_auc")
    pivot = pivot[list(ARMS)].dropna()
    means = pivot.mean()
    eligible = [arm for arm in ARMS if bool((pivot[arm] >= pivot["A000"]).all())]
    selected = max(eligible, key=lambda arm: (float(means[arm]), -ARMS.index(arm)))
    return {
        "selected_arm": selected,
        "selected_label": ARM_LABELS[selected],
        "eligible_arms": eligible,
        "mean_auc_by_arm": {arm: float(means[arm]) for arm in ARMS},
        "n_complete_seeds": len(pivot),
        "selection_rule": (
            "highest mean normalized validation-accuracy AUC among arms whose "
            "AUC is not below frozen A000 in any seed"
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--latent-result-dir", type=Path, required=True)
    parser.add_argument("--latent-prefix", required=True)
    parser.add_argument("--latent-config", type=Path, required=True)
    parser.add_argument("--supervised-result-dir", type=Path, required=True)
    parser.add_argument("--supervised-prefix", required=True)
    parser.add_argument("--supervised-config", type=Path, required=True)
    parser.add_argument("--full-result-dir", type=Path, required=True)
    parser.add_argument("--full-prefix", required=True)
    parser.add_argument("--full-config", type=Path, required=True)
    parser.add_argument("--full-arm", default="C1")
    parser.add_argument("--reference-records", type=Path, required=True)
    parser.add_argument("--reference-condition", default="four_shot")
    parser.add_argument("--reference-accuracy", type=float, default=0.7925)
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260722)
    parser.add_argument("--write-dir", type=Path, required=True)
    args = parser.parse_args()

    table, trajectories, evaluations = load_three_term_factorial(
        args.latent_result_dir.expanduser(),
        args.latent_prefix,
        args.latent_config,
        args.supervised_result_dir.expanduser(),
        args.supervised_prefix,
        args.supervised_config,
        args.full_result_dir.expanduser(),
        args.full_prefix,
        args.full_config,
        args.full_arm,
    )
    seeds = sorted(int(value) for value in table["seed"].unique())
    trained_curves = summarize_curves(trajectories, args.reference_accuracy)
    curves = add_frozen_curves(trained_curves, seeds, args.reference_accuracy)
    all_trajectories = add_frozen_trajectories(
        trajectories, seeds, args.reference_accuracy
    )
    aggregate_trajectories_frame = aggregate_trajectories(
        all_trajectories, args.reference_accuracy
    )
    seed_effects = seed_factorial_effects(curves)

    reference_records = {
        int(record["idx"]): record
        for record in _read_jsonl_gz(args.reference_records.expanduser())
        if record.get("condition") == args.reference_condition
    }
    reference = {idx: bool(record["correct"]) for idx, record in reference_records.items()}
    question_effects = question_auc_effects(table, evaluations, reference)
    aggregate_effects = aggregate_factorial_effects(
        seed_effects, question_effects, args.bootstrap_draws, args.bootstrap_seed
    )
    checkpoint_effects = aggregate_checkpoint_reference_effects(
        table,
        evaluations,
        reference,
        args.bootstrap_draws,
        args.bootstrap_seed,
    )
    best_checkpoints = checkpoint_effects.loc[
        checkpoint_effects.groupby("arm")["mean_difference_from_base"].idxmax()
    ].sort_values("arm")
    windows = mechanism_windows(table)
    aggregate_windows = (
        windows.groupby(["arm", "label", "window"], as_index=False)
        .mean(numeric_only=True)
        .sort_values(["arm", "window"])
    )
    decision = selection_decision(curves)

    args.write_dir.mkdir(parents=True, exist_ok=True)
    outputs = {
        "three_term_curve_summary.csv": curves,
        "three_term_aggregate_trajectories.csv": aggregate_trajectories_frame,
        "three_term_seed_factorial_effects.csv": seed_effects,
        "three_term_question_factorial_effects.csv": question_effects,
        "three_term_aggregate_factorial_effects.csv": aggregate_effects,
        "three_term_checkpoint_reference_aggregate.csv": checkpoint_effects,
        "three_term_best_checkpoint_by_arm.csv": best_checkpoints,
        "three_term_cell_mechanism_summary.csv": table.sort_values(["arm", "seed"]),
        "three_term_mechanism_windows.csv": windows,
        "three_term_mechanism_window_aggregate.csv": aggregate_windows,
    }
    for filename, frame in outputs.items():
        frame.to_csv(args.write_dir / filename, index=False)
    (args.write_dir / "three_term_selection.json").write_text(
        json.dumps(decision, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    pd.set_option("display.width", 260)
    pd.set_option("display.max_columns", None)
    print("=== THREE-TERM CURVES ===")
    print(curves.to_string(index=False))
    print("\n=== CONDITIONAL AND MARGINAL EFFECTS ===")
    print(aggregate_effects.to_string(index=False))
    print("\n=== BEST MEAN CHECKPOINT PER TRAINED ARM ===")
    print(best_checkpoints.to_string(index=False))
    print("\n=== FROZEN SELECTION ===")
    print(json.dumps(decision, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
