"""Analyze the matched 2x2 AC-ALG1 latent-objective factorial.

The three ablation corners come from the objective-term study. The matched
token-mean arm from the collapse-stability study supplies the full-objective
corner. The primary outcome is normalized validation-accuracy AUC over rounds
0--30, with the frozen four-shot result inserted at round 0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from analysis.analyze_ac_alg1_collapse_stability import (
        aggregate_trajectories,
        summarize_curves,
    )
    from analysis.analyze_ac_alg1_numerical_study import (
        _paired_bootstrap_interval,
        load_cells,
        load_checkpoint_trajectories,
    )
except ModuleNotFoundError:  # Direct execution from analysis/.
    from analyze_ac_alg1_collapse_stability import aggregate_trajectories, summarize_curves
    from analyze_ac_alg1_numerical_study import (
        _paired_bootstrap_interval,
        load_cells,
        load_checkpoint_trajectories,
    )


ARMS = ("T00", "T10", "T01", "T11")
CONTRASTS = (
    "Bprime_at_Bunsup0",
    "Bprime_at_Bunsup1",
    "Bunsup_at_Bprime0",
    "Bunsup_at_Bprime1",
    "interaction",
)


def factorial_effects(curve_summary: pd.DataFrame) -> pd.DataFrame:
    """Return seed-level AUC effects for the 2x2 objective factorial."""

    pivot = curve_summary.pivot(
        index="seed", columns="arm", values="normalized_accuracy_auc"
    )
    missing = set(ARMS) - set(pivot.columns)
    if missing:
        raise ValueError(f"missing objective-factorial arms: {sorted(missing)}")
    pivot = pivot[list(ARMS)].dropna()
    return pd.DataFrame({
        "seed": pivot.index.astype(int),
        **{arm: pivot[arm].to_numpy(float) for arm in ARMS},
        "Bprime_at_Bunsup0": (pivot["T10"] - pivot["T00"]).to_numpy(float),
        "Bprime_at_Bunsup1": (pivot["T11"] - pivot["T01"]).to_numpy(float),
        "Bunsup_at_Bprime0": (pivot["T01"] - pivot["T00"]).to_numpy(float),
        "Bunsup_at_Bprime1": (pivot["T11"] - pivot["T10"]).to_numpy(float),
        "interaction": (
            pivot["T11"] - pivot["T10"] - pivot["T01"] + pivot["T00"]
        ).to_numpy(float),
    })


def selection_decision(curve_summary: pd.DataFrame) -> dict:
    """Apply the frozen highest-mean-AUC subject to no-seed-harm rule."""

    pivot = curve_summary.pivot(
        index="seed", columns="arm", values="normalized_accuracy_auc"
    )
    missing = set(ARMS) - set(pivot.columns)
    if missing:
        raise ValueError(f"missing objective-factorial arms: {sorted(missing)}")
    pivot = pivot[list(ARMS)].dropna()
    if pivot.empty:
        raise ValueError("no seed has all four objective-factorial arms")

    means = pivot.mean(axis=0)
    eligible = [arm for arm in ARMS if bool((pivot[arm] >= pivot["T00"]).all())]
    parsimony_order = {arm: index for index, arm in enumerate(ARMS)}
    selected = sorted(
        eligible,
        key=lambda arm: (-float(means[arm]), parsimony_order[arm]),
    )[0]
    return {
        "selected_arm": selected,
        "eligible_arms": eligible,
        "mean_auc_by_arm": {arm: float(means[arm]) for arm in ARMS},
        "n_complete_seeds": int(len(pivot)),
        "selection_rule": (
            "highest mean normalized validation-accuracy AUC among arms whose "
            "AUC is not below T00 in any seed"
        ),
        "supervised_only_not_worse_than_every_latent_arm": bool(
            all(means["T00"] >= means[arm] for arm in ARMS if arm != "T00")
        ),
    }


def _correctness_by_round(records: dict[int, dict]) -> dict[int, dict[int, float]]:
    return {
        completed_rounds: {
            int(item["idx"]): float(bool(item["correct"]))
            for item in record.get("records", [])
        }
        for completed_rounds, record in records.items()
    }


def question_factorial_effects(
    table: pd.DataFrame,
    checkpoint_evaluations: dict[tuple[str, int, int], dict],
) -> pd.DataFrame:
    """Integrate paired factorial effects for every held-out question."""

    rows: list[dict] = []
    for seed in sorted(table["seed"].unique()):
        seed_table = table[table["seed"] == seed]
        tags = {str(row["arm"]): str(row["tag"]) for _, row in seed_table.iterrows()}
        if set(ARMS) - set(tags):
            continue
        records_by_arm: dict[str, dict[int, dict]] = {}
        for arm in ARMS:
            records_by_arm[arm] = {
                completed_rounds: record
                for (tag, checkpoint_seed, completed_rounds), record
                in checkpoint_evaluations.items()
                if tag == tags[arm] and checkpoint_seed == int(seed)
            }
        shared_rounds = sorted(
            set.intersection(*(set(records_by_arm[arm]) for arm in ARMS))
        )
        if not shared_rounds:
            continue
        correct = {
            arm: _correctness_by_round(records_by_arm[arm]) for arm in ARMS
        }
        shared_questions = set.intersection(*(
            set(correct[arm][completed_rounds])
            for arm in ARMS
            for completed_rounds in shared_rounds
        ))
        x = np.array([0, *shared_rounds], dtype=float)
        for idx in sorted(shared_questions):
            values = {
                arm: np.array([
                    0.0,
                    *(correct[arm][completed_rounds][idx]
                      for completed_rounds in shared_rounds),
                ])
                for arm in ARMS
            }
            round_effects = {
                "Bprime_at_Bunsup0": values["T10"] - values["T00"],
                "Bprime_at_Bunsup1": values["T11"] - values["T01"],
                "Bunsup_at_Bprime0": values["T01"] - values["T00"],
                "Bunsup_at_Bprime1": values["T11"] - values["T10"],
                "interaction": (
                    values["T11"] - values["T10"] - values["T01"] + values["T00"]
                ),
            }
            rows.append({
                "seed": int(seed),
                "idx": int(idx),
                "n_shared_checkpoints": len(shared_rounds),
                "final_round": int(shared_rounds[-1]),
                **{
                    name: float(np.trapezoid(effect, x) / float(shared_rounds[-1]))
                    for name, effect in round_effects.items()
                },
            })
    return pd.DataFrame(rows).sort_values(["seed", "idx"]) if rows else pd.DataFrame()


def aggregate_question_effects(
    seed_effects: pd.DataFrame,
    question_effects: pd.DataFrame,
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Summarize each effect over seeds and paired question clusters."""

    rows: list[dict] = []
    for offset, contrast in enumerate(CONTRASTS):
        seed_values = seed_effects[contrast].to_numpy(float)
        clustered = (
            question_effects.groupby("idx")[contrast].mean().to_numpy(float)
            if not question_effects.empty
            else np.array([], dtype=float)
        )
        low, high = _paired_bootstrap_interval(
            clustered, draws=draws, seed=bootstrap_seed + offset
        )
        rows.append({
            "contrast": contrast,
            "mean_seed_auc_effect": float(seed_values.mean()),
            "positive_seeds": int(np.sum(seed_values > 0)),
            "negative_seeds": int(np.sum(seed_values < 0)),
            "n_seeds": len(seed_values),
            "n_question_clusters": len(clustered),
            "question_cluster_ci95_low": low,
            "question_cluster_ci95_high": high,
        })
    return pd.DataFrame(rows)


def load_factorial(
    term_result_dir: Path,
    term_prefix: str,
    term_config: Path,
    reference_result_dir: Path,
    reference_prefix: str,
    reference_config: Path,
    reference_arm: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[tuple[str, int, int], dict]]:
    """Load and relabel the three ablations plus the full-objective reference."""

    terms, _ = load_cells(term_result_dir, term_prefix, term_config, final_rounds=10)
    term_trajectories, term_evaluations = load_checkpoint_trajectories(
        term_result_dir, terms
    )
    term_arm_map = {"C0": "T00", "C1": "T10", "C2": "T01"}
    terms["arm"] = terms["arm"].map(term_arm_map)
    term_trajectories["arm"] = term_trajectories["arm"].map(term_arm_map)

    reference, _ = load_cells(
        reference_result_dir, reference_prefix, reference_config, final_rounds=10
    )
    reference_trajectories, reference_evaluations = load_checkpoint_trajectories(
        reference_result_dir, reference
    )
    reference = reference[reference["arm"] == reference_arm].copy()
    reference_trajectories = reference_trajectories[
        reference_trajectories["arm"] == reference_arm
    ].copy()
    reference["arm"] = "T11"
    reference_trajectories["arm"] = "T11"

    table = pd.concat([terms, reference], ignore_index=True)
    trajectories = pd.concat(
        [term_trajectories, reference_trajectories], ignore_index=True
    )
    evaluations = {**term_evaluations, **reference_evaluations}
    return table, trajectories, evaluations


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("term_result_dir", type=Path)
    parser.add_argument("--term-prefix", required=True)
    parser.add_argument("--term-config", type=Path, required=True)
    parser.add_argument("--reference-result-dir", type=Path, required=True)
    parser.add_argument("--reference-prefix", required=True)
    parser.add_argument("--reference-config", type=Path, required=True)
    parser.add_argument("--reference-arm", default="C1")
    parser.add_argument("--reference-accuracy", type=float, default=0.7925)
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260722)
    parser.add_argument("--write-dir", type=Path, default=None)
    args = parser.parse_args()

    table, trajectories, checkpoint_evaluations = load_factorial(
        args.term_result_dir.expanduser(),
        args.term_prefix,
        args.term_config,
        args.reference_result_dir.expanduser(),
        args.reference_prefix,
        args.reference_config,
        args.reference_arm,
    )
    curves = summarize_curves(trajectories, args.reference_accuracy)
    aggregate_curves = aggregate_trajectories(trajectories, args.reference_accuracy)
    seeds = factorial_effects(curves)
    questions = question_factorial_effects(table, checkpoint_evaluations)
    aggregate = aggregate_question_effects(
        seeds, questions, args.bootstrap_draws, args.bootstrap_seed
    )
    decision = selection_decision(curves)
    mechanisms = table.sort_values(["arm", "seed"])

    pd.set_option("display.width", 240)
    pd.set_option("display.max_columns", None)
    print("=== OBJECTIVE-FACTORIAL CURVES ===")
    print(curves.to_string(index=False))
    print("\n=== SEED-LEVEL FACTORIAL EFFECTS ===")
    print(seeds.to_string(index=False))
    print("\n=== AGGREGATE PAIRED EFFECTS ===")
    print(aggregate.to_string(index=False))
    print("\n=== FROZEN SELECTION ===")
    print(json.dumps(decision, indent=2, sort_keys=True))

    if args.write_dir is not None:
        args.write_dir.mkdir(parents=True, exist_ok=True)
        curves.to_csv(args.write_dir / "objective_curve_summary.csv", index=False)
        aggregate_curves.to_csv(
            args.write_dir / "objective_aggregate_trajectories.csv", index=False
        )
        seeds.to_csv(args.write_dir / "objective_seed_factorial_effects.csv", index=False)
        questions.to_csv(
            args.write_dir / "objective_question_factorial_effects.csv", index=False
        )
        aggregate.to_csv(
            args.write_dir / "objective_aggregate_factorial_effects.csv", index=False
        )
        mechanisms.to_csv(
            args.write_dir / "objective_cell_mechanism_summary.csv", index=False
        )
        (args.write_dir / "objective_selection.json").write_text(
            json.dumps(decision, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
