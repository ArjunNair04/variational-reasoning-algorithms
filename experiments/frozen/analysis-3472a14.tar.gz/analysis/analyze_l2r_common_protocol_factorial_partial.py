#!/usr/bin/env python3
"""Audit and analyse a receipt-complete prefix of the common factorial.

This is a recovery analyser for an interrupted SGE array.  It preserves the
pre-registered metrics and gates from ``analyze_l2r_common_protocol_factorial``
while refusing incomplete three-seed cells, unreceipted artifacts, or logs
without terminal evidence.  Partial evidence can describe complete method
families, but cannot make the frozen whole-study nomination decision.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:  # Support direct file execution.
    sys.path.insert(0, str(REPOSITORY_ROOT))

from analysis.analyze_barber_source_programme import FAILURE_PATTERNS
from analysis import analyze_l2r_common_protocol_factorial as frozen
from lm_study.result_contract import (
    ResultContractError,
    validate_completion_receipt,
)


KNOWN_COMMIT_EXCEPTION_TASKS = (3, 274)
TERMINAL_LOG_MARKERS = ("=== done in", "GPU Epilog Script")
LOG_NAME_RE = re.compile(
    r"^qwen3_l2r_common_protocol_factorial\.(?P<job>[0-9]+)\.(?P<task>[0-9]+)\.log$"
)


def _execution_segment(
    task_id: int,
    *,
    expected_commit: str,
    expected_source_job: str,
    continuation_execution_commit: str | None,
    continuation_source_job: str | None,
    continuation_first_task: int,
) -> tuple[str, str]:
    """Return the exact commit and scheduler job responsible for one task."""

    has_commit = continuation_execution_commit is not None
    has_job = continuation_source_job is not None
    if has_commit != has_job:
        raise ValueError(
            "continuation execution commit and source job must be supplied together"
        )
    if has_commit and task_id >= continuation_first_task:
        return str(continuation_execution_commit), str(continuation_source_job)
    return expected_commit, expected_source_job


def expected_task_table(config_path: Path) -> pd.DataFrame:
    """Return the exact array task-to-cell/seed mapping in YAML order."""

    _config, design = frozen.load_design(config_path)
    rows: list[dict[str, Any]] = []
    for cell_index, design_row in enumerate(design.to_dict("records")):
        for seed_index, seed in enumerate(frozen.SEEDS):
            rows.append(
                {
                    "task_id": cell_index * len(frozen.SEEDS) + seed_index + 1,
                    "cell": str(design_row["cell"]),
                    "method_family": str(design_row["method_family"]),
                    "seed": seed,
                }
            )
    return pd.DataFrame(rows)


def _receipt_cell_seed(
    receipt: Mapping[str, Any], registered_cells: Sequence[str]
) -> tuple[str, int]:
    identity = receipt.get("identity") or {}
    tag = str(identity.get("tag", ""))
    cell, seed = frozen._cell_seed_from_tag(tag, registered_cells)
    if int(identity.get("seed", -1)) != seed:
        raise ValueError(f"receipt tag and seed disagree: {tag}")
    return cell, seed


def _sweep_name(receipt: Mapping[str, Any]) -> str:
    identity = receipt.get("identity") or {}
    return f"sweep_{identity.get('task')}__{identity.get('tag')}.csv"


def _rate(records: Sequence[Mapping[str, Any]], field: str) -> float:
    values = [record.get(field) for record in records]
    if not values or any(not isinstance(value, bool) for value in values):
        raise ValueError(f"records omit boolean field {field!r}")
    return float(np.mean(values))


def _derived_metrics(records: Sequence[Mapping[str, Any]]) -> dict[str, float]:
    if not records:
        raise ValueError("cannot derive metrics from an empty record set")
    marker_counts = [record.get("answer_marker_count") for record in records]
    terminals = [record.get("answer_marker_terminal") for record in records]
    if any(not isinstance(value, int) or value < 0 for value in marker_counts):
        raise ValueError("records omit nonnegative answer_marker_count")
    if any(not isinstance(value, bool) for value in terminals):
        raise ValueError("records omit boolean answer_marker_terminal")
    strict_count = sum(bool(record["strict_correct"]) for record in records)
    return {
        "test_acc_legacy": _rate(records, "legacy_correct"),
        "test_acc_strict": _rate(records, "strict_correct"),
        "eval_natural_eos_fraction": _rate(records, "generated_eos"),
        "eval_hit_max_new_fraction": _rate(records, "hit_max_new_tokens"),
        "eval_multiple_marker_fraction": float(
            np.mean([value > 1 for value in marker_counts])
        ),
        "eval_nonterminal_marker_fraction": float(
            np.mean(
                [
                    count == 1 and not terminal
                    for count, terminal in zip(marker_counts, terminals, strict=True)
                ]
            )
        ),
        "eval_strict_format_failure_fraction": _rate(
            records, "strict_format_failure"
        ),
        "eval_eos_given_strict_correct_fraction": (
            sum(
                bool(record["strict_correct"] and record["generated_eos"])
                for record in records
            )
            / strict_count
            if strict_count
            else 0.0
        ),
    }


def _check_record_metrics(
    records: Sequence[Mapping[str, Any]],
    reported: Mapping[str, Any],
    *,
    context: str,
) -> None:
    derived = _derived_metrics(records)
    for key, expected in derived.items():
        observed = reported.get(key)
        if not isinstance(observed, (int, float)) or not math.isclose(
            float(observed), expected, abs_tol=1e-12
        ):
            raise ValueError(
                f"{context}: {key}={observed!r}, reconstructed {expected!r}"
            )


def verify_question_metrics(artifact_dir: Path, cells: pd.DataFrame) -> int:
    """Reconstruct every saved final/checkpoint metric from question rows."""

    checked = 0
    for row in cells.to_dict("records"):
        eval_path = frozen._single_artifact(
            artifact_dir,
            f"eval_gsm8k__{row['tag']}__*.json",
            f"{row['cell']}/{row['seed']}/final",
        )
        payload = frozen._read_json(eval_path)
        records = payload.get("records") or []
        if len(records) != 400:
            raise ValueError(f"{eval_path.name}: expected 400 final records")
        for index, record in enumerate(records):
            frozen._require_record_non_access(
                record, context=f"{eval_path.name}/record{index}"
            )
        _check_record_metrics(records, payload, context=eval_path.name)
        checked += len(records)
        if row["cell"] == frozen.BASE_CELL:
            continue
        checkpoint_path = frozen._single_artifact(
            artifact_dir,
            f"checkpoint_eval_*__{row['tag']}__*.jsonl.gz",
            f"{row['cell']}/{row['seed']}/checkpoints",
        )
        payloads = frozen._read_jsonl_gz(checkpoint_path)
        if tuple(int(item.get("completed_rounds", -1)) for item in payloads) != (
            frozen.CHECKPOINT_ROUNDS
        ):
            raise ValueError(f"{checkpoint_path.name}: checkpoint schedule mismatch")
        for checkpoint in payloads:
            records = checkpoint.get("records") or []
            if len(records) != 400:
                raise ValueError(
                    f"{checkpoint_path.name}: expected 400 checkpoint records"
                )
            for index, record in enumerate(records):
                frozen._require_record_non_access(
                    record,
                    context=(
                        f"{checkpoint_path.name}/round"
                        f"{checkpoint['completed_rounds']}/record{index}"
                    ),
                )
            _check_record_metrics(
                records,
                checkpoint.get("metrics") or {},
                context=f"{checkpoint_path.name}/round{checkpoint['completed_rounds']}",
            )
            checked += len(records)
    return checked


def verify_pairing(artifact_dir: Path, cells: pd.DataFrame) -> dict[str, Any]:
    """Require the same schedules within seed and disjoint data roles."""

    schedule_hashes: dict[int, dict[str, str]] = {}
    for seed in frozen.SEEDS:
        subset = cells[cells["seed"] == seed]
        reference: dict[str, tuple[int, ...]] | None = None
        for row in subset.to_dict("records"):
            result_path = frozen._single_artifact(
                artifact_dir,
                f"cell_result_*__{row['tag']}__*.json",
                f"{row['cell']}/{seed}/result",
            )
            result = (frozen._read_json(result_path).get("result") or {})
            eval_path = frozen._single_artifact(
                artifact_dir,
                f"eval_gsm8k__{row['tag']}__*.json",
                f"{row['cell']}/{seed}/eval",
            )
            passk_path = frozen._single_artifact(
                artifact_dir,
                f"passk_gsm8k__{row['tag']}__*.json",
                f"{row['cell']}/{seed}/passk",
            )
            schedule = {
                "shots": tuple(int(value) for value in result.get("shot_qi") or []),
                "train": tuple(int(value) for value in result.get("train_qi") or []),
                "eval": tuple(
                    int(record["idx"])
                    for record in frozen._read_json(eval_path).get("records") or []
                ),
                "pass8": tuple(
                    int(record["idx"])
                    for record in frozen._read_json(passk_path).get("records") or []
                ),
            }
            expected_sizes = {"shots": 3, "train": 128, "eval": 400, "pass8": 100}
            for role, expected_size in expected_sizes.items():
                if len(schedule[role]) != expected_size or len(
                    set(schedule[role])
                ) != expected_size:
                    raise ValueError(
                        f"seed {seed}: {role} schedule is not {expected_size} unique rows"
                    )
            if not set(schedule["pass8"]).issubset(schedule["eval"]):
                raise ValueError(f"seed {seed}: pass-at-8 rows are not an eval subset")
            if reference is None:
                reference = schedule
            elif schedule != reference:
                raise ValueError(f"seed {seed}: paired question schedule changed")
        if reference is None:
            raise ValueError(f"seed {seed}: no completed cells")
        if len(reference["shots"]) != 3 or len(reference["train"]) != 128:
            raise ValueError(f"seed {seed}: prompt/train schedule size changed")
        if len(reference["eval"]) != 400 or len(reference["pass8"]) != 100:
            raise ValueError(f"seed {seed}: evaluation schedule size changed")
        roles = (set(reference["shots"]), set(reference["train"]), set(reference["eval"]))
        if any(left & right for index, left in enumerate(roles) for right in roles[index + 1 :]):
            raise ValueError(f"seed {seed}: prompt/train/eval partitions overlap")
        schedule_hashes[seed] = {
            role: hashlib.sha256(
                json.dumps(values, separators=(",", ":")).encode("utf-8")
            ).hexdigest()
            for role, values in reference.items()
        }
    return {"paired_seeds": list(frozen.SEEDS), "schedule_sha256": schedule_hashes}


def verify_runtime_configurations(
    artifact_dir: Path,
    config_path: Path,
    cells: pd.DataFrame,
    design: pd.DataFrame,
) -> dict[str, Any]:
    """Bind every completed runtime identity to its frozen YAML cell."""

    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    variants: dict[str, tuple[str, dict[str, Any]]] = {}
    for method, method_spec in (config.get("algos") or {}).items():
        method_variants = method_spec if isinstance(method_spec, list) else [method_spec]
        for variant in method_variants:
            cell = str((variant or {}).get("cell_id"))
            variants[cell] = (str(method), dict(variant or {}))
    if not set(design["cell"].astype(str)).issubset(variants):
        raise ValueError("runtime audit cell catalogue differs from the frozen design")

    design_by_cell = design.set_index("cell").to_dict("index")
    fixed_sweep = {
        "rounds": 32,
        "seeds": 1,
        "prompts": 128,
        "shots": 3,
        "shot_bank_size": 5,
        "n_test": 400,
        "train_partition": "train",
        "eval_partition": "validation",
        "answer_event_mode": "strict_terminal_marker",
        "question_sampling": "epoch_shuffle",
        "task_seed_from_run_seed": True,
        "eval_rounds": list(frozen.CHECKPOINT_ROUNDS),
        "passk": 8,
        "passk_n": 100,
        "save_adapter": False,
        "save_training_diagnostics": True,
    }
    trained_modules = [
        "q_proj",
        "k_proj",
        "v_proj",
        "o_proj",
        "gate_proj",
        "up_proj",
        "down_proj",
    ]
    checked = 0
    trained = 0
    for row in cells.to_dict("records"):
        cell = str(row["cell"])
        seed = int(row["seed"])
        result_path = frozen._single_artifact(
            artifact_dir,
            f"cell_result_*__{row['tag']}__*.json",
            f"{cell}/{seed}/runtime-configuration",
        )
        identity = frozen._read_json(result_path).get("identity") or {}
        method, variant = variants[cell]
        if (
            identity.get("run_id") != "f31c2a6e"
            or identity.get("task") != "gsm8k"
            or identity.get("model") != "qwen3-1.7b-base"
            or identity.get("method") != method
            or int(identity.get("seed", -1)) != seed
            or identity.get("tag") != row["tag"]
        ):
            raise ValueError(f"{result_path.name}: runtime identity mismatch")
        runtime = identity.get("configuration") or {}
        if runtime.get("run_id") != "f31c2a6e":
            raise ValueError(f"{result_path.name}: runtime run-ID mismatch")
        sweep = runtime.get("sweep") or {}
        for key, expected in {**fixed_sweep, "seed0": seed}.items():
            if sweep.get(key) != expected:
                raise ValueError(
                    f"{result_path.name}: runtime {key}={sweep.get(key)!r}, "
                    f"expected {expected!r}"
                )
        methods = runtime.get("methods") or {}
        if method == "base":
            if methods:
                raise ValueError(f"{result_path.name}: frozen base has trainer arguments")
        else:
            trained += 1
            design_row = design_by_cell[cell]
            expected_batch = int(design_row["S"] * design_row["B"])
            for key, expected in {
                "B": expected_batch,
                "G": int(design_row["S"]),
                "lora_target_set": "attention_mlp",
                "answer_target_termination": (
                    "eos" if method == "AC-ALG1" else "none"
                ),
            }.items():
                if sweep.get(key) != expected:
                    raise ValueError(
                        f"{result_path.name}: runtime {key}={sweep.get(key)!r}, "
                        f"expected {expected!r}"
                    )
            if (sweep.get("lora_target_modules") or {}).get(
                "qwen3-1.7b-base"
            ) != trained_modules:
                raise ValueError(f"{result_path.name}: trained LoRA surface changed")
            if set(methods) != {method}:
                raise ValueError(f"{result_path.name}: trainer identity set changed")
            method_runtime = methods[method]
            for key, expected in variant.items():
                if key in {"cell_id", "batch", "G", "answer_target_termination"}:
                    continue
                if method_runtime.get(key) != expected:
                    raise ValueError(
                        f"{result_path.name}: trainer {key}="
                        f"{method_runtime.get(key)!r}, expected {expected!r}"
                    )
        checked += 1
    return {
        "runtime_configurations_verified": checked,
        "trained_runtime_configurations_verified": trained,
    }


def verify_partial_mirror(
    artifact_dir: Path,
    config_path: Path,
    *,
    last_complete_task: int,
    expected_commit: str,
    expected_source_job: str,
    continuation_execution_commit: str | None = None,
    continuation_source_job: str | None = None,
    continuation_first_task: int = frozen.CONTINUATION_FIRST_TASK,
    commit_exception_tasks: Sequence[int] = KNOWN_COMMIT_EXCEPTION_TASKS,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Verify a contiguous receipt-complete, three-seed array prefix."""

    if last_complete_task < 3 or last_complete_task % len(frozen.SEEDS):
        raise ValueError("partial boundary must end on a complete three-seed cell")
    if continuation_first_task < 1:
        raise ValueError("continuation first task must be positive")
    if len(expected_commit) != 40 or not expected_source_job.isdigit():
        raise ValueError("original execution segment identity is malformed")
    if continuation_execution_commit is not None and (
        len(continuation_execution_commit) != 40
        or continuation_source_job is None
        or not continuation_source_job.isdigit()
    ):
        raise ValueError("continuation execution segment identity is malformed")
    mapping = expected_task_table(config_path)
    selected = mapping[mapping["task_id"] <= last_complete_task].copy()
    if len(selected) != last_complete_task:
        raise ValueError("partial boundary exceeds the registered array")
    cells = tuple(mapping["cell"].drop_duplicates())
    lookup = {
        (str(row.cell), int(row.seed)): int(row.task_id)
        for row in mapping.itertuples(index=False)
    }
    receipts_by_task: dict[int, tuple[Path, dict[str, Any]]] = {}
    verified_files = 0
    for path in sorted(artifact_dir.glob("complete_*.json")):
        try:
            receipt = validate_completion_receipt(
                path,
                result_root=artifact_dir,
                verify_hashes=True,
            )
        except ResultContractError as exc:
            raise ValueError(f"{path.name}: invalid completion receipt: {exc}") from exc
        cell, seed = _receipt_cell_seed(receipt, cells)
        task_id = lookup[(cell, seed)]
        if task_id > last_complete_task:
            raise ValueError(f"{path.name}: receipt lies beyond partial boundary")
        if task_id in receipts_by_task:
            raise ValueError(f"duplicate receipt for task {task_id}")
        receipts_by_task[task_id] = (path, receipt)
        verified_files += len(receipt.get("artifacts") or [])
        sweep = artifact_dir / _sweep_name(receipt)
        if not sweep.is_file():
            raise ValueError(f"missing sweep: {sweep.name}")
        frame = pd.read_csv(sweep)
        if len(frame) != 1 or str(frame.iloc[0].get("run_id")) != "f31c2a6e":
            raise ValueError(f"{sweep.name}: invalid one-row run identity")
        params = json.loads(str(frame.iloc[0].get("params") or ""))
        observed_commit = str((params.get("env") or {}).get("commit", ""))
        task_commit, _task_job = _execution_segment(
            task_id,
            expected_commit=expected_commit,
            expected_source_job=expected_source_job,
            continuation_execution_commit=continuation_execution_commit,
            continuation_source_job=continuation_source_job,
            continuation_first_task=continuation_first_task,
        )
        if task_id in commit_exception_tasks:
            if observed_commit != "unknown":
                raise ValueError(
                    f"task {task_id}: expected documented unknown commit exception"
                )
        elif not observed_commit or not task_commit.startswith(observed_commit):
            raise ValueError(f"task {task_id}: execution commit mismatch")
    expected_tasks = set(range(1, last_complete_task + 1))
    if set(receipts_by_task) != expected_tasks:
        raise ValueError(
            "receipt task mismatch: "
            f"missing={sorted(expected_tasks - set(receipts_by_task))}, "
            f"extra={sorted(set(receipts_by_task) - expected_tasks)}"
        )

    log_paths = sorted(artifact_dir.glob("qwen3_l2r_common_protocol_factorial.*.*.log"))
    log_tasks: dict[int, Path] = {}
    for path in log_paths:
        match = LOG_NAME_RE.fullmatch(path.name)
        if match is None:
            raise ValueError(f"malformed task log name: {path.name}")
        source_job = match.group("job")
        task_id = int(match.group("task"))
        if task_id > last_complete_task:
            raise ValueError(f"{path.name}: log lies beyond partial boundary")
        _task_commit, task_source_job = _execution_segment(
            task_id,
            expected_commit=expected_commit,
            expected_source_job=expected_source_job,
            continuation_execution_commit=continuation_execution_commit,
            continuation_source_job=continuation_source_job,
            continuation_first_task=continuation_first_task,
        )
        if source_job != task_source_job:
            raise ValueError(
                f"task {task_id}: expected scheduler job {task_source_job}, "
                f"found {source_job}"
            )
        if task_id in log_tasks:
            raise ValueError(f"duplicate terminal log for task {task_id}")
        text = path.read_text(encoding="utf-8", errors="replace")
        for marker in TERMINAL_LOG_MARKERS:
            if marker not in text:
                raise ValueError(f"{path.name}: missing terminal marker {marker!r}")
        for pattern in FAILURE_PATTERNS:
            match = pattern.search(text)
            if match:
                raise ValueError(f"{path.name}: failure signature {match.group(0)!r}")
        log_tasks[task_id] = path
    if set(log_tasks) != expected_tasks:
        raise ValueError("terminal log task set does not match receipt task set")

    gzip_files = sorted(artifact_dir.glob("*.jsonl.gz"))
    trained_tasks = last_complete_task - len(frozen.SEEDS)
    if len(gzip_files) != 2 * trained_tasks:
        raise ValueError(
            f"expected {2 * trained_tasks} gzip streams, found {len(gzip_files)}"
        )
    for path in gzip_files:
        with gzip.open(path, "rb") as handle:
            while handle.read(1024 * 1024):
                pass

    execution_segments = [
        {
            "task_range": [1, min(last_complete_task, continuation_first_task - 1)],
            "execution_commit": expected_commit,
            "source_job": expected_source_job,
        }
    ]
    if continuation_execution_commit is not None and last_complete_task >= continuation_first_task:
        execution_segments.append(
            {
                "task_range": [continuation_first_task, last_complete_task],
                "execution_commit": continuation_execution_commit,
                "source_job": continuation_source_job,
            }
        )
    integrity = {
        "status": "verified",
        "artifact_dir": str(artifact_dir),
        "last_complete_task": last_complete_task,
        "complete_three_seed_cells": last_complete_task // len(frozen.SEEDS),
        "receipts": len(receipts_by_task),
        "receipt_files_hash_verified": verified_files,
        "sweep_files": len(receipts_by_task),
        "terminal_logs": len(log_tasks),
        "gzip_streams": len(gzip_files),
        "execution_segments": execution_segments,
        "commit_exception_tasks": list(commit_exception_tasks),
        "validator_marker_present": False,
        "whole_study_complete": False,
    }
    return integrity, selected


def _family_overview(gates: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for method, group in gates.groupby("method_family", sort=False):
        eligible = group[group["passes_all_gates"]]
        best = group.sort_values("mean_extracted_auc", ascending=False).iloc[0]
        rows.append(
            {
                "method_family": method,
                "complete_cells": len(group),
                "factorial_complete": len(group) == 27,
                "gate_passing_cells": len(eligible),
                "best_observed_cell": str(best["cell"]),
                "best_observed_auc": float(best["mean_extracted_auc"]),
                "best_observed_auc_delta_pp": float(
                    best["mean_extracted_auc_delta_pp"]
                ),
                "best_observed_passes_all_gates": bool(best["passes_all_gates"]),
            }
        )
    return pd.DataFrame(rows)


def _matched_complete_family_contrasts(
    summaries: pd.DataFrame, complete_families: Sequence[str]
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    indexed = summaries.set_index(["method_family", "S", "B", "U", "seed"])
    for left_index, left in enumerate(complete_families):
        for right in complete_families[left_index + 1 :]:
            for support in frozen.RESOURCE_LEVELS["S"]:
                for questions in frozen.RESOURCE_LEVELS["B"]:
                    for reuse in frozen.RESOURCE_LEVELS["U"]:
                        differences = [
                            float(
                                indexed.loc[
                                    (left, support, questions, reuse, seed),
                                    "extracted_auc",
                                ]
                                - indexed.loc[
                                    (right, support, questions, reuse, seed),
                                    "extracted_auc",
                                ]
                            )
                            for seed in frozen.SEEDS
                        ]
                        mean, low, high = frozen.paired_bootstrap(
                            differences,
                            draws=20_000,
                            seed=20260806 + len(rows),
                        )
                        rows.append(
                            {
                                "left_method": left,
                                "right_method": right,
                                "S": support,
                                "B": questions,
                                "U": reuse,
                                "mean_difference_pp": 100.0 * mean,
                                "ci95_low_pp": 100.0 * low,
                                "ci95_high_pp": 100.0 * high,
                                "positive_seeds": int(
                                    np.sum(np.asarray(differences) > 0)
                                ),
                            }
                        )
    return pd.DataFrame(rows)


def run_analysis(args: argparse.Namespace) -> dict[str, Any]:
    artifact_dir = Path(args.artifact_dir).resolve()
    config_path = Path(args.config).resolve()
    out_dir = Path(args.out_dir).resolve()
    integrity, selected_tasks = verify_partial_mirror(
        artifact_dir,
        config_path,
        last_complete_task=args.last_complete_task,
        expected_commit=args.expected_execution_commit,
        expected_source_job=args.expected_source_job,
        continuation_execution_commit=args.continuation_execution_commit,
        continuation_source_job=args.continuation_source_job,
    )
    _config, full_design = frozen.load_design(config_path)
    completed_cells = list(selected_tasks["cell"].drop_duplicates())
    partial_design = full_design[full_design["cell"].isin(completed_cells)].copy()
    cells = frozen.load_cell_results(artifact_dir, partial_design, run_id="f31c2a6e")
    runtime_audit = verify_runtime_configurations(
        artifact_dir,
        config_path,
        cells,
        partial_design,
    )
    integrity.update(runtime_audit)
    question_records_checked = verify_question_metrics(artifact_dir, cells)
    pairing = verify_pairing(artifact_dir, cells)
    curves, summaries = frozen.build_curves(artifact_dir, cells)
    summaries = summaries.merge(
        frozen.load_pass8(artifact_dir, cells),
        on=["cell", "seed"],
        validate="one_to_one",
    )
    summaries = summaries.merge(
        cells[
            [
                "cell",
                "seed",
                "seconds",
                "accelerator_hours",
                "peak_cuda_reserved_gb",
                "generated_tokens",
                "backward_tokens",
                "optimizer_steps",
            ]
        ],
        on=["cell", "seed"],
        validate="one_to_one",
    ).merge(partial_design, on="cell", validate="many_to_one")
    mechanisms = frozen.load_mechanisms(
        artifact_dir, cells, run_id="f31c2a6e"
    ).merge(partial_design, on="cell", validate="many_to_one")
    gates = frozen.candidate_gates(summaries)
    overview = _family_overview(gates)
    complete_families = tuple(
        overview.loc[overview["factorial_complete"], "method_family"].astype(str)
    )
    matched = _matched_complete_family_contrasts(summaries, complete_families)
    frontier = frozen.compute_frontier(summaries)

    out_dir.mkdir(parents=True, exist_ok=True)
    curves.to_csv(out_dir / "checkpoint_curves.csv", index=False)
    summaries.to_csv(out_dir / "seed_summary.csv", index=False)
    mechanisms.to_csv(out_dir / "mechanism_summary.csv", index=False)
    gates.to_csv(out_dir / "candidate_gates.csv", index=False)
    overview.to_csv(out_dir / "method_family_overview.csv", index=False)
    matched.to_csv(out_dir / "matched_complete_family_contrasts.csv", index=False)
    frontier.to_csv(out_dir / "compute_performance_frontier.csv", index=False)
    (out_dir / "integrity.json").write_text(
        json.dumps({**integrity, "pairing": pairing}, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    payload = {
        "run_id": "f31c2a6e",
        "status": "validated_partial_interrupted",
        "observational_unit": "paired training seed",
        "last_complete_task": args.last_complete_task,
        "complete_three_seed_cells": len(completed_cells),
        "complete_method_families": list(complete_families),
        "question_records_reconstructed": question_records_checked,
        "whole_factorial_nomination_permitted": False,
        "official_test_used": False,
        "integrity": integrity,
    }
    (out_dir / "analysis_summary.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
    )
    return payload


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact-dir", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--last-complete-task", type=int, required=True)
    parser.add_argument("--expected-execution-commit", required=True)
    parser.add_argument("--expected-source-job", required=True)
    parser.add_argument("--continuation-execution-commit")
    parser.add_argument("--continuation-source-job")
    args = parser.parse_args(argv)
    if len(args.expected_execution_commit) != 40:
        parser.error("--expected-execution-commit must be a full 40-character SHA")
    if not str(args.expected_source_job).isdigit():
        parser.error("--expected-source-job must be numeric")
    continuation_values = (
        args.continuation_execution_commit,
        args.continuation_source_job,
    )
    if any(value is not None for value in continuation_values) and not all(
        value is not None for value in continuation_values
    ):
        parser.error(
            "--continuation-execution-commit and --continuation-source-job "
            "must be supplied together"
        )
    if args.continuation_execution_commit is not None and len(
        args.continuation_execution_commit
    ) != 40:
        parser.error("--continuation-execution-commit must be a full 40-character SHA")
    if args.continuation_source_job is not None and not str(
        args.continuation_source_job
    ).isdigit():
        parser.error("--continuation-source-job must be numeric")
    return args


def main(argv: Sequence[str] | None = None) -> int:
    print(json.dumps(run_analysis(parse_args(argv)), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
