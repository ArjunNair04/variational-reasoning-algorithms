#!/usr/bin/env python3
"""Analyse the preregistered L2R common-protocol structural factorial.

This analyser is frozen before outcomes are inspected.  The paired training
seed is the observational unit; checkpoints and validation questions are
repeated measurements within a seed.  The run can nominate development
configurations for fresh-seed confirmation, but cannot establish final method
superiority or license access to the official GSM8K test split.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import itertools
import json
import math
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:  # Support direct file execution.
    sys.path.insert(0, str(REPOSITORY_ROOT))

from analysis.analyze_barber_eos_repair import _require_validation_non_access
from analysis.analyze_barber_source_programme import paired_bootstrap, verify_mirror


SEEDS = (31, 47, 73)
BASE_CELL = "CTRL-base"
METHODS = ("VIN", "VOUT", "POLD", "PIS", "GRPO", "RLOO")
RESOURCE_LEVELS = {
    "S": (8, 16, 32),
    "B": (4, 8, 16),
    "U": (1, 2, 4),
}
CHECKPOINT_ROUNDS = (1, 2, 4, 8, 16, 24, 32)
ORIGINAL_LAST_COMPLETE_TASK = 236
CONTINUATION_FIRST_TASK = ORIGINAL_LAST_COMPLETE_TASK + 1
FINAL_TASK = 489
# The array wrappers proved the full commit before training; only the nested
# sweep helper's best-effort short-SHA probe returned ``unknown`` in these tasks.
KNOWN_COMMIT_EXCEPTIONS = {3: "unknown", 274: "unknown"}
CURVE_METRICS = {
    "extracted": "test_acc_legacy",
    "strict": "test_acc_strict",
    "natural_eos": "eval_natural_eos_fraction",
    "hit_max": "eval_hit_max_new_fraction",
    "multiple_marker": "eval_multiple_marker_fraction",
    "nonterminal_marker": "eval_nonterminal_marker_fraction",
    "format_failure": "eval_strict_format_failure_fraction",
}


def _finite_float(value: Any, *, context: str) -> float:
    if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
        raise ValueError(f"{context}: expected a finite number, found {value!r}")
    return float(value)


def _optional_float(value: Any, *, context: str) -> float:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return math.nan
    return _finite_float(value, context=context)


def _read_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _read_jsonl_gz(path: Path) -> list[dict[str, Any]]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _single_artifact(root: Path, pattern: str, context: str) -> Path:
    matches = sorted(root.glob(pattern))
    if len(matches) != 1:
        raise ValueError(
            f"{context}: expected one artifact matching {pattern!r}, found {len(matches)}"
        )
    return matches[0]


def _nested(payload: Mapping[str, Any], *keys: str) -> Any:
    value: Any = payload
    for key in keys:
        if not isinstance(value, Mapping):
            return None
        value = value.get(key)
    return value


def _finite_mean(values: Sequence[Any]) -> float:
    finite = [
        float(value)
        for value in values
        if isinstance(value, (int, float)) and math.isfinite(float(value))
    ]
    return float(np.mean(finite)) if finite else math.nan


def _normalized_auc(values: Sequence[float], rounds: Sequence[int]) -> float:
    values_array = np.asarray(values, dtype=float)
    rounds_array = np.asarray(rounds, dtype=float)
    if (
        len(values_array) != len(rounds_array)
        or len(values_array) < 2
        or not np.all(np.isfinite(values_array))
        or not np.all(np.diff(rounds_array) > 0)
        or rounds_array[0] != 0
        or rounds_array[-1] != 32
    ):
        raise ValueError("AUC requires finite, ordered round-0-to-32 observations")
    return float(np.trapezoid(values_array, rounds_array) / 32.0)


def _require_record_non_access(record: Mapping[str, Any], *, context: str) -> None:
    if record.get("official_test_accessed") is not False:
        raise ValueError(f"{context}: official-test non-access is not proven")
    if record.get("eval_source_split") != "train":
        raise ValueError(f"{context}: evaluation is not train-derived")
    if record.get("dataset_splits_loaded") != ["train"]:
        raise ValueError(f"{context}: loaded dataset splits are not ['train']")


def load_design(config_path: Path) -> tuple[dict[str, Any], pd.DataFrame]:
    """Load the exact 163-cell design and derive the common resource axes."""

    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(config, dict) or not str(config.get("run_id", "")):
        raise ValueError("configuration omits a run ID")
    defaults = dict(config.get("defaults") or {})
    diagnostic = dict(config.get("diagnostic") or {})
    fixed = dict(diagnostic.get("fixed_contract") or {})
    if defaults.get("seed_values") != list(SEEDS):
        raise ValueError("registered seed set changed")
    if defaults.get("eval_partition") != "validation":
        raise ValueError("evaluation must use the train-derived validation partition")
    if fixed.get("official_test_used") is not False:
        raise ValueError("configuration does not prohibit official-test use")
    if tuple(defaults.get("eval_rounds") or ()) != CHECKPOINT_ROUNDS:
        raise ValueError("checkpoint schedule changed")
    if int(defaults.get("rounds", -1)) != 32:
        raise ValueError("outer-round count changed")

    algos = config.get("algos") or {}
    rows: list[dict[str, Any]] = []
    base = dict(algos.get("base") or {})
    rows.append(
        {
            "cell": str(base.get("cell_id")),
            "method_family": "base",
            "trainer_method": "base",
            "S": math.nan,
            "B": math.nan,
            "U": math.nan,
            "planned_rollouts": 0,
        }
    )
    for trainer_method in ("AC-ALG1", "GRPO", "RLOO"):
        variants = algos.get(trainer_method) or []
        if not isinstance(variants, list):
            raise ValueError(f"{trainer_method}: variants must be a list")
        for variant in variants:
            cell = str(variant.get("cell_id"))
            family = cell.split("-", 1)[0]
            if family not in METHODS:
                raise ValueError(f"{cell}: unregistered method family")
            support = int(variant["G"])
            batch = int(variant["batch"])
            if batch % support:
                raise ValueError(f"{cell}: batch is not divisible by support size")
            questions = batch // support
            reuse = int(
                variant["iters"] if trainer_method == "AC-ALG1" else variant["epochs"]
            )
            rows.append(
                {
                    "cell": cell,
                    "method_family": family,
                    "trainer_method": trainer_method,
                    "S": support,
                    "B": questions,
                    "U": reuse,
                    "planned_rollouts": int(defaults["rounds"]) * batch,
                }
            )
    design = pd.DataFrame(rows)
    if len(design) != 163 or design["cell"].nunique() != 163:
        raise ValueError("design must contain 163 unique logical cells")
    if design.iloc[0]["cell"] != BASE_CELL:
        raise ValueError("frozen-control identity changed")
    trained = design[design["method_family"] != "base"]
    expected_coordinates = set(itertools.product(*RESOURCE_LEVELS.values()))
    for method in METHODS:
        subset = trained[trained["method_family"] == method]
        observed = set(zip(subset["S"], subset["B"], subset["U"], strict=True))
        if observed != expected_coordinates:
            raise ValueError(f"{method}: incomplete S-by-B-by-U factorial")
    return config, design


def _cell_seed_from_tag(tag: str, cells: Sequence[str]) -> tuple[str, int]:
    for cell in sorted(cells, key=len, reverse=True):
        marker = f"_{cell}_seed"
        if marker not in tag:
            continue
        suffix = tag.rsplit(marker, 1)[1]
        if suffix.isdigit():
            return cell, int(suffix)
    raise ValueError(f"cannot resolve registered cell and seed from tag {tag!r}")


def load_cell_results(
    artifact_dir: Path, design: pd.DataFrame, *, run_id: str
) -> pd.DataFrame:
    """Load terminal summaries and require complete paired cell/seed coverage."""

    cells = tuple(design["cell"].astype(str))
    rows: list[dict[str, Any]] = []
    for path in sorted(artifact_dir.glob("cell_result_*.json")):
        payload = _read_json(path)
        identity = payload.get("identity") or {}
        result = payload.get("result") or {}
        if str(identity.get("run_id")) != run_id or str(result.get("run_id")) != run_id:
            raise ValueError(f"{path.name}: run-ID mismatch")
        cell, seed = _cell_seed_from_tag(str(identity.get("tag")), cells)
        if int(identity.get("seed", -1)) != seed:
            raise ValueError(f"{path.name}: identity seed disagrees with tag")
        _require_validation_non_access(result, context=path.name, prefix="eval")
        _require_validation_non_access(result, context=path.name, prefix="passk")
        row: dict[str, Any] = {
            "cell": cell,
            "seed": seed,
            "tag": str(identity["tag"]),
            "seconds": _finite_float(result.get("secs"), context=f"{path.name}/secs"),
            "accelerator_hours": _optional_float(
                result.get("accelerator_hours"), context=f"{path.name}/accelerator_hours"
            ),
            "peak_cuda_reserved_gb": _optional_float(
                result.get("peak_cuda_reserved_gb"),
                context=f"{path.name}/peak_cuda_reserved_gb",
            ),
            "generated_tokens": _optional_float(
                result.get("generated_tokens"), context=f"{path.name}/generated_tokens"
            ),
            "backward_tokens": _optional_float(
                result.get("backward_tokens"), context=f"{path.name}/backward_tokens"
            ),
            "optimizer_steps": _optional_float(
                result.get("optimizer_steps"), context=f"{path.name}/optimizer_steps"
            ),
        }
        for metric, key in CURVE_METRICS.items():
            row[f"{metric}_result_final"] = _finite_float(
                result.get(key), context=f"{path.name}/{key}"
            )
        rows.append(row)
    table = pd.DataFrame(rows)
    expected = {(cell, seed) for cell in cells for seed in SEEDS}
    observed = set(zip(table.get("cell", []), table.get("seed", []), strict=True))
    if observed != expected:
        raise ValueError(
            f"cell/seed mismatch; missing={sorted(expected-observed)}, "
            f"extra={sorted(observed-expected)}"
        )
    if table.duplicated(["cell", "seed"]).any():
        raise ValueError("duplicate cell/seed terminal result")
    return table.sort_values(["cell", "seed"]).reset_index(drop=True)


def build_curves(
    artifact_dir: Path, cells: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build round-0-to-32 trajectories with each seed's paired frozen base."""

    base = cells[cells["cell"] == BASE_CELL].set_index("seed")
    points: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    for cell_row in cells.to_dict("records"):
        cell = str(cell_row["cell"])
        seed = int(cell_row["seed"])
        base_row = base.loc[seed]
        rounds = [0]
        series = {
            metric: [float(base_row[f"{metric}_result_final"])]
            for metric in CURVE_METRICS
        }
        if cell == BASE_CELL:
            rounds.extend(CHECKPOINT_ROUNDS)
            for metric in CURVE_METRICS:
                series[metric].extend(
                    [float(cell_row[f"{metric}_result_final"])]
                    * len(CHECKPOINT_ROUNDS)
                )
        else:
            path = _single_artifact(
                artifact_dir,
                f"checkpoint_eval_*__{cell_row['tag']}__*.jsonl.gz",
                f"{cell}/{seed}",
            )
            payloads = _read_jsonl_gz(path)
            observed_rounds = tuple(int(row.get("completed_rounds", -1)) for row in payloads)
            if observed_rounds != CHECKPOINT_ROUNDS:
                raise ValueError(f"{path.name}: checkpoint schedule mismatch")
            rounds.extend(observed_rounds)
            for checkpoint in payloads:
                records = checkpoint.get("records") or []
                if len(records) != 400:
                    raise ValueError(f"{path.name}: expected 400 checkpoint records")
                for index, record in enumerate(records):
                    _require_record_non_access(
                        record,
                        context=(
                            f"{path.name}/round{checkpoint['completed_rounds']}/record{index}"
                        ),
                    )
                metrics = checkpoint.get("metrics") or {}
                for metric, key in CURVE_METRICS.items():
                    series[metric].append(
                        _finite_float(
                            metrics.get(key),
                            context=f"{path.name}/round{checkpoint['completed_rounds']}/{key}",
                        )
                    )
        for metric in CURVE_METRICS:
            if not math.isclose(
                series[metric][-1],
                float(cell_row[f"{metric}_result_final"]),
                abs_tol=1e-12,
            ):
                raise ValueError(f"{cell}/{seed}: checkpoint and terminal {metric} disagree")
        for position, completed_rounds in enumerate(rounds):
            points.append(
                {
                    "cell": cell,
                    "seed": seed,
                    "completed_rounds": completed_rounds,
                    **{metric: values[position] for metric, values in series.items()},
                }
            )
        late_positions = [index for index, value in enumerate(rounds) if value >= 8]
        summary: dict[str, Any] = {"cell": cell, "seed": seed}
        for metric, values in series.items():
            summary[f"{metric}_auc"] = _normalized_auc(values, rounds)
            summary[f"{metric}_final"] = float(values[-1])
        summary["late_peak_extracted"] = float(
            max(series["extracted"][index] for index in late_positions)
        )
        summary["late_peak_to_final_extracted_drop"] = (
            summary["late_peak_extracted"] - summary["extracted_final"]
        )
        summaries.append(summary)
    return pd.DataFrame(points), pd.DataFrame(summaries)


def load_pass8(artifact_dir: Path, cells: pd.DataFrame) -> pd.DataFrame:
    """Derive pass@8 from per-question records and retain paired seed identity."""

    rows: list[dict[str, Any]] = []
    for row in cells.to_dict("records"):
        path = _single_artifact(
            artifact_dir,
            f"passk_gsm8k__{row['tag']}__*.json",
            f"{row['cell']}/{row['seed']}",
        )
        payload = _read_json(path)
        _require_validation_non_access(payload, context=path.name, prefix="passk")
        records = payload.get("records") or []
        if len(records) != 100 or any(record.get("k") != 8 for record in records):
            raise ValueError(f"{path.name}: expected 100 pass@8 question records")
        for index, record in enumerate(records):
            _require_record_non_access(record, context=f"{path.name}/record{index}")
        derived = float(np.mean([int(record.get("n_correct", 0)) > 0 for record in records]))
        reported = _finite_float(payload.get("pass8"), context=f"{path.name}/pass8")
        if not math.isclose(derived, reported, abs_tol=1e-12):
            raise ValueError(f"{path.name}: reported pass@8 disagrees with records")
        rows.append({"cell": row["cell"], "seed": row["seed"], "pass8_final": derived})
    return pd.DataFrame(rows)


def load_mechanisms(
    artifact_dir: Path, cells: pd.DataFrame, *, run_id: str
) -> pd.DataFrame:
    """Reduce method-specific diagnostics while preserving unavailable values."""

    rows: list[dict[str, Any]] = []
    trained = cells[cells["cell"] != BASE_CELL]
    for row in trained.to_dict("records"):
        path = _single_artifact(
            artifact_dir,
            f"training_diagnostics_*__{row['tag']}__*.jsonl.gz",
            f"{row['cell']}/{row['seed']}",
        )
        records = _read_jsonl_gz(path)
        if len(records) != 32:
            raise ValueError(f"{path.name}: expected 32 diagnostic rounds")
        completed = tuple(
            int(record.get("completed_rounds", int(record.get("round", -1)) + 1))
            for record in records
        )
        if completed != tuple(range(1, 33)):
            raise ValueError(f"{path.name}: diagnostic round schedule mismatch")
        if any(str(record.get("run_id")) != run_id for record in records):
            raise ValueError(f"{path.name}: diagnostic run-ID mismatch")
        ess = [
            _nested(
                record,
                "responsibilities",
                "partitions",
                "answer_only",
                "mean_effective_sample_size_fraction",
            )
            for record in records
        ]
        maxima = [
            _nested(
                record,
                "responsibilities",
                "partitions",
                "answer_only",
                "mean_max_responsibility",
            )
            for record in records
        ]
        correct_mass = [
            _nested(
                record,
                "responsibilities",
                "partitions",
                "answer_only",
                "mean_answer_correct_mass",
            )
            for record in records
        ]
        final = records[-1]
        rows.append(
            {
                "cell": row["cell"],
                "seed": row["seed"],
                "mean_ess_fraction": _finite_mean(ess),
                "final_ess_fraction": _optional_float(
                    ess[-1], context=f"{path.name}/final_ess"
                ),
                "mean_max_responsibility": _finite_mean(maxima),
                "final_max_responsibility": _optional_float(
                    maxima[-1], context=f"{path.name}/final_max_responsibility"
                ),
                "mean_correct_trace_mass": _finite_mean(correct_mass),
                "final_parameter_l2_drift": _optional_float(
                    _nested(final, "optimizer", "parameter_l2_drift_from_initial"),
                    context=f"{path.name}/parameter_l2_drift",
                ),
            }
        )
    return pd.DataFrame(rows)


def verify_provenance(
    artifact_dir: Path,
    config_path: Path,
    marker_path: Path,
    *,
    run_id: str,
    expected_commit: str,
    expected_source_job: str,
    expected_continuation_commit: str | None = None,
    expected_continuation_source_job: str | None = None,
) -> dict[str, Any]:
    """Bind the mirror to either one execution or the audited recovery union."""

    config_sha = hashlib.sha256(config_path.read_bytes()).hexdigest()
    marker = _read_json(marker_path)
    expected_common = {
        "status": "ok",
        "run_id": run_id,
        "configuration_sha256": config_sha,
    }
    for key, value in expected_common.items():
        if marker.get(key) != value:
            raise ValueError(f"validator marker {key} mismatch")

    schema_version = marker.get("schema_version")
    if schema_version == 1:
        if expected_continuation_commit or expected_continuation_source_job:
            raise ValueError("single-execution marker cannot bind a continuation")
        expected_marker = {
            "execution_commit": expected_commit,
            "source_job_id": expected_source_job,
        }
        task_segments = [(1, FINAL_TASK, expected_commit)]
    elif schema_version == 2:
        if not expected_continuation_commit or not expected_continuation_source_job:
            raise ValueError("recovery marker requires expected continuation provenance")
        expected_marker = {
            "execution_segments": [
                {
                    "source_job_id": expected_source_job,
                    "execution_commit": expected_commit,
                    "task_range": [1, ORIGINAL_LAST_COMPLETE_TASK],
                },
                {
                    "source_job_id": expected_continuation_source_job,
                    "execution_commit": expected_continuation_commit,
                    "task_range": [CONTINUATION_FIRST_TASK, FINAL_TASK],
                },
            ],
            "known_commit_exceptions": [
                {
                    "task_id": task_id,
                    "observed": observed,
                    "reconciled_by": (
                        "fail-closed array wrapper plus scheduler environment, "
                        "submission metadata and the union receipt/log audit"
                    ),
                }
                for task_id, observed in sorted(KNOWN_COMMIT_EXCEPTIONS.items())
            ],
            "interruption_recovery": {
                "original_terminal_tasks": [1, ORIGINAL_LAST_COMPLETE_TASK],
                "continuation_tasks": [CONTINUATION_FIRST_TASK, FINAL_TASK],
                "duplicated_completed_tasks": 0,
            },
        }
        task_segments = [
            (1, ORIGINAL_LAST_COMPLETE_TASK, expected_commit),
            (CONTINUATION_FIRST_TASK, FINAL_TASK, expected_continuation_commit),
        ]
    else:
        raise ValueError(f"unsupported validator marker schema {schema_version!r}")
    for key, value in expected_marker.items():
        if marker.get(key) != value:
            raise ValueError(f"validator marker {key} mismatch")

    _config, design = load_design(config_path)
    cells = tuple(design["cell"].astype(str))
    expected_tasks = {
        (cell, seed): cell_index * len(SEEDS) + seed_index + 1
        for cell_index, cell in enumerate(cells)
        for seed_index, seed in enumerate(SEEDS)
    }

    def expected_task_commit(task_id: int) -> str:
        for first, last, commit in task_segments:
            if first <= task_id <= last:
                return commit
        raise ValueError(f"task {task_id}: no registered execution segment")

    sweeps = sorted(artifact_dir.glob("sweep_*.csv"))
    if len(sweeps) != FINAL_TASK:
        raise ValueError(f"expected {FINAL_TASK} sweep files, found {len(sweeps)}")
    seen_fingerprints: set[str] = set()
    seen_tasks: set[int] = set()
    for path in sweeps:
        frame = pd.read_csv(path)
        if len(frame) != 1:
            raise ValueError(f"{path.name}: expected one sweep row")
        row = frame.iloc[0]
        if str(row.get("run_id")) != run_id:
            raise ValueError(f"{path.name}: run-ID mismatch")
        params_values = [
            value
            for value in frame.get("params", pd.Series(dtype=object)).tolist()
            if isinstance(value, str) and value.strip()
        ]
        if not params_values:
            raise ValueError(f"{path.name}: missing per-sweep parameter blob")
        params = json.loads(params_values[0])
        if str(params.get("run_id")) != run_id:
            raise ValueError(f"{path.name}: parameter run-ID mismatch")
        cell, seed = _cell_seed_from_tag(path.stem, cells)
        task_id = expected_tasks[(cell, seed)]
        if task_id in seen_tasks:
            raise ValueError(f"{path.name}: duplicate sweep for array task {task_id}")
        seen_tasks.add(task_id)
        observed_commit = str((params.get("env") or {}).get("commit", ""))
        task_commit = expected_task_commit(task_id)
        if task_id in KNOWN_COMMIT_EXCEPTIONS:
            if observed_commit != KNOWN_COMMIT_EXCEPTIONS[task_id]:
                raise ValueError(f"{path.name}: documented commit exception mismatch")
        elif not observed_commit or not task_commit.startswith(observed_commit):
            raise ValueError(f"{path.name}: execution commit mismatch")
        fingerprint = str(row.get("cell_fingerprint", ""))
        if not fingerprint:
            raise ValueError(f"{path.name}: missing cell fingerprint")
        seen_fingerprints.add(fingerprint)
    if seen_tasks != set(range(1, FINAL_TASK + 1)):
        raise ValueError("sweep array-task coverage is incomplete")
    if len(seen_fingerprints) != FINAL_TASK:
        raise ValueError("sweep cell fingerprints are not unique")
    return {
        "schema_version": schema_version,
        **expected_common,
        **expected_marker,
        "official_test_used": False,
        "official_test_non_access_verified": True,
    }


def _effect_record(
    *,
    effect_type: str,
    term: str,
    level: str,
    values: Sequence[float],
    draws: int,
    seed: int,
) -> dict[str, Any]:
    mean, low, high = paired_bootstrap(values, draws=draws, seed=seed)
    return {
        "effect_type": effect_type,
        "term": term,
        "level": level,
        "observational_unit": "paired training seed",
        "n_seeds": len(values),
        "mean_effect": mean,
        "ci95_low": low,
        "ci95_high": high,
        "mean_effect_pp": 100.0 * mean,
        "positive_seeds": int(np.sum(np.asarray(values) > 0)),
    }


def categorical_effects(
    summaries: pd.DataFrame,
    *,
    metric: str,
    bootstrap_draws: int,
    bootstrap_seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Estimate categorical main effects and all method-resource interactions."""

    trained = summaries[summaries["method_family"] != "base"].copy()
    main_rows: list[dict[str, Any]] = []
    offset = 0
    for factor, levels in {"method_family": METHODS, **RESOURCE_LEVELS}.items():
        for level in levels:
            values = []
            for seed in SEEDS:
                seed_rows = trained[trained["seed"] == seed]
                level_rows = seed_rows[seed_rows[factor] == level]
                values.append(float(level_rows[metric].mean() - seed_rows[metric].mean()))
            main_rows.append(
                _effect_record(
                    effect_type="categorical_main_effect",
                    term=factor,
                    level=str(level),
                    values=values,
                    draws=bootstrap_draws,
                    seed=bootstrap_seed + offset,
                )
            )
            offset += 1

    interaction_rows: list[dict[str, Any]] = []
    for factor, levels in RESOURCE_LEVELS.items():
        for method in METHODS:
            for level in levels:
                values = []
                for seed in SEEDS:
                    seed_rows = trained[trained["seed"] == seed]
                    joint = seed_rows[
                        (seed_rows["method_family"] == method)
                        & (seed_rows[factor] == level)
                    ][metric].mean()
                    method_mean = seed_rows[
                        seed_rows["method_family"] == method
                    ][metric].mean()
                    level_mean = seed_rows[seed_rows[factor] == level][metric].mean()
                    values.append(
                        float(joint - method_mean - level_mean + seed_rows[metric].mean())
                    )
                interaction_rows.append(
                    _effect_record(
                        effect_type="method_by_resource_interaction",
                        term=f"method_family:{factor}",
                        level=f"{method}:{level}",
                        values=values,
                        draws=bootstrap_draws,
                        seed=bootstrap_seed + offset,
                    )
                )
                offset += 1
    return pd.DataFrame(main_rows), pd.DataFrame(interaction_rows)


def matched_method_contrasts(
    summaries: pd.DataFrame,
    *,
    metric: str,
    bootstrap_draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Compare methods only at identical S, B and U coordinates."""

    indexed = summaries.set_index(["method_family", "S", "B", "U", "seed"])
    rows: list[dict[str, Any]] = []
    offset = 0
    for support, questions, reuse in itertools.product(*RESOURCE_LEVELS.values()):
        for left, right in itertools.combinations(METHODS, 2):
            differences = [
                float(
                    indexed.loc[(left, support, questions, reuse, seed), metric]
                    - indexed.loc[(right, support, questions, reuse, seed), metric]
                )
                for seed in SEEDS
            ]
            mean, low, high = paired_bootstrap(
                differences, draws=bootstrap_draws, seed=bootstrap_seed + offset
            )
            rows.append(
                {
                    "left_method": left,
                    "right_method": right,
                    "S": support,
                    "B": questions,
                    "U": reuse,
                    "metric": metric,
                    "observational_unit": "paired training seed",
                    "n_seeds": len(SEEDS),
                    "mean_difference": mean,
                    "ci95_low": low,
                    "ci95_high": high,
                    "mean_difference_pp": 100.0 * mean,
                    "positive_seeds": int(np.sum(np.asarray(differences) > 0)),
                }
            )
            offset += 1
    return pd.DataFrame(rows)


def candidate_gates(summaries: pd.DataFrame) -> pd.DataFrame:
    """Apply the frozen behavioural and stability gates to every trained cell."""

    base = summaries[summaries["cell"] == BASE_CELL].set_index("seed")
    rows: list[dict[str, Any]] = []
    trained = summaries[summaries["cell"] != BASE_CELL]
    for cell, group in trained.groupby("cell", sort=True):
        group = group.set_index("seed").reindex(SEEDS)
        if group.isna().all(axis=1).any():
            raise ValueError(f"{cell}: incomplete seed table")
        auc_delta = group["extracted_auc"] - base["extracted_auc"]
        final_delta = group["extracted_final"] - base["extracted_final"]
        eos_delta = group["natural_eos_final"] - base["natural_eos_final"]
        pass8_delta = group["pass8_final"] - base["pass8_final"]
        gates = {
            "auc_positive_in_at_least_two_seeds": int((auc_delta > 0).sum()) >= 2,
            "mean_final_extracted_not_below_base": float(final_delta.mean()) >= 0.0,
            "mean_late_peak_drop_at_most_3pp": float(
                group["late_peak_to_final_extracted_drop"].mean()
            )
            <= 0.03,
            "mean_natural_eos_drop_at_most_2pp": float(eos_delta.mean()) >= -0.02,
            "mean_pass8_drop_at_most_3pp": float(pass8_delta.mean()) >= -0.03,
            "all_primary_values_finite": bool(
                np.isfinite(
                    group[
                        [
                            "extracted_auc",
                            "extracted_final",
                            "strict_auc",
                            "strict_final",
                            "pass8_final",
                        ]
                    ].to_numpy(float)
                ).all()
            ),
        }
        first = group.iloc[0]
        rows.append(
            {
                "cell": cell,
                "method_family": first["method_family"],
                "S": int(first["S"]),
                "B": int(first["B"]),
                "U": int(first["U"]),
                "mean_extracted_auc": float(group["extracted_auc"].mean()),
                "se_extracted_auc": float(group["extracted_auc"].std(ddof=1) / np.sqrt(3)),
                "mean_extracted_auc_delta_pp": 100.0 * float(auc_delta.mean()),
                "positive_auc_seeds": int((auc_delta > 0).sum()),
                "mean_final_extracted_delta_pp": 100.0 * float(final_delta.mean()),
                "mean_strict_auc": float(group["strict_auc"].mean()),
                "mean_late_peak_drop_pp": 100.0
                * float(group["late_peak_to_final_extracted_drop"].mean()),
                "mean_natural_eos_delta_pp": 100.0 * float(eos_delta.mean()),
                "mean_pass8_delta_pp": 100.0 * float(pass8_delta.mean()),
                "mean_accelerator_hours": _finite_mean(
                    group["accelerator_hours"].tolist()
                ),
                "planned_rollouts": int(first["planned_rollouts"]),
                **gates,
                "passes_all_gates": all(gates.values()),
            }
        )
    return pd.DataFrame(rows)


def select_nominees(gates: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Apply a per-family one-standard-error, lower-compute selection rule."""

    annotated = gates.copy()
    annotated["within_one_se_of_family_best"] = False
    annotated["nominated"] = False
    nominees: list[str] = []
    for method in METHODS:
        eligible = annotated[
            (annotated["method_family"] == method) & annotated["passes_all_gates"]
        ]
        if eligible.empty:
            continue
        best = eligible.sort_values("mean_extracted_auc", ascending=False).iloc[0]
        threshold = float(best["mean_extracted_auc"] - best["se_extracted_auc"])
        candidates = eligible[eligible["mean_extracted_auc"] >= threshold].copy()
        annotated.loc[candidates.index, "within_one_se_of_family_best"] = True
        candidates["compute_missing"] = ~np.isfinite(
            candidates["mean_accelerator_hours"].to_numpy(float)
        )
        candidates["compute_sort"] = candidates["mean_accelerator_hours"].fillna(
            np.inf
        )
        selected = candidates.sort_values(
            ["compute_missing", "compute_sort", "planned_rollouts", "U", "S", "B"],
            ascending=True,
        ).iloc[0]
        annotated.loc[selected.name, "nominated"] = True
        nominees.append(str(selected["cell"]))
    return annotated, nominees


def compute_frontier(summaries: pd.DataFrame) -> pd.DataFrame:
    """Mark non-dominated cells for planned-rollout and measured-time cost."""

    trained = summaries[summaries["cell"] != BASE_CELL]
    aggregated = (
        trained.groupby(["cell", "method_family", "S", "B", "U"], as_index=False)
        .agg(
            mean_extracted_auc=("extracted_auc", "mean"),
            mean_accelerator_hours=("accelerator_hours", "mean"),
            planned_rollouts=("planned_rollouts", "first"),
        )
        .reset_index(drop=True)
    )

    def mark(cost_column: str) -> list[bool]:
        flags: list[bool] = []
        for row in aggregated.to_dict("records"):
            cost = float(row[cost_column])
            if not math.isfinite(cost):
                flags.append(False)
                continue
            dominated = False
            for other in aggregated.to_dict("records"):
                other_cost = float(other[cost_column])
                if not math.isfinite(other_cost):
                    continue
                if (
                    other_cost <= cost
                    and float(other["mean_extracted_auc"])
                    >= float(row["mean_extracted_auc"])
                    and (
                        other_cost < cost
                        or float(other["mean_extracted_auc"])
                        > float(row["mean_extracted_auc"])
                    )
                ):
                    dominated = True
                    break
            flags.append(not dominated)
        return flags

    aggregated["planned_rollout_frontier"] = mark("planned_rollouts")
    aggregated["accelerator_hour_frontier"] = mark("mean_accelerator_hours")
    return aggregated


def _markdown(table: pd.DataFrame) -> str:
    shown = table.copy()
    for column in shown.select_dtypes(include=["float"]).columns:
        shown[column] = shown[column].map(
            lambda value: "NA" if pd.isna(value) else f"{value:.3f}"
        )
    headers = [str(column) for column in shown.columns]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    lines.extend(
        "| " + " | ".join(map(str, row)) + " |"
        for row in shown.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def run_analysis(args: argparse.Namespace) -> dict[str, Any]:
    config_path = Path(args.config).resolve()
    artifact_dir = Path(args.artifact_dir).resolve()
    log_dir = Path(args.log_dir).resolve()
    out_dir = Path(args.out_dir).resolve()
    config, design = load_design(config_path)
    run_id = str(config["run_id"])
    provenance = verify_provenance(
        artifact_dir,
        config_path,
        Path(args.validator_marker).resolve(),
        run_id=run_id,
        expected_commit=args.expected_execution_commit,
        expected_source_job=args.expected_source_job,
        expected_continuation_commit=args.expected_continuation_execution_commit,
        expected_continuation_source_job=args.expected_continuation_source_job,
    )
    integrity = verify_mirror(
        artifact_dir, log_dir, expected_cells=489, trained_cells=486
    )
    if integrity["issues"]:
        raise ValueError(f"mirror verification failed: {integrity['issues']}")

    cells = load_cell_results(artifact_dir, design, run_id=run_id)
    curves, summaries = build_curves(artifact_dir, cells)
    summaries = summaries.merge(
        load_pass8(artifact_dir, cells), on=["cell", "seed"], validate="one_to_one"
    )
    summaries = summaries.merge(
        cells[
            [
                "cell",
                "seed",
                "seconds",
                "accelerator_hours",
                "peak_cuda_reserved_gb",
                "generated_tokens",
                "backward_tokens",
                "optimizer_steps",
            ]
        ],
        on=["cell", "seed"],
        validate="one_to_one",
    )
    summaries = summaries.merge(design, on="cell", validate="many_to_one")
    mechanisms = load_mechanisms(artifact_dir, cells, run_id=run_id).merge(
        design, on="cell", validate="many_to_one"
    )

    main_effects, interactions = categorical_effects(
        summaries,
        metric="extracted_auc",
        bootstrap_draws=args.bootstrap_draws,
        bootstrap_seed=args.bootstrap_seed,
    )
    matched = matched_method_contrasts(
        summaries,
        metric="extracted_auc",
        bootstrap_draws=args.bootstrap_draws,
        bootstrap_seed=args.bootstrap_seed + 1_000,
    )
    gates = candidate_gates(summaries)
    gates, nominees = select_nominees(gates)
    frontier = compute_frontier(summaries)

    out_dir.mkdir(parents=True, exist_ok=True)
    curves.to_csv(out_dir / "checkpoint_curves.csv", index=False)
    summaries.to_csv(out_dir / "seed_summary.csv", index=False)
    mechanisms.to_csv(out_dir / "mechanism_summary.csv", index=False)
    main_effects.to_csv(out_dir / "categorical_main_effects.csv", index=False)
    interactions.to_csv(out_dir / "method_resource_interactions.csv", index=False)
    matched.to_csv(out_dir / "matched_method_contrasts.csv", index=False)
    gates.to_csv(out_dir / "candidate_gates.csv", index=False)
    frontier.to_csv(out_dir / "compute_performance_frontier.csv", index=False)

    payload = {
        "run_id": run_id,
        "observational_unit": "paired training seed",
        "seeds": list(SEEDS),
        "primary_metric": "normalized extracted-answer accuracy AUC, rounds 0-32",
        "late_peak_window": [8, 16, 24, 32],
        "nominees": nominees,
        "maximum_one_nominee_per_method_family": True,
        "nominees_are_final_method_selections": False,
        "official_test_used": False,
        "provenance": provenance,
        "integrity": integrity,
    }
    (out_dir / "analysis_summary.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
    )
    selected_columns = [
        "cell",
        "method_family",
        "mean_extracted_auc",
        "mean_extracted_auc_delta_pp",
        "mean_strict_auc",
        "mean_late_peak_drop_pp",
        "mean_accelerator_hours",
        "passes_all_gates",
        "within_one_se_of_family_best",
        "nominated",
    ]
    report = [
        "# L2R Common-Protocol Structural Factorial",
        "",
        "The paired training seed is the independent unit. Method and resource effects are estimated before cell ranking; all direct method comparisons hold S, B and U fixed. The official GSM8K test split is not used.",
        "",
        "## Development Decisions",
        "",
        _markdown(gates[selected_columns]),
        "",
        f"Fresh-seed confirmation nominees: {nominees or 'none'}.",
        "These are development nominations, not final method selections.",
        "",
        "## Categorical Main Effects",
        "",
        _markdown(main_effects),
        "",
        "## Method-by-Resource Interactions",
        "",
        _markdown(interactions),
        "",
    ]
    (out_dir / "analysis.md").write_text("\n".join(report), encoding="utf-8")
    return payload


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact-dir", required=True)
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--validator-marker", required=True)
    parser.add_argument("--expected-execution-commit", required=True)
    parser.add_argument("--expected-source-job", required=True)
    parser.add_argument("--expected-continuation-execution-commit")
    parser.add_argument("--expected-continuation-source-job")
    parser.add_argument("--bootstrap-draws", type=int, default=20_000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260804)
    args = parser.parse_args(argv)
    if args.bootstrap_draws < 1:
        parser.error("--bootstrap-draws must be positive")
    if len(args.expected_execution_commit) != 40:
        parser.error("--expected-execution-commit must be a full 40-character SHA")
    if not str(args.expected_source_job).isdigit():
        parser.error("--expected-source-job must be numeric")
    continuation_values = (
        args.expected_continuation_execution_commit,
        args.expected_continuation_source_job,
    )
    if any(continuation_values) and not all(continuation_values):
        parser.error("continuation commit and source job must be provided together")
    if args.expected_continuation_execution_commit:
        if len(args.expected_continuation_execution_commit) != 40:
            parser.error(
                "--expected-continuation-execution-commit must be a full "
                "40-character SHA"
            )
        if not str(args.expected_continuation_source_job).isdigit():
            parser.error("--expected-continuation-source-job must be numeric")
    return args


def main(argv: Sequence[str] | None = None) -> int:
    print(json.dumps(run_analysis(parse_args(argv)), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
