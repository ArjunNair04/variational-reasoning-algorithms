"""Analyze a matched AC-ALG1 numerical-rationale study.

The observational unit for accuracy contrasts is one held-out GSM8K question,
paired by ``(seed, idx)``. Mechanism summaries use the last N completed outer
rounds from each cell's versioned training diagnostics.

Example:
    python analysis/analyze_ac_alg1_numerical_study.py ~/po_results \
      --prefix q3_alg1_num_20260721c \
      --config lm_study/experiments_qwen3_17b_ac_alg1_full_numerical_study.yaml \
      --write-dir ../results/qwen3_ac_alg1_numerical_study
"""
from __future__ import annotations

import argparse
import gzip
import json
import math
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
LM_STUDY = ROOT / "lm_study"
if str(LM_STUDY) not in sys.path:
    sys.path.insert(0, str(LM_STUDY))


def _params_from_frame(frame: pd.DataFrame) -> dict:
    """Parse the first non-empty per-file params blob."""

    if "params" not in frame:
        return {}
    blobs = frame["params"].dropna()
    return json.loads(blobs.iloc[0]) if not blobs.empty else {}


def _method_config(params: dict, method: str = "AC-ALG1") -> dict:
    return dict(params.get("methods", {}).get(method, {}))


def _read_jsonl_gz(path: Path) -> list[dict]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _artifact_dir(result_dir: Path, artifact_type: str) -> Path:
    """Use an indexed artifact subdirectory when present, else a flat result root."""

    candidate = result_dir / artifact_type
    return candidate if candidate.is_dir() else result_dir


def _mean(values) -> float | None:
    finite = [float(value) for value in values if value is not None and math.isfinite(float(value))]
    return float(np.mean(finite)) if finite else None


def _arm_description(config: dict) -> str:
    parts = [
        str(config.get("labelled_supervision", "gold")),
        f"Bprime={config.get('labelled_em_weight', 1.0):g}",
        f"phi={config.get('labelled_numeric_constraint', 'off')}",
    ]
    if float(config.get("numeric_contradiction_penalty", 0.0)):
        parts.append(f"contra={config['numeric_contradiction_penalty']:g}")
    if float(config.get("numeric_missing_penalty", 0.0)):
        parts.append(f"miss={config['numeric_missing_penalty']:g}")
    if float(config.get("digit_token_weight", 1.0)) != 1.0:
        parts.append(f"digit={config['digit_token_weight']:g}")
    if config.get("trace_representation", "reasoning") != "reasoning":
        parts.append(str(config["trace_representation"]))
    return "; ".join(parts)


def _tag_to_arm(config_path: Path | None) -> dict[str, str]:
    if config_path is None:
        return {}
    import yaml
    from run_yaml import _cells

    with config_path.open() as handle:
        config = yaml.safe_load(handle)
    declared_cell_ids = {
        str(variant["cell_id"])
        for method_spec in (config.get("algos") or {}).values()
        for variant in (
            method_spec if isinstance(method_spec, list) else [method_spec or {}]
        )
        if isinstance(variant, dict) and variant.get("cell_id") is not None
    }
    mapping = {}
    for index, (_model, _method, _axes, tag) in enumerate(
        _cells(config, None, config["run_id"])
    ):
        explicit = next(
            (
                cell_id for cell_id in sorted(
                    declared_cell_ids,
                    key=lambda value: (-len(value), value),
                )
                if tag.endswith(f"_{cell_id}")
            ),
            None,
        )
        mapping[tag] = explicit or f"C{index}"
    return mapping


def _mechanism_summary(records: list[dict], final_rounds: int) -> dict:
    window = records[-final_rounds:]
    labelled = [
        record.get("responsibilities", {}).get("partitions", {}).get("labelled", {})
        for record in window
    ]
    answer_only = [
        record.get("responsibilities", {}).get("partitions", {}).get(
            "answer_only", {}
        )
        for record in window
    ]
    responsibilities = [
        record.get("responsibilities", {}) for record in window
    ]
    objective = [record.get("objective", {}) for record in window]
    optimizer = [record.get("optimizer", {}) for record in window]
    generation_filter = [
        record.get("generation", {}).get("filter", {}) for record in window
    ]
    gradient_geometry = [record.get("gradient_geometry", {}) for record in window]
    return {
        "diag_rounds": len(records),
        "gold_mass": _mean(item.get("mean_gold_mass") for item in labelled),
        "gold_top1": _mean(item.get("gold_top1_fraction") for item in labelled),
        "responsibility_ess_fraction": _mean(
            item.get("mean_effective_sample_size_fraction") for item in labelled
        ),
        "responsibility_max": _mean(
            item.get("mean_max_responsibility") for item in labelled
        ),
        "responsibility_normalized_entropy": _mean(
            item.get("mean_normalized_entropy") for item in labelled
        ),
        "responsibility_weighted_age": _mean(
            item.get("mean_responsibility_weighted_age") for item in labelled
        ),
        "counterfactual_joint_gold_mass": _mean(
            item.get("counterfactuals", {}).get("joint_tau1", {}).get("mean_gold_mass")
            for item in labelled
        ),
        "counterfactual_joint_ess_fraction": _mean(
            item.get("counterfactuals", {})
            .get("joint_tau1", {})
            .get("mean_effective_sample_size_fraction")
            for item in labelled
        ),
        "counterfactual_token_mean_gold_mass": _mean(
            item.get("counterfactuals", {})
            .get("token_mean_tau1", {})
            .get("mean_gold_mass")
            for item in labelled
        ),
        "counterfactual_token_mean_ess_fraction": _mean(
            item.get("counterfactuals", {})
            .get("token_mean_tau1", {})
            .get("mean_effective_sample_size_fraction")
            for item in labelled
        ),
        "answer_only_responsibility_ess_fraction": _mean(
            item.get("mean_effective_sample_size_fraction")
            for item in answer_only
        ),
        "answer_only_responsibility_max": _mean(
            item.get("mean_max_responsibility") for item in answer_only
        ),
        "answer_only_responsibility_weighted_age": _mean(
            item.get("mean_responsibility_weighted_age")
            for item in answer_only
        ),
        "inter_refresh_total_variation": _mean(
            item.get("inter_refresh_total_variation_mean")
            for item in responsibilities
        ),
        "gold_mass_before_phi": _mean(
            item.get("mean_gold_mass_before_potential") for item in labelled
        ),
        "gold_mass_delta_phi": _mean(
            item.get("mean_gold_mass_change_from_potential") for item in labelled
        ),
        "phi_total_variation": _mean(
            item.get("mean_responsibility_total_variation_from_potential")
            for item in labelled
        ),
        "numeric_valid_mass": _mean(
            item.get("mean_numeric_valid_mass") for item in labelled
        ),
        "numeric_invalid_mass": _mean(
            item.get("mean_numeric_invalid_mass") for item in labelled
        ),
        "numeric_unparsed_mass": _mean(
            item.get("mean_numeric_unparsed_mass") for item in labelled
        ),
        "numeric_hard_rejected_traces": _mean(
            item.get("numeric_hard_rejected_traces") for item in labelled
        ),
        "graph_node_coverage": _mean(
            item.get("mean_numeric_graph_node_coverage") for item in labelled
        ),
        "graph_edge_coverage": _mean(
            item.get("mean_numeric_graph_edge_coverage") for item in labelled
        ),
        "structured_well_formed": _mean(
            item.get("mean_structured_well_formed_fraction") for item in labelled
        ),
        "B_sup": _mean(item.get("B_sup") for item in objective),
        "B_prime_unsup": _mean(item.get("B_prime_unsup") for item in objective),
        "B_unsup": _mean(item.get("B_unsup") for item in objective),
        "proposal_acceptance": _mean(
            item.get("acceptance_fraction") for item in generation_filter
        ),
        "parameter_l2_drift_from_initial": _mean(
            item.get("parameter_l2_drift_from_initial") for item in optimizer
        ),
        "grad_cos_Bsup_Bprime": _mean(
            item.get("cosines", {}).get("B_sup__B_prime_unsup")
            for item in gradient_geometry
        ),
        "grad_cos_Bsup_Bunsup": _mean(
            item.get("cosines", {}).get("B_sup__B_unsup")
            for item in gradient_geometry
        ),
        "update_direction_norm": _mean(
            item.get("update_direction_norm") for item in objective
        ),
        "update_B_sup_coefficient": _mean(
            item.get("update_B_sup_coefficient") for item in objective
        ),
        "update_B_prime_unsup_coefficient": _mean(
            item.get("update_B_prime_unsup_coefficient") for item in objective
        ),
        "update_B_unsup_coefficient": _mean(
            item.get("update_B_unsup_coefficient") for item in objective
        ),
        "safeguard_acceptance_fraction": _mean(
            item.get("safeguard_acceptance_fraction") for item in objective
        ),
        "accepted_step_scale": _mean(
            item.get("accepted_step_scale") for item in objective
        ),
        "accepted_surrogate_total_delta": _mean(
            item.get("accepted_surrogate_total_delta") for item in objective
        ),
        "rollback_fraction": (
            (
                sum(float(item.get("rolled_back_candidates", 0.0)) for item in objective)
                / sum(float(item.get("candidate_steps", 0.0)) for item in objective)
            )
            if sum(float(item.get("candidate_steps", 0.0)) for item in objective) > 0
            else None
        ),
    }


def load_cells(
    result_dir: Path,
    prefix: str,
    config_path: Path | None,
    final_rounds: int,
) -> tuple[pd.DataFrame, dict[tuple[str, int], dict]]:
    """Load one row per completed cell and its held-out records."""

    arm_by_tag = _tag_to_arm(config_path)
    rows: list[dict] = []
    evaluations: dict[tuple[str, int], dict] = {}
    pattern = f"sweep_gsm8k__{prefix}*.csv"
    sweep_dir = _artifact_dir(result_dir, "sweeps")
    diagnostics_dir = _artifact_dir(result_dir, "training_diagnostics")
    evaluation_dir = _artifact_dir(result_dir, "evaluations")
    for csv_path in sorted(sweep_dir.glob(pattern)):
        frame = pd.read_csv(csv_path)
        if frame.empty:
            continue
        params = _params_from_frame(frame)
        config = _method_config(params)
        for _, result in frame.iterrows():
            if result.get("method") != "AC-ALG1":
                continue
            raw_tag = result.get("tag")
            tag = (
                raw_tag
                if isinstance(raw_tag, str) and raw_tag
                else csv_path.stem.split("__", 1)[-1]
            )
            seed = int(result.get("seed", 0))
            arm = arm_by_tag.get(tag)
            if arm is None:
                arm = arm_by_tag.get(re.sub(r"_seed\d+$", "", tag), "")
            row = {
                "arm": arm,
                "description": _arm_description(config),
                "tag": tag,
                "seed": seed,
                "test_acc": result.get("test_acc"),
                "pass1": result.get("pass1"),
                "pass8": result.get("pass8"),
                "runtime_s": result.get("secs"),
                "vram_gb": result.get("vram_gb"),
                "rounds": params.get("sweep", {}).get("rounds"),
                "batch": params.get("sweep", {}).get("B"),
                "G": params.get("sweep", {}).get("G"),
            }
            diagnostics_path = diagnostics_dir / (
                f"training_diagnostics_gsm8k__{tag}__AC-ALG1_s{seed}.jsonl.gz"
            )
            if diagnostics_path.exists():
                row.update(_mechanism_summary(
                    _read_jsonl_gz(diagnostics_path), final_rounds
                ))
            eval_path = evaluation_dir / f"eval_gsm8k__{tag}__AC-ALG1_s{seed}.json"
            if eval_path.exists():
                evaluation = json.loads(eval_path.read_text())
                evaluations[(tag, seed)] = evaluation
                eval_records = evaluation.get("records", [])
                row["eval_mean_tokens"] = _mean(record.get("len") for record in eval_records)
                row["eval_cap_fraction"] = _mean(
                    int(record.get("len", 0) >= 256) for record in eval_records
                )
                row["eval_mean_rep4"] = _mean(record.get("rep4") for record in eval_records)
            rows.append(row)

    table = pd.DataFrame(rows)
    if not table.empty:
        table["arm_order"] = table["arm"].str.extract(r"(\d+)", expand=False).fillna(999).astype(int)
        table = table.sort_values(["arm_order", "seed", "tag"]).drop(columns="arm_order")
    return table, evaluations


def load_checkpoint_trajectories(
    result_dir: Path,
    table: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[tuple[str, int, int], dict]]:
    checkpoint_dir = _artifact_dir(result_dir, "checkpoint_evaluations")
    rows = []
    evaluations = {}
    for _, cell in table.iterrows():
        path = checkpoint_dir / (
            f"checkpoint_eval_gsm8k__{cell['tag']}__AC-ALG1_s{int(cell['seed'])}.jsonl.gz"
        )
        if not path.exists():
            continue
        for record in _read_jsonl_gz(path):
            completed_rounds = int(record["completed_rounds"])
            evaluations[(cell["tag"], int(cell["seed"]), completed_rounds)] = record
            eval_records = record.get("records", [])
            rows.append({
                "arm": cell["arm"],
                "seed": int(cell["seed"]),
                "completed_rounds": completed_rounds,
                "test_acc": record.get("metrics", {}).get("test_acc"),
                "mean_tokens": _mean(item.get("len") for item in eval_records),
                "cap_fraction": _mean(
                    int(item.get("len", 0) >= 256) for item in eval_records
                ),
                "mean_rep4": _mean(item.get("rep4") for item in eval_records),
            })
    table = (
        pd.DataFrame(rows).sort_values(["seed", "arm", "completed_rounds"])
        if rows
        else pd.DataFrame()
    )
    return table, evaluations


def checkpoint_selection_summary(
    trajectories: pd.DataFrame,
    candidate_rounds: list[int],
    expected_seeds: int,
    preferred_arm: str,
) -> pd.DataFrame:
    """Apply the prespecified mean-validation checkpoint selection rule."""

    if trajectories.empty:
        return pd.DataFrame()
    candidates = trajectories[
        trajectories["completed_rounds"].isin(candidate_rounds)
    ]
    if candidates.empty:
        return pd.DataFrame()
    summary = (
        candidates.groupby(["arm", "completed_rounds"], as_index=False)
        .agg(
            n_seeds=("seed", "nunique"),
            mean_validation_accuracy=("test_acc", "mean"),
            std_validation_accuracy=("test_acc", "std"),
            min_validation_accuracy=("test_acc", "min"),
            max_validation_accuracy=("test_acc", "max"),
        )
    )
    summary = summary[summary["n_seeds"] == expected_seeds].copy()
    if summary.empty:
        return summary
    summary["preferred_arm_tie_break"] = (summary["arm"] != preferred_arm).astype(int)
    summary = summary.sort_values(
        [
            "mean_validation_accuracy",
            "completed_rounds",
            "preferred_arm_tie_break",
            "arm",
        ],
        ascending=[False, True, True, True],
    ).reset_index(drop=True)
    summary["selected"] = False
    summary.loc[0, "selected"] = True
    return summary.drop(columns="preferred_arm_tie_break")


def _exact_mcnemar_p(b: int, c: int) -> float:
    """Two-sided exact sign-test p-value over discordant paired outcomes."""

    n = b + c
    if n == 0:
        return 1.0
    lower = sum(math.comb(n, k) for k in range(min(b, c) + 1)) / (2 ** n)
    return min(1.0, 2.0 * lower)


def _paired_bootstrap_interval(
    differences: np.ndarray,
    draws: int,
    seed: int,
) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    n = len(differences)
    if not n:
        return float("nan"), float("nan")
    means = np.empty(draws, dtype=float)
    for start in range(0, draws, 1000):
        stop = min(start + 1000, draws)
        indices = rng.integers(0, n, size=(stop - start, n))
        means[start:stop] = differences[indices].mean(axis=1)
    return tuple(float(value) for value in np.quantile(means, [0.025, 0.975]))


def paired_contrasts(
    table: pd.DataFrame,
    evaluations: dict[tuple[str, int], dict],
    control_arm: str,
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Compare every arm with the matched control on held-out questions."""

    if table.empty or control_arm not in set(table["arm"]):
        return pd.DataFrame()
    rows = []
    for seed in sorted(table["seed"].unique()):
        controls = table[(table["arm"] == control_arm) & (table["seed"] == seed)]
        if controls.empty:
            continue
        control_tag = controls.iloc[0]["tag"]
        control_eval = evaluations.get((control_tag, int(seed)))
        if not control_eval:
            continue
        control = {record["idx"]: bool(record["correct"])
                   for record in control_eval.get("records", [])}
        for _, cell in table[table["seed"] == seed].iterrows():
            candidate_eval = evaluations.get((cell["tag"], int(seed)))
            if not candidate_eval:
                continue
            candidate = {record["idx"]: bool(record["correct"])
                         for record in candidate_eval.get("records", [])}
            shared = sorted(set(control) & set(candidate))
            if not shared:
                continue
            base_values = np.array([control[index] for index in shared], dtype=float)
            candidate_values = np.array([candidate[index] for index in shared], dtype=float)
            differences = candidate_values - base_values
            fixed = int(np.sum((candidate_values == 1) & (base_values == 0)))
            broke = int(np.sum((candidate_values == 0) & (base_values == 1)))
            low, high = _paired_bootstrap_interval(
                differences, draws=draws, seed=bootstrap_seed + int(seed)
            )
            rows.append({
                "arm": cell["arm"],
                "seed": int(seed),
                "n_paired": len(shared),
                "accuracy_difference": float(differences.mean()),
                "ci95_low": low,
                "ci95_high": high,
                "fixed_vs_control": fixed,
                "broke_vs_control": broke,
                "mcnemar_exact_p": _exact_mcnemar_p(fixed, broke),
            })
    return pd.DataFrame(rows).sort_values(["seed", "arm"])


def load_reference_outcomes(path: Path, condition: str) -> dict[int, bool]:
    records = _read_jsonl_gz(path)
    return {
        int(record["idx"]): bool(record["correct"])
        for record in records
        if record.get("condition") == condition
    }


def paired_reference_contrasts(
    table: pd.DataFrame,
    evaluations: dict[tuple[str, int], dict],
    reference: dict[int, bool],
    reference_name: str,
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    """Compare every cell with an external reference on shared held-out questions."""

    rows = []
    for _, cell in table.iterrows():
        seed = int(cell["seed"])
        candidate_eval = evaluations.get((cell["tag"], seed))
        if not candidate_eval:
            continue
        candidate = {
            int(record["idx"]): bool(record["correct"])
            for record in candidate_eval.get("records", [])
        }
        shared = sorted(set(reference) & set(candidate))
        if not shared:
            continue
        reference_values = np.array([reference[index] for index in shared], dtype=float)
        candidate_values = np.array([candidate[index] for index in shared], dtype=float)
        differences = candidate_values - reference_values
        fixed = int(np.sum((candidate_values == 1) & (reference_values == 0)))
        broke = int(np.sum((candidate_values == 0) & (reference_values == 1)))
        low, high = _paired_bootstrap_interval(
            differences,
            draws=draws,
            seed=bootstrap_seed + seed,
        )
        rows.append({
            "arm": cell["arm"],
            "seed": seed,
            "reference": reference_name,
            "n_paired": len(shared),
            "accuracy_difference": float(differences.mean()),
            "ci95_low": low,
            "ci95_high": high,
            "fixed_vs_reference": fixed,
            "broke_vs_reference": broke,
            "mcnemar_exact_p": _exact_mcnemar_p(fixed, broke),
        })
    return pd.DataFrame(rows).sort_values(["seed", "arm"]) if rows else pd.DataFrame()


def paired_checkpoint_reference_contrasts(
    table: pd.DataFrame,
    checkpoint_evaluations: dict[tuple[str, int, int], dict],
    reference: dict[int, bool],
    reference_name: str,
    draws: int,
    bootstrap_seed: int,
) -> pd.DataFrame:
    rows = []
    for _, cell in table.iterrows():
        seed = int(cell["seed"])
        checkpoints = sorted(
            (rounds, evaluation)
            for (tag, checkpoint_seed, rounds), evaluation in checkpoint_evaluations.items()
            if tag == cell["tag"] and checkpoint_seed == seed
        )
        for completed_rounds, evaluation in checkpoints:
            candidate = {
                int(record["idx"]): bool(record["correct"])
                for record in evaluation.get("records", [])
            }
            shared = sorted(set(reference) & set(candidate))
            if not shared:
                continue
            reference_values = np.array([reference[index] for index in shared], dtype=float)
            candidate_values = np.array([candidate[index] for index in shared], dtype=float)
            differences = candidate_values - reference_values
            fixed = int(np.sum((candidate_values == 1) & (reference_values == 0)))
            broke = int(np.sum((candidate_values == 0) & (reference_values == 1)))
            low, high = _paired_bootstrap_interval(
                differences,
                draws=draws,
                seed=bootstrap_seed + seed + completed_rounds,
            )
            rows.append({
                "arm": cell["arm"],
                "seed": seed,
                "completed_rounds": completed_rounds,
                "reference": reference_name,
                "n_paired": len(shared),
                "accuracy_difference": float(differences.mean()),
                "ci95_low": low,
                "ci95_high": high,
                "fixed_vs_reference": fixed,
                "broke_vs_reference": broke,
                "mcnemar_exact_p": _exact_mcnemar_p(fixed, broke),
            })
    return (
        pd.DataFrame(rows).sort_values(["seed", "arm", "completed_rounds"])
        if rows
        else pd.DataFrame()
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("result_dir", type=Path)
    parser.add_argument("--prefix", required=True, help="cell-tag prefix, including run id")
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--control-arm", default="C0")
    parser.add_argument("--final-rounds", type=int, default=10)
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260721)
    parser.add_argument("--reference-records", type=Path, default=None)
    parser.add_argument("--reference-condition", default="four_shot")
    parser.add_argument("--write-dir", type=Path, default=None)
    args = parser.parse_args()
    if args.final_rounds < 1 or args.bootstrap_draws < 1:
        parser.error("--final-rounds and --bootstrap-draws must be positive")

    table, evaluations = load_cells(
        args.result_dir.expanduser(),
        args.prefix,
        args.config,
        args.final_rounds,
    )
    checkpoint_trajectories, checkpoint_evaluations = load_checkpoint_trajectories(
        args.result_dir.expanduser(),
        table,
    )
    checkpoint_selection = pd.DataFrame()
    if args.config is not None:
        import yaml

        with args.config.open() as handle:
            experiment_config = yaml.safe_load(handle)
        selection = experiment_config.get("selection") or {}
        if selection:
            checkpoint_selection = checkpoint_selection_summary(
                checkpoint_trajectories,
                [int(value) for value in selection["candidate_rounds"]],
                int(experiment_config["defaults"]["seeds"]),
                str(selection.get("preferred_arm", "C0")),
            )
    contrasts = paired_contrasts(
        table,
        evaluations,
        args.control_arm,
        args.bootstrap_draws,
        args.bootstrap_seed,
    )
    reference_contrasts = pd.DataFrame()
    checkpoint_reference_contrasts = pd.DataFrame()
    if args.reference_records is not None:
        reference = load_reference_outcomes(
            args.reference_records.expanduser(),
            args.reference_condition,
        )
        reference_contrasts = paired_reference_contrasts(
            table,
            evaluations,
            reference,
            args.reference_condition,
            args.bootstrap_draws,
            args.bootstrap_seed,
        )
        checkpoint_reference_contrasts = paired_checkpoint_reference_contrasts(
            table,
            checkpoint_evaluations,
            reference,
            args.reference_condition,
            args.bootstrap_draws,
            args.bootstrap_seed,
        )

    pd.set_option("display.width", 260)
    pd.set_option("display.max_columns", None)
    pd.set_option("display.max_colwidth", 80)
    print("=== CELL AND MECHANISM SUMMARY ===")
    print(table.to_string(index=False) if not table.empty else "No completed cells found.")
    print("\n=== PAIRED HELD-OUT CONTRASTS ===")
    print(contrasts.to_string(index=False) if not contrasts.empty else "No paired eval records found.")
    print("\n=== CHECKPOINT TRAJECTORIES ===")
    print(
        checkpoint_trajectories.to_string(index=False)
        if not checkpoint_trajectories.empty
        else "No checkpoint evaluation records found."
    )
    if args.config is not None and selection:
        print("\n=== PRESPECIFIED CHECKPOINT SELECTION ===")
        print(
            checkpoint_selection.to_string(index=False)
            if not checkpoint_selection.empty
            else "No arm/checkpoint has all configured seeds yet."
        )
    if args.reference_records is not None:
        print("\n=== PAIRED EXTERNAL-REFERENCE CONTRASTS ===")
        print(
            reference_contrasts.to_string(index=False)
            if not reference_contrasts.empty
            else "No shared external-reference records found."
        )
        print("\n=== PAIRED CHECKPOINT-REFERENCE CONTRASTS ===")
        print(
            checkpoint_reference_contrasts.to_string(index=False)
            if not checkpoint_reference_contrasts.empty
            else "No shared checkpoint-reference records found."
        )

    if args.write_dir is not None:
        args.write_dir.mkdir(parents=True, exist_ok=True)
        table.to_csv(args.write_dir / "cell_mechanism_summary.csv", index=False)
        contrasts.to_csv(args.write_dir / "paired_accuracy_contrasts.csv", index=False)
        checkpoint_trajectories.to_csv(
            args.write_dir / "checkpoint_trajectories.csv",
            index=False,
        )
        if args.config is not None and selection:
            checkpoint_selection.to_csv(
                args.write_dir / "checkpoint_selection.csv",
                index=False,
            )
        if args.reference_records is not None:
            reference_contrasts.to_csv(
                args.write_dir / "paired_reference_contrasts.csv",
                index=False,
            )
            checkpoint_reference_contrasts.to_csv(
                args.write_dir / "paired_checkpoint_reference_contrasts.csv",
                index=False,
            )


if __name__ == "__main__":
    main()
