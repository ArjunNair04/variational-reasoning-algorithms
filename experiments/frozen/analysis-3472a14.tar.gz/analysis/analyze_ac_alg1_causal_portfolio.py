"""Analyse the preregistered fresh-seed AC-ALG1 causal portfolio.

The primary unit is a held-out GSM8K question paired within training seed.
Trajectory AUC is integrated over cumulative training generations, includes
the paired frozen model at generation zero, and never treats checkpoints as
independent replicates.  Intervals use a crossed seed-by-question bootstrap:
training seeds and the shared held-out question set are resampled independently.

Examples
--------
Early-horizon replication::

    python analysis/analyze_ac_alg1_causal_portfolio.py \
      --study early \
      --input lm_study/experiments_qwen3_17b_ac_alg1_early_horizon_replication.yaml \
              ~/po_results/2026-07-24/causal-portfolio/qwen3-early-horizon__20260724c

Feedback and EM-cycle factorials (the early study supplies the shared base)::

    python analysis/analyze_ac_alg1_causal_portfolio.py \
      --study causal \
      --input lm_study/experiments_qwen3_17b_ac_alg1_early_horizon_replication.yaml <early-dir> \
      --input lm_study/experiments_qwen3_17b_ac_alg1_feedback_factorial.yaml <feedback-dir> \
      --input lm_study/experiments_qwen3_17b_ac_alg1_em_cycle_factorial.yaml <cycle-dir>
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
import sys
from collections.abc import Iterable, Sequence
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
LM_STUDY = ROOT / "lm_study"
if str(LM_STUDY) not in sys.path:
    sys.path.insert(0, str(LM_STUDY))

from run_yaml import _cells  # noqa: E402


DIAGNOSTICS_SCHEMA = (
    ROOT / "analysis" / "schemas" / "training_diagnostics.schema.json"
)
_DIAGNOSTICS_VALIDATOR = None


def _artifact_dir(result_dir: Path, artifact_type: str) -> Path:
    candidate = result_dir / artifact_type
    return candidate if candidate.is_dir() else result_dir


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _read_jsonl_gz(path: Path) -> list[dict]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _configured_seed_values(config: dict) -> tuple[int, ...]:
    defaults = config.get("defaults") or {}
    configured = int(defaults.get("seeds", 1))
    values = defaults.get("seed_values")
    if values is None:
        return tuple(range(configured))
    values = tuple(int(value) for value in values)
    if len(values) != configured or len(set(values)) != len(values):
        raise ValueError("seed_values must be unique and match defaults.seeds")
    return values


def _explicit_cell_ids(config: dict) -> set[str]:
    return {
        str(variant["cell_id"])
        for method_spec in (config.get("algos") or {}).values()
        for variant in (
            method_spec if isinstance(method_spec, list) else [method_spec or {}]
        )
        if isinstance(variant, dict) and variant.get("cell_id") is not None
    }


def _cell_id(tag: str, method: str, explicit_ids: set[str]) -> str:
    matches = [
        value for value in explicit_ids if tag.endswith(f"_{value}")
    ]
    if len(matches) > 1:
        matches.sort(key=lambda value: (-len(value), value))
        if not matches[0].endswith(matches[1]):
            raise ValueError(f"ambiguous explicit cell id in tag {tag!r}")
    if matches:
        return sorted(matches, key=lambda value: (-len(value), value))[0]
    if method == "base":
        return "base"
    raise ValueError(
        f"portfolio cell {tag!r} has no explicit cell_id; "
        "scientific contrasts must not depend on grid order"
    )


def _correctness(
    records: list[dict],
    *,
    expected_n: int | None = None,
    source: str = "evaluation records",
) -> dict[int, float]:
    if expected_n is not None and len(records) != expected_n:
        raise ValueError(
            f"{source}: expected {expected_n} question records, "
            f"found {len(records)}"
        )
    result = {}
    for position, record in enumerate(records):
        idx_value = record.get("idx")
        if isinstance(idx_value, bool) or not isinstance(idx_value, int):
            raise ValueError(
                f"{source}: record {position} has non-integer idx={idx_value!r}"
            )
        idx = int(idx_value)
        if idx in result:
            raise ValueError(f"{source}: duplicate evaluation question idx={idx}")
        correct = record.get("correct")
        if not isinstance(correct, (bool, np.bool_)):
            raise ValueError(
                f"{source}: question idx={idx} has non-boolean correct={correct!r}"
            )
        result[idx] = float(correct)
    return result


def _expected_checkpoint_rounds(defaults: dict, rounds: int) -> list[int]:
    configured = defaults.get("eval_rounds") or []
    if configured:
        try:
            values = [int(value) for value in configured]
        except (TypeError, ValueError) as exc:
            raise ValueError("defaults.eval_rounds must contain integers") from exc
        if any(value <= 0 for value in values):
            raise ValueError("defaults.eval_rounds must be positive")
        if len(values) != len(set(values)):
            raise ValueError("defaults.eval_rounds must be unique")
        return sorted({*(value for value in values if value <= rounds), rounds})
    eval_every = int(defaults.get("eval_every", 0))
    if eval_every <= 0:
        raise ValueError(
            "trained portfolio cells require eval_rounds or positive eval_every"
        )
    expected = list(range(eval_every, rounds + 1, eval_every))
    if not expected or expected[-1] != rounds:
        expected.append(rounds)
    return expected


def _validate_provenance(
    payload: dict,
    expected: dict[str, object],
    *,
    source: Path | str,
) -> None:
    for field, value in expected.items():
        observed = payload.get(field)
        if observed != value:
            raise ValueError(
                f"{source}: {field} provenance mismatch "
                f"(expected {value!r}, found {observed!r})"
            )


def _diagnostics_validator():
    global _DIAGNOSTICS_VALIDATOR
    if _DIAGNOSTICS_VALIDATOR is not None:
        return _DIAGNOSTICS_VALIDATOR
    try:
        import jsonschema
    except ImportError as exc:  # pragma: no cover - exercised on deployment only
        raise RuntimeError(
            "jsonschema is required to validate AC-ALG1 training diagnostics"
        ) from exc
    schema = _read_json(DIAGNOSTICS_SCHEMA)
    jsonschema.Draft202012Validator.check_schema(schema)
    _DIAGNOSTICS_VALIDATOR = jsonschema.Draft202012Validator(schema)
    return _DIAGNOSTICS_VALIDATOR


def _validate_training_diagnostic_schema(record: dict, *, source: Path) -> None:
    errors = sorted(
        (
            error
            for error in _diagnostics_validator().iter_errors(record)
            if not _is_machine_roundoff_bound_error(error)
        ),
        key=lambda error: tuple(str(part) for part in error.absolute_path),
    )
    if not errors:
        return
    error = errors[0]
    location = ".".join(str(part) for part in error.absolute_path) or "<root>"
    raise ValueError(
        f"{source}: training diagnostic schema violation at "
        f"{location}: {error.message}"
    )


def _is_machine_roundoff_bound_error(error: object) -> bool:
    """Accept only sub-picounit floating-point drift at probability bounds."""

    if getattr(error, "validator", None) not in {"minimum", "maximum"}:
        return False
    bound = getattr(error, "validator_value", None)
    value = getattr(error, "instance", None)
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not isinstance(bound, (int, float))
        or float(bound) not in {-1.0, 0.0, 1.0}
    ):
        return False
    return (
        math.isfinite(float(value))
        and abs(float(value) - float(bound)) <= 1e-12
    )


def _mean_nullable(values: Iterable[object]) -> float | None:
    present = [float(value) for value in values if value is not None]
    if not all(math.isfinite(value) for value in present):
        raise ValueError("mechanism diagnostics must be finite or null")
    return float(np.mean(present)) if present else None


def summarize_training_diagnostics(records: list[dict]) -> dict[str, float | None]:
    """Reduce per-round records to explicitly named mechanism estimands."""

    if not records:
        raise ValueError("cannot summarize empty training diagnostics")
    answer_only = [
        record["responsibilities"]["partitions"]["answer_only"]
        for record in records
    ]
    final_drift = records[-1]["optimizer"]["parameter_l2_drift_from_initial"]
    if final_drift is not None and not math.isfinite(float(final_drift)):
        raise ValueError("final parameter drift must be finite or null")
    return {
        "mechanism_proposal_acceptance_mean": _mean_nullable(
            record["generation"]["filter"]["acceptance_fraction"]
            for record in records
        ),
        "mechanism_within_question_duplicate_fraction_mean": _mean_nullable(
            record["generation"]["samples"][
                "duplicate_fraction_within_question"
            ]
            for record in records
        ),
        "mechanism_answer_only_max_responsibility_mean": _mean_nullable(
            partition["mean_max_responsibility"]
            for partition in answer_only
        ),
        "mechanism_answer_only_normalized_entropy_mean": _mean_nullable(
            partition["mean_normalized_entropy"]
            for partition in answer_only
        ),
        "mechanism_answer_only_ess_fraction_mean": _mean_nullable(
            partition["mean_effective_sample_size_fraction"]
            for partition in answer_only
        ),
        "mechanism_answer_only_weighted_age_mean": _mean_nullable(
            partition["mean_responsibility_weighted_age"]
            for partition in answer_only
        ),
        "mechanism_inter_refresh_total_variation_mean": _mean_nullable(
            record["responsibilities"][
                "inter_refresh_total_variation_mean"
            ]
            for record in records
        ),
        "mechanism_parameter_l2_drift_final": (
            None if final_drift is None else float(final_drift)
        ),
        "mechanism_update_direction_norm_mean": _mean_nullable(
            record["objective"]["update_direction_norm"]
            for record in records
        ),
        "mechanism_B_unsup_mean": _mean_nullable(
            record["objective"]["B_unsup"] for record in records
        ),
        "mechanism_safeguard_acceptance_fraction_mean": _mean_nullable(
            record["objective"]["safeguard_acceptance_fraction"]
            for record in records
        ),
        "mechanism_accepted_surrogate_total_delta_mean": _mean_nullable(
            record["objective"]["accepted_surrogate_total_delta"]
            for record in records
        ),
        "mechanism_accepted_B_sup_delta_mean": _mean_nullable(
            record["objective"]["accepted_B_sup_delta"]
            for record in records
        ),
        "mechanism_accepted_B_prime_unsup_delta_mean": _mean_nullable(
            record["objective"]["accepted_B_prime_unsup_delta"]
            for record in records
        ),
        "mechanism_accepted_B_unsup_delta_mean": _mean_nullable(
            record["objective"]["accepted_B_unsup_delta"]
            for record in records
        ),
        "mechanism_policy_anchor_target_ratio_mean": _mean_nullable(
            record["objective"]["policy_anchor_target_ratio"]
            for record in records
        ),
        "mechanism_policy_anchor_achieved_ratio_mean": _mean_nullable(
            record["objective"]["policy_anchor_achieved_ratio"]
            for record in records
        ),
        "mechanism_policy_anchor_beta_mean": _mean_nullable(
            record["objective"]["policy_anchor_beta"]
            for record in records
        ),
        "mechanism_policy_anchor_beta_unclipped_mean": _mean_nullable(
            record["objective"]["policy_anchor_beta_unclipped"]
            for record in records
        ),
        "mechanism_policy_anchor_beta_clip_fraction_mean": _mean_nullable(
            record["objective"]["policy_anchor_beta_clip_fraction"]
            for record in records
        ),
        "mechanism_policy_anchor_objective_grad_norm_mean": _mean_nullable(
            record["objective"]["policy_anchor_objective_grad_norm"]
            for record in records
        ),
        "mechanism_policy_anchor_raw_grad_norm_mean": _mean_nullable(
            record["objective"]["policy_anchor_raw_grad_norm"]
            for record in records
        ),
        "mechanism_policy_anchor_applied_grad_norm_mean": _mean_nullable(
            record["objective"]["policy_anchor_applied_grad_norm"]
            for record in records
        ),
    }


def load_study(
    config_path: Path,
    result_dir: Path,
) -> tuple[pd.DataFrame, dict[tuple[str, int], dict], dict[tuple[str, int], list[dict]]]:
    """Load strict cells, evaluations, checkpoints, and mechanism summaries."""

    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    defaults = config.get("defaults") or {}
    explicit_ids = _explicit_cell_ids(config)
    seeds = _configured_seed_values(config)
    run_id = str(config["run_id"])
    task = str(defaults.get("task", "gsm8k"))
    n_test = int(defaults.get("n_test", 200))
    if n_test <= 0:
        raise ValueError("defaults.n_test must be positive")
    sweeps = _artifact_dir(result_dir, "sweeps")
    evaluations_dir = _artifact_dir(result_dir, "evaluations")
    checkpoints_dir = _artifact_dir(result_dir, "checkpoint_evaluations")
    diagnostics_dir = _artifact_dir(result_dir, "training_diagnostics")

    rows = []
    evaluations = {}
    checkpoints = {}
    for model, method, axes, base_tag in _cells(config, None, run_id):
        cell_id = _cell_id(base_tag, method, explicit_ids)
        rounds = int(axes.get("rounds", defaults.get("rounds", 0)))
        batch = int(axes.get("batch", defaults.get("batch", 0)))
        if method != "base" and (rounds <= 0 or batch <= 0):
            raise ValueError(f"{cell_id} needs positive rounds and batch")
        expected_checkpoint_rounds = (
            [] if method == "base"
            else _expected_checkpoint_rounds(defaults, rounds)
        )
        for seed in seeds:
            tag = f"{base_tag}_seed{seed}"
            csv_path = sweeps / f"sweep_{task}__{tag}.csv"
            if not csv_path.is_file():
                raise FileNotFoundError(csv_path)
            frame = pd.read_csv(csv_path)
            selected = frame[
                (frame["method"].astype(str) == method)
                & (frame["seed"].astype(int) == seed)
            ]
            if len(selected) != 1:
                raise ValueError(
                    f"{csv_path}: expected one {method}/seed{seed} row, "
                    f"found {len(selected)}"
                )
            result = selected.iloc[0]
            for field, expected in {
                "run_id": run_id,
                "model": model,
                "task": task,
            }.items():
                if field not in selected:
                    raise ValueError(f"{csv_path}: missing {field} provenance column")
                observed = result[field]
                if str(observed) != str(expected):
                    raise ValueError(
                        f"{csv_path}: {field} provenance mismatch "
                        f"(expected {expected!r}, found {observed!r})"
                    )

            eval_path = evaluations_dir / (
                f"eval_{task}__{tag}__{method}_s{seed}.json"
            )
            if not eval_path.is_file():
                raise FileNotFoundError(eval_path)
            evaluation = _read_json(eval_path)
            _validate_provenance(
                evaluation,
                {
                    "run_id": run_id,
                    "model": model,
                    "method": method,
                    "seed": seed,
                },
                source=eval_path,
            )
            final_correctness = _correctness(
                evaluation.get("records") or [],
                expected_n=n_test,
                source=str(eval_path),
            )
            sweep_accuracy = float(result["test_acc"])
            evaluation_accuracy = float(evaluation.get("test_acc", float("nan")))
            record_accuracy = float(np.mean(list(final_correctness.values())))
            if not all(
                math.isfinite(value)
                for value in (
                    sweep_accuracy,
                    evaluation_accuracy,
                    record_accuracy,
                )
            ):
                raise ValueError(
                    f"{eval_path}: final accuracy values must be finite"
                )
            if not (
                math.isclose(
                    sweep_accuracy,
                    evaluation_accuracy,
                    rel_tol=1e-9,
                    abs_tol=1e-12,
                )
                and math.isclose(
                    evaluation_accuracy,
                    record_accuracy,
                    rel_tol=1e-9,
                    abs_tol=1e-12,
                )
            ):
                raise ValueError(
                    f"{eval_path}: final accuracy mismatch "
                    f"(sweep={sweep_accuracy}, evaluation={evaluation_accuracy}, "
                    f"records={record_accuracy})"
                )
            evaluations[(cell_id, seed)] = evaluation

            checkpoint_records = []
            if method != "base":
                checkpoint_path = checkpoints_dir / (
                    f"checkpoint_eval_{task}__{tag}__{method}_s{seed}.jsonl.gz"
                )
                if not checkpoint_path.is_file():
                    raise FileNotFoundError(checkpoint_path)
                checkpoint_records = _read_jsonl_gz(checkpoint_path)
                completed = [
                    int(record["completed_rounds"])
                    for record in checkpoint_records
                ]
                if completed != expected_checkpoint_rounds:
                    raise ValueError(
                        f"{checkpoint_path}: expected completed rounds "
                        f"{expected_checkpoint_rounds}, found {completed}"
                    )
                for record in checkpoint_records:
                    _validate_provenance(
                        record,
                        {
                            "run_id": run_id,
                            "model": model,
                            "task": task,
                            "method": method,
                            "seed": seed,
                            "tag": tag,
                        },
                        source=checkpoint_path,
                    )
                    checkpoint_correctness = _correctness(
                        record.get("records") or [],
                        expected_n=n_test,
                        source=(
                            f"{checkpoint_path} completed_rounds="
                            f"{record['completed_rounds']}"
                        ),
                    )
                    if set(checkpoint_correctness) != set(final_correctness):
                        raise ValueError(
                            f"{checkpoint_path}: checkpoint/final question "
                            f"IDs differ at completed round "
                            f"{record['completed_rounds']}"
                        )
                checkpoints[(cell_id, seed)] = checkpoint_records

            row = {
                "run_id": run_id,
                "cell_id": cell_id,
                "method": method,
                "seed": seed,
                "tag": tag,
                "rounds": rounds,
                "batch": batch,
                "final_generations": rounds * batch if method != "base" else 0,
                "final_accuracy": sweep_accuracy,
                "runtime_s": float(result["secs"]),
                "vram_gb": (
                    None
                    if pd.isna(result.get("vram_gb"))
                    else float(result["vram_gb"])
                ),
            }
            if method == "AC-ALG1" and defaults.get(
                "save_training_diagnostics"
            ):
                diagnostics_path = diagnostics_dir / (
                    f"training_diagnostics_{task}__{tag}__{method}_s{seed}.jsonl.gz"
                )
                if not diagnostics_path.is_file():
                    raise FileNotFoundError(diagnostics_path)
                diagnostics = _read_jsonl_gz(diagnostics_path)
                if len(diagnostics) != rounds:
                    raise ValueError(
                        f"{diagnostics_path}: expected {rounds} records, "
                        f"found {len(diagnostics)}"
                    )
                for round_index, record in enumerate(diagnostics):
                    _validate_training_diagnostic_schema(
                        record,
                        source=diagnostics_path,
                    )
                    _validate_provenance(
                        record,
                        {
                            "run_id": run_id,
                            "model": model,
                            "task": task,
                            "method": method,
                            "seed": seed,
                            "tag": tag,
                            "round": round_index,
                            "completed_rounds": round_index + 1,
                        },
                        source=diagnostics_path,
                    )
                row.update(summarize_training_diagnostics(diagnostics))
            rows.append(row)
    table = pd.DataFrame(rows).sort_values(
        ["run_id", "cell_id", "seed"]
    ).reset_index(drop=True)
    return table, evaluations, checkpoints


def question_generation_auc(
    cells: pd.DataFrame,
    evaluations: dict[tuple[str, int], dict],
    checkpoints: dict[tuple[str, int], list[dict]],
    *,
    cell_id: str,
    baseline_cell: str,
    horizon_generations: int,
    generation_grid: Sequence[int] | None = None,
) -> pd.DataFrame:
    """Integrate per-question correctness through a fixed generation horizon."""

    if horizon_generations <= 0:
        raise ValueError("horizon_generations must be positive")
    requested_grid = None
    if generation_grid is not None:
        requested_grid = [int(value) for value in generation_grid]
        if (
            not requested_grid
            or requested_grid != sorted(set(requested_grid))
            or requested_grid[0] <= 0
            or requested_grid[-1] != horizon_generations
        ):
            raise ValueError(
                "generation_grid must be strictly increasing, positive, "
                "and end at horizon_generations"
            )
    rows = []
    selected_cells = cells[cells["cell_id"] == cell_id]
    if selected_cells.empty:
        raise ValueError(f"missing cell {cell_id!r}")
    for _, cell in selected_cells.iterrows():
        seed = int(cell["seed"])
        baseline_eval = evaluations.get((baseline_cell, seed))
        if baseline_eval is None:
            raise ValueError(
                f"missing paired {baseline_cell!r} evaluation for seed {seed}"
            )
        baseline = _correctness(
            baseline_eval.get("records") or [],
            source=f"{baseline_cell}/seed{seed} final evaluation",
        )
        if cell_id == baseline_cell:
            for idx, correct in baseline.items():
                rows.append({
                    "cell_id": cell_id,
                    "seed": seed,
                    "idx": idx,
                    "horizon_generations": horizon_generations,
                    "auc": correct,
                    "final_correct": correct,
                    "baseline_correct": correct,
                    "n_checkpoints": 0,
                })
            continue

        records = checkpoints.get((cell_id, seed))
        if records is None:
            raise ValueError(f"missing checkpoints for {cell_id}/seed{seed}")
        batch = int(cell["batch"])
        records_by_generation = {
            int(record["completed_rounds"]) * batch: record
            for record in records
        }
        if len(records_by_generation) != len(records):
            raise ValueError(
                f"{cell_id}/seed{seed} has duplicate generation checkpoints"
            )
        generation_points = (
            requested_grid
            if requested_grid is not None
            else sorted(
                point
                for point in records_by_generation
                if point <= horizon_generations
            )
        )
        if (
            not generation_points
            or generation_points[-1] != horizon_generations
            or any(point not in records_by_generation for point in generation_points)
        ):
            raise ValueError(
                f"{cell_id}/seed{seed} does not contain the required "
                f"generation grid {generation_points!r} through "
                f"{horizon_generations}"
            )
        selected = [records_by_generation[point] for point in generation_points]
        checkpoint_maps = [
            _correctness(
                record.get("records") or [],
                expected_n=len(baseline),
                source=(
                    f"{cell_id}/seed{seed} checkpoint at "
                    f"{generation_points[index]} generations"
                ),
            )
            for index, record in enumerate(selected)
        ]
        baseline_ids = set(baseline)
        for point, values in zip(generation_points, checkpoint_maps):
            if set(values) != baseline_ids:
                missing = sorted(baseline_ids - set(values))
                extra = sorted(set(values) - baseline_ids)
                raise ValueError(
                    f"{cell_id}/seed{seed} checkpoint at {point} generations "
                    f"has different question IDs (missing={missing[:5]}, "
                    f"extra={extra[:5]})"
                )
        x = np.asarray([0, *generation_points], dtype=float)
        for idx in sorted(baseline_ids):
            y = np.asarray([
                baseline[idx],
                *(values[idx] for values in checkpoint_maps),
            ])
            rows.append({
                "cell_id": cell_id,
                "seed": seed,
                "idx": int(idx),
                "horizon_generations": horizon_generations,
                "auc": float(np.trapezoid(y, x) / horizon_generations),
                "final_correct": float(y[-1]),
                "baseline_correct": float(y[0]),
                "n_checkpoints": len(selected),
            })
    return pd.DataFrame(rows).sort_values(["seed", "idx"]).reset_index(drop=True)


def question_final_correctness(
    cells: pd.DataFrame,
    evaluations: dict[tuple[str, int], dict],
    *,
    cell_id: str,
) -> pd.DataFrame:
    """Return strict per-question endpoint correctness for one study cell."""

    rows = []
    selected_cells = cells[cells["cell_id"] == cell_id]
    if selected_cells.empty:
        raise ValueError(f"missing cell {cell_id!r}")
    for seed in sorted(selected_cells["seed"].astype(int).unique()):
        evaluation = evaluations.get((cell_id, seed))
        if evaluation is None:
            raise ValueError(
                f"missing final evaluation for {cell_id!r}, seed {seed}"
            )
        for idx, correct in sorted(
            _correctness(evaluation.get("records") or []).items()
        ):
            rows.append({
                "cell_id": cell_id,
                "seed": seed,
                "idx": idx,
                "final_correct": correct,
            })
    return pd.DataFrame(rows).sort_values(["seed", "idx"]).reset_index(drop=True)


def linear_contrast(
    question_tables: dict[str, pd.DataFrame],
    coefficients: dict[str, float],
    *,
    name: str,
    value_column: str = "auc",
) -> pd.DataFrame:
    """Apply a named linear contrast to paired per-question estimand tables."""

    if not coefficients or not math.isclose(sum(coefficients.values()), 0.0):
        raise ValueError("contrast coefficients must be nonempty and sum to zero")
    merged = None
    value_columns = []
    reference_keys = None
    reference_cell = None
    for cell_id, coefficient in coefficients.items():
        table = question_tables.get(cell_id)
        if table is None or table.empty:
            raise ValueError(f"missing question table for {cell_id!r}")
        if value_column not in table:
            raise ValueError(
                f"question table for {cell_id!r} lacks {value_column!r}"
            )
        column = f"value__{cell_id}"
        current = table[["seed", "idx", value_column]].rename(
            columns={value_column: column}
        )
        if current.duplicated(["seed", "idx"]).any():
            raise ValueError(
                f"question table for {cell_id!r} has duplicate (seed, idx) keys"
            )
        current_keys = set(
            zip(
                current["seed"].astype(int),
                current["idx"].astype(int),
            )
        )
        if reference_keys is None:
            reference_keys = current_keys
            reference_cell = cell_id
        elif current_keys != reference_keys:
            missing = sorted(reference_keys - current_keys)
            extra = sorted(current_keys - reference_keys)
            raise ValueError(
                f"question keys differ between {reference_cell!r} and "
                f"{cell_id!r} (missing={missing[:5]}, extra={extra[:5]})"
            )
        merged = (
            current
            if merged is None
            else merged.merge(
                current,
                on=["seed", "idx"],
                how="inner",
                validate="one_to_one",
            )
        )
        value_columns.append((column, float(coefficient)))
    if merged is None or merged.empty:
        raise ValueError(f"contrast {name!r} has no paired observations")
    merged["effect"] = sum(
        merged[column] * coefficient
        for column, coefficient in value_columns
    )
    merged.insert(0, "contrast", name)
    return merged[["contrast", "seed", "idx", "effect"]].sort_values(
        ["seed", "idx"]
    )


def hierarchical_paired_interval(
    effects: pd.DataFrame,
    *,
    draws: int,
    seed: int,
) -> tuple[float, float, float]:
    """Crossed seed-by-question interval and one-sided 95% upper bound.

    The same held-out questions are observed under every training seed.  Each
    bootstrap draw therefore samples a seed vector and one shared question
    vector, then averages their Cartesian product.  Sampling questions
    independently inside each seed would incorrectly treat the fixed question
    set as nested.
    """

    if draws < 1:
        raise ValueError("draws must be positive")
    required = {"seed", "idx", "effect"}
    missing_columns = required - set(effects)
    if missing_columns:
        raise ValueError(
            f"effects lack required columns: {sorted(missing_columns)}"
        )
    if effects.empty:
        return float("nan"), float("nan"), float("nan")
    if effects.duplicated(["seed", "idx"]).any():
        raise ValueError("effects contain duplicate (seed, idx) keys")
    grouped = list(effects.groupby("seed", sort=True))
    reference_ids = tuple(sorted(grouped[0][1]["idx"].astype(int)))
    if not reference_ids:
        return float("nan"), float("nan"), float("nan")
    rows = []
    for training_seed, group in grouped:
        ids = tuple(sorted(group["idx"].astype(int)))
        if ids != reference_ids:
            raise ValueError(
                "crossed bootstrap requires identical question IDs for every "
                f"seed; seed {training_seed} differs"
            )
        ordered = group.assign(idx=group["idx"].astype(int)).set_index("idx")
        values = ordered.loc[list(reference_ids), "effect"].to_numpy(float)
        if not np.isfinite(values).all():
            raise ValueError("effects must be finite")
        rows.append(values)
    matrix = np.stack(rows)
    n_seeds, n_questions = matrix.shape
    rng = np.random.default_rng(seed)
    means = np.empty(draws, dtype=float)
    chunk = 500
    for start in range(0, draws, chunk):
        stop = min(start + chunk, draws)
        width = stop - start
        sampled_seeds = rng.integers(
            0,
            n_seeds,
            size=(width, n_seeds),
        )
        sampled_questions = rng.integers(
            0,
            n_questions,
            size=(width, n_questions),
        )
        sampled = matrix[
            sampled_seeds[:, :, None],
            sampled_questions[:, None, :],
        ]
        means[start:stop] = sampled.mean(axis=(1, 2))
    low, high = np.quantile(means, [0.025, 0.975])
    upper95 = np.quantile(means, 0.95)
    return float(low), float(high), float(upper95)


def _common_generation_grid(
    cells: pd.DataFrame,
    checkpoints: dict[tuple[str, int], list[dict]],
    *,
    cell_ids: set[str],
    horizon_generations: int,
) -> list[int]:
    """Return the exact positive generation budgets shared by trained cells."""

    grids = []
    for cell_id in sorted(cell_ids):
        selected = cells[cells["cell_id"] == cell_id]
        if selected.empty:
            raise ValueError(f"missing cell {cell_id!r}")
        if set(selected["method"]) == {"base"}:
            continue
        for _, cell in selected.iterrows():
            seed = int(cell["seed"])
            records = checkpoints.get((cell_id, seed))
            if records is None:
                raise ValueError(f"missing checkpoints for {cell_id}/seed{seed}")
            batch = int(cell["batch"])
            grid = {
                int(record["completed_rounds"]) * batch
                for record in records
                if int(record["completed_rounds"]) * batch
                <= horizon_generations
            }
            grids.append(grid)
    if not grids:
        raise ValueError("common generation grid needs at least one trained cell")
    common = sorted(set.intersection(*grids))
    if not common or common[-1] != horizon_generations:
        raise ValueError(
            "trained cells do not share an exact terminal checkpoint at "
            f"{horizon_generations} generations"
        )
    return common


def _preregistered_auc_generation_grid(
    inputs: list[tuple[Path, Path]],
    *,
    horizon_generations: int,
) -> list[int]:
    """Load the one frozen AUC grid declared across a study's input configs."""

    declared = []
    for config_path, _result_dir in inputs:
        config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        diagnostic = config.get("diagnostic") or {}
        if "auc_generation_grid" in diagnostic:
            declared.append((config_path, diagnostic["auc_generation_grid"]))
    if len(declared) != 1:
        raise ValueError(
            "GRPO analysis requires exactly one supplied config with a "
            f"diagnostic.auc_generation_grid; found {len(declared)}"
        )
    source, raw_grid = declared[0]
    if not isinstance(raw_grid, (list, tuple)) or not raw_grid:
        raise ValueError(
            f"{source}: diagnostic.auc_generation_grid must be a nonempty list"
        )
    try:
        grid = [int(value) for value in raw_grid]
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"{source}: diagnostic.auc_generation_grid must contain integers"
        ) from exc
    if (
        grid != sorted(set(grid))
        or grid[0] <= 0
        or grid[-1] != horizon_generations
    ):
        raise ValueError(
            f"{source}: diagnostic.auc_generation_grid must be strictly "
            f"increasing, positive, and end at {horizon_generations}"
        )
    return grid


def contrast_decision(
    effects: pd.DataFrame,
    *,
    practical_margin: float,
    draws: int,
    bootstrap_seed: int,
    required_positive_seeds: int | None = None,
    catastrophic_threshold: float | None = None,
) -> dict:
    """Apply the prespecified seed-sign, interval, and futility rules."""

    seed_effects = effects.groupby("seed")["effect"].mean().sort_index()
    low, high, upper95 = hierarchical_paired_interval(
        effects,
        draws=draws,
        seed=bootstrap_seed,
    )
    required = (
        len(seed_effects)
        if required_positive_seeds is None
        else int(required_positive_seeds)
    )
    positive = int((seed_effects > 0).sum())
    catastrophic = (
        int((seed_effects < catastrophic_threshold).sum())
        if catastrophic_threshold is not None else 0
    )
    mean = float(seed_effects.mean())
    if (
        positive >= required
        and low > 0
        and mean >= practical_margin
        and catastrophic == 0
    ):
        verdict = "support"
    elif positive <= 1 and upper95 < practical_margin:
        verdict = "practical_futility"
    else:
        verdict = "inconclusive"
    return {
        "verdict": verdict,
        "n_seeds": int(len(seed_effects)),
        "required_positive_seeds": required,
        "positive_seed_differences": positive,
        "catastrophic_seed_differences": catastrophic,
        "mean_effect": mean,
        "practical_margin": practical_margin,
        "crossed_seed_question_ci95_low": low,
        "crossed_seed_question_ci95_high": high,
        "crossed_seed_question_one_sided_95_upper": upper95,
        # Back-compatible aliases retained for existing report consumers.
        "hierarchical_ci95_low": low,
        "hierarchical_ci95_high": high,
        "hierarchical_one_sided_95_upper": upper95,
        "seed_effects": {
            str(int(seed)): float(value)
            for seed, value in seed_effects.items()
        },
    }


def _study_spec(study: str) -> tuple[list[int], dict[str, dict[str, float]]]:
    if study == "early":
        return [640, 1920], {
            "Bunsup_exact_minus_base": {
                "Bunsup_exact": 1.0,
                "base": -1.0,
            },
        }
    if study == "causal":
        return [640, 1920], {
            "fixed_E_step_main_effect": {
                "E1_outer_persistent": 0.5,
                "E3_outer_reset": 0.5,
                "E0_inner_persistent": -0.5,
                "E2_inner_reset": -0.5,
            },
            "reset_Adam_main_effect": {
                "E2_inner_reset": 0.5,
                "E3_outer_reset": 0.5,
                "E0_inner_persistent": -0.5,
                "E1_outer_persistent": -0.5,
            },
            "fixed_E_step_by_reset_Adam": {
                "E3_outer_reset": 1.0,
                "E2_inner_reset": -1.0,
                "E1_outer_persistent": -1.0,
                "E0_inner_persistent": 1.0,
            },
            "E1_outer_persistent_minus_E0_inner_persistent": {
                "E1_outer_persistent": 1.0,
                "E0_inner_persistent": -1.0,
            },
            "frozen_proposal_main_effect": {
                "F2_frozen_proposal": 0.5,
                "F4_frozen_both": 0.5,
                "E1_outer_persistent": -0.5,
                "F3_frozen_scorer": -0.5,
            },
            "frozen_responsibility_and_retention_main_effect": {
                "F3_frozen_scorer": 0.5,
                "F4_frozen_both": 0.5,
                "E1_outer_persistent": -0.5,
                "F2_frozen_proposal": -0.5,
            },
            "frozen_proposal_by_responsibility_and_retention": {
                "F4_frozen_both": 1.0,
                "F2_frozen_proposal": -1.0,
                "F3_frozen_scorer": -1.0,
                "E1_outer_persistent": 1.0,
            },
        }
    if study == "grpo":
        return [7680], {
            "long_GRPO_minus_base": {
                "long_B64_G16_R120": 1.0,
                "base": -1.0,
            },
            "wide_GRPO_minus_base": {
                "wide_B256_G4_R30": 1.0,
                "base": -1.0,
            },
            "long_GRPO_minus_wide_GRPO": {
                "long_B64_G16_R120": 1.0,
                "wide_B256_G4_R30": -1.0,
            },
        }
    if study == "anchor":
        return [1920], {
            "rho_003_minus_rho_0": {
                "A1_rho003": 1.0,
                "A0_rho0": -1.0,
            },
        }
    raise ValueError(f"unknown study {study!r}")


def analyse(
    study: str,
    inputs: list[tuple[Path, Path]],
    *,
    draws: int,
    bootstrap_seed: int,
    practical_margin: float,
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Load all study inputs and return cells, question effects, decisions."""

    loaded = [
        load_study(config_path, result_dir)
        for config_path, result_dir in inputs
    ]
    cells = pd.concat([item[0] for item in loaded], ignore_index=True)
    evaluations = {}
    checkpoints = {}
    for _table, current_evaluations, current_checkpoints in loaded:
        overlap = set(evaluations) & set(current_evaluations)
        if overlap:
            raise ValueError(f"duplicate evaluation keys: {sorted(overlap)}")
        evaluations.update(current_evaluations)
        checkpoints.update(current_checkpoints)
    if cells.duplicated(["cell_id", "seed"]).any():
        duplicated = cells.loc[
            cells.duplicated(["cell_id", "seed"], keep=False),
            ["cell_id", "seed"],
        ]
        raise ValueError(
            "duplicate cell/seed rows: "
            f"{duplicated.drop_duplicates().to_dict(orient='records')}"
        )

    horizons, contrast_specs = _study_spec(study)
    all_effects = []
    decisions = {}
    available_cells = set(cells["cell_id"])
    needed_cells = {
        cell_id
        for coefficients in contrast_specs.values()
        for cell_id in coefficients
    }
    missing = needed_cells - available_cells
    if missing:
        raise ValueError(f"missing study cells: {sorted(missing)}")

    for horizon_index, horizon in enumerate(horizons):
        generation_grid = None
        if study == "grpo":
            preregistered_grid = _preregistered_auc_generation_grid(
                inputs,
                horizon_generations=horizon,
            )
            artifact_grid = _common_generation_grid(
                cells,
                checkpoints,
                cell_ids=needed_cells,
                horizon_generations=horizon,
            )
            if artifact_grid != preregistered_grid:
                raise ValueError(
                    "GRPO checkpoint intersection does not equal the frozen "
                    "diagnostic.auc_generation_grid "
                    f"(expected {preregistered_grid}, found {artifact_grid})"
                )
            generation_grid = preregistered_grid
        auc_tables = {
            cell_id: question_generation_auc(
                cells,
                evaluations,
                checkpoints,
                cell_id=cell_id,
                baseline_cell="base",
                horizon_generations=horizon,
                generation_grid=generation_grid,
            )
            for cell_id in needed_cells
        }
        for contrast_index, (name, coefficients) in enumerate(
            contrast_specs.items()
        ):
            auc_name = (
                f"{name}__auc"
                if study in {"grpo", "anchor"}
                else name
            )
            effects = linear_contrast(
                auc_tables,
                coefficients,
                name=auc_name,
            )
            effects.insert(1, "horizon_generations", horizon)
            all_effects.append(effects)
            decision_key = f"{auc_name}__g{horizon}"
            decisions[decision_key] = contrast_decision(
                effects,
                practical_margin=practical_margin,
                draws=draws,
                bootstrap_seed=(
                    bootstrap_seed
                    + 100 * horizon_index
                    + contrast_index
                ),
                required_positive_seeds=(
                    4 if study == "early" and horizon == 640 else None
                ),
                catastrophic_threshold=(
                    -0.05 if study == "early" and horizon == 640 else None
                ),
            )
            if study in {"grpo", "anchor"}:
                final_tables = {
                    cell_id: question_final_correctness(
                        cells,
                        evaluations,
                        cell_id=cell_id,
                    )
                    for cell_id in coefficients
                }
                final_name = f"{name}__final_accuracy"
                final_effects = linear_contrast(
                    final_tables,
                    coefficients,
                    name=final_name,
                    value_column="final_correct",
                )
                final_effects.insert(1, "horizon_generations", horizon)
                all_effects.append(final_effects)
                final_key = f"{final_name}__g{horizon}"
                decisions[final_key] = contrast_decision(
                    final_effects,
                    practical_margin=practical_margin,
                    draws=draws,
                    bootstrap_seed=(
                        bootstrap_seed
                        + 100 * horizon_index
                        + len(contrast_specs)
                        + contrast_index
                    ),
                )
                if study == "grpo":
                    decisions[f"{name}__co_primary"] = {
                        "verdict": (
                            "support"
                            if decisions[decision_key]["verdict"] == "support"
                            and decisions[final_key]["verdict"] == "support"
                            else "not_jointly_supported"
                        ),
                        "auc_decision": decision_key,
                        "final_accuracy_decision": final_key,
                    }
    effects = pd.concat(all_effects, ignore_index=True)
    return cells, effects, decisions


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--study",
        choices=("early", "causal", "grpo", "anchor"),
        required=True,
    )
    parser.add_argument(
        "--input",
        action="append",
        nargs=2,
        metavar=("CONFIG", "RESULT_DIR"),
        required=True,
        help="repeat for every config/result directory participating in the study",
    )
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260724)
    parser.add_argument("--practical-margin", type=float, default=0.01)
    parser.add_argument("--write-dir", type=Path)
    args = parser.parse_args()

    cells, effects, decisions = analyse(
        args.study,
        [(Path(config), Path(result).expanduser()) for config, result in args.input],
        draws=args.bootstrap_draws,
        bootstrap_seed=args.bootstrap_seed,
        practical_margin=args.practical_margin,
    )
    seed_effects = (
        effects.groupby(["contrast", "horizon_generations", "seed"], as_index=False)
        ["effect"].mean()
    )

    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", None)
    print("=== CELLS ===")
    print(cells.to_string(index=False))
    print("\n=== SEED EFFECTS ===")
    print(seed_effects.to_string(index=False))
    print("\n=== DECISIONS ===")
    print(json.dumps(decisions, indent=2, sort_keys=True))

    if args.write_dir is not None:
        args.write_dir.mkdir(parents=True, exist_ok=True)
        cells.to_csv(args.write_dir / "cells.csv", index=False)
        effects.to_csv(args.write_dir / "paired_question_effects.csv", index=False)
        seed_effects.to_csv(args.write_dir / "seed_effects.csv", index=False)
        (args.write_dir / "decisions.json").write_text(
            json.dumps(decisions, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
