#!/usr/bin/env python3
"""Fail-closed validator for the 56-task frozen transfer study."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import glob
import gzip
import json
import math
from pathlib import Path
import re
from typing import Any, Mapping

from evaluate_qwen3_final_transfer import file_sha256, load_manifest
from result_contract import atomic_write_json


EXPECTED_TASK_COUNT = 56
EXPECTED_DATASET_ROWS = {"svamp": 1000, "math_500": 500}
METRIC_FIELDS = (
    "final_extracted_answer_accuracy",
    "final_strict_terminal_accuracy",
    "natural_eos_rate",
    "token_limit_rate",
)
FAILURE_SIGNATURE = re.compile(
    r"Traceback|CUDA out of memory|OutOfMemoryError|Killed|ERROR:|FAILED",
    re.IGNORECASE,
)


def artifact_stem(task: Mapping[str, Any]) -> str:
    return (
        f"transfer_task_{int(task['task_index']):03d}__{task['dataset']}__"
        f"{task['role']}__s{task['seed']}"
    )


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: expected a JSON object")
    return payload


def _load_json_gz(path: Path) -> dict[str, Any]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: expected a compressed JSON object")
    return payload


def _finite_rate(value: Any, *, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be numeric")
    number = float(value)
    if not math.isfinite(number) or not 0.0 <= number <= 1.0:
        raise ValueError(f"{field} must be finite and in [0, 1]")
    return number


def validate_task_output(
    task: Mapping[str, Any],
    *,
    output_root: Path,
    manifest_sha256: str,
    execution_commit: str,
) -> list[str]:
    problems: list[str] = []
    stem = artifact_stem(task)
    artifact_path = output_root / f"{stem}.json.gz"
    receipt_path = output_root / f"{stem}.receipt.json"
    if not artifact_path.is_file():
        problems.append(f"missing artifact: {artifact_path}")
        return problems
    if not receipt_path.is_file():
        problems.append(f"missing receipt: {receipt_path}")
        return problems

    try:
        receipt = _load_json(receipt_path)
        expected_receipt = {
            "schema_version": 1,
            "status": "complete",
            "task_index": int(task["task_index"]),
            "manifest_sha256": manifest_sha256,
            "execution_commit": execution_commit,
            "artifact": artifact_path.name,
            "artifact_sha256": file_sha256(artifact_path),
            "official_gsm8k_test_used": False,
        }
        if receipt != expected_receipt:
            raise ValueError("receipt identity or artifact checksum changed")

        payload = _load_json_gz(artifact_path)
        if payload.get("schema_version") != 1 or payload.get("status") != "complete":
            raise ValueError("artifact is not a complete schema-v1 result")
        if payload.get("manifest_sha256") != manifest_sha256:
            raise ValueError("artifact manifest identity changed")
        if payload.get("execution_commit") != execution_commit:
            raise ValueError("artifact execution commit changed")
        if payload.get("official_gsm8k_test_used") is not False:
            raise ValueError("artifact reports GSM8K official-test access")
        if payload.get("task") != dict(task):
            raise ValueError("artifact task coordinate differs from manifest")

        metrics = payload.get("metrics")
        if not isinstance(metrics, dict) or metrics.get("trajectory_auc") is not None:
            raise ValueError("transfer metrics must contain trajectory_auc=null")
        observed_metrics = {
            field: _finite_rate(metrics.get(field), field=f"metrics.{field}")
            for field in METRIC_FIELDS
        }
        if (
            observed_metrics["final_strict_terminal_accuracy"]
            > observed_metrics["final_extracted_answer_accuracy"] + 1e-12
        ):
            raise ValueError("strict accuracy exceeds extracted accuracy")

        records = payload.get("records")
        expected_rows = EXPECTED_DATASET_ROWS[str(task["dataset"])]
        if not isinstance(records, list) or len(records) != expected_rows:
            raise ValueError(
                f"expected {expected_rows} per-example records, got "
                f"{len(records) if isinstance(records, list) else type(records).__name__}"
            )
        dataset_ids = []
        for row_index, row in enumerate(records):
            if not isinstance(row, dict):
                raise ValueError(f"record {row_index} is not an object")
            dataset_id = str(row.get("dataset_id") or "").strip()
            if not dataset_id:
                raise ValueError(f"record {row_index} has no dataset_id")
            dataset_ids.append(dataset_id)
            for field in (
                "extracted_correct",
                "strict_correct",
                "generated_eos",
                "hit_max_new_tokens",
            ):
                if not isinstance(row.get(field), bool):
                    raise ValueError(f"record {row_index} omits boolean {field}")
            if row["strict_correct"] and not row["extracted_correct"]:
                raise ValueError(
                    f"record {row_index} is strict-correct but extraction-incorrect"
                )
        if len(set(dataset_ids)) != expected_rows:
            raise ValueError("dataset_id coverage is incomplete or duplicated")

        reconstructed = {
            "final_extracted_answer_accuracy": sum(
                row["extracted_correct"] for row in records
            )
            / expected_rows,
            "final_strict_terminal_accuracy": sum(
                row["strict_correct"] for row in records
            )
            / expected_rows,
            "natural_eos_rate": sum(row["generated_eos"] for row in records)
            / expected_rows,
            "token_limit_rate": sum(
                row["hit_max_new_tokens"] for row in records
            )
            / expected_rows,
        }
        for field, expected in reconstructed.items():
            if abs(observed_metrics[field] - expected) > 1e-12:
                raise ValueError(f"metrics.{field} does not reconstruct from records")

        dataset = payload.get("dataset")
        if not isinstance(dataset, dict):
            raise ValueError("dataset metadata is missing")
        if dataset.get("evaluation_prompt") != "question":
            raise ValueError("evaluation prompt changed")
        if dataset.get("demonstration_source") != "openai/gsm8k:train":
            raise ValueError("demonstration source changed")
        if int(dataset.get("demonstration_shots", -1)) != 3:
            raise ValueError("demonstration shot count changed")
        if int(dataset.get("demonstration_shot_bank_size", -1)) != 5:
            raise ValueError("demonstration shot bank changed")
        for key, value in dataset.items():
            if "official" in str(key).lower() and "test" in str(key).lower() and value is not False:
                raise ValueError(f"dataset metadata does not prove {key}=false")

        runtime = payload.get("runtime")
        if not isinstance(runtime, dict):
            raise ValueError("runtime metadata is missing")
        elapsed = float(runtime.get("elapsed_seconds", 0.0))
        accelerator_hours = float(runtime.get("accelerator_hours", 0.0))
        peak_memory = int(runtime.get("peak_gpu_memory_bytes", 0))
        evaluated_examples = int(runtime.get("evaluated_examples", 0))
        generated_tokens = int(runtime.get("generated_tokens", 0))
        if not math.isfinite(elapsed) or elapsed <= 0.0:
            raise ValueError("elapsed_seconds is not positive and finite")
        if not math.isfinite(accelerator_hours) or accelerator_hours <= 0.0:
            raise ValueError("accelerator_hours is not positive and finite")
        if abs(accelerator_hours - elapsed / 3600.0) > 1e-6:
            raise ValueError("accelerator_hours does not match elapsed_seconds")
        if peak_memory <= 0 or "H100" not in str(runtime.get("gpu_name")):
            raise ValueError("runtime does not prove a positive-memory H100 execution")
        if evaluated_examples != expected_rows or generated_tokens <= 0:
            raise ValueError("runtime example or generated-token accounting changed")
    except (OSError, EOFError, gzip.BadGzipFile, json.JSONDecodeError, ValueError) as exc:
        problems.append(f"invalid transfer output {stem}: {exc}")
    return problems


def validate_logs(pattern: str, *, source_job_id: str) -> list[str]:
    problems: list[str] = []
    paths = [Path(value) for value in sorted(glob.glob(str(Path(pattern).expanduser())))]
    if len(paths) != EXPECTED_TASK_COUNT:
        return [f"expected {EXPECTED_TASK_COUNT} payload logs, found {len(paths)}"]
    observed_tasks = []
    for path in paths:
        match = re.search(rf"\.{re.escape(source_job_id)}\.([0-9]+)\.log$", path.name)
        if not match:
            problems.append(f"cannot parse source task from log {path}")
            continue
        observed_tasks.append(int(match.group(1)))
        text = path.read_text(encoding="utf-8", errors="replace")
        if FAILURE_SIGNATURE.search(text):
            problems.append(f"failure signature in payload log: {path}")
        if "wrote " not in text or ".receipt.json" not in text:
            problems.append(f"payload log lacks terminal write marker: {path}")
    if sorted(observed_tasks) != list(range(1, EXPECTED_TASK_COUNT + 1)):
        problems.append(f"payload log task coverage changed: {sorted(observed_tasks)}")
    return problems


def validate_transfer(
    manifest_path: Path,
    *,
    expected_manifest_sha256: str,
    output_root: Path,
    log_glob: str,
    execution_commit: str,
    source_job_id: str,
) -> tuple[list[str], dict[str, Any]]:
    problems: list[str] = []
    if not re.fullmatch(r"[0-9a-f]{7,40}", execution_commit):
        problems.append(f"invalid execution commit {execution_commit!r}")
    if not source_job_id.isdigit():
        problems.append(f"invalid source job id {source_job_id!r}")
    try:
        manifest = load_manifest(manifest_path, expected_manifest_sha256)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return [f"invalid transfer manifest: {exc}"], {}
    for task in manifest["tasks"]:
        problems.extend(
            validate_task_output(
                task,
                output_root=output_root,
                manifest_sha256=expected_manifest_sha256,
                execution_commit=execution_commit,
            )
        )
    problems.extend(validate_logs(log_glob, source_job_id=source_job_id))
    marker = {
        "schema_version": 1,
        "status": "ok",
        "stage": "frozen_external_transfer",
        "source_registry_id": manifest["source_registry_id"],
        "source_run_id": manifest["source_run_id"],
        "source_decision_sha256": manifest["source_decision_sha256"],
        "manifest_sha256": expected_manifest_sha256,
        "execution_commit": execution_commit,
        "source_job_id": source_job_id,
        "task_count": EXPECTED_TASK_COUNT,
        "dataset_task_counts": {"svamp": 28, "math_500": 28},
        "official_gsm8k_test_used": False,
        "validated_at": datetime.now(timezone.utc).isoformat(),
    }
    return problems, marker


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log-glob", required=True)
    parser.add_argument("--marker", type=Path, required=True)
    parser.add_argument("--execution-commit", required=True)
    parser.add_argument("--source-job-id", required=True)
    args = parser.parse_args()
    problems, marker = validate_transfer(
        args.manifest,
        expected_manifest_sha256=args.expected_manifest_sha256,
        output_root=args.output.expanduser(),
        log_glob=args.log_glob,
        execution_commit=args.execution_commit,
        source_job_id=args.source_job_id,
    )
    if problems:
        for problem in problems:
            print(f"ERROR: {problem}")
        return 1
    atomic_write_json(args.marker.expanduser(), marker)
    print(json.dumps(marker, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
